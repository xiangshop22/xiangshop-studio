/* 效果工坊 · 一键发布更新（作者用：双击「发布更新.bat」）
 *
 * 【第1步 打包】
 *   studio/   工作台程序（不含效果），给「在线更新」用
 *   effects/  每个效果一个 zip（含 _shared 共用文件）
 *   full/     完整包（程序 + 全部效果），给第一次用的人下载
 *   manifest.json  版本清单：程序版本、每个文件的指纹；每个效果的名字、每个文件的指纹
 * 【第2步 上传】用电脑上的 Git 推到 GitHub，再推到 Gitee（update.json 里填了才推）
 *   第一次推送时 Git 会弹出登录窗口，登录一次以后就记住了
 *   没装 Git：会把打好的文件放在 _publish\repo 里，告诉你怎么在网页上传
 *   【GitHub 走代理（v7.8）】浏览器能上 GitHub、git 却连不上，是因为浏览器走了代理软件（系统代理），git 不走。
 *   推 GitHub 前按顺序找代理：update.json 的 "proxy" → git 自己配的代理 → 环境变量 → Windows 系统代理 → 本机常见代理端口；
 *   找到就只给这一次 GitHub 推送用（不改 git 全局设置，Gitee 照常直连）。带代理失败会再直连试一次。
 *   update.json 里 "proxy": "http://127.0.0.1:7890" 可以手动指定；"proxy": "off" 关掉自动找。
 *
 * 用法：node tools/publish.js [--no-push] [--out 目录]
 */
const fs = require('fs'), path = require('path'), net = require('net'), { spawnSync } = require('child_process'), readline = require('readline');
const { writeZip } = require('./zip');
const U = require('./update');
const ROOT = U.ROOT;
const args = process.argv.slice(2);
const NO_PUSH = args.includes('--no-push');
const OUT = args.includes('--out') ? path.resolve(args[args.indexOf('--out') + 1]) : path.join(ROOT, '_publish', 'repo');
const FIXED = new Date(2026, 0, 1, 0, 0, 0);                     // 固定打包时间：内容没变，zip 就一模一样
const log = (...a) => console.log('  ' + a.join(' '));

const version = (fs.readFileSync(path.join(ROOT, 'server.js'), 'utf8').match(/const VERSION = '([^']+)'/) || [])[1] || 'v0';
const read = rel => fs.readFileSync(path.join(ROOT, ...rel.split('/')));
const zipOf = (files, prefix) => writeZip(files.map(f => ({ path: prefix + f, data: read(f) })), { date: FIXED });
const short = h => h.slice(0, 10);

function findGit() {
  const cands = ['git', 'C:\\Program Files\\Git\\cmd\\git.exe', 'C:\\Program Files (x86)\\Git\\cmd\\git.exe', 'D:\\git\\cmd\\git.exe', 'D:\\Git\\cmd\\git.exe', 'D:\\Program Files\\Git\\cmd\\git.exe'];
  for (const g of cands) { try { if (spawnSync(g, ['--version'], { windowsHide: true }).status === 0) return g; } catch (e) {} }
  return null;
}
const git = (g, a, cwd, quiet, env) => spawnSync(g, a, { cwd, stdio: quiet ? 'pipe' : 'inherit', windowsHide: true, encoding: 'utf8', env: env ? { ...process.env, ...env } : process.env });

// ---------- 【第2步-代理】给 GitHub 推送找代理（v7.8） ----------
// 1) update.json 的 "proxy"（"off" = 不用代理）
function cfgProxy() {
  try { const c = JSON.parse(fs.readFileSync(path.join(ROOT, 'update.json'), 'utf8').replace(/^\uFEFF/, '')); return typeof c.proxy === 'string' ? c.proxy.trim() : ''; } catch (e) { return ''; }
}
// 2) git 自己已经配了代理 → 尊重它，不另外加
function gitProxy(g) {
  for (const k of ['http.https://github.com.proxy', 'http.https://github.com/.proxy', 'https.proxy', 'http.proxy']) {
    const r = spawnSync(g, ['config', '--get', k], { encoding: 'utf8', windowsHide: true });
    if (r.status === 0 && String(r.stdout).trim()) return String(r.stdout).trim();
  }
  return '';
}
// 3) 环境变量
const envProxy = () => process.env.HTTPS_PROXY || process.env.https_proxy || process.env.ALL_PROXY || process.env.all_proxy || process.env.HTTP_PROXY || process.env.http_proxy || '';
// 4) Windows 系统代理（Clash / v2rayN 等「设置系统代理」写在注册表里）
function parseRegProxy(out) {
  const en = /ProxyEnable\s+REG_DWORD\s+0x([0-9a-f]+)/i.exec(out);
  if (!en || parseInt(en[1], 16) === 0) return '';
  const sv = /ProxyServer\s+REG_SZ\s+(\S+)/i.exec(out);
  if (!sv) return '';
  let s = sv[1];
  if (s.includes('=')) {                                            // 形如 http=127.0.0.1:7890;https=127.0.0.1:7890;socks=127.0.0.1:7891
    const m = {}; s.split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) m[p.slice(0, i).trim().toLowerCase()] = p.slice(i + 1).trim(); });
    if (m.https || m.http) s = m.https || m.http;
    else if (m.socks) return 'socks5h://' + m.socks.replace(/^\w+:\/\//, '');
    else return '';
  }
  return /^\w+:\/\//.test(s) ? s : 'http://' + s;
}
function regProxy() {
  if (process.platform !== 'win32') return '';
  const r = spawnSync('reg', ['query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings'], { encoding: 'utf8', windowsHide: true });
  return r.status === 0 ? parseRegProxy(String(r.stdout || '')) : '';
}
// 5) 本机常见代理端口（代理软件开着、但没开「系统代理」时）
const PORTS = [[7890, 'http'], [7897, 'http'], [10809, 'http'], [33210, 'http'], [8889, 'http'], [1087, 'http'], [10808, 'socks5h'], [1080, 'socks5h']];
const portOpen = (port, host = '127.0.0.1') => new Promise(ok => {
  const s = net.connect({ port, host }); const done = v => { s.destroy(); ok(v); };
  s.setTimeout(300, () => done(false)); s.on('connect', () => done(true)); s.on('error', () => done(false));
});
async function findProxy(g) {
  const c = cfgProxy();
  if (/^(off|none|no|false|direct)$/i.test(c)) return { url: '', from: 'update.json 里设成了不用代理' };
  if (c) return { url: /^\w+:\/\//.test(c) ? c : 'http://' + c, from: 'update.json' };
  const gp = gitProxy(g); if (gp) return { url: '', from: 'git 自己配的代理 ' + gp, keep: true };
  const ep = envProxy(); if (ep) return { url: ep, from: '环境变量' };
  const rp = regProxy(); if (rp) return { url: rp, from: 'Windows 系统代理' };
  for (const [p, sch] of PORTS) if (await portOpen(p)) return { url: `${sch}://127.0.0.1:${p}`, from: '本机端口 ' + p };
  return { url: '', from: '' };
}
// 只给这一次推送加代理：-c 让 git 用；环境变量让登录窗口（Git Credential Manager）也能走代理
const withProxy = (url, a) => url ? ['-c', 'http.https://github.com.proxy=' + url, '-c', 'http.lowSpeedLimit=1000', '-c', 'http.lowSpeedTime=30', ...a] : a;
const proxyEnv = url => url ? { HTTPS_PROXY: url, https_proxy: url, HTTP_PROXY: url, http_proxy: url, ALL_PROXY: url } : null;
const ask = q => new Promise(ok => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); rl.question(q, a => { rl.close(); ok(a.trim()); }); });

(async () => {
  console.log('\n  ─────────────── 效果工坊 · 发布更新 ───────────────');
  const cfg = U.config();
  if (!cfg.github && !NO_PUSH) { log('update.json 里还没填 GitHub 仓库，先填上再发布'); process.exit(1); }
  log('工作台版本：' + version + '（改了程序要记得在 server.js 和 public/index.html 里把版本号加 1）');
  const notes = process.stdin.isTTY ? await ask('  这次更新了什么？（可不填，直接回车）：') : '';

  // ---------- 第1步 打包 ----------
  const g = NO_PUSH ? null : findGit();
  if (g && !fs.existsSync(path.join(OUT, '.git'))) {
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    log('第一次发布：下载仓库…');
    git(g, ['clone', `https://github.com/${cfg.github}.git`, OUT]);
    if (!fs.existsSync(path.join(OUT, '.git'))) { fs.mkdirSync(OUT, { recursive: true }); git(g, ['init', '-b', cfg.branch], OUT); git(g, ['remote', 'add', 'origin', `https://github.com/${cfg.github}.git`], OUT); }
  }
  if (g) git(g, ['pull', '--ff-only', 'origin', cfg.branch], OUT, true);
  fs.mkdirSync(OUT, { recursive: true });
  for (const n of fs.readdirSync(OUT)) if (n !== '.git') fs.rmSync(path.join(OUT, n), { recursive: true, force: true });
  const put = (rel, buf) => { const p = path.join(OUT, ...rel.split('/')); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, buf); };

  const prog = U.programFiles();
  const progZip = zipOf(prog, 'effect-studio/');
  const studioFile = `studio/EffectStudio-${version}-${short(U.sha(progZip))}.zip`;
  put(studioFile, progZip);
  const manifest = {
    schema: 1, published: new Date().toISOString(), notes,
    studio: { version, file: studioFile, zipSha: U.sha(progZip), size: progZip.length, files: prog.map(f => ({ path: f, sha: U.sha(read(f)) })) },
    effects: [],
  };
  const shared = U.listFiles(path.join(ROOT, 'effects', '_shared'), '_shared/');
  for (const id of U.effectIds()) {
    const own = U.listFiles(path.join(ROOT, 'effects', id), id + '/');
    const rels = [...own, ...shared];
    const z = zipOf(rels.map(r => 'effects/' + r), '');
    let meta = {}; try { meta = JSON.parse(read(`effects/${id}/effect.json`).toString('utf8').replace(/^\uFEFF/, '')); } catch (e) {}
    const file = `effects/${id}-${short(U.sha(z))}.zip`;
    put(file, z);
    manifest.effects.push({ id, name: meta.name || id, description: meta.description || '', file, zipSha: U.sha(z), size: z.length, files: rels.map(r => ({ path: r, sha: U.sha(read('effects/' + r)) })) });
    log('效果：' + (meta.name || id));
  }
  // 完整包：程序 + 全部效果（给第一次用的人）
  const fullRels = [...prog, ...U.effectIds().flatMap(id => U.listFiles(path.join(ROOT, 'effects', id), `effects/${id}/`)), ...shared.map(r => 'effects/' + r)];
  const full = writeZip([...fullRels.map(f => ({ path: 'effect-studio/' + f, data: read(f) })), { path: 'effect-studio/output/.keep', data: Buffer.alloc(0) }, { path: 'effect-studio/uploads/.keep', data: Buffer.alloc(0) }], { date: FIXED });
  put('full/EffectStudio-full.zip', full);
  put('manifest.json', Buffer.from(JSON.stringify(manifest, null, 1)));
  put('README.md', Buffer.from(`# 效果工坊 ${version}\n\n` +
    `**第一次使用：** 下载 [full/EffectStudio-full.zip](full/EffectStudio-full.zip)，解压后双击 \`start.bat\`。\n\n` +
    `**已经在用：** 打开工作台，点左上角「检查更新」，勾选后自动下载安装，不用手动下载。\n\n` +
    `- 工作台版本：${version}\n- 效果数量：${manifest.effects.length}\n- 发布时间：${manifest.published.slice(0, 10)}\n` + (notes ? `- 本次更新：${notes}\n` : '') +
    `\n这个仓库由「发布更新.bat」自动生成，请不要手动修改里面的文件。\n`));
  log(`打包完成：程序 ${version} + ${manifest.effects.length} 个效果 → ${OUT}`);

  // ---------- 第2步 上传 ----------
  if (NO_PUSH) return;
  if (!g) {
    log('');
    log('没有找到 Git，没法自动上传。两种办法：');
    log('  1. 安装 Git（https://git-scm.com/download/win），再双击「发布更新.bat」');
    log(`  2. 打开 https://github.com/${cfg.github} → Add file → Upload files，把 ${OUT} 里的所有文件拖进去提交`);
    return;
  }
  git(g, ['add', '-A'], OUT);
  const st = git(g, ['status', '--porcelain'], OUT, true);
  if (!String(st.stdout || '').trim()) { log('和上次发布的一模一样，不用上传'); }
  else {
    git(g, ['-c', 'user.name=EffectStudio', '-c', 'user.email=effect-studio@users.noreply.github.com', 'commit', '-q', '-m', `发布 ${version}${notes ? '：' + notes : ''}`], OUT);
  }
  const px = await findProxy(g);
  log('上传到 GitHub…（第一次会弹出登录窗口）' + (px.url ? '　走代理 ' + px.url + '（' + px.from + '）' : px.from ? '　' + px.from : '　没找到代理，直连'));
  const push1 = ['push', 'origin', 'HEAD:' + cfg.branch];
  let r1 = git(g, withProxy(px.url, push1), OUT, false, proxyEnv(px.url));
  if (r1.status !== 0 && px.url && px.from !== 'update.json') { log('带代理没传上去，改成直连再试一次…'); r1 = git(g, push1, OUT); }
  if (r1.status === 0) log('✔ GitHub 已更新');
  else {
    log('✘ GitHub 上传失败。浏览器能打开 GitHub、这里却连不上，一般是 git 没走代理：');
    log('   1. 确认代理软件（Clash / v2rayN 等）开着；');
    log('   2. 在代理软件里看「端口」是多少（Clash 一般 7890，Clash Verge 7897，v2rayN 10809）；');
    log('   3. 打开工作台目录的 update.json，加一行  "proxy": "http://127.0.0.1:端口",  保存后再双击「发布更新.bat」。');
    log('   Gitee 已经照常上传，用户那边能收到更新；GitHub 只是备用下载源。');
  }
  if (cfg.gitee) {
    log('上传到 Gitee…（第一次会要求输入 Gitee 账号和密码）');
    const r2 = git(g, ['-c', 'credential.https://gitee.com.provider=generic', 'push', '--force', `https://gitee.com/${cfg.gitee}.git`, 'HEAD:' + cfg.branch], OUT);   // provider=generic：省掉「auto-detection took too long」的等待
    log(r2.status === 0 ? '✔ Gitee 已更新' : '✘ Gitee 上传失败：检查 update.json 里的 gitee 仓库地址，或账号密码');
  }
  log('完成。用户打开工作台（或点「检查更新」）就能看到这次的更新。');
})().catch(e => { console.error('  发布失败：' + e.message); process.exit(1); });
