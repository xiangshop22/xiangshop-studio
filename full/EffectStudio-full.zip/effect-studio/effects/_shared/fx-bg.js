/* ===========================================================================
   fx-bg.js —— 背景库（工作台公共模块，2026-11-14 新增，工作台 v35.4，全局 FXBg）
   ---------------------------------------------------------------------------
   做什么：画整屏的「纯背景」：底色（纯色 / 对角渐变 / 中心向外渐变 / 上下渐变）
           + 一层重复图案（方格、坐标纸、点阵、菱形……）+ 构图（中心光、暗角、透视地面、光斑……）。
           画面是时间 t 的纯函数，预览和逐帧导出一致。
   谁在用：纯背景（effects/bg-pattern）。以后别的效果想要一块图案底，也直接调这里，不要再写一份。

   想加东西，只往表里加一项（面板会自动多一个按钮、缩略图自动画）：
     · 新图案   FXBg.addPattern('key', { name, tip, tile(c, s, lw, col) → [tw, th] })   【区域G2】
     · 新构图   FXBg.addDecor('key', { name, tip, draw(ctx, W, H, D, t) })              【区域G3】
     · 新版式   FXBg.addLayout('key', { name, group:'basic'|'compose'|'photo', note, pat, grad, mask, decor:[], size, line, op, gradK, decorK, tint })   【区域G5】

   区域地图
   【区域G1 颜色小工具】     hex ↔ rgb、变亮 / 变暗 / 混色
   【区域G2 图案 PATTERNS】  每种图案画一块「瓷砖」，整屏用 createPattern 平铺（每帧只平移，不重画瓷砖）
   【区域G3 构图 DECOR】     画在图案上面的光效、透视、几何；每一项 draw(ctx, 1920, 1080, D, t)
   【区域G4 底色 GRADS】     纯色 / 对角渐变 / 中心向外渐变（新）/ 上下渐变；「双色」= 中心偏向图案色
   【区域G5 版式 LAYOUTS】   一个版式 = 图案 + 底色渐变 + 图案范围 + 构图 + 各项数值；分「基础 / 构图 / 图片」三组
   【区域G6 画】             paintBase（底色）、paintTint（照片上压的底色）—— 都只在设置变了时画；paintTop（图案 + 构图，按时间画）、thumb（版式缩略图）
   =========================================================================== */
(function () {
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const TAU = Math.PI * 2;

  // ================= 【区域G1 颜色小工具】 =================
  const rgb = h => { h = String(h || '').trim(); if (/^#[0-9a-f]{3}$/i.test(h)) h = '#' + h.slice(1).split('').map(x => x + x).join('');
    if (!/^#[0-9a-f]{6}$/i.test(h)) return [32, 40, 60]; const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const css = (c, a) => `rgba(${Math.round(c[0])},${Math.round(c[1])},${Math.round(c[2])},${a == null ? 1 : +a.toFixed(4)})`;
  const mix = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
  const lite = (c, k) => mix(c, [255, 255, 255], clamp(k, 0, 1));
  const dark = (c, k) => mix(c, [0, 0, 0], clamp(k, 0, 1));
  const lum = c => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
  // 固定种子的随机数（每次导出同一个画面）
  const rng = seed => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };

  // ================= 【区域G2 图案 PATTERNS】 =================
  // tile(c, s, lw, col)：在 2D 画布 c 上画一块瓷砖（坐标已按清晰度放大好），返回瓷砖的 [宽, 高]（逻辑像素）。
  // 瓷砖必须首尾相接（左边 = 右边、上边 = 下边），铺满后看不出接缝。s = 图案大小，lw = 线条粗细。
  const PATTERNS = {
    none:    { name: '无', tip: '不要图案，只留底色和构图', size: [0, 0], tile: null },
    grid:    { name: '方格', tip: '最常用的网格', tile: (c, s, lw, col) => { c.fillStyle = col; c.fillRect(0, 0, s, lw); c.fillRect(0, 0, lw, s); return [s, s]; } },
    paper:   { name: '坐标纸', tip: '大格套小格（小格 = 大格的五分之一）', tile: (c, s, lw, col) => {
      c.fillStyle = col; c.globalAlpha = 0.38; for (let i = 1; i < 5; i++) { c.fillRect(i * s / 5, 0, lw * 0.6, s); c.fillRect(0, i * s / 5, s, lw * 0.6); }
      c.globalAlpha = 1; c.fillRect(0, 0, s, lw * 1.3); c.fillRect(0, 0, lw * 1.3, s); return [s, s]; } },
    dots:    { name: '点阵', tip: '圆点；线条粗细 = 点的大小', tile: (c, s, lw, col) => { c.fillStyle = col; c.beginPath(); c.arc(s / 2, s / 2, Math.max(0.8, lw * 1.6), 0, TAU); c.fill(); return [s, s]; } },
    diamond: { name: '菱形格', tip: '斜 45° 的网格', tile: (c, s, lw, col) => {
      c.strokeStyle = col; c.lineWidth = lw; c.beginPath(); c.moveTo(0, s / 2); c.lineTo(s / 2, 0); c.lineTo(s, s / 2); c.lineTo(s / 2, s); c.closePath(); c.stroke(); return [s, s]; } },
    argyle:  { name: '菱格花纹', tip: '实心菱形交错（毛衣花纹）', tile: (c, s, lw, col) => {
      const h = s * 1.3; c.fillStyle = col; c.globalAlpha = 0.45; c.beginPath(); c.moveTo(s / 2, 0); c.lineTo(s, h / 2); c.lineTo(s / 2, h); c.lineTo(0, h / 2); c.closePath(); c.fill();
      c.globalAlpha = 1; c.strokeStyle = col; c.lineWidth = lw * 0.7; c.setLineDash([lw * 3, lw * 3]); c.beginPath(); c.moveTo(0, 0); c.lineTo(s, h); c.moveTo(s, 0); c.lineTo(0, h); c.stroke(); c.setLineDash([]); return [s, h]; } },
    diag:    { name: '斜纹', tip: '45° 斜线条', tile: (c, s, lw, col) => {
      c.strokeStyle = col; c.lineWidth = lw; c.beginPath(); c.moveTo(-s * 0.1, s * 1.1); c.lineTo(s * 1.1, -s * 0.1);
      c.moveTo(-s * 0.6, s * 0.6); c.lineTo(s * 0.6, -s * 0.6); c.moveTo(s * 0.4, s * 1.6); c.lineTo(s * 1.6, s * 0.4); c.stroke(); return [s, s]; } },
    cross:   { name: '十字', tip: '一个个小加号', tile: (c, s, lw, col) => { const a = s * 0.13; c.fillStyle = col; c.fillRect(s / 2 - a, s / 2 - lw / 2, a * 2, lw); c.fillRect(s / 2 - lw / 2, s / 2 - a, lw, a * 2); return [s, s]; } },
    hex:     { name: '蜂窝', tip: '六边形', tile: (c, s, lw, col) => {
      const r = s / 2, h = Math.sqrt(3) * r, W = 3 * r; c.strokeStyle = col; c.lineWidth = lw; c.lineJoin = 'round';
      [[0, 0], [W, 0], [0, h], [W, h], [1.5 * r, h / 2]].forEach(([x, y]) => { c.beginPath(); for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; c[i ? 'lineTo' : 'moveTo'](x + r * Math.cos(a), y + r * Math.sin(a)); } c.closePath(); c.stroke(); });
      return [W, h]; } },
    tri:     { name: '三角网', tip: '等边三角形拼成的网', tile: (c, s, lw, col) => {
      const h = s * Math.sqrt(3); c.strokeStyle = col; c.lineWidth = lw; c.beginPath();
      [0, h / 2, h].forEach(y => { c.moveTo(-1, y); c.lineTo(s + 1, y); });
      [[0, 0, s / 2, h / 2], [s, 0, s / 2, h / 2], [s / 2, h / 2, 0, h], [s / 2, h / 2, s, h], [0, 0, -s / 2, h / 2], [0, h, -s / 2, h / 2], [s, 0, 1.5 * s, h / 2], [s, h, 1.5 * s, h / 2]]
        .forEach(([a, b, x, y]) => { c.moveTo(a, b); c.lineTo(x, y); }); c.stroke(); return [s, h]; } },
    check:   { name: '棋盘格', tip: '深浅方块交错（浓度调低更耐看）', tile: (c, s, lw, col) => { c.fillStyle = col; c.fillRect(0, 0, s, s); c.fillRect(s, s, s, s); return [s * 2, s * 2]; } },
    wave:    { name: '波浪', tip: '一行行波浪线', tile: (c, s, lw, col) => {
      const w = s * 2, h = s * 0.7, A = h * 0.28; c.strokeStyle = col; c.lineWidth = lw; c.beginPath();
      for (let x = 0; x <= w; x += 2) { const y = h / 2 + A * Math.sin(x / w * TAU); x ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); return [w, h]; } }
  };

  // ================= 【区域G3 构图 DECOR】 =================
  // D = { bg, pc（图案色 rgb）, k（构图强度 0~1.5）, sp（动起来的速度，0 = 静止）}；画在 1920×1080 的逻辑坐标上
  const ctr = (W, H) => [W / 2, H / 2, Math.hypot(W, H) / 2];
  const DECOR = {
    glow: { name: '中心光', tip: '画面中间一团柔光，慢慢呼吸', draw: (c, W, H, D, t) => {
      const [x, y, R] = ctr(W, H), a = 0.34 * D.k * (1 + 0.1 * Math.sin(t * 1.3 * D.sp));
      const g = c.createRadialGradient(x, y, 0, x, y, R * 0.62); g.addColorStop(0, css(D.pc, a)); g.addColorStop(0.45, css(D.pc, a * 0.35)); g.addColorStop(1, css(D.pc, 0));
      c.fillStyle = g; c.fillRect(0, 0, W, H); } },
    vignette: { still: true, name: '暗角', tip: '四个角压暗，视线集中到中间', draw: (c, W, H, D) => {
      const [x, y, R] = ctr(W, H), g = c.createRadialGradient(x, y, R * 0.42, x, y, R * 1.02);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, css([0, 0, 0], clamp(0.62 * D.k, 0, 0.95))); c.fillStyle = g; c.fillRect(0, 0, W, H); } },
    blobs: { name: '光斑', tip: '几团大的彩色柔光，缓缓飘动', draw: (c, W, H, D, t) => {
      const cols = [D.pc, lite(D.bg, 0.45), mix(D.pc, D.bg, 0.4), lite(D.pc, 0.3)], sp = D.sp * 0.18;
      [[0.18, 0.22, 0.42, 0], [0.84, 0.3, 0.36, 1.7], [0.7, 0.86, 0.46, 3.1], [0.22, 0.8, 0.32, 4.4]].forEach(([fx, fy, fr, ph], i) => {
        const x = W * (fx + 0.05 * Math.sin(t * sp + ph)), y = H * (fy + 0.06 * Math.cos(t * sp * 0.8 + ph)), r = W * fr;
        const g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, css(cols[i], 0.3 * D.k)); g.addColorStop(1, css(cols[i], 0));
        c.fillStyle = g; c.fillRect(0, 0, W, H); }); } },
    floor: { name: '透视地面', tip: '下半屏一片往远处延伸的网格地面，慢慢往前走', draw: (c, W, H, D, t) => {
      const y0 = H * 0.56, vx = W / 2, hh = H - y0, a = clamp(0.6 * D.k, 0, 1);
      c.save(); c.beginPath(); c.rect(0, y0, W, hh); c.clip();
      c.lineWidth = 1.6; const N = 22;
      for (let i = -N; i <= N; i++) {                                   // 往消失点收拢的竖线
        const xb = vx + i * W * 0.14, g = c.createLinearGradient(0, y0, 0, H); g.addColorStop(0, css(D.pc, 0)); g.addColorStop(1, css(D.pc, a));
        c.strokeStyle = g; c.beginPath(); c.moveTo(vx + i * 2, y0); c.lineTo(vx + (xb - vx) * 1.7, H + hh * 0.7); c.stroke();
      }
      const ph = ((t * 0.55 * D.sp) % 1 + 1) % 1;                        // 横线：近大远小，往前走
      for (let n = 1; n < 40; n++) {
        const z = n - ph; if (z <= 0.15) continue;
        const y = y0 + hh * 0.9 / z; if (y > H + 4) continue;
        c.strokeStyle = css(D.pc, a * clamp((y - y0) / hh * 1.3, 0, 1)); c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke();
      }
      c.restore();
      const g = c.createLinearGradient(0, y0 - 90, 0, y0 + 60);           // 地平线上一道光
      g.addColorStop(0, css(D.pc, 0)); g.addColorStop(0.6, css(D.pc, 0.28 * D.k)); g.addColorStop(1, css(D.pc, 0));
      c.fillStyle = g; c.fillRect(0, y0 - 90, W, 150); } },
    beams: { name: '放射光束', tip: '从中心往外的一道道光，慢慢转', draw: (c, W, H, D, t) => {
      const [x, y, R] = ctr(W, H), n = 14, rot = t * 0.05 * D.sp;
      const g = c.createRadialGradient(x, y, 0, x, y, R); g.addColorStop(0, css(D.pc, 0.15 * D.k)); g.addColorStop(1, css(D.pc, 0));
      c.fillStyle = g; c.beginPath();
      for (let i = 0; i < n; i++) { const a = rot + i * TAU / n; c.moveTo(x, y); c.arc(x, y, R * 1.1, a - 0.06, a + 0.06); c.closePath(); }
      c.fill(); } },
    rings: { name: '光环波纹', tip: '一圈圈从中心往外扩散的细圆环', draw: (c, W, H, D, t) => {
      const [x, y, R] = ctr(W, H), gap = 150, ph = ((t * 0.25 * D.sp) % 1 + 1) % 1;
      c.lineWidth = 2;
      for (let i = 0; i < R / gap + 1; i++) { const r = (i + ph) * gap; if (r < 4) continue; c.strokeStyle = css(D.pc, 0.42 * D.k * clamp(1 - r / R, 0, 1)); c.beginPath(); c.arc(x, y, r, 0, TAU); c.stroke(); } } },
    shapes: { name: '几何漂浮', tip: '圆、方、三角、加号的线框在画面里慢慢飘', draw: (c, W, H, D, t) => {
      const R = rng(7), sp = D.sp; c.lineWidth = 3; c.strokeStyle = css(D.pc, 0.4 * D.k);
      for (let i = 0; i < 16; i++) {
        const kind = i % 4, sz = 26 + R() * 56, x0 = R() * W, y0 = R() * H, ph = R() * TAU, vr = (R() - 0.5) * 0.6;
        const x = x0 + Math.sin(t * 0.21 * sp + ph) * 30, y = ((y0 - t * 14 * sp) % (H + 200) + H + 200) % (H + 200) - 100;
        c.save(); c.translate(x, y); c.rotate(ph + t * vr * sp); c.beginPath();
        if (kind === 0) c.arc(0, 0, sz / 2, 0, TAU);
        else if (kind === 1) c.rect(-sz / 2, -sz / 2, sz, sz);
        else if (kind === 2) { c.moveTo(0, -sz / 2); c.lineTo(sz * 0.45, sz * 0.35); c.lineTo(-sz * 0.45, sz * 0.35); c.closePath(); }
        else { c.moveTo(-sz / 2, 0); c.lineTo(sz / 2, 0); c.moveTo(0, -sz / 2); c.lineTo(0, sz / 2); }
        c.stroke(); c.restore();
      } } },
    stars: { name: '闪烁光点', tip: '满屏小光点，一闪一闪', draw: (c, W, H, D, t) => {
      const R = rng(19); c.fillStyle = css(D.pc, 1);
      for (let i = 0; i < 90; i++) { const x = R() * W, y = R() * H, r = 1 + R() * 2.6, ph = R() * TAU, f = 0.6 + R() * 1.4;
        c.globalAlpha = clamp(D.k * (0.25 + 0.55 * (0.5 + 0.5 * Math.sin(t * f * D.sp + ph))), 0, 1); c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
      c.globalAlpha = 1; } },
    corners: { still: true, name: '科技角框', tip: '四个角的直角框 + 细边线，像取景框', draw: (c, W, H, D) => {
      const m = 64, L = 130, a = clamp(0.75 * D.k, 0, 1); c.strokeStyle = css(D.pc, a); c.lineWidth = 4; c.lineCap = 'square'; c.beginPath();
      [[m, m, 1, 1], [W - m, m, -1, 1], [m, H - m, 1, -1], [W - m, H - m, -1, -1]].forEach(([x, y, sx, sy]) => { c.moveTo(x + sx * L, y); c.lineTo(x, y); c.lineTo(x, y + sy * L); });
      c.stroke(); c.lineWidth = 1.5; c.strokeStyle = css(D.pc, a * 0.35); c.strokeRect(m + 22, m + 22, W - 2 * m - 44, H - 2 * m - 44);
      c.fillStyle = css(D.pc, a * 0.8); for (let i = 0; i < 9; i++) c.fillRect(W / 2 - 160 + i * 40, m - 2, 14, 4); c.lineCap = 'butt'; } },
    grain: { still: true, name: '颗粒质感', tip: '一层很细的噪点，像胶片', draw: (c, W, H, D) => {
      if (!grainTile) { grainTile = document.createElement('canvas'); grainTile.width = grainTile.height = 256; const g = grainTile.getContext('2d'), R = rng(3), im = g.createImageData(256, 256);
        for (let i = 0; i < im.data.length; i += 4) { const v = R() * 255; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 255; } g.putImageData(im, 0, 0); }
      c.globalAlpha = clamp(0.09 * D.k, 0, 0.4); c.globalCompositeOperation = 'overlay'; c.fillStyle = c.createPattern(grainTile, 'repeat'); c.fillRect(0, 0, W, H);
      c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1; } }
  };
  let grainTile = null;

  // ================= 【区域G4 底色 GRADS】 =================
  // k = 渐变强度 0~1；two = 「双色」：亮的那一头偏向图案色
  const GRADS = [['solid', '纯色'], ['diag', '对角渐变'], ['center', '中心向外'], ['vert', '上下渐变']];
  function fillGrad(c, W, H, mode, bg, pc, k, two) {
    const hi = two ? mix(lite(bg, 0.12 * k), pc, 0.42 * k) : lite(bg, (lum(bg) > 0.7 ? 0.5 : 0.24) * k);
    const lo = dark(bg, (lum(bg) > 0.7 ? 0.18 : 0.55) * k);
    let g;
    if (mode === 'center') {                     // 从画面中心往外：中心亮、四周暗（新，2026-11-14）
      const [x, y, R] = ctr(W, H); g = c.createRadialGradient(x, y, 0, x, y, R);
      g.addColorStop(0, css(hi)); g.addColorStop(0.5, css(mix(hi, bg, 0.75))); g.addColorStop(1, css(lo));
    } else if (mode === 'diag') {                // 左上亮 → 右下暗（和以前的效果一样）
      g = c.createLinearGradient(0, 0, W, H); g.addColorStop(0, css(hi)); g.addColorStop(0.5, css(bg)); g.addColorStop(1, css(lo));
    } else if (mode === 'vert') {
      g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, css(hi)); g.addColorStop(0.55, css(bg)); g.addColorStop(1, css(lo));
    }
    c.fillStyle = g || css(bg); c.fillRect(0, 0, W, H);
  }
  // 面板色块（一个色块 = 渐变的样子），给别的效果的配色块用
  const gradCss = (mode, bgHex, pcHex, k, two) => {
    const bg = rgb(bgHex), pc = rgb(pcHex);
    const hi = two ? mix(lite(bg, 0.12 * k), pc, 0.42 * k) : lite(bg, 0.24 * k), lo = dark(bg, 0.55 * k);
    if (mode === 'center') return `radial-gradient(circle,${css(hi)},${css(bg)} 55%,${css(lo)})`;
    if (mode === 'diag') return `linear-gradient(135deg,${css(hi)},${css(bg)},${css(lo)})`;
    if (mode === 'vert') return `linear-gradient(180deg,${css(hi)},${css(bg)},${css(lo)})`;
    return css(bg);
  };

  // 图案范围（遮罩）：哪里有图案
  const MASKS = [['none', '铺满'], ['edge', '四周淡出'], ['hole', '中间留空'], ['up', '上淡下浓']];
  // 图案范围不用 destination-in 遮罩（没有显卡时整屏合成很慢，实测 55 → 20 fps），
  // 改成「分圈画」：把画面按到中心的距离（或从上到下）切成 16 圈，每圈用自己的透明度画一次图案，每个像素只画一次。
  // 一圈透明度只差约 6%，乘上图案浓度后看不出台阶。
  // 更快的办法（效果用）：图案照常铺满，上面盖一层「底色」，盖的透明度 = 1 - 范围；底色不动，所以这层只画一次。
  // 看起来和遮罩完全一样（底色 + 图案 × 范围），前提是图案和底色之间没有别的东西（有照片时不能用，退回分圈画）。
  function paintCover(c, S, W = 1920, H = 1080) {
    c.clearRect(0, 0, W, H); if (!S.mask || S.mask === 'none') return;
    fillGrad(c, W, H, S.grad, S.bg, S.pc, S.gradK, S.two);
    const [x, y, R] = ctr(W, H); let g;
    if (S.mask === 'edge') { g = c.createRadialGradient(x, y, R * 0.18, x, y, R * 0.95); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, '#000'); }
    else if (S.mask === 'hole') { g = c.createRadialGradient(x, y, R * 0.16, x, y, R * 0.72); g.addColorStop(0, '#000'); g.addColorStop(1, 'rgba(0,0,0,0)'); }
    else { g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgba(0,0,0,0.92)'); g.addColorStop(1, 'rgba(0,0,0,0)'); }
    c.globalCompositeOperation = 'destination-in'; c.fillStyle = g; c.fillRect(0, 0, W, H); c.globalCompositeOperation = 'source-over';
  }
  const BANDS = 16;
  function maskBands(c, W, H, mode, op, fill) {
    if (!mode || mode === 'none') { c.globalAlpha = op; fill(); c.globalAlpha = 1; return; }
    const [x, y, R] = ctr(W, H), ss = k => k * k * (3 - 2 * k);
    for (let i = 0; i < BANDS; i++) {
      const k0 = i / BANDS, k1 = (i + 1) / BANDS, km = (k0 + k1) / 2;
      let a; c.save(); c.beginPath();
      if (mode === 'up') { a = 0.08 + 0.92 * km; c.rect(0, H * k0, W, H / BANDS + 1); }
      else {
        const r0 = mode === 'edge' ? R * 0.18 : R * 0.16, r1 = mode === 'edge' ? R * 0.95 : R * 0.72;
        const ra = i === 0 ? 0 : r0 + (r1 - r0) * k0, rb = i === BANDS - 1 ? R * 1.05 : r0 + (r1 - r0) * k1;
        a = mode === 'edge' ? 1 - ss(km) : ss(km);
        if (i === 0) a = mode === 'edge' ? 1 : 0; if (i === BANDS - 1) a = mode === 'edge' ? 0 : 1;
        c.arc(x, y, rb, 0, TAU); if (ra > 0) { c.moveTo(x + ra, y); c.arc(x, y, ra, 0, TAU, true); }
      }
      if (a > 0.004) { c.clip(); c.globalAlpha = op * a; fill(); }
      c.restore();
    }
  }

  // ================= 【区域G5 版式 LAYOUTS】 =================
  // group：basic = 基础（只有底色 + 图案，没有别的变化）；compose = 构图（加光效 / 透视 / 几何）；photo = 图片（照片 + 图案蒙层）
  // 没写的项用 DEF 里的；颜色、图片、速度不在版式里（换版式不会把你选的颜色换掉）
  const DEF = { pat: 'grid', grad: 'center', mask: 'none', decor: [], size: 80, line: 1.5, op: 22, gradK: 70, decorK: 100, tint: 60 };
  const LAYOUTS = {
    grid:      { group: 'basic', name: '方格', pat: 'grid', grad: 'center', size: 80, line: 1.5, op: 22, note: '中心向外渐变 + 方格' },
    paper:     { group: 'basic', name: '坐标纸', pat: 'paper', grad: 'solid', size: 160, line: 1.5, op: 26, note: '纯色 + 大格套小格' },
    dots:      { group: 'basic', name: '点阵', pat: 'dots', grad: 'center', size: 44, line: 2, op: 34, note: '中心向外渐变 + 圆点' },
    diamond:   { group: 'basic', name: '菱形格', pat: 'diamond', grad: 'diag', size: 96, line: 1.5, op: 22, note: '对角渐变 + 45° 菱形格' },
    diag:      { group: 'basic', name: '斜纹', pat: 'diag', grad: 'diag', size: 34, line: 2, op: 17, note: '对角渐变 + 细斜线' },
    hex:       { group: 'basic', name: '蜂窝', pat: 'hex', grad: 'center', size: 56, line: 1.5, op: 20, note: '中心向外渐变 + 六边形' },
    wave:      { group: 'basic', name: '波浪', pat: 'wave', grad: 'vert', size: 50, line: 2, op: 18, note: '上下渐变 + 波浪线' },
    check:     { group: 'basic', name: '棋盘格', pat: 'check', grad: 'center', size: 90, line: 1, op: 6, note: '中心向外渐变 + 很淡的棋盘格' },
    spotGrid:  { group: 'compose', name: '聚光方格', pat: 'grid', grad: 'center', mask: 'edge', size: 80, line: 1.5, op: 30, decor: ['glow', 'vignette'], note: '方格只在中间一片，四周淡出 + 中心光 + 暗角' },
    floor:     { group: 'compose', name: '透视地面', pat: 'dots', grad: 'vert', mask: 'up', size: 48, line: 1.5, op: 14, decor: ['floor', 'glow', 'stars'], note: '下半屏网格地面往前走，上面星点闪烁' },
    blobDia:   { group: 'compose', name: '光斑菱形', pat: 'diamond', grad: 'diag', mask: 'edge', size: 110, line: 1.5, op: 20, decor: ['blobs', 'vignette'], note: '菱形格 + 几团飘动的彩色光斑' },
    tech:      { group: 'compose', name: '科技边框', pat: 'paper', grad: 'center', mask: 'edge', size: 160, line: 1.5, op: 26, decor: ['corners', 'glow', 'vignette'], note: '坐标纸 + 四角取景框，适合数据 / 科技' },
    ripple:    { group: 'compose', name: '光环波纹', pat: 'dots', grad: 'center', mask: 'hole', size: 40, line: 1.8, op: 30, decor: ['rings', 'glow'], note: '一圈圈从中心扩散，点阵中间空出来' },
    beams:     { group: 'compose', name: '放射光束', pat: 'none', grad: 'center', decor: ['beams', 'glow', 'vignette'], note: '从中心往外慢慢转的光束，适合揭晓 / 重点' },
    shapes:    { group: 'compose', name: '几何漂浮', pat: 'hex', grad: 'diag', mask: 'edge', size: 60, line: 1.2, op: 12, decor: ['shapes', 'blobs'], note: '淡蜂窝 + 漂浮的几何线框' },
    blank:     { group: 'compose', name: '中间留白', pat: 'grid', grad: 'center', mask: 'hole', size: 72, line: 1.5, op: 28, decor: ['glow', 'vignette'], note: '方格只在四周，中间空出来放字' },
    stars:     { group: 'compose', name: '星点光斑', pat: 'none', grad: 'center', decor: ['stars', 'blobs', 'grain'], note: '满屏闪烁光点 + 柔光 + 颗粒质感' },
    film:      { group: 'compose', name: '颗粒质感', pat: 'diag', grad: 'diag', size: 30, line: 1.5, op: 8, decor: ['grain', 'glow', 'vignette'], note: '胶片颗粒 + 很淡的斜纹，适合人文 / 复古' },
    photoGrid: { group: 'photo', name: '照片 + 方格', pat: 'grid', grad: 'center', mask: 'edge', size: 80, line: 1.5, op: 30, decor: ['vignette'], tint: 55, note: '照片压上一层底色，再盖方格' },
    photoDots: { group: 'photo', name: '照片 + 点阵', pat: 'dots', grad: 'center', size: 26, line: 1.6, op: 40, decor: ['vignette'], tint: 68, note: '像网点印刷的效果' },
    photoTech: { group: 'photo', name: '照片 + 角框', pat: 'paper', grad: 'diag', mask: 'edge', size: 160, line: 1.2, op: 20, decor: ['corners', 'vignette'], tint: 60, note: '照片 + 坐标纸 + 取景框' },
    photoFloor:{ group: 'photo', name: '照片 + 地面', pat: 'none', grad: 'vert', decor: ['floor', 'vignette'], tint: 62, note: '照片下半屏铺一片透视网格地面' }
  };
  const GROUPS = [['basic', '基础', '只有底色 + 图案，干净'], ['compose', '构图', '加光效 / 透视 / 几何，画面更丰富'], ['photo', '图片', '先上传一张照片，再盖图案']];
  const layoutOf = k => Object.assign({}, DEF, LAYOUTS[k] || LAYOUTS.spotGrid);

  // ================= 【区域G6 画】 =================
  const patCache = new Map();
  function patternFor(c, S, q, boost) {
    const P = PATTERNS[S.pat]; if (!P || !P.tile) return null;
    const s = Math.max(6, S.size * (boost || 1)), lw = Math.max(0.6, S.line * (boost ? boost * 1.6 : 1)) / 1;
    const key = [S.pat, s, lw, S.pcHex, q].join('|');
    let hit = patCache.get(key);
    if (!hit) {
      // 先量瓷砖多大，再按清晰度 q 画一块真正的瓷砖
      const probe = document.createElement('canvas').getContext('2d'); const [tw, th] = P.tile(probe, s, lw, '#000');
      const cv = document.createElement('canvas'); cv.width = Math.max(1, Math.round(tw * q)); cv.height = Math.max(1, Math.round(th * q));
      const g = cv.getContext('2d'); g.scale(cv.width / tw, cv.height / th); P.tile(g, s, lw, S.pcHex);
      hit = { cv, tw, th }; patCache.set(key, hit); if (patCache.size > 40) patCache.delete(patCache.keys().next().value);
    }
    const pat = c.createPattern(hit.cv, 'repeat');
    return { pat, tw: hit.tw, th: hit.th, sx: hit.tw / hit.cv.width, sy: hit.th / hit.cv.height };
  }
  const DIRS = { diag: [0.7071, 0.7071], up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] };
  // 把面板参数整理成一份设置（缺的、坏的都兜住）
  function norm(o) {
    const n = (v, d, a, b) => { v = +v; return Number.isFinite(v) ? clamp(v, a, b) : d; };
    const decor = (Array.isArray(o.decor) ? o.decor : String(o.decor || '').split(',')).map(x => String(x).trim()).filter(x => DECOR[x]);
    return {
      pat: PATTERNS[o.pat] ? o.pat : 'grid', grad: GRADS.some(g => g[0] === o.grad) ? o.grad : 'center', two: o.gradMix === 'two',
      mask: MASKS.some(m => m[0] === o.mask) ? o.mask : 'none', decor,
      bgHex: o.bg || '#13244f', pcHex: o.pc || '#9ff0ff', bg: rgb(o.bg || '#13244f'), pc: rgb(o.pc || '#9ff0ff'),
      size: n(o.size, 80, 6, 600), line: n(o.line, 1.5, 0.3, 30), op: n(o.op, 22, 0, 100) / 100,
      gradK: n(o.gradK, 70, 0, 100) / 100, decorK: n(o.decorK, 100, 0, 150) / 100, tint: n(o.tint, 60, 0, 100) / 100,
      speed: n(o.speed, 1, 0, 5), dir: DIRS[o.dir] ? o.dir : 'diag', photo: !!o.photo
    };
  }
  // 底色：只在设置变了时画（不随时间变）
  function paintBase(c, S, W = 1920, H = 1080) { fillGrad(c, W, H, S.grad, S.bg, S.pc, S.gradK, S.two); }
  // 照片上面压的一层底色（不随时间变；效果把它画在照片和图案之间单独一张画布上）
  function paintTint(c, S, W = 1920, H = 1080) { c.clearRect(0, 0, W, H); if (S.photo && S.tint > 0) { c.globalAlpha = S.tint; fillGrad(c, W, H, S.grad, S.bg, S.pc, S.gradK, S.two); c.globalAlpha = 1; } }
  // 上层：图案（带范围）→ 构图。part 见 paintDecor；part = 'pattern' = 只画铺满的图案（范围交给 paintCover）
  function paintTop(c, S, t, q, W = 1920, H = 1080, boost, part) {
    c.clearRect(0, 0, W, H);
    const pp = S.op > 0 && patternFor(c, S, q, boost);
    if (pp) {
      const d = DIRS[S.dir], v = 22 * S.speed * t;                    // 图案平移：每秒 22px × 速度
      const ox = ((d[0] * v) % pp.tw + pp.tw) % pp.tw, oy = ((d[1] * v) % pp.th + pp.th) % pp.th;
      try { pp.pat.setTransform(new DOMMatrix().translateSelf(ox - pp.tw, oy - pp.th).scaleSelf(pp.sx, pp.sy)); } catch (e) { }
      c.fillStyle = pp.pat; maskBands(c, W, H, part === 'pattern' ? 'none' : S.mask, S.op, () => c.fillRect(0, 0, W, H));
    }
    if (part !== 'pattern') paintDecor(c, S, t, W, H, part);
  }
  // 构图；part = 'move'（只画会动的）/ 'still'（只画不动的：暗角、角框、颗粒）/ 不传 = 全画
  function paintDecor(c, S, t, W = 1920, H = 1080, part) {
    const D = { bg: S.bg, pc: S.pc, k: S.decorK, sp: S.speed };
    S.decor.forEach(k => { const st = !!DECOR[k].still || S.speed <= 0; if (part === 'move' && st || part === 'still' && !st) return;
      try { c.save(); DECOR[k].draw(c, W, H, D, t); c.restore(); } catch (e) { } });
  }
  // 这一组设置会不会随时间变（不会的话效果每帧不用重画）
  const moving = S => S.speed > 0 && (S.op > 0 && S.pat !== 'none' || S.decor.some(k => !DECOR[k].still));

  // 版式缩略图：240×135，同一组设置只画一次；boost = 图案放大几倍（缩略图里图案太小看不清）
  const thumbCache = new Map();
  function thumb(o, w = 240, h = 135, boost = 2.2) {
    const S = norm(o), key = JSON.stringify(S) + w + '|' + boost;
    if (thumbCache.has(key)) return thumbCache.get(key);
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h; const c = cv.getContext('2d'), q = w / 1920;
    c.setTransform(q, 0, 0, q, 0, 0); paintBase(c, S);
    if (S.photo) { c.fillStyle = 'rgba(255,255,255,.18)'; c.beginPath(); c.moveTo(0, 1080); c.lineTo(600, 420); c.lineTo(980, 800); c.lineTo(1300, 520); c.lineTo(1920, 1080); c.fill(); c.beginPath(); c.arc(1500, 260, 110, 0, TAU); c.fill(); }
    if (S.photo && S.tint > 0) { c.globalAlpha = S.tint; fillGrad(c, 1920, 1080, S.grad, S.bg, S.pc, S.gradK, S.two); c.globalAlpha = 1; }
    const top = document.createElement('canvas'); top.width = w; top.height = h; const tc = top.getContext('2d'); tc.setTransform(q, 0, 0, q, 0, 0);
    paintTop(tc, S, 1.5, q, 1920, 1080, boost);
    c.setTransform(1, 0, 0, 1, 0, 0); c.drawImage(top, 0, 0);
    const url = cv.toDataURL('image/png'); thumbCache.set(key, url); if (thumbCache.size > 120) thumbCache.delete(thumbCache.keys().next().value);
    return url;
  }

  window.FXBg = {
    PATTERNS, DECOR, GRADS, MASKS, LAYOUTS, GROUPS, DEF, DIRS,
    layoutOf, norm, paintBase, paintTint, paintTop, paintDecor, paintCover, moving, thumb, gradCss, fillGrad, rgb, css,
    addPattern: (k, d) => { PATTERNS[k] = d; },
    addDecor: (k, d) => { DECOR[k] = d; },
    addLayout: (k, d) => { LAYOUTS[k] = d; }
  };
})();
