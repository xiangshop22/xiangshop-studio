/* 效果工坊 · 卡片类效果共用工具（fx-cards.js）
 *
 * 所有「卡片飞入」类效果共用这一套：三种卡（文字 / 照片 / 视频）、内容不够时的循环填充、
 * 节奏时间轴、卡片编辑器。效果自己只负责「卡片摆在哪、怎么动」。
 *
 * 【区域C1 数据】读参数里的卡片内容 → 规范成 { count, items, ui }
 * 【区域C2 填充】内容数量和卡片数量对不齐时，用已有的内容循环填充，绝不留空白卡片
 * 【区域C3 节奏】每张卡片的 进场 / 停留 / 退出 时间点（和发牌展开一致）
 * 【区域C4 画面】卡片外观：文字卡 / 照片卡 / 视频卡 / 占位卡，和文字标记（**重点** 等）
 * 【区域C5 编辑器】右侧面板里的卡片编辑器：数量、三种卡切换、上传、节奏、每张单独调时长
 *
 * 效果里的用法（见各效果 effect.html 开头的区域地图）：
 *   const D = FXCards.read(P, { min:1, max:12, def:6 });      // 读内容
 *   const list = FXCards.fill(D.items, 张数);                  // 按张数填充，不留空
 *   const TM = FXCards.timing(list, D.ui, P, 要不要退场);       // 节奏
 *   FXCards.card(卡片元素, 内容, { W, H, ... , loads });        // 画一张卡
 *   FXCards.editor({ ... });                                   // 挂编辑器
 */
(function () {
  const FX = {};
  window.FXCards = FX;

  // ---------- 小工具 ----------
  const num = FX.num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const clamp = FX.clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const prog = FX.prog = (t, a, b) => (b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1));
  const lerp = FX.lerp = (a, b, k) => a + (b - a) * k;
  FX.backOut = s => x => 1 + (s + 1) * Math.pow(x - 1, 3) + s * Math.pow(x - 1, 2);   // GSAP back.out(s)
  FX.backIn = s => x => (s + 1) * x * x * x - s * x * x;                              // GSAP back.in(s)
  FX.cubicOut = x => 1 - Math.pow(1 - x, 3);
  FX.cubicIn = x => x * x * x;
  FX.cubicInOut = x => x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
  FX.smooth = x => x * x * (3 - 2 * x);
  // 固定随机：同一个种子永远得到同一串数，保证逐帧导出和预览完全一致
  FX.rnd = (seed, k) => {
    let h = (seed * 374761393 + k * 668265263) >>> 0;
    h = (h ^ (h >>> 13)) >>> 0; h = Math.imul(h, 1274126177) >>> 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  FX.rndAt = (seed, k, a, b) => a + (b - a) * FX.rnd(seed, k);
  // 每帧写样式前先比一下：值没变就不写。浏览器对「写了同样的值」也会标记为脏，省下来就是省重绘
  FX.put = (el, tr, op) => {
    if (el.__tr !== tr) { el.__tr = tr; el.style.transform = tr; }
    const o = (op <= 0 ? 0 : op >= 1 ? 1 : op).toFixed(3);
    if (el.__op !== o) { el.__op = o; el.style.opacity = o; }
  };
  FX.ACC = { orange: '#f28c0f', blue: '#4c9aff', green: '#3ecf8e', pink: '#f472b6', yellow: '#f5c542', red: '#ef5b5b', purple: '#a78bfa', cyan: '#2dd4e0' };
  FX.RATIO = { '16:9': 9 / 16, '4:3': 3 / 4, '3:2': 2 / 3, '1:1': 1, '3:4': 4 / 3, '2:3': 3 / 2, '9:16': 16 / 9 };
  FX.accOf = P => FX.ACC[P && P.accent] || (/^#[0-9a-f]{6}$/i.test((P && P.accent) || '') ? P.accent : FX.ACC.orange);
  FX.ratioOf = (P, d) => FX.RATIO[P && P.ratio] || FX.RATIO[d || '16:9'];
  // ---------- 裁剪保留哪一块（object-position） ----------
  FX.FOCUS = { center: '50% 50%', top: '50% 0%', bottom: '50% 100%', left: '0% 50%', right: '100% 50%' };
  FX.focusPos = f => FX.FOCUS[f] || FX.FOCUS.center;
  // 图片比例最接近哪个卡片比例选项
  FX.bestRatio = (iw, ih) => {
    const r = ih / iw; let best = '16:9', d = 1e9;
    for (const k in FX.RATIO) { const x = Math.abs(Math.log(FX.RATIO[k] / r)); if (x < d) { d = x; best = k; } }
    return best;
  };
  // 按「铺满」放进这个比例的卡里，会裁掉多少（面积比）、裁的是上下还是左右
  FX.cropInfo = (iw, ih, cardRatio) => {
    if (!(iw > 0 && ih > 0 && cardRatio > 0)) return null;
    const ir = ih / iw;
    const same = Math.abs(Math.log(ir / cardRatio)) < 0.1;        // 差不到 10% 就当一样
    const vis = ir > cardRatio ? cardRatio / ir : ir / cardRatio;
    return { ir, same, loss: 1 - vis, axis: ir > cardRatio ? 'v' : 'h', best: FX.bestRatio(iw, ih) };
  };

  // ---------- 【区域C4】文字标记（和 Markdown 一致，见规则 3）----------
  const esc = FX.esc = x => String(x == null ? '' : x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  // **重点** / ***重点*** → 加粗 + 主题色；*文字* → 只加粗；~划掉~ / ~~划掉~~ → 划掉
  FX.mark = x => esc(x)
    .replace(/\*\*\*(.+?)\*\*\*/g, '<em class="hi">$1</em>')
    .replace(/\*\*(.+?)\*\*/g, '<em class="hi">$1</em>')
    .replace(/\*(.+?)\*/g, '<b>$1</b>')
    .replace(/~~(.+?)~~/g, '<s>$1</s>')
    .replace(/~(.+?)~/g, '<s>$1</s>');
  const plain = FX.plain = x => String(x == null ? '' : x).replace(/\*{1,3}(.+?)\*{1,3}/g, '$1').replace(/~{1,2}(.+?)~{1,2}/g, '$1');
  // 标题字号随字数自动缩小（按卡片尺寸算，导出逐帧一致）
  FX.titleSize = (W, H, txt, room) => {
    const n = Array.from(txt).reduce((a, ch) => a + ((ch.codePointAt(0) || 0) >= 0x2e80 ? 1 : 0.55), 0) || 1;
    const inner = W * 0.78, cap = H * (room == null ? 0.46 : room);
    let fs = Math.min(W * 0.17, H * 0.3);
    for (; fs > W * 0.035; fs -= 1) {
      const perLine = Math.max(1, Math.floor(inner / (fs * 1.03)));
      if (Math.ceil(n / perLine) * fs * 1.22 <= cap) break;
    }
    return fs;
  };

  // ---------- 【区域C1 数据】 ----------
  // 返回 { count, items, ui }；items 是用户在编辑器里填的原始卡片（可能有空的）
  const TDEF = FX.TDEF = { stagger: 0.12, in: 0.8, hold: 2, out: 0.55, gap: 0.08, mode: 'lifo' };
  const MODES = FX.MODES = ['lifo', 'fifo', 'together', 'custom'];
  FX.read = (P, o) => {
    o = o || {};
    const min = o.min || 1, max = o.max || 12, def = o.def || 6;
    let C = P && P.cards;
    if (typeof C === 'string') { try { C = JSON.parse(C); } catch (e) { C = null; } }
    let items, count;
    if (C && Array.isArray(C.items)) {
      count = clamp(Math.round(num(C.count, C.items.length) || def), min, max);
      items = C.items.slice(0, Math.max(count, C.items.length));
    } else if (P && Array.isArray(P.images) && P.images.length) {
      items = P.images.filter(Boolean).map(u => ({ type: 'image', img: u }));
      count = clamp(items.length, min, max);
    } else {
      count = clamp(def, min, max);
      items = Array.from({ length: count }, () => ({ type: 'image', img: '' }));
    }
    while (items.length < count) items.push({ type: 'image', img: '' });
    const u0 = (C && C.ui) || {};
    const ui = {
      stagger: Math.max(0, num(u0.stagger, TDEF.stagger)),
      in: Math.max(0.05, num(u0.in, TDEF.in)),
      hold: Math.max(0, num(u0.hold, TDEF.hold)),
      out: Math.max(0.05, num(u0.out, TDEF.out)),
      gap: Math.max(0, num(u0.gap, TDEF.gap)),
      mode: MODES.includes(u0.mode) ? u0.mode : TDEF.mode
    };
    return { count, items: items.slice(0, count), all: items, ui };
  };

  // ---------- 【区域C2 填充】内容不够就用已有的循环填，不留空白卡 ----------
  const has = FX.hasContent = it => !!it && (
    it.type === 'hole' ? true                       // 镂空卡本身就是「内容」（透明窗口），不用借别人的
      : it.type === 'text' ? !!String(it.title || it.sub || '').trim()
        : it.type === 'video' ? !!it.video
          : !!it.img);
  // items：用户填的卡片；n：画面上要几张。返回长度 n 的数组，每一项都有内容（除非一张都没填）
  FX.fill = (items, n) => {
    items = Array.isArray(items) ? items : [];
    const src = items.filter(has);
    const out = [];
    for (let i = 0; i < n; i++) {
      const it = items[i];
      if (has(it)) out.push(it);                       // 自己有内容 → 用自己的
      else if (src.length) out.push(src[i % src.length]); // 空的 → 循环借用前面有内容的
      else out.push(it || { type: 'image', img: '' });    // 一张都没填 → 占位卡（有编号，不是空白）
    }
    return out;
  };
  // 有几张是「借来的」，编辑器里给个说明
  FX.fillInfo = (items, n) => {
    const real = (Array.isArray(items) ? items : []).filter(has).length;
    return { real, borrowed: Math.max(0, n - real), n };
  };

  // ---------- 【区域C3 节奏】每张卡片 进场 → 停留 → 退出 ----------
  // mode：lifo 后出现的先退 / fifo 先出现的先退 / together 同时退 / custom 按每张自己的停留时长
  FX.timing = (items, ui, P, exitOn) => {
    ui = ui || {}; P = P || {};
    const pos = (x, d) => Math.max(0, num(x, d));
    const st = pos(ui.stagger, TDEF.stagger);
    const inD = Math.max(0.05, num(ui.in, TDEF.in));
    const outD = Math.max(0.05, num(ui.out, TDEF.out));
    const H = pos(ui.hold, TDEF.hold);
    const gap = pos(ui.gap, TDEF.gap);
    const mode = MODES.includes(ui.mode) ? ui.mode : TDEF.mode;
    const n = items.length;
    const T = items.map((it, i) => {
      const a = i * st, d = Math.max(0.05, num(it && it.inDur, inD));
      return { a, in: d, land: a + d, out: Math.max(0.05, num(it && it.outDur, outD)) };
    });
    const maxLand = Math.max(0, ...T.map(x => x.land));
    T.forEach((x, i) => {
      if (mode === 'custom') x.e = x.land + pos(items[i] && items[i].hold, H);
      else if (mode === 'lifo') x.e = maxLand + H + (n - 1 - i) * gap;
      else if (mode === 'fifo') x.e = maxLand + H + i * gap;
      else x.e = maxLand + H;
      x.hold = x.e - x.land;
    });
    const total = exitOn === false
      ? (mode === 'custom' ? Math.max(0, ...T.map(x => x.e)) : maxLand + H)
      : Math.max(0, ...T.map(x => x.e + x.out));
    return { T, total: Math.max(0.2, total), st, inD, outD, H, gap, mode };
  };

  // ---------- 【区域C4 画面】卡片外观 ----------
  FX.css = () => {
    if (document.getElementById('fxc-style')) return;
    const st = document.createElement('style'); st.id = 'fxc-style';
    st.textContent = `
/* will-change 要留着：实测去掉以后帧率反而从 30 掉到 25（每帧都要重新提层）。
   投影分三档：默认那档有 60px 的大模糊，很漂亮但很吃填充率 —— 一屏几十张卡的效果（粒子群）
   必须用 sh-light，实测 40 张卡时差了 20+ fps。 */
.fxc{position:absolute;left:0;top:0;box-sizing:border-box;border-radius:var(--r);overflow:hidden;will-change:transform,opacity;
  contain:layout style paint;
  background:#141414;box-shadow:0 30px 60px -18px rgba(0,0,0,.55),0 10px 22px rgba(0,0,0,.28)}
.fxc.sh-light{box-shadow:0 10px 20px -10px rgba(0,0,0,.6)}
.fxc.sh-none{box-shadow:none}
.fxc.f-thin{border:2px solid color-mix(in srgb,var(--acc) 70%,transparent)}
.fxc.f-white{border:calc(var(--w)*.022px) solid #fafafa;background:#fafafa}
.fxc.f-line{border:1px solid rgba(255,255,255,.22)}
.fxc.f-none{border:0}
.fxc .fxc-img{position:absolute;inset:0;width:100%;height:100%;display:block}
.fxc .fxc-shine{position:absolute;inset:0;background:linear-gradient(160deg,rgba(255,255,255,.14) 0%,rgba(255,255,255,0) 38%);pointer-events:none}
.fxc .fxc-edge{position:absolute;left:0;top:0;bottom:0;width:calc(var(--w)*.012px);background:var(--acc);pointer-events:none}
/* 文字卡 */
.fxc-txt{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;padding:17% 9% 15%;box-sizing:border-box;
  background:radial-gradient(130% 90% at 0% 0%,color-mix(in srgb,var(--acc) 24%,#1b1b1b) 0%,#161616 52%,#101010 100%)}
.fxc-txt .k{position:absolute;left:9%;top:9%;display:flex;align-items:center;gap:calc(var(--w)*.025px);font:700 calc(var(--w)*.038px)/1 "Helvetica Neue",Arial,sans-serif;letter-spacing:.2em;color:var(--acc)}
.fxc-txt .k i{display:block;width:calc(var(--w)*.075px);height:calc(var(--w)*.0085px);border-radius:2px;background:var(--acc)}
.fxc-txt .t{font-weight:400;line-height:1.24;text-wrap:balance;color:#fff;letter-spacing:.01em;word-break:break-word;overflow-wrap:anywhere}
.fxc-txt .s{margin-top:calc(var(--w)*.035px);text-wrap:balance;font-weight:400;line-height:1.5;color:rgba(255,255,255,.6);word-break:break-word;overflow-wrap:anywhere}
.fxc-txt .u{position:absolute;left:9%;bottom:9%;width:calc(var(--w)*.13px);height:calc(var(--w)*.009px);border-radius:2px;background:var(--acc)}
.fxc-txt em.hi{font-style:normal;font-weight:800;color:var(--acc)}
.fxc-txt b{font-weight:800}
.fxc-txt s{text-decoration:line-through;text-decoration-thickness:.08em;opacity:.72}
.fxc-txt.bold .t,.fxc-txt.bold .s{font-weight:800}
.fxc-txt,.fxc-txt *{font-family:"PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif}
.f-white .fxc-txt{background:#fafafa}
.f-white .fxc-txt .t{color:#161616}
.f-white .fxc-txt .s{color:rgba(0,0,0,.55)}
/* 占位卡（没上传任何内容时的样子，缩略图也靠它好看）*/
.fxc-ph{position:absolute;inset:0;background:radial-gradient(120% 95% at 18% 0%,color-mix(in srgb,var(--acc) 30%,#1b1b1b) 0%,#161616 55%,#0f0f0f 100%)}
.fxc-ph .tag{position:absolute;left:8%;top:10%;font:600 calc(var(--w)*.038px)/1 "Helvetica Neue",Arial,"Microsoft YaHei",sans-serif;letter-spacing:.3em;color:rgba(255,255,255,.5)}
.fxc-ph .bar{position:absolute;left:8%;top:calc(10% + var(--w)*.07px);width:20%;height:calc(var(--w)*.008px);border-radius:2px;background:var(--acc)}
.fxc-ph .no{position:absolute;left:7.5%;bottom:8%;font:800 calc(var(--w)*.26px)/1 "Arial Black","Helvetica Neue",Arial,sans-serif;color:var(--acc);letter-spacing:-.02em}
.fxc-ph .rows{position:absolute;right:8%;bottom:12%;display:flex;flex-direction:column;align-items:flex-end;gap:calc(var(--w)*.022px)}
.fxc-ph .rows i{display:block;height:calc(var(--w)*.014px);border-radius:3px;background:rgba(255,255,255,.16)}
/* 镂空卡：卡片内部完全透明（导出的 ProRes 4444 里这块 alpha=0），
   只画一圈边框和外投影 —— 后期把自己的视频垫在下面一轨，就会从这个"窗口"透出来，
   不用把整段视频上传进来。边框和投影画在子元素上，方便推到满屏时单独淡掉。 */
.fxc.f-hole{background:transparent;box-shadow:none;border:0}
.fxc-holeframe{position:absolute;inset:0;border-radius:inherit;box-sizing:border-box;pointer-events:none;
  box-shadow:0 30px 60px -18px rgba(0,0,0,.45),0 10px 22px rgba(0,0,0,.22)}
.fxc-holeframe.hf-thin{border:2px solid color-mix(in srgb,var(--acc) 70%,transparent)}
.fxc-holeframe.hf-white{border:calc(var(--w)*.022px) solid #fafafa}
.fxc-holeframe.hf-line{border:1px solid rgba(255,255,255,.3)}
.fxc-holeframe.hf-none{border:0;box-shadow:none}`;
    document.head.appendChild(st);
  };

  // 画一张卡的内容。o = { W, H, fit, frame, accent, index, loads, bold, posterOnly, shine, edge }
  FX.card = (el, it, o) => {
    o = o || {}; it = it || {};
    const W = o.W, H = o.H == null ? W : o.H;
    const frame = ['thin', 'white', 'line', 'none'].includes(o.frame) ? o.frame : 'thin';
    const sh = o.shadow === 'light' ? ' sh-light' : o.shadow === 'none' ? ' sh-none' : '';
    el.className = 'fxc f-' + frame + sh;
    el.style.width = W + 'px'; el.style.height = H + 'px';
    el.style.setProperty('--w', W);
    el.style.setProperty('--r', Math.round(W * (frame === 'white' ? 0.028 : 0.038)) + 'px');
    const no = String((o.index || 0) + 1).padStart(2, '0');
    const loads = o.loads || [];
    // 镂空卡：里面什么都不画，保持透明；只放一层边框 / 投影（el.__hf 方便效果单独淡掉它）
    if (it.type === 'hole') {
      el.className = 'fxc f-hole' + sh;
      const fr = document.createElement('div');
      fr.className = 'fxc-holeframe hf-' + frame;
      el.appendChild(fr);
      el.__hf = fr;
      return el;
    }
    if (it.type === 'text') {
      const title = String(it.title || '').trim() || '写一句**重点**标题';
      const sub = String(it.sub || '').trim();
      // 标题字号自动收缩；有副标题时给标题留小一点的地方，避免副标题顶到底部的下划线
      const tfs = FX.titleSize(W, H, plain(title), sub ? 0.32 : 0.46);
      const sfs = Math.max(10, Math.min(W * 0.044, tfs * 0.46));
      el.innerHTML = `<div class="fxc-txt${o.bold ? ' bold' : ''}"><div class="k">${no}<i></i></div>`
        + `<div class="t" style="font-size:${tfs.toFixed(1)}px">${FX.mark(title)}</div>`
        + (sub ? `<div class="s" style="font-size:${sfs.toFixed(1)}px">${FX.mark(sub)}</div>` : '')
        + `<div class="u"></div></div>`;
    } else if (it.type === 'video' && it.video && !o.posterOnly && window.FXVideo) {
      loads.push(FXVideo.mount(el, it, o.fit));                       // 视频卡（见 _shared/fx-video.js）
    } else if (it.type === 'video' && it.video && o.posterOnly && it.poster) {
      // 粒子那种一次上百张的场合：超出「同时播放上限」的那些用封面图，画面不会黑
      const im = new Image();
      im.className = 'fxc-img'; im.style.objectFit = o.fit === 'contain' ? 'contain' : 'cover';
      im.src = it.poster;
      loads.push(im.decode ? im.decode().catch(() => { }) : new Promise(r => { im.onload = im.onerror = r; }));
      el.appendChild(im);
    } else if (it.img) {
      const im = new Image();
      im.className = 'fxc-img'; im.style.objectFit = o.fit === 'contain' ? 'contain' : 'cover';
      im.style.objectPosition = FX.focusPos(it.focus);      // 裁剪时保留哪一块（见编辑器里的「保留」）
      im.src = it.img;
      loads.push(im.decode ? im.decode().catch(() => { }) : new Promise(r => { im.onload = im.onerror = r; }));
      el.appendChild(im);
    } else {
      el.innerHTML = `<div class="fxc-ph"><div class="tag">${it.type === 'video' ? 'VIDEO' : 'PHOTO'}</div><div class="bar"></div>`
        + `<div class="rows"><i style="width:${(W * 0.3).toFixed(0)}px"></i><i style="width:${(W * 0.22).toFixed(0)}px"></i><i style="width:${(W * 0.26).toFixed(0)}px"></i></div>`
        + `<div class="no">${no}</div></div>`;
    }
    if (o.edge !== false && frame !== 'white') { const e = document.createElement('div'); e.className = 'fxc-edge'; el.appendChild(e); }
    if (o.shine !== false) { const sh = document.createElement('div'); sh.className = 'fxc-shine'; el.appendChild(sh); }
    return el;
  };

  // ================= 【区域C5 编辑器】 =================
  // 在工作台里预览时，把右侧「卡片内容」那一栏换成卡片编辑器；编辑结果写回隐藏输入框。
  // 导出时本页单独打开（没有父页面），这段不会运行。
  FX.editor = (o) => {
    o = o || {};
    let P = o.P || {};                       // 可变：工作台每次改参数都会重新 init，这里要换成新的 P
    const ED = o.ED || (o.ED = {});
    let pd, pw;
    try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
    const box = pd.getElementById('params'); if (!box) return;
    // 已经挂好了就不要重建（重建会把用户正在输入的文字框干掉）；
    // 只把新的参数交给它，刷新一下和参数有关的提示（比例提醒、缩略图裁剪、时间）
    if (ED.mounted && box.contains(ED.mounted)) { if (ED.setP) ED.setP(o.P || {}); return; }
    box.querySelectorAll('.cdx').forEach(x => x.remove());
    const labelOf = el => (el.firstChild && el.firstChild.nodeType === 3 ? el.firstChild.textContent : el.textContent || '').trim();
    const kids = [...box.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);
    const key = o.label || '卡片内容';
    const jl = kids.find(el => el.tagName === 'LABEL' && labelOf(el).startsWith(key));
    const field = jl && jl.querySelector('input,textarea');
    if (!field) return;
    (o.hideParams || ['卡片大小']).forEach(h => kids.filter(el => labelOf(el).startsWith(h)).forEach(el => el.style.display = 'none'));
    jl.style.display = 'none';

    if (!pd.getElementById('cdx-style')) {
      const st = pd.createElement('style'); st.id = 'cdx-style';
      st.textContent = `
.cdx{display:block;font-size:12px;color:#999;margin-bottom:14px}
.cdx-h{display:flex;flex-direction:column;gap:8px;margin:8px 0}
.cdx input.cdx-num{width:56px!important;margin:0!important;text-align:center;padding:6px!important;display:inline-block!important}
.cdx-b{background:#262626;color:#eee;border:1px solid #333;border-radius:6px;cursor:pointer;font-family:inherit;font-size:12px;padding:4px 10px}
.cdx-b:hover{border-color:#f28c0f}
.cdx-all{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.cdx-list{display:flex;flex-direction:column;gap:8px}
.cdx-i{background:#101010;border:1px solid #2c2c2c;border-radius:8px;padding:8px}
.cdx-i.drag{opacity:.35}.cdx-i.over{border-color:#f28c0f;box-shadow:0 0 0 1px #f28c0f}
.cdx-top{display:flex;align-items:center;gap:8px}
.cdx-grip{cursor:grab;color:#777;font-size:16px;line-height:1;padding:2px;user-select:none}.cdx-grip:hover{color:#f28c0f}
.cdx-no{min-width:20px;height:20px;padding:0 5px;border-radius:10px;background:#f28c0f;color:#000;font-size:12px;line-height:20px;text-align:center;font-weight:700}
.cdx-seg{display:flex;margin-left:auto;background:#1d1d1d;border:1px solid #333;border-radius:6px;overflow:hidden}
.cdx-seg button{border:0;background:none;color:#aaa;padding:4px 12px;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap}
.cdx-seg button.on{background:#f28c0f;color:#000;font-weight:600}
.cdx-del{width:22px;height:22px;padding:0;border:0;border-radius:50%;background:#262626;color:#bbb;cursor:pointer;font-size:14px;line-height:22px}
.cdx-del:hover{background:#5a1f1f;color:#fff}
.cdx-body{margin-top:8px}
.cdx-body input.cdx-txt{display:block!important;width:100%;box-sizing:border-box;margin:6px 0 0!important;padding:8px 10px;font-size:14px;background:#0b0b0b;color:#eee;border:1px solid #333;border-radius:6px;font-family:inherit}
.cdx-body input.cdx-txt:first-child{margin-top:0!important}.cdx-body input.cdx-txt:focus{outline:none;border-color:#f28c0f}
.cdx-ph{position:relative;height:92px;border:1px dashed #444;border-radius:6px;display:flex;align-items:center;justify-content:center;text-align:center;color:#999;font-size:12px;cursor:pointer;overflow:hidden;line-height:1.5}
.cdx-ph:hover,.cdx-ph.over{border-color:#f28c0f;color:#f28c0f}.cdx-ph small{color:#666}
.cdx-ph.has{border-style:solid}.cdx-ph img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
/* 缩略图按卡片比例显示：所见即所得，一眼看出「铺满」会裁掉哪一块 */
.cdx-ph.ar{height:auto;aspect-ratio:var(--ar,1.777);margin:0 auto}
.cdx-warn{margin-top:8px;padding:8px 10px;background:#16100a;border:1px solid #4a3312;border-radius:6px;font-size:12px;line-height:1.7;color:#d8ab6a}
.cdx-warn>b:first-child{display:block;color:#f2a33d;font-weight:600;margin-bottom:2px}
.cdx-warn u{text-decoration:none;color:#ffcf8a;font-weight:600}
.cdx-wbtn{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}
.cdx-wbtn .cdx-b{flex:1;min-width:120px;padding:6px 8px}
.cdx-focus{display:flex;align-items:center;gap:8px;margin-top:8px;color:#c8a46a}
.cdx-focus span{flex:1;min-width:0}
.cdx-focus .cdx-seg{margin:0}.cdx-focus .cdx-seg button{padding:4px 14px}
.cdx-ph.has span{position:relative;background:rgba(0,0,0,.65);color:#fff;padding:3px 8px;border-radius:4px;opacity:0;transition:opacity .15s}
.cdx-ph.has:hover span{opacity:1}
.cdx-clr{margin-top:6px;background:none;border:0;color:#888;font-size:12px;cursor:pointer;padding:0;font-family:inherit}.cdx-clr:hover{color:#f28c0f}
.cdx-bulk{display:block;width:100%;margin-top:10px;padding:10px;font-size:13px;background:#262626;color:#eee;border:0;border-radius:6px;cursor:pointer;font-family:inherit}
.cdx-bulk:hover{background:#2f2f2f}.cdx-bulk:disabled{opacity:.6}
.cdx-note{margin-top:6px;font-size:12px;color:#777;line-height:1.6}
.cdx-fill{margin-top:8px;padding:8px 10px;background:#141008;border:1px solid #3a2c10;border-radius:6px;font-size:12px;line-height:1.6;color:#c8a964}
.cdx-hole{padding:8px 10px;background:#0c1014;border:1px dashed #30444f;border-radius:6px;font-size:12px;line-height:1.7;color:#8fa9b5}
.cdx-hole b{display:inline;color:#6fd3ea;font-weight:600}
.cdx-hole>b:first-child{display:block;color:#6fd3ea;margin-bottom:2px}
.cdx-c{display:block;margin:0}
.cdx-cr{display:flex;align-items:center;justify-content:space-between;gap:6px;color:#ccc;font-size:13px}
.cdx-cr span{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cdx input.cdx-cn{width:64px!important;flex:none;margin:0!important;padding:5px 6px!important;text-align:right;display:inline-block!important;font-size:13px}
.cdx input.cdx-rg{display:block!important;width:100%!important;margin:6px 0 2px!important;padding:0!important;border:0!important;background:none!important;height:16px;accent-color:#f28c0f;cursor:pointer}
.cdx-rh{display:flex;flex-direction:column;gap:10px;margin:10px 0 12px;padding:10px;background:#101010;border:1px solid #2c2c2c;border-radius:8px}
.cdx-rh .cdx-seg{margin:0}.cdx-rh .cdx-seg button{flex:1;padding:6px 4px}
.cdx-ord{display:flex;flex-direction:column;gap:6px;color:#ccc;font-size:13px}
.cdx-tm{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:10px;padding-top:8px;border-top:1px solid #222}
.cdx-tm .cdx-cr{flex-direction:column;align-items:stretch;gap:4px;font-size:12px;color:#999}
.cdx-tm input.cdx-cn{width:100%!important}
.cdx-when{font-size:11px;color:#777;margin-top:6px;line-height:1.5}
.cdx-fold{width:22px;height:22px;padding:0;border:0;background:none;color:#f28c0f;cursor:pointer;font-size:13px;line-height:22px;transition:transform .15s;flex:none}
.cdx-i.off .cdx-fold{transform:rotate(-90deg)}
.cdx-i.off .cdx-body,.cdx-i.off .cdx-tm{display:none}
.cdx-rh>.cdx-rhh{display:flex;align-items:center;gap:6px;background:none;border:0;padding:0;color:#f28c0f;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;text-align:left}
.cdx-rhh i{font-style:normal;display:inline-block;transition:transform .15s}
.cdx-rh.off .cdx-rhh i{transform:rotate(-90deg)}
.cdx-rhh small{margin-left:auto;color:#777;font-weight:400;font-size:12px}
.cdx-rh.off>:not(.cdx-rhh){display:none}
.cdx-folds{display:flex;align-items:center;gap:6px}`;
      pd.head.appendChild(st);
    }

    const MIN = o.min || 1, MAX = o.max || 12, DEF = o.def || 6;
    let v; try { v = JSON.parse(field.value); } catch (e) { v = null; }
    if (!v || !Array.isArray(v.items)) v = { count: DEF, items: [] };
    v.count = clamp(Math.round(num(v.count, DEF)), MIN, MAX);
    const blank = t => ({ type: t || 'image', img: '', title: '', sub: '' });
    const pad = () => { while (v.items.length < v.count) v.items.push(blank(v.items.length ? v.items[v.items.length - 1].type : 'image')); };
    pad();
    const items = () => v.items.slice(0, v.count);
    const FOLD = ED.FOLD || (ED.FOLD = new WeakSet());
    const u0 = v.ui || {};
    v.ui = {
      stagger: num(u0.stagger, TDEF.stagger), in: num(u0.in, TDEF.in), hold: num(u0.hold, TDEF.hold),
      out: num(u0.out, TDEF.out), gap: num(u0.gap, TDEF.gap), mode: MODES.includes(u0.mode) ? u0.mode : TDEF.mode
    };
    const exitOn = () => (o.exitOn ? o.exitOn() : P.exit !== 'off');
    const tm = () => FX.timing(items(), v.ui, P, exitOn());
    let commitT = 0;
    const commit = (ms = 120) => {
      clearTimeout(commitT);
      commitT = setTimeout(() => {
        field.value = JSON.stringify({ count: v.count, ui: v.ui, items: v.items.slice(0, Math.max(v.count, v.items.length)) });
        field.dispatchEvent(new pw.Event('input', { bubbles: true }));
      }, ms);
    };
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const fileInput = multi => { const f = mk('input'); f.type = 'file'; f.accept = 'image/png,image/jpeg,image/webp,image/gif'; f.multiple = !!multi; f.style.display = 'none'; return f; };
    const isImg = f => f && /^image\/(png|jpeg|webp|gif)$/.test(f.type);
    // ---------- 图片：传到工作台的 uploads\ 里，参数里只存一个路径 ----------
    // 以前是读成 base64 直接塞进参数：几张图就是好几 MB 的字符串，每改一次参数都要重新解析、
    // 重新解码所有图片 —— 又占内存又卡。现在改成 POST /api/upload（存到硬盘，返回 /uploads/xxx），
    // 参数里只剩一行路径，浏览器按普通图片加载、自带 HTTP 缓存，旧电脑也扛得住。
    // 上传前先缩到最长边 1920（够 1080p 出片和推近用），避免几十 MB 的原图把解码内存吃爆。
    const MAXEDGE = 1920;
    const decode = file => new Promise((res, rej) => {
      const url = URL.createObjectURL(file);
      const im = new Image();
      im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('图片无法识别')); };
      im.onload = () => res({ im, url });
      im.src = url;
    });
    const toBlob = (cv, type, q) => new Promise(r => cv.toBlob(r, type, q));
    const putImage = async file => {
      const { im, url } = await decode(file);
      const iw = im.naturalWidth, ih = im.naturalHeight;     // 原图尺寸（比例提醒要用）
      let body = file, type = file.type;
      try {
        if (Math.max(iw, ih) > MAXEDGE && file.type !== 'image/gif') {
          const k = MAXEDGE / Math.max(iw, ih);
          const cv = document.createElement('canvas');
          cv.width = Math.max(1, Math.round(iw * k)); cv.height = Math.max(1, Math.round(ih * k));
          cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
          let b = await toBlob(cv, 'image/webp', 0.92);
          if (!b || !/webp/.test(b.type)) b = await toBlob(cv, 'image/jpeg', 0.92);
          if (b) { body = b; type = b.type; }
        }
      } catch (e) { /* 缩不动就按原图传 */ }
      URL.revokeObjectURL(url);
      try {
        const r = await fetch('/api/upload', { method: 'POST', headers: { 'X-FX': '1', 'Content-Type': type }, body });
        const j = await r.json();
        if (!j.url) throw new Error(j.error || '上传失败');
        return { img: j.url, iw, ih };
      } catch (e) {
        // 接口不通（工作台太旧 / 单独打开页面）时退回老办法：内嵌 base64，功能不受影响
        const fr = await new Promise((res2, rej2) => { const f2 = new FileReader(); f2.onload = () => res2(f2.result); f2.onerror = () => rej2(new Error('图片读取失败')); f2.readAsDataURL(body); });
        return { img: fr, iw, ih, inline: true };
      }
    };
    const ime = (el, onCommit) => {
      let comp = false;
      el.addEventListener('compositionstart', () => { comp = true; });
      el.addEventListener('compositionend', () => { comp = false; onCommit(el.value); });
      el.addEventListener('input', e => { if (comp || e.isComposing) return; onCommit(el.value); });
    };
    // 规则 5：属性文字 + 后面一个数字框 + 下面一条滑杆，两个都能调
    const r2 = x => Math.round(x * 100) / 100;
    const ctl = (label, op, get, set) => {
      const w = mk('div', 'cdx-c'), row = mk('div', 'cdx-cr'), sp = mk('span'), bx = mk('input', 'cdx-cn'), rg = mk('input', 'cdx-rg');
      sp.textContent = label; sp.title = label;
      const hi = op.boxMax != null ? op.boxMax : op.max;
      bx.type = 'number'; bx.min = op.min; bx.max = hi; bx.step = op.step;
      rg.type = 'range'; rg.min = op.min; rg.max = op.max; rg.step = op.step;
      row.append(sp, bx); w.append(row, rg);
      w.show = () => { const x = r2(get()); rg.value = x; if (pd.activeElement !== bx) bx.value = x; };
      bx.addEventListener('input', () => {
        if (bx.value === '') return; const x = Number(bx.value); if (!Number.isFinite(x)) return;
        rg.value = clamp(x, op.min, hi); set(clamp(x, op.min, hi));
      });
      bx.addEventListener('change', () => { bx.blur(); w.show(); });
      bx.addEventListener('focus', () => setTimeout(() => bx.select(), 0));
      rg.addEventListener('input', () => { bx.value = rg.value; set(+rg.value); });
      w.show(); return w;
    };
    const SEC = { min: 0.1, max: 5, step: 0.05, boxMax: 60 }, HOLD = { min: 0, max: 30, step: 0.1, boxMax: 600 };

    // ---------- 【比例检查】图片比例和卡片比例对不上时，提醒 + 一键处理 ----------
    const cardRatio = () => FX.ratioOf(P, '16:9');
    // 改右侧面板里的某个参数（用来一键「把卡片比例改成 9:16」「改成完整显示」）
    const setParam = (labelPrefix, value) => {
      const rows = [...box.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);
      const row = rows.find(el => el.tagName === 'LABEL' && labelOf(el).startsWith(labelPrefix));
      const inp = row && row.querySelector('select,input');
      if (!inp) return false;
      inp.value = value;
      inp.dispatchEvent(new pw.Event('input', { bubbles: true }));
      inp.dispatchEvent(new pw.Event('change', { bubbles: true }));
      return true;
    };
    const pct = x => Math.round(x * 100) + '%';
    // 缩略图按卡片比例显示（所见即所得）；竖卡会很高，所以按高度封顶 190px，宽度跟着缩
    const applyThumb = (ph, c) => {
      if (!ph) return;
      const ar = 1 / cardRatio();                        // 宽 / 高
      ph.classList.add('ar');
      ph.style.setProperty('--ar', String(ar));
      ph.style.maxWidth = ar < 1.4 ? Math.round(190 * ar) + 'px' : '';
      const im = ph.querySelector('img');
      if (im) { im.style.objectPosition = FX.focusPos(c.focus); im.style.objectFit = P.fit === 'contain' ? 'contain' : 'cover'; }
    };
    function ratioBox(c) {
      const info = FX.cropInfo(+c.iw, +c.ih, cardRatio());
      if (!info || info.same) return null;              // 没记尺寸（老卡片）或比例本来就一致 → 不啰嗦
      const contain = P.fit === 'contain';
      const w = mk('div', 'cdx-warn');
      w.innerHTML = '<b>比例对不上</b>图片 ' + (+c.iw) + '×' + (+c.ih) + '（≈' + info.best + '），卡片是 ' + (P.ratio || '16:9') + '。'
        + (contain ? '现在是「完整显示」，不裁剪，但卡片里会留边。'
          : '按现在的「铺满卡片」会裁掉大约 <u>' + pct(info.loss) + '</u> 的画面。');
      const btns = mk('div', 'cdx-wbtn');
      const b1 = mk('button', 'cdx-b'); b1.type = 'button'; b1.textContent = '把卡片比例改成 ' + info.best;
      b1.onclick = () => { if (!setParam('卡片比例', info.best)) note.textContent = '这个效果没有「卡片比例」参数'; };
      const b2 = mk('button', 'cdx-b'); b2.type = 'button';
      b2.textContent = contain ? '改回铺满（会裁剪）' : '完整显示（留边，不裁）';
      b2.onclick = () => { if (!setParam('照片', contain ? 'cover' : 'contain')) note.textContent = '这个效果没有「填充方式」参数'; };
      btns.append(b1, b2);
      w.appendChild(btns);
      if (!contain) {
        const vert = info.axis === 'v';
        const opts = vert ? [['top', '上'], ['center', '中'], ['bottom', '下']] : [['left', '左'], ['center', '中'], ['right', '右']];
        const row = mk('div', 'cdx-focus', '<span>裁剪保留' + (vert ? '上 / 中 / 下' : '左 / 中 / 右') + '</span>');
        const seg = mk('div', 'cdx-seg');
        opts.forEach(([k, label]) => {
          const b = mk('button'); b.type = 'button'; b.textContent = label;
          if ((c.focus || 'center') === k) b.className = 'on';
          b.onclick = () => { c.focus = k; draw(); commit(); };
          seg.appendChild(b);
        });
        row.appendChild(seg);
        w.appendChild(row);
      }
      return w;
    }
    const RH = Object.assign({ title: '节奏 · 统一设置所有卡片', in: '进场时长（秒）', hold: '停留时长（秒）', out: '退出时长（秒）', stagger: '出现间隔（秒）', gap: '退场间隔（秒）', order: '退场顺序' }, o.rhythm || {});
    const ORD = Object.assign({
      lifo: '全部出现后一起停留，从最后一张开始依次退场', fifo: '全部出现后一起停留，从第 1 张开始依次退场',
      together: '全部出现后一起停留，同时退场', custom: '每张卡片出现后，按它自己的「停留」时长退场'
    }, o.orderNote || {});
    const hasRh = o.rhythm !== false;        // 有的效果（粒子群）不按张排时间，用整体浮现 / 消散
    let cardCtl = [];
    const fmtS = x => r2(x).toFixed(2).replace(/\.?0+$/, '') + ' 秒';
    function refreshTimes() {
      if (hasRh) {
        const R = tm(), ex = exitOn();
        rhythm.querySelectorAll('.cdx-c').forEach(c => c.show());
        ordSeg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.m === v.ui.mode));
        gapCtl.style.display = (v.ui.mode === 'lifo' || v.ui.mode === 'fifo') ? '' : 'none';
        ordNote.textContent = ORD[v.ui.mode];
        cardCtl.forEach(k => {
          k.ctls.forEach(c => c.show());
          const T = R.T[k.i]; if (!T) return;
          const desc = k.c.type === 'hole' ? '镂空窗口'
            : k.c.type === 'text' ? '「' + (plain(k.c.title || '').trim() || '标题') + '」'
              : k.c.type === 'video' ? (k.c.video ? '视频' : '视频（未上传）') : k.c.img ? '照片' : '照片（未上传）';
          k.line.textContent = (k.it.classList.contains('off') ? desc + ' · ' : '')
            + '第 ' + fmtS(T.a) + '出现' + (ex ? ' · 第 ' + fmtS(T.e) + '开始退场 · ' + fmtS(T.e + T.out) + '离场' : ' · 之后一直停在画面上');
        });
        totalNote.textContent = '整段动画约 ' + fmtS(R.total);
        rhSum.textContent = '共 ' + fmtS(R.total);
      }
      if (fillBox) {
        const n = o.screenCount ? o.screenCount() : v.count;
        const f = FX.fillInfo(items(), n);
        if (f.real === 0) { fillBox.style.display = ''; fillBox.textContent = '还没填任何内容，画面上先用带编号的占位卡顶着。上传照片 / 填文字 / 传视频后会自动替换。'; }
        else if (f.borrowed > 0) { fillBox.style.display = ''; fillBox.textContent = `画面上要 ${f.n} 张，你填了 ${f.real} 张有内容的 —— 剩下 ${f.borrowed} 张会循环借用这 ${f.real} 张的内容，不会出现空白卡。`; }
        else fillBox.style.display = 'none';
      }
      if (o.onRefresh) try { o.onRefresh(); } catch (e) { }
    }
    const changed = () => { refreshTimes(); commit(); };
    // 改了某一张的停留：先把当前每张的实际停留写下来，再切到「每张自定」，其他卡片不会跳
    const toCustom = () => {
      if (v.ui.mode === 'custom') return;
      const T = tm().T; items().forEach((c, k) => { c.hold = r2(T[k].hold); }); v.ui.mode = 'custom';
    };

    const wrap = mk('div', 'cdx'); wrap.append(key);
    const head = mk('div', 'cdx-h');
    const cntCtl = ctl(o.countLabel || '卡片数量', { min: MIN, max: MAX, step: 1 }, () => v.count, x => setCount(x));
    if (!o.hideCount) head.append(cntCtl);
    head.append(
      mk('div', 'cdx-folds', '卡片<button type="button" class="cdx-b" data-fold="1">全部收起</button><button type="button" class="cdx-b" data-fold="0">全部展开</button>'),
      mk('div', 'cdx-all', '全部设为<button type="button" class="cdx-b" data-all="image">照片</button><button type="button" class="cdx-b" data-all="text">文字</button><button type="button" class="cdx-b" data-all="video">视频</button>')
    );
    // ---------- 节奏 ----------
    const rhythm = mk('div', 'cdx-rh', `<button type="button" class="cdx-rhh"><i>▾</i>${RH.title}<small></small></button>`);
    const rhSum = rhythm.querySelector('small');
    if (ED.rhOff) rhythm.classList.add('off');
    rhythm.querySelector('.cdx-rhh').onclick = () => { ED.rhOff = rhythm.classList.toggle('off'); };
    const allIn = ctl(RH.in, SEC, () => v.ui.in, x => { v.ui.in = x; items().forEach(c => c.inDur = x); changed(); });
    const allHold = ctl(RH.hold, HOLD, () => v.ui.hold, x => { v.ui.hold = x; if (v.ui.mode === 'custom') items().forEach(c => c.hold = x); changed(); });
    const allOut = ctl(RH.out, SEC, () => v.ui.out, x => { v.ui.out = x; items().forEach(c => c.outDur = x); changed(); });
    const stagCtl = ctl(RH.stagger, { min: 0, max: 5, step: 0.02, boxMax: 60 }, () => v.ui.stagger, x => { v.ui.stagger = x; changed(); });
    const ord = mk('div', 'cdx-ord', RH.order);
    const ordSeg = mk('div', 'cdx-seg', '<button type="button" data-m="lifo">后出先退</button><button type="button" data-m="fifo">先出先退</button><button type="button" data-m="together">同时</button><button type="button" data-m="custom">每张自定</button>');
    const ordNote = mk('div', 'cdx-note'); ordNote.style.marginTop = '0';
    ordSeg.querySelectorAll('button').forEach(b => b.onclick = () => { if (b.dataset.m === 'custom') toCustom(); else v.ui.mode = b.dataset.m; changed(); });
    ord.append(ordSeg, ordNote);
    const gapCtl = ctl(RH.gap, { min: 0, max: 3, step: 0.02, boxMax: 60 }, () => v.ui.gap, x => { v.ui.gap = x; changed(); });
    const totalNote = mk('div', 'cdx-note'); totalNote.style.marginTop = '0';
    rhythm.append(allIn, allHold, allOut, stagCtl, ord, gapCtl, totalNote);

    const fillBox = o.screenCount !== false ? mk('div', 'cdx-fill') : null;
    const list = mk('div', 'cdx-list');
    const bulk = mk('button', 'cdx-bulk'); bulk.type = 'button'; bulk.textContent = '批量上传照片（按顺序填进照片卡）';
    const bulkIn = fileInput(true);
    const note = mk('div', 'cdx-note');
    // 老项目里的图片是以 base64 内嵌在参数里的（占内存、每次改参数都要重新解码）。
    // 这个按钮把它们转存到 uploads\，参数里只留路径。
    const mig = mk('button', 'cdx-bulk'); mig.type = 'button';
    const inlineN = () => items().filter(c => c.type === 'image' && /^data:/.test(c.img || '')).length;
    const showMig = () => {
      const n = inlineN();
      mig.style.display = n ? '' : 'none';
      mig.textContent = '把 ' + n + ' 张内嵌图片转存到硬盘（更省内存、更流畅）';
    };
    mig.onclick = async () => {
      mig.disabled = true; mig.textContent = '转存中…';
      for (const c of items()) {
        if (c.type !== 'image' || !/^data:/.test(c.img || '')) continue;
        try {
          const b = await (await fetch(c.img)).blob();
          const d = await new Promise(r => { const im = new Image(); im.onload = () => r({ w: im.naturalWidth, h: im.naturalHeight }); im.onerror = () => r({ w: 0, h: 0 }); im.src = c.img; });
          const j = await (await fetch('/api/upload', { method: 'POST', headers: { 'X-FX': '1', 'Content-Type': b.type }, body: b })).json();
          if (j.url) { c.img = j.url; if (d.w) { c.iw = d.w; c.ih = d.h; } }
        } catch (e) { note.textContent = '转存失败：' + e.message; }
      }
      mig.disabled = false; draw(); commit();
    };
    const setCount = n => { const c = clamp(Math.round(+n || MIN), MIN, MAX); if (c === v.count) return; v.count = c; pad(); draw(); commit(); };
    head.querySelectorAll('[data-fold]').forEach(b => b.onclick = () => { items().forEach(c => b.dataset.fold === '1' ? FOLD.add(c) : FOLD.delete(c)); draw(); });
    head.querySelectorAll('[data-all]').forEach(b => b.onclick = () => { v.items.slice(0, v.count).forEach(c => c.type = b.dataset.all); draw(); commit(); });
    bulk.onclick = () => bulkIn.click();
    bulkIn.onchange = async () => {
      const files = [...bulkIn.files].filter(isImg); bulkIn.value = '';
      if (!files.length) return;
      bulk.disabled = true; bulk.textContent = '读取中…';
      for (const f of files) {
        let i = v.items.slice(0, v.count).findIndex(c => c.type === 'image' && !c.img);
        if (i < 0) { if (v.count >= MAX) { note.textContent = '最多 ' + MAX + ' 张卡片'; break; } v.count++; pad(); i = v.count - 1; v.items[i] = blank('image'); }
        try { Object.assign(v.items[i], await putImage(f), { type: 'image' }); } catch (e) { note.textContent = e.message; }
      }
      cntCtl.show(); bulk.disabled = false; bulk.textContent = '批量上传照片（按顺序填进照片卡）'; draw(); commit();
    };

    // 图片卡的「比例提醒 / 缩略图」要跟着卡片比例、填充方式变，但又不能重建整个列表（会打断输入），
    // 所以单独记下来，参数变了只换这一小块
    let imgCards = [];
    const refreshRatio = () => {
      imgCards.forEach(k => {
        const old = k.body.querySelector('.cdx-warn');
        const adv = ratioBox(k.c);
        if (old && adv) k.body.replaceChild(adv, old);
        else if (old) old.remove();
        else if (adv) k.body.insertBefore(adv, k.clr || null);
        applyThumb(k.ph, k.c);
      });
    };
    ED.setP = p => { P = p || {}; refreshTimes(); refreshRatio(); };

    let dragFrom = -1;
    function draw() {
      list.innerHTML = ''; cardCtl = []; imgCards = [];
      v.items.slice(0, v.count).forEach((c, i) => {
        const it = mk('div', 'cdx-i',
          '<div class="cdx-top"><button type="button" class="cdx-fold" title="收起 / 展开">▾</button><span class="cdx-grip" title="按住拖动调整顺序">⠿</span><span class="cdx-no"></span>'
          + '<div class="cdx-seg"><button type="button" data-t="image">照片</button><button type="button" data-t="text">文字</button><button type="button" data-t="video">视频</button>'
          + '<button type="button" data-t="hole" title="镂空：这块导出后是透明的，后期在下面垫自己的视频">镂空</button></div>'
          + '<button type="button" class="cdx-del" title="删除这张卡片">×</button></div><div class="cdx-body"></div>');
        it.querySelector('.cdx-no').textContent = i + 1;
        if (FOLD.has(c)) it.classList.add('off');
        it.querySelector('.cdx-fold').onclick = () => { it.classList.toggle('off') ? FOLD.add(c) : FOLD.delete(c); refreshTimes(); };
        it.querySelectorAll('.cdx-seg button').forEach(b => { b.classList.toggle('on', b.dataset.t === c.type); b.onclick = () => { c.type = b.dataset.t; draw(); commit(); }; });
        it.querySelector('.cdx-del').onclick = () => { if (v.count <= MIN) return; v.items.splice(i, 1); v.count--; cntCtl.show(); pad(); draw(); commit(); };
        const body = it.querySelector('.cdx-body');
        if (c.type === 'text') {
          const t1 = mk('input', 'cdx-txt'), t2 = mk('input', 'cdx-txt');
          t1.type = t2.type = 'text';
          t1.placeholder = '标题（用 **文字** 标出重点）'; t2.placeholder = '副标题（可不填，也支持 **重点**）';
          t1.value = c.title || ''; t2.value = c.sub || '';
          ime(t1, val => { c.title = val; commit(300); });
          ime(t2, val => { c.sub = val; commit(300); });
          body.append(t1, t2);
        } else if (c.type === 'video') {
          body.append(FXVideo.editorBody({ pd, c, total: () => +window.getDuration() || 0, changed: () => { draw(); commit(); }, note: m => { note.textContent = m; } }));
        } else if (c.type === 'hole') {
          body.append(mk('div', 'cdx-hole',
            '<b>这块是透明的</b>导出的 ProRes 4444 里这张卡内部 alpha = 0，只留一圈边框和投影。<br>'
            + '剪辑软件里把<b>你自己的视频放在下面一轨</b>，这个效果放上面一轨，视频就会从这个窗口里透出来 ——'
            + '<b>一秒视频都不用上传</b>，10 分钟的片子也不怕。'));
        } else {
          const ph = mk('div', 'cdx-ph' + (c.img ? ' has' : ''), c.img ? '<img alt=""><span>点击更换照片</span>' : '<span>点击上传照片<br><small>或把图片拖到这里</small></span>');
          if (c.img) { ph.querySelector('img').src = c.img; applyThumb(ph, c); }
          const fin = fileInput(false);
          const put = async f => {
            if (!isImg(f)) { note.textContent = '只支持 PNG / JPG / WEBP / GIF 图片'; return; }
            ph.innerHTML = '<span>上传中…</span>';
            try { Object.assign(c, await putImage(f)); } catch (e) { note.textContent = e.message; }
            draw(); commit();
          };
          ph.onclick = () => fin.click();
          fin.onchange = () => put(fin.files[0]);
          ph.addEventListener('dragover', e => { if (dragFrom < 0 && [...e.dataTransfer.types].includes('Files')) { e.preventDefault(); ph.classList.add('over'); } });
          ph.addEventListener('dragleave', () => ph.classList.remove('over'));
          ph.addEventListener('drop', e => { if (dragFrom >= 0 || !e.dataTransfer.files.length) return; e.preventDefault(); e.stopPropagation(); put(e.dataTransfer.files[0]); });
          body.append(ph, fin);
          if (c.img) {
            const adv = ratioBox(c);                      // 比例不匹配时的提醒 + 一键处理
            if (adv) body.appendChild(adv);
            const clr = mk('button', 'cdx-clr'); clr.type = 'button'; clr.textContent = '移除照片';
            clr.onclick = () => { c.img = ''; c.iw = c.ih = 0; draw(); commit(); };
            body.appendChild(clr);
            imgCards.push({ c, body, ph, clr });
          }
        }
        if (o.extraCard) { const ex = o.extraCard(c, i, { mk, ctl, commit, draw, changed }); if (ex) body.append(ex); }
        if (hasRh) {
          const tb = mk('div', 'cdx-tm'), line = mk('div', 'cdx-when');
          const T = () => tm().T[i] || { in: v.ui.in, hold: v.ui.hold, out: v.ui.out };
          const ctls = [
            ctl('进场', SEC, () => T().in, x => { c.inDur = x; changed(); }),
            ctl('停留', HOLD, () => T().hold, x => { toCustom(); c.hold = x; changed(); }),
            ctl('退出', SEC, () => T().out, x => { c.outDur = x; changed(); }),
          ];
          tb.append(...ctls); it.append(tb, line);
          cardCtl.push({ i, ctls, line, c, it });
        }
        const grip = it.querySelector('.cdx-grip');
        grip.addEventListener('mousedown', () => { it.draggable = true; });
        grip.addEventListener('mouseup', () => { it.draggable = false; });
        it.addEventListener('dragstart', e => { dragFrom = i; it.classList.add('drag'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'card'); });
        it.addEventListener('dragend', () => { dragFrom = -1; it.draggable = false; it.classList.remove('drag'); list.querySelectorAll('.over').forEach(x => x.classList.remove('over')); });
        it.addEventListener('dragover', e => { if (dragFrom < 0) return; e.preventDefault(); it.classList.add('over'); });
        it.addEventListener('dragleave', e => { if (!it.contains(e.relatedTarget)) it.classList.remove('over'); });
        it.addEventListener('drop', e => {
          if (dragFrom < 0) return; e.preventDefault();
          const [m] = v.items.splice(dragFrom, 1); v.items.splice(i, 0, m); dragFrom = -1; draw(); commit();
        });
        list.appendChild(it);
      });
      note.innerHTML = (o.note || '') + '文字卡里用 <b>**文字**</b> 标出重点（主题色），<b>*文字*</b> 只加粗，<b>~文字~</b> 划掉。按住 ⠿ 上下拖动调整顺序'
        + (hasRh ? '，1 号最先出现。每张卡片下面可以单独调进场、停留、退出时长。' : '。')
        + '预览区：滚轮缩放 · 按住左键拖动位置 · 双击还原。';
      showMig();
      refreshTimes();
    }
    wrap.append(head);
    if (hasRh) wrap.append(rhythm);
    if (o.extraTop) { const ex = o.extraTop({ mk, ctl, commit, refreshTimes }); if (ex) wrap.append(ex); }
    if (fillBox) wrap.append(fillBox);
    wrap.append(list, bulk, mig, bulkIn, note);
    jl.after(wrap);
    ED.mounted = wrap; ED.refresh = refreshTimes;
    draw();
  };
})();

/* =====================================================================
 * 效果工坊 · 公共关键帧（FXKeys）—— 所有卡片类效果共用
 *
 * 做什么：在某一秒把「整组卡片的 X / Y / Z 角度（可选还有大小）」记成一个关键帧，
 *         两个关键帧之间自动过渡。导出时服务器也是逐帧调 renderAt，所以导出的每一帧
 *         和预览里看到的完全一致。
 *
 * 【关键】关键帧只管「中间那一段」：
 *   第一个关键帧之前、最后一个关键帧之后，角度回到参数里的默认值，
 *   于是效果自带的开场和结尾原样保留，不会被关键帧按住。
 *   两端用「首尾衔接（秒）」平滑过渡过去，不会硬切。
 *   想让首尾保持关键帧的角度，把「关键帧之外」改成「保持首尾」。
 *
 * 效果里只要三步：
 *   1) effect.json 加 rotX / rotY / rotZ / persp / keys 五个参数（照抄任意一个卡片效果）
 *   2) renderAt 里： const R = FXKeys.at(P, t, 总时长);
 *                   stage.style.perspective = R.persp + 'px';
 *                   根元素.style.transform = `... rotateX(${R.x}deg) rotateY(${R.y}deg) rotateZ(${R.z}deg)`;
 *   3) init 里： FXKeys.mount({ P, render: renderAt, total: () => 总时长 });
 * ===================================================================== */
(function () {
  const FX = window.FXCards;
  const num = FX.num, clamp = FX.clamp, prog = FX.prog, lerp = FX.lerp;
  const K = { _raw: null, _K: null, dragging: false, api: null };
  window.FXKeys = K;

  const KDEF = () => ({ on: true, auto: true, scale: false, ease: 'smooth', edge: 'blend', fade: 0.6, list: [] });
  const r1 = x => Math.round(x * 10) / 10;
  const r2 = x => Math.round(x * 100) / 100;

  // ---------- 读数据（按字符串缓存，没变就不重复解析） ----------
  K.read = P => {
    const raw = typeof (P && P.keys) === 'string' ? P.keys : JSON.stringify((P && P.keys) || null);
    if (K._raw === raw && K._K) return K._K;
    let v; try { v = typeof P.keys === 'string' ? JSON.parse(P.keys) : P.keys; } catch (e) { v = null; }
    const o = KDEF();
    if (v && typeof v === 'object') {
      o.on = v.on !== false; o.auto = v.auto !== false; o.scale = v.scale === true;
      o.ease = v.ease === 'linear' ? 'linear' : 'smooth';
      o.edge = v.edge === 'hold' ? 'hold' : 'blend';
      o.fade = Math.max(0, num(v.fade, 0.6));
      if (Array.isArray(v.list)) o.list = v.list;
    }
    o.list = o.list.filter(k => k && Number.isFinite(+k.t))
      .map(k => ({ t: Math.max(0, r2(+k.t)), x: r1(+k.x || 0), y: r1(+k.y || 0), z: r1(+k.z || 0), s: Number.isFinite(+k.s) ? r2(+k.s) : 1 }))
      .sort((a, b) => a.t - b.t);
    K._raw = raw; K._K = o;
    return o;
  };

  // ---------- 求值：返回这一帧要用的角度 / 大小 / 透视 ----------
  // def = 参数里的默认角度；关键帧之外就用它 —— 开场和结尾因此原样保留
  const MAP0 = { x: 'rotX', y: 'rotY', z: 'rotZ' };
  K.at = (P, t, total, map) => {
    P = P || {}; map = map || K.map || MAP0;
    const def = { x: num(P[map.x], 0), y: num(P[map.y], 0), z: num(P[map.z], 0), s: clamp(num(P.scale, 1), 0.1, 5) };
    const out = { x: def.x, y: def.y, z: def.z, s: def.s, persp: clamp(num(P.persp, 2400), 400, 20000), on: false };
    const o = K.read(P);
    // 正在右键拖动时先不走曲线，直接显示拖出来的角度（不然画面被曲线按住，不跟手）
    if (!o.on || !o.list.length || K.dragging) return out;
    const L = o.list, first = L[0], last = L[L.length - 1];
    const ease = u => (o.ease === 'linear' ? u : FX.smooth(u));
    const mix = (a, b, u) => ({ x: lerp(a.x, b.x, u), y: lerp(a.y, b.y, u), z: lerp(a.z, b.z, u), s: lerp(a.s, b.s, u) });
    let v;
    if (t <= first.t) {
      if (o.edge === 'hold') v = first;
      else if (o.fade <= 0) v = (t < first.t ? def : first);
      else v = mix(def, first, ease(prog(t, first.t - o.fade, first.t)));     // 开场：从默认角度平滑过渡到第一个关键帧
    } else if (t >= last.t) {
      if (o.edge === 'hold') v = last;
      else if (o.fade <= 0) v = (t > last.t ? def : last);
      else v = mix(last, def, ease(prog(t, last.t, last.t + o.fade)));        // 结尾：平滑回到默认角度
    } else {
      let i = 0; while (i < L.length - 1 && L[i + 1].t <= t) i++;
      v = mix(L[i], L[i + 1], ease((t - L[i].t) / Math.max(1e-6, L[i + 1].t - L[i].t)));
    }
    out.x = v.x; out.y = v.y; out.z = v.z; out.on = true;
    if (o.scale) out.s = clamp(v.s, 0.1, 5);
    return out;
  };

  // ---------- 挂到工作台：右键拖动 + 右侧面板 + 给轨道用的接口 ----------
  // o = { P, render(t), total() }
  K.mount = o => {
    const P = o.P;
    const MAP = o.map || MAP0;          // 有的老效果把角度存在自己的参数里（如 ring-carousel 的 tilt / roll / startAngle）
    K.map = MAP;
    let pw, pd;
    try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
    const boxOf = () => pd.getElementById('box');
    const inBox = e => { const b = boxOf(); return b && e.target instanceof pw.Node && b.contains(e.target); };
    const hint = s => { const h = pd.getElementById('hint'); if (h) h.textContent = s; };
    const slider = () => pd.getElementById('slider');
    const nowT = () => { const s = slider(); return s ? +s.value || 0 : 0; };
    const seekTo = t => { const s = slider(); if (!s) return; s.value = t; s.dispatchEvent(new pw.Event('input', { bubbles: true })); };
    const KF = () => K.read(P);
    // 存回参数。**不派发 input 事件**：工作台收到 input 会重新 init 并从 0 秒重播，
    // 关键帧这种「停在某一秒反复微调」的操作就没法用了。P 就是工作台的 params（按引用传进来的），直接写即可。
    const commit = () => {
      const o2 = KF();
      const json = JSON.stringify({ on: o2.on, auto: o2.auto, scale: o2.scale, ease: o2.ease, edge: o2.edge, fade: o2.fade, list: o2.list });
      P.keys = json; K._raw = json;
      if (field) field.value = json;
      try { if (pw.markDirty) pw.markDirty(); } catch (e) { }
      try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }   // 顺手刷新播放器下面的轨道
    };

    // ---- 给工作台轨道用的接口 ----
    K.api = {
      get: () => KF().list.map(k => ({ ...k })),
      set: list => { const o2 = KF(); o2.list = list.map(k => ({ t: Math.max(0, r2(+k.t)), x: r1(+k.x || 0), y: r1(+k.y || 0), z: r1(+k.z || 0), s: Number.isFinite(+k.s) ? r2(+k.s) : 1 })).sort((a, b) => a.t - b.t); commit(); refresh(); o.render(nowT()); },
      addAt: t => { const c = K.at(P, nowT(), K.api.total()); setKey(t, c.x, c.y, c.z); o.render(nowT()); },
      enabled: () => KF().on,
      total: () => (o.total ? +o.total() || 0 : 0)
    };
    window.__fxKeysApi = K.api;      // 挂在效果自己的 window 上：换效果时跟着 iframe 一起消失，不会留下过期接口

    function setKey(t, x, y, z) {
      const o2 = KF();
      t = Math.max(0, r2(t));
      const hit = o2.list.find(k => Math.abs(k.t - t) < 0.04);
      const rec = { t, x: r1(x), y: r1(y), z: r1(z), s: r2(clamp(num(P.scale, 1), 0.1, 5)) };
      if (hit) Object.assign(hit, rec); else o2.list.push(rec);
      o2.list.sort((a, b) => a.t - b.t);
      commit(); refresh();
    }
    K.setAt = setKey;

    // ================= 右键拖动转 XYZ =================
    const syncRot = () => {
      const b = pd.getElementById('params'); if (!b) return;
      const rows = [...b.children].flatMap(el => el.classList && el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);
      const LB = o.labels || { y: 'Y 轴旋转', x: 'X 轴俯仰', z: 'Z 轴倾斜' };
      [[LB.y, 'rotY'], [LB.x, 'rotX'], [LB.z, 'rotZ']].forEach(([lab, key]) => {
        const row = rows.find(el => {
          const f = el.firstChild; if (!f) return false;
          const txt = f.nodeType === 3 ? f.textContent : (f.firstChild && f.firstChild.textContent) || '';
          return String(txt).trim().startsWith(lab);
        });
        const inp = row && row.querySelector('input[type=number]');
        if (inp) { inp.value = r1(num(P[key], 0)); if (inp.__fxRange) inp.__fxRange.value = inp.value; }
      });
    };
    let drag = null, raf = 0, lastRight = 0, lastRightXY = [0, 0];
    const zeroAll = why => {
      P[MAP.x] = 0; P[MAP.y] = 0; P[MAP.z] = 0;
      const o2 = KF(); if (o2.on && o2.list.length) setKey(nowT(), 0, 0, 0);
      o.render(nowT()); syncRot(); hint(why);
    };
    const onCtx = e => { if (inBox(e)) e.preventDefault(); };
    const onDown = e => {
      if (!inBox(e) || e.button !== 2) return;
      e.preventDefault(); e.stopPropagation();
      const now = Date.now();
      // 浏览器的 dblclick 只对左键触发，右键没有这个事件 → 自己判断双击
      if (now - lastRight < 350 && Math.abs(e.clientX - lastRightXY[0]) < 6 && Math.abs(e.clientY - lastRightXY[1]) < 6) {
        lastRight = 0; drag = null; K.dragging = false;
        const b0 = boxOf(); if (b0) b0.style.cursor = '';
        zeroAll('三轴角度已归零'); return;
      }
      lastRight = now; lastRightXY = [e.clientX, e.clientY];
      const cur = K.at(P, nowT(), K.api.total());          // 从「当前这一帧实际的角度」开始拖，画面不跳
      P[MAP.x] = cur.x; P[MAP.y] = cur.y; P[MAP.z] = cur.z;
      K.dragging = true;
      drag = { x: e.clientX, y: e.clientY, rx: cur.x, ry: cur.y, rz: cur.z, shift: e.shiftKey };
      const b = boxOf(); if (b) b.style.cursor = 'move';
    };
    const onMove = e => {
      if (!drag) return;
      e.preventDefault();
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (drag.shift || e.shiftKey) P[MAP.z] = r1(clamp(drag.rz + dx * 0.25, -180, 180));
      else { P[MAP.y] = r1(clamp(drag.ry + dx * 0.3, -180, 180)); P[MAP.x] = r1(clamp(drag.rx - dy * 0.3, -90, 90)); }
      if (!raf) raf = pw.requestAnimationFrame(() => { raf = 0; o.render(nowT()); syncRot(); });
      hint('X 轴 ' + r1(num(P[MAP.x], 0)) + '°　Y 轴 ' + r1(num(P[MAP.y], 0)) + '°　Z 轴 ' + r1(num(P[MAP.z], 0))
        + '°　·　Shift + 右键转 Z 轴　·　右键双击归零');
    };
    const onUp = () => {
      if (!drag) return;
      drag = null; K.dragging = false;
      const b = boxOf(); if (b) b.style.cursor = '';
      const o2 = KF();
      if (o2.on && o2.auto) {                               // 松手就在当前这一秒记一个关键帧
        const t = nowT();
        setKey(t, num(P[MAP.x], 0), num(P[MAP.y], 0), num(P[MAP.z], 0));
        hint('已在 ' + t.toFixed(2) + ' 秒记下关键帧：X ' + r1(num(P[MAP.x], 0)) + '°　Y ' + r1(num(P[MAP.y], 0)) + '°　Z ' + r1(num(P[MAP.z], 0)) + '°');
      }
      o.render(nowT());
    };
    const onDbl = e => { if (inBox(e) && e.button === 0) setTimeout(() => zeroAll('已还原：大小、位置、角度'), 0); };
    // 效果自己已经有右键转轴时（ring-carousel），传 drag:false，这里就不重复接管，
    // 由它在自己的松手处调 FXKeys.recordNow() 来自动打点
    K.recordNow = () => {
      const o2 = KF(); if (!o2.on || !o2.auto) return;
      const t = nowT();
      setKey(t, num(P[MAP.x], 0), num(P[MAP.y], 0), num(P[MAP.z], 0));
      hint('已在 ' + t.toFixed(2) + ' 秒记下关键帧：X ' + r1(num(P[MAP.x], 0)) + '°　Y ' + r1(num(P[MAP.y], 0)) + '°　Z ' + r1(num(P[MAP.z], 0)) + '°');
      o.render(t);
    };
    if (o.drag !== false) {
    try { if (pw.__fxRotDispose) pw.__fxRotDispose(); } catch (e) { }
    pd.addEventListener('contextmenu', onCtx, true);
    pd.addEventListener('mousedown', onDown, true);
    pd.addEventListener('mousemove', onMove, true);
    pd.addEventListener('mouseup', onUp, true);
    pd.addEventListener('dblclick', onDbl, true);
    pw.__fxRotDispose = () => {
      pd.removeEventListener('contextmenu', onCtx, true);
      pd.removeEventListener('mousedown', onDown, true);
      pd.removeEventListener('mousemove', onMove, true);
      pd.removeEventListener('mouseup', onUp, true);
      pd.removeEventListener('dblclick', onDbl, true);
      pw.__fxRotDispose = null;
    };
    } else { try { if (pw.__fxRotDispose) pw.__fxRotDispose(); } catch (e) { } }

    // ================= 右侧面板里的「关键帧」一栏 =================
    const box = pd.getElementById('params');
    const labelOf = el => { const f = el.firstChild; if (!f) return ''; return String(f.nodeType === 3 ? f.textContent : (f.firstChild && f.firstChild.textContent) || '').trim(); };
    const rowsOf = () => [...box.children].flatMap(el => el.classList && el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);
    let field = null, host = null, refresh = () => { };
    if (box) {
      const jl = rowsOf().find(el => el.tagName === 'LABEL' && labelOf(el).startsWith('关键帧'));
      field = jl && jl.querySelector('input,textarea');
      if (field) {
        if (K.panelBox && box.contains(K.panelBox)) { K.panelRedraw && K.panelRedraw(); refresh = K.panelRedraw; }
        else {
          box.querySelectorAll('.kfx').forEach(x => x.remove());
          jl.style.display = 'none';
          host = buildPanel(pd, pw, jl);
          refresh = host.redraw;
        }
      }
    }
    refresh();
    try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }

    function buildPanel(pd, pw, jl) {
      if (!pd.getElementById('kfx-style')) {
        const st = pd.createElement('style'); st.id = 'kfx-style';
        st.textContent = `
.kfx{display:block;font-size:12px;color:#999;margin-bottom:14px}
.kfx-b{margin-top:8px;padding:10px;background:#101010;border:1px solid #2c2c2c;border-radius:8px}
.kfx-top{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.kfx-top>span{flex:1;color:#ccc;font-size:13px}
.kfx-seg{display:flex;background:#1d1d1d;border:1px solid #333;border-radius:6px;overflow:hidden}
.kfx-seg button{border:0;background:none;color:#aaa;padding:4px 11px;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap}
.kfx-seg button.on{background:#f28c0f;color:#000;font-weight:600}
.kfx-now{padding:7px 9px;background:#0b0b0b;border:1px solid #262626;border-radius:6px;font-size:12px;color:#bbb;line-height:1.7}
.kfx-now b{color:#f2a33d;font-weight:600}
.kfx-add{display:block;width:100%;margin-top:8px;padding:9px;font-size:13px;color:#111;border:0;border-radius:6px;cursor:pointer;font-family:inherit;font-weight:600;background:#f28c0f}
.kfx-add:hover{filter:brightness(1.08)}
.kfx-row{display:flex;align-items:center;gap:8px;margin-top:9px;color:#aaa}
.kfx-row>span{flex:1;min-width:0}
.kfx-clr{display:block;width:100%;margin-top:8px;padding:7px;font-size:12px;border-radius:6px;cursor:pointer;font-family:inherit;background:#262626;color:#bbb;border:1px solid #333}
.kfx-clr:hover{border-color:#5a1f1f;color:#fff}
.kfx-note{margin-top:7px;font-size:11.5px;color:#777;line-height:1.7}
.kfx-note b{color:#f2b56a;font-weight:500}`;
        pd.head.appendChild(st);
      }
      const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
      const wrap = mk('div', 'kfx'); wrap.append('关键帧');
      const b = mk('div', 'kfx-b');
      const top = mk('div', 'kfx-top', '<span>关键帧动画</span>');
      const segOn = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
      top.appendChild(segOn);
      const now = mk('div', 'kfx-now', '把进度条拖到某一秒，这里会显示那一帧的角度');
      const add = mk('button', 'kfx-add'); add.type = 'button';
      const rowAuto = mk('div', 'kfx-row', '<span>拖完自动打点</span>');
      const segAuto = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
      rowAuto.appendChild(segAuto);
      const rowEase = mk('div', 'kfx-row', '<span>两点之间</span>');
      const segEase = mk('div', 'kfx-seg', '<button type="button" data-v="smooth">平滑</button><button type="button" data-v="linear">匀速</button>');
      rowEase.appendChild(segEase);
      const rowEdge = mk('div', 'kfx-row', '<span>关键帧之外</span>');
      const segEdge = mk('div', 'kfx-seg', '<button type="button" data-v="blend">回到默认</button><button type="button" data-v="hold">保持首尾</button>');
      rowEdge.appendChild(segEdge);
      const rowFade = mk('div', 'kfx-row', '<span>首尾衔接（秒）</span>');
      const fadeIn = mk('input'); fadeIn.type = 'number'; fadeIn.min = '0'; fadeIn.max = '10'; fadeIn.step = '0.1';
      fadeIn.style.cssText = 'width:72px;flex:none;margin:0;padding:5px 7px;text-align:right';
      rowFade.appendChild(fadeIn);
      const rowScale = mk('div', 'kfx-row', '<span>也记录卡片大小</span>');
      const segScale = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
      rowScale.appendChild(segScale);
      const clr = mk('button', 'kfx-clr'); clr.type = 'button'; clr.textContent = '清空全部关键帧';
      const note = mk('div', 'kfx-note');

      const applyNow = () => { liveT = 0; redraw(); commit(); o.render(nowT()); };
      segOn.querySelectorAll('button').forEach(x => x.onclick = () => { KF().on = x.dataset.v === '1'; applyNow(); });
      segAuto.querySelectorAll('button').forEach(x => x.onclick = () => { KF().auto = x.dataset.v === '1'; applyNow(); });
      segEase.querySelectorAll('button').forEach(x => x.onclick = () => { KF().ease = x.dataset.v; applyNow(); });
      segEdge.querySelectorAll('button').forEach(x => x.onclick = () => { KF().edge = x.dataset.v; applyNow(); });
      segScale.querySelectorAll('button').forEach(x => x.onclick = () => { KF().scale = x.dataset.v === '1'; applyNow(); });
      fadeIn.addEventListener('input', () => { KF().fade = Math.max(0, num(fadeIn.value, 0.6)); liveT = 0; commit(); o.render(nowT()); });
      add.onclick = () => { const c = K.at(P, nowT(), o.total ? +o.total() || 0 : 0); setKey(nowT(), c.x, c.y, c.z); o.render(nowT()); };
      clr.onclick = () => { KF().list = []; applyNow(); };

      function redraw() {
        const o2 = KF(), t = nowT(), n = o2.list.length;
        segOn.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.on));
        segAuto.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.auto));
        segEase.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.v === o2.ease));
        segEdge.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.v === o2.edge));
        segScale.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.scale));
        if (pd.activeElement !== fadeIn) fadeIn.value = o2.fade;
        rowFade.style.display = o2.edge === 'blend' ? '' : 'none';
        add.textContent = '＋ 在 ' + t.toFixed(2) + ' 秒打一个关键帧';
        note.innerHTML = !o2.on
          ? '关键帧动画已关闭，现在用的是「X / Y / Z」三个固定角度。'
          : n === 0 ? '还没有关键帧。<b>把进度条拖到某一秒，再在预览区按住右键转到合适的角度，松手就自动记下这一帧</b>；播放器下面那条轨道上会出现一个点，可以框选、拖着前后移动。'
            : n + ' 个关键帧。<b>第一个点之前、最后一个点之后会回到默认角度</b>，所以效果自带的开场和结尾原样保留；中间这一段才走你打的关键帧。点在播放器下面的轨道上，可以框选、拖动、按 Delete 删除。';
        try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }
      }
      let liveT = 0;
      K.live = (t, rx, ry, rz, s) => {
        const nn = Date.now(); if (nn - liveT < 80) return; liveT = nn;
        const o2 = KF();
        now.innerHTML = '当前 <b>' + (+t).toFixed(2) + ' 秒</b>　X <b>' + r1(rx) + '°</b>　Y <b>' + r1(ry) + '°</b>　Z <b>' + r1(rz) + '°</b>'
          + (o2.scale ? '　大小 <b>' + Math.round(s * 100) + '%</b>' : '');
        add.textContent = '＋ 在 ' + (+t).toFixed(2) + ' 秒打一个关键帧';
      };
      b.append(top, now, add, rowAuto, rowEase, rowEdge, rowFade, rowScale, clr, note);
      wrap.appendChild(b); jl.after(wrap);
      K.panelBox = wrap; K.panelRedraw = redraw;
      redraw();
      return { redraw };
    }
  };
})();
