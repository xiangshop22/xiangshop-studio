/* 效果工坊 · 通用预览操作（所有效果共用）
 * 在工作台预览区：
 *   - 鼠标滚轮：缩放大小（写入参数 scale）
 *   - 按住鼠标左键拖动：移动位置（写入参数 offsetX / offsetY，单位是 1920×1080 画布上的像素）
 *   - 双击：还原大小和位置
 * 改的是工作台里同一份参数，所以导出的视频和预览一致。
 * 导出时页面单独打开（没有工作台），这个脚本什么都不做。
 * 放在 effects/_shared 里：没有 effect.json，工作台不会把它当成一个效果。
 */
(function () {
  let pw, pd;
  try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
  if (typeof window.init !== 'function' || typeof window.renderAt !== 'function') return;

  const CFG = window.VIEW_CONTROLS || {};          // { live: true } = renderAt 每帧都读参数，不用重新 init
  let lastP = null, lastT = 0;
  const origInit = window.init, origRender = window.renderAt;
  window.init = function (p) { lastP = p; const r = origInit.apply(this, arguments); setTimeout(() => { hideSize(); enhancePanel(); groupPanel(); }, 0); return r; };
  window.renderAt = function (t) { lastT = +t || 0; return origRender.apply(this, arguments); };

  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const box = () => pd.getElementById('box');
  const labelOf = el => {
    const f = el.firstChild; if (!f) return '';
    if (f.nodeType === 3) return f.textContent.trim();
    if (f.classList && f.classList.contains('fxr-row')) return (f.firstChild.textContent || '').trim();
    return '';
  };
  // 面板里的每一项（分组折叠后它们在分组里面，也要找得到）
  const panelItems = () => {
    const b = pd.getElementById('params'); if (!b) return [];
    return [...b.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : el.classList.contains('fxg-bar') ? [] : [el]);
  };
  const panelLabel = prefix => panelItems().find(el => labelOf(el).startsWith(prefix));
  // 右侧面板精简：大小、水平偏移、垂直偏移都用鼠标在预览区直接调（滚轮 / 拖动 / 双击还原），面板里不再显示
  function hideSize() { ['卡片大小', '水平偏移', '垂直偏移'].forEach(k => { const l = panelLabel(k); if (l) l.style.display = 'none'; }); }
  function syncInputs() {
    [['水平偏移', 'offsetX'], ['垂直偏移', 'offsetY']].forEach(([lab, key]) => {
      const l = panelLabel(lab), i = l && l.querySelector('input');
      if (i && lastP) { i.value = Math.round(num(lastP[key], 0)); if (i.__fxRange) i.__fxRange.value = i.value; }
    });
  }

  // ---------- 规则：所有数字参数 = 文字后面一个数字框 + 下面一条滑块 ----------
  let defs = null;
  fetch(new URL('effect.json', location.href)).then(r => r.json()).then(j => { defs = j.params || []; hideSize(); enhancePanel(); groupPanel(); }).catch(() => {});
  function rangeOf(def, input) {
    const key = def && def.key, d = num(def && def.default, num(input.value, 0));
    let min = def && def.min != null ? +def.min : null, max = def && def.max != null ? +def.max : null;
    if (key === 'offsetX') { if (min == null) min = -960; if (max == null) max = 960; }
    if (key === 'offsetY') { if (min == null) min = -540; if (max == null) max = 540; }
    if (min == null) min = d < 0 ? d * 4 : 0;
    if (max == null) max = d > 0 ? Math.max(10, Math.ceil(d * 4)) : 100;
    if (max <= min) max = min + 1;
    let step = def && def.step != null && def.step !== 'any' ? +def.step : null;
    if (!step || !(step > 0)) { const raw = (max - min) / 200, p10 = Math.pow(10, Math.floor(Math.log10(raw))); step = [1, 2, 5, 10].map(m => m * p10).find(x => x >= raw) || raw; }
    return { min, max, step };
  }
  function enhancePanel() {
    const box = pd.getElementById('params'); if (!box || !defs) return;
    if (!pd.getElementById('fxr-style')) {
      const st = pd.createElement('style'); st.id = 'fxr-style';
      st.textContent = `
.fxr-row{display:flex;align-items:center;justify-content:space-between;gap:10px}
.fxr-row>span{flex:1;min-width:0}
.fxr-row input[type=number]{width:96px!important;flex:none;margin:0!important;display:inline-block!important;text-align:right;padding:6px 8px!important}
input.fxr-range{display:block!important;width:100%!important;margin:8px 0 2px!important;padding:0!important;border:0!important;background:none!important;height:18px;accent-color:#f28c0f;cursor:pointer}`;
      pd.head.appendChild(st);
    }
    panelItems().forEach(lab => {
      if (lab.tagName !== 'LABEL' || lab.dataset.fxr) return;
      const input = [...lab.children].find(x => x.tagName === 'INPUT' && x.type === 'number');
      if (!input) return;
      const text = labelOf(lab);
      const def = defs.find(q => q.type === 'number' && q.label === text) || defs.find(q => q.type === 'number' && text && q.label && text.startsWith(q.label));
      const { min, max, step } = rangeOf(def, input);
      lab.dataset.fxr = '1';
      const row = pd.createElement('div'); row.className = 'fxr-row';
      const span = pd.createElement('span'); span.textContent = text;
      lab.firstChild.remove();
      row.append(span, input);
      const rng = pd.createElement('input'); rng.type = 'range'; rng.className = 'fxr-range';
      rng.min = min; rng.max = max; rng.step = step; rng.value = input.value;
      input.__fxRange = rng;
      rng.addEventListener('input', () => {
        input.value = rng.value;
        input.dispatchEvent(new pw.Event('input', { bubbles: true }));
      });
      input.addEventListener('input', () => { if (input.value !== '') rng.value = input.value; });
      lab.prepend(row); lab.appendChild(rng);
    });
  }
  // ---------- 右侧参数分组折叠：内容 / 样式 / 数值调节 ----------
  const effId = (location.pathname.match(/effects\/([^/]+)\//) || [])[1] || 'fx';
  const store = {
    get(k) { try { return pw.localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { pw.localStorage.setItem(k, v); } catch (e) {} },
  };
  function groupPanel() {
    const box = pd.getElementById('params'); if (!box || !defs) return;
    if (box.querySelector(':scope > .fxg')) return;
    const kids = [...box.children]; if (!kids.length) return;
    if (!pd.getElementById('fxg-style')) {
      const st = pd.createElement('style'); st.id = 'fxg-style';
      st.textContent = `
.fxg-bar{display:flex;justify-content:flex-end;gap:6px;margin:-4px 0 8px}
.fxg-bar button{background:#1d1d1d;color:#aaa;border:1px solid #2c2c2c;border-radius:6px;padding:3px 10px;font-size:12px;cursor:pointer;font-family:inherit}
.fxg-bar button:hover{color:#f28c0f;border-color:#f28c0f}
.fxg{margin:0 0 10px;border:1px solid #262626;border-radius:8px;background:#121212}
.fxg-h{display:flex;align-items:center;gap:8px;width:100%;padding:10px 12px;background:none;border:0;color:#ddd;font-size:13px;font-weight:600;cursor:pointer;text-align:left;font-family:inherit}
.fxg-h:hover{color:#f28c0f}
.fxg-h i{font-style:normal;color:#f28c0f;display:inline-block;transition:transform .15s}
.fxg.off .fxg-h i{transform:rotate(-90deg)}
.fxg-h small{margin-left:auto;color:#666;font-weight:400;font-size:12px}
.fxg-b{padding:4px 12px 2px}
.fxg.off .fxg-b{display:none}`;
      pd.head.appendChild(st);
    }
    const kindOf = el => {
      if (el.classList.contains('cdx') || (el.dataset && el.dataset.fxContent)) return 'content';
      const t = labelOf(el);
      const d = defs.find(q => q.label && t && (t === q.label || t.startsWith(q.label)));
      if (!d) return 'look';
      if (d.type === 'text' || d.type === 'textarea' || d.type === 'images' || d.type === 'cards') return 'content';
      if (d.type === 'number') return 'num';
      return 'look';
    };
    const G = [['content', '内容'], ['look', '样式'], ['num', '数值调节']];
    const groups = [];
    G.forEach(([k, name]) => {
      const mine = kids.filter(el => kindOf(el) === k); if (!mine.length) return;
      const g = pd.createElement('div'); g.className = 'fxg'; g.dataset.k = k;
      const h = pd.createElement('button'); h.type = 'button'; h.className = 'fxg-h';
      const shown = mine.filter(el => el.style.display !== 'none').length;
      h.innerHTML = '<i>▾</i>' + name + '<small>' + (k === 'content' ? '' : shown + ' 项') + '</small>';
      const body = pd.createElement('div'); body.className = 'fxg-b';
      body.append(...mine); g.append(h, body);
      if (!shown) g.style.display = 'none';
      const key = 'fxg:' + effId + ':' + k;
      if (store.get(key) === '0') g.classList.add('off');
      h.onclick = () => { g.classList.toggle('off'); store.set(key, g.classList.contains('off') ? '0' : '1'); };
      groups.push(g);
    });
    const bar = pd.createElement('div'); bar.className = 'fxg-bar';
    bar.innerHTML = '<button type="button" data-f="0">全部折叠</button><button type="button" data-f="1">全部展开</button>';
    bar.querySelectorAll('button').forEach(b => b.onclick = () => groups.forEach(g => {
      g.classList.toggle('off', b.dataset.f === '0'); store.set('fxg:' + effId + ':' + g.dataset.k, b.dataset.f);
    }));
    box.innerHTML = '';
    box.append(bar, ...groups);
  }
  function hint(msg) { const h = pd.getElementById('hint'); if (h) h.textContent = msg; }
  function apply() {
    if (!lastP) return;
    const t = lastT;                                  // init 内部会 renderAt(0)，先记住当前时间
    if (CFG.live) window.renderAt(t);
    else { window.init(lastP); window.renderAt(t); }
    syncInputs();
  }
  // 预览区里 1 个屏幕像素 = 多少个 1920×1080 画布像素
  function stagePerScreen() {
    const b = box(); if (!b) return 1;
    const fitS = Math.min(innerWidth / 1920, innerHeight / 1080) || 1;
    return (innerWidth / (b.getBoundingClientRect().width || innerWidth)) / fitS;
  }
  const inBox = e => { const b = box(); return b && e.target instanceof pw.Node && b.contains(e.target); };

  function onWheel(e) {
    if (!inBox(e) || !lastP) return;
    e.preventDefault(); e.stopPropagation();          // 拦下工作台自带的滚轮处理，避免缩放两次
    let s = num(lastP.scale, 1) * (e.deltaY < 0 ? 1.06 : 1 / 1.06);
    s = Math.min(5, Math.max(0.2, Math.round(s * 100) / 100));
    lastP.scale = s; apply();
    hint('大小 ' + Math.round(s * 100) + '%　·　按住左键拖动位置　·　双击还原');
  }
  let drag = null;
  function onDown(e) {
    if (!inBox(e) || e.button !== 0 || !lastP) return;
    e.preventDefault();
    drag = { x: e.clientX, y: e.clientY, ox: num(lastP.offsetX, 0), oy: num(lastP.offsetY, 0), k: stagePerScreen() };
    const b = box(); if (b) b.style.cursor = 'grabbing';
  }
  let raf = 0;
  function onMove(e) {
    if (!drag) return;
    lastP.offsetX = Math.round(drag.ox + (e.clientX - drag.x) * drag.k);
    lastP.offsetY = Math.round(drag.oy + (e.clientY - drag.y) * drag.k);
    if (!raf) raf = pw.requestAnimationFrame(() => { raf = 0; apply(); });
    hint('位置 X ' + lastP.offsetX + '　Y ' + lastP.offsetY + '　·　双击还原');
  }
  function onUp() { if (!drag) return; drag = null; const b = box(); if (b) b.style.cursor = 'grab'; }
  function onDbl(e) {
    if (!inBox(e) || !lastP) return;
    e.preventDefault(); e.stopPropagation();
    lastP.scale = 1; lastP.offsetX = 0; lastP.offsetY = 0; apply();
    hint('已还原：大小 100%，位置居中');
  }

  // 上一个效果留下的监听先撤掉，再挂这个效果的
  try { if (pw.__fxViewDispose) pw.__fxViewDispose(); } catch (e) {}
  pd.addEventListener('wheel', onWheel, { capture: true, passive: false });
  pd.addEventListener('mousedown', onDown, true);
  pd.addEventListener('mousemove', onMove, true);
  pd.addEventListener('mouseup', onUp, true);
  pd.addEventListener('dblclick', onDbl, true);
  const dispose = () => {
    pd.removeEventListener('wheel', onWheel, { capture: true });
    pd.removeEventListener('mousedown', onDown, true);
    pd.removeEventListener('mousemove', onMove, true);
    pd.removeEventListener('mouseup', onUp, true);
    pd.removeEventListener('dblclick', onDbl, true);
    if (pw.__fxViewDispose === dispose) pw.__fxViewDispose = null;
  };
  pw.__fxViewDispose = dispose;
  window.addEventListener('pagehide', dispose);
  window.addEventListener('unload', dispose);
  const b = box(); if (b) { b.style.cursor = 'grab'; const f = pd.getElementById('frame'); if (f) f.style.pointerEvents = 'none'; }
  hint('滚轮缩放大小　·　按住左键拖动位置　·　双击还原');
})();
