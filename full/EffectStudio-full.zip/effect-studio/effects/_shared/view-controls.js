/* 效果工坊 · 通用预览操作（所有效果共用）
 * 在工作台预览区：
 *   - 鼠标滚轮：缩放大小（写入参数 scale）
 *   - 按住鼠标左键拖动：移动位置（写入参数 offsetX / offsetY，单位是 1920×1080 画布上的像素）
 *   - 双击：还原大小和位置（v34.1：双击到字 = 就地改字，见文件末尾【预览里直接改字】）
 * 改的是工作台里同一份参数，所以导出的视频和预览一致。
 * 导出时页面单独打开（没有工作台），这个脚本什么都不做。
 * 放在 effects/_shared 里：没有 effect.json，工作台不会把它当成一个效果。
 */

/* =====================================================================
 * 【整体时长 · 按比例伸缩】（v8.1）—— 预览和导出都生效
 *
 * 工作台右侧最上面的「持续时间」：
 *   - 效果自己有「总时长」参数（dur / total / 分+秒）→ 工作台直接改那个参数，这一层不管；
 *   - 有「停留」类参数 → 工作台把多出来 / 少掉的时间加减在停留上，这一层也不管；
 *   - 都没有 → 工作台写 params.__dur = 目标秒数，由这一层把整段动画按比例放慢 / 加快：
 *       getDuration() 返回目标秒数；renderAt(t) 换算成效果原来的时间 t × 原长 / 目标。
 * 效果在 init / renderAt 里面自己调 getDuration() 时，拿到的仍是原来的时长（inner 计数），
 * 所以效果内部的进度计算不会乱。window.__fxNativeDur() = 效果原来的时长（给工作台算用）。
 * ===================================================================== */
(function () {
  const oi = window.init, or = window.renderAt, og = window.getDuration;
  if (typeof oi !== 'function' || typeof or !== 'function' || typeof og !== 'function') return;
  let P = null, inner = 0;
  const native = () => { inner++; try { return +og.call(window) || 0; } catch (e) { return 0; } finally { inner--; } };
  const target = () => { const v = P ? +P.__dur : 0; return Number.isFinite(v) && v > 0 ? v : 0; };
  window.__fxNativeDur = native;
  window.__fxCurP = () => P;                        // 当前参数（清晰度那一层判断「大小 / 角度变了没有」用）
  window.init = function (p) { P = p || {}; inner++; try { return oi.apply(this, arguments); } finally { inner--; } };
  window.getDuration = function () { if (inner) return og.apply(this, arguments); return target() || og.apply(this, arguments); };
  window.renderAt = function (t) {
    const T = target();
    if (!T || inner) return or.apply(this, arguments);
    const D = native(), k = D > 0 ? D / T : 1;
    inner++; try { return or.call(this, Math.max(0, +t || 0) * k); } finally { inner--; }
  };
})();

(function () {
  let pw, pd;
  try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
  if (typeof window.init !== 'function' || typeof window.renderAt !== 'function') return;

  const CFG = window.VIEW_CONTROLS || {};          // { live: true } = renderAt 每帧都读参数，不用重新 init
  let lastP = null, lastT = 0;
  const origInit = window.init, origRender = window.renderAt;
  window.init = function (p) { lastP = p; const r = origInit.apply(this, arguments); setTimeout(() => { hideSize(); enhancePanel(); groupPanel(); }, 0); return r; };
  window.renderAt = function (t) { lastT = +t || 0; return origRender.apply(this, arguments); };

  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const box = () => pd.getElementById('box');
  const labelOf = el => {
    const f = el.firstChild; if (!f) return '';
    if (f.nodeType === 3) return f.textContent.trim();
    if (f.classList && f.classList.contains('fxr-row')) return (f.firstChild.textContent || '').trim();
    return '';
  };
  // 面板里的每一项（分组折叠后它们在分组里面，也要找得到）
  const panelItems = () => {
    const b = pd.getElementById('params'); if (!b) return [];
    return [...b.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children]
      : el.classList.contains('fxdur') ? [...el.querySelectorAll('.fxdur-list > *')]          // 顶部「时长」里的分段时间（v8.1）
      : el.classList.contains('fxtop') ? [...el.children]                                      // 持续时间下面的「排版」（v29.1）
        : el.classList.contains('fxg-bar') ? [] : [el]);
  };
  const panelLabel = prefix => panelItems().find(el => labelOf(el).startsWith(prefix));
  // 右侧面板精简：大小、水平偏移、垂直偏移都用鼠标在预览区直接调（滚轮 / 拖动 / 双击还原），面板里不再显示
  // v8.1：X / Y / Z 三个角度也不再列出来 —— 在预览区按住右键拖（Shift + 右键转 Z），右键双击归零
  function hideSize() {
    ['卡片大小', '水平偏移', '垂直偏移'].forEach(k => { const l = panelLabel(k); if (l) l.style.display = 'none'; });
    if (!defs) return;
    const M = (window.FXKeys && window.FXKeys.map) || { x: 'rotX', y: 'rotY', z: 'rotZ' };
    const rk = new Set(['rotX', 'rotY', 'rotZ', M.x, M.y, M.z]);
    defs.forEach(d => {
      if (!rk.has(d.key) || !d.label) return;
      panelItems().forEach(el => { if (el.tagName === 'LABEL' && labelOf(el) === d.label) el.style.display = 'none'; });
    });
  }
  function syncInputs() {
    [['水平偏移', 'offsetX'], ['垂直偏移', 'offsetY']].forEach(([lab, key]) => {
      const l = panelLabel(lab), i = l && l.querySelector('input');
      if (i && lastP) { i.value = Math.round(num(lastP[key], 0)); if (i.__fxRange) i.__fxRange.value = i.value; }
    });
  }

  // ---------- 规则：所有数字参数 = 文字后面一个数字框 + 下面一条滑块 ----------
  let defs = null;
  fetch(new URL('effect.json', location.href)).then(r => r.json()).then(j => { defs = j.params || []; hideSize(); enhancePanel(); groupPanel(); }).catch(() => {});
  function rangeOf(def, input) {
    const key = def && def.key, d = num(def && def.default, num(input.value, 0));
    let min = def && def.min != null ? +def.min : null, max = def && def.max != null ? +def.max : null;
    if (key === 'offsetX') { if (min == null) min = -960; if (max == null) max = 960; }
    if (key === 'offsetY') { if (min == null) min = -540; if (max == null) max = 540; }
    if (min == null) min = d < 0 ? d * 4 : 0;
    if (max == null) max = d > 0 ? Math.max(10, Math.ceil(d * 4)) : 100;
    if (max <= min) max = min + 1;
    let step = def && def.step != null && def.step !== 'any' ? +def.step : null;
    if (!step || !(step > 0)) { const raw = (max - min) / 200, p10 = Math.pow(10, Math.floor(Math.log10(raw))); step = [1, 2, 5, 10].map(m => m * p10).find(x => x >= raw) || raw; }
    return { min, max, step };
  }
  function enhancePanel() {
    const box = pd.getElementById('params'); if (!box || !defs) return;
    if (!pd.getElementById('fxr-style')) {
      const st = pd.createElement('style'); st.id = 'fxr-style';
      st.textContent = `
.fxr-row{display:flex;align-items:center;justify-content:space-between;gap:10px}
.fxr-row>span{flex:1;min-width:0}
.fxr-row input[type=number]{width:96px!important;flex:none;margin:0!important;display:inline-block!important;text-align:right;padding:6px 8px!important}
input.fxr-range{display:block!important;width:100%!important;margin:8px 0 2px!important;padding:0!important;border:0!important;background:none!important;height:18px;accent-color:#f28c0f;cursor:pointer}`;
      pd.head.appendChild(st);
    }
    panelItems().forEach(lab => {
      if (lab.tagName !== 'LABEL' || lab.dataset.fxr) return;
      const input = [...lab.children].find(x => x.tagName === 'INPUT' && x.type === 'number');
      if (!input) return;
      const text = labelOf(lab);
      const def = defs.find(q => q.type === 'number' && q.label === text) || defs.find(q => q.type === 'number' && text && q.label && text.startsWith(q.label));
      const { min, max, step } = rangeOf(def, input);
      lab.dataset.fxr = '1';
      const row = pd.createElement('div'); row.className = 'fxr-row';
      const span = pd.createElement('span'); span.textContent = text;
      lab.firstChild.remove();
      row.append(span, input);
      const rng = pd.createElement('input'); rng.type = 'range'; rng.className = 'fxr-range';
      rng.min = min; rng.max = max; rng.step = step; rng.value = input.value;
      input.__fxRange = rng;
      rng.addEventListener('input', () => {
        input.value = rng.value;
        input.dispatchEvent(new pw.Event('input', { bubbles: true }));
      });
      input.addEventListener('input', () => { if (input.value !== '') rng.value = input.value; });
      lab.prepend(row); lab.appendChild(rng);
    });
  }
  // ---------- 右侧参数分组折叠：内容 / 样式 / 数值调节 ----------
  const effId = (location.pathname.match(/effects\/([^/]+)\//) || [])[1] || 'fx';
  const store = {
    get(k) { try { return pw.localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { pw.localStorage.setItem(k, v); } catch (e) {} },
  };
  function groupPanel() {
    const box = pd.getElementById('params'); if (!box || !defs) return;
    if (box.querySelector(':scope > .fxg')) return;
    const top = box.querySelector(':scope > .fxdur');           // 顶部「时长」那一块（v8.1）：不进分组，永远放在最上面
    const top2 = box.querySelector(':scope > .fxtop');          // 紧跟着的「排版」（v29.1）：也不进分组
    const kids = [...box.children].filter(el => el !== top && el !== top2 && !el.classList.contains('fxcolor') && !el.classList.contains('fxop'));   /* 「不透明度」（v39.0）也不进分组，跟在排版下面 */ if (!kids.length) return;   // 「去色 · 高亮」那一块（v14.0）不进分组，永远放在最后
    if (!pd.getElementById('fxg-style')) {
      const st = pd.createElement('style'); st.id = 'fxg-style';
      st.textContent = `
.fxg-bar{display:flex;justify-content:flex-end;gap:6px;margin:-4px 0 8px}
.fxg-bar button{background:#1d1d1d;color:#aaa;border:1px solid #2c2c2c;border-radius:6px;padding:3px 10px;font-size:12px;cursor:pointer;font-family:inherit}
.fxg-bar button:hover{color:#f28c0f;border-color:#f28c0f}
.fxg{margin:0 0 10px;border:1px solid #262626;border-radius:8px;background:#121212}
.fxg-h{display:flex;align-items:center;gap:8px;width:100%;padding:10px 12px;background:none;border:0;color:#ddd;font-size:13px;font-weight:600;cursor:pointer;text-align:left;font-family:inherit}
.fxg-h:hover{color:#f28c0f}
.fxg-h i{font-style:normal;color:#f28c0f;display:inline-block;transition:transform .15s}
.fxg.off .fxg-h i{transform:rotate(-90deg)}
.fxg-h small{margin-left:auto;color:#666;font-weight:400;font-size:12px}
.fxg-b{padding:4px 12px 2px}
.fxg.off .fxg-b{display:none}`;
      pd.head.appendChild(st);
    }
    const kindOf = el => {
      if (el.classList.contains('cdx') || (el.dataset && el.dataset.fxContent)) return 'content';
      const t = labelOf(el);
      const d = defs.find(q => q.label && t && (t === q.label || t.startsWith(q.label)));
      if (!d) return 'look';
      if (d.type === 'text' || d.type === 'textarea' || d.type === 'images' || d.type === 'cards') return 'content';
      if (d.type === 'number') return 'num';
      return 'look';
    };
    const G = [['content', '内容'], ['look', '样式'], ['num', '数值调节']];
    const groups = [];
    G.forEach(([k, name]) => {
      const mine = kids.filter(el => kindOf(el) === k); if (!mine.length) return;
      const g = pd.createElement('div'); g.className = 'fxg'; g.dataset.k = k;
      const h = pd.createElement('button'); h.type = 'button'; h.className = 'fxg-h';
      const shown = mine.filter(el => el.style.display !== 'none').length;
      h.innerHTML = '<i>▾</i>' + name + '<small>' + (k === 'content' ? '' : shown + ' 项') + '</small>';
      const body = pd.createElement('div'); body.className = 'fxg-b';
      body.append(...mine); g.append(h, body);
      if (!shown) g.style.display = 'none';
      const key = 'fxg:' + effId + ':' + k;
      if (store.get(key) === '0') g.classList.add('off');
      h.onclick = () => { g.classList.toggle('off'); store.set(key, g.classList.contains('off') ? '0' : '1'); };
      groups.push(g);
    });
    const bar = pd.createElement('div'); bar.className = 'fxg-bar';
    bar.innerHTML = '<button type="button" data-f="0">全部折叠</button><button type="button" data-f="1">全部展开</button>';
    bar.querySelectorAll('button').forEach(b => b.onclick = () => groups.forEach(g => {
      g.classList.toggle('off', b.dataset.f === '0'); store.set('fxg:' + effId + ':' + g.dataset.k, b.dataset.f);
    }));
    box.innerHTML = '';
    if (top) box.append(top);
    if (top2) box.append(top2);
    box.append(bar, ...groups);
  }
  function hint(msg) { const h = pd.getElementById('hint'); if (h) h.textContent = msg; }
  function apply() {
    if (!lastP) return;
    const t = lastT;                                  // init 内部会 renderAt(0)，先记住当前时间
    if (CFG.live) window.renderAt(t);
    else { window.init(lastP); window.renderAt(t); }
    syncInputs();
  }
  // 预览区里 1 个屏幕像素 = 多少个 1920×1080 画布像素
  function stagePerScreen() {
    const b = box(); if (!b) return 1;
    const fitS = Math.min(innerWidth / 1920, innerHeight / 1080) || 1;
    return (innerWidth / (b.getBoundingClientRect().width || innerWidth)) / fitS;
  }
  const inBox = e => { const b = box(); return b && e.target instanceof pw.Node && b.contains(e.target); };

  function onWheel(e) {
    if (!inBox(e) || !lastP) return;
    e.preventDefault(); e.stopPropagation();          // 拦下工作台自带的滚轮处理，避免缩放两次
    begin();                                          // 从画面当前这一帧的大小开始缩放
    const s0 = num(lastP.scale, 1);
    let s = s0 * (e.deltaY < 0 ? 1.06 : 1 / 1.06);
    s = Math.min(5, Math.max(0.2, Math.round(s * 100) / 100));
    lastP.scale = s; apply();
    try { if (pw.__fxLive) pw.__fxLive('s', s0, s); } catch (x) { }   // 多选时其他素材实时跟着缩放（v24.5）
    hint('大小 ' + Math.round(s * 100) + '%　·　按住左键拖动位置　·　双击还原');
    changed('scale');                                 // 让关键帧那一层在这一秒记下大小
  }
  // 手动操作开始 / 结束：交给关键帧层（对齐当前帧 + 操作期间暂停曲线）
  const begin = () => { try { if (window.__fxViewBegin) window.__fxViewBegin(); } catch (e) { } };
  const end = () => { try { if (window.__fxViewEnd) window.__fxViewEnd(); } catch (e) { } };
  // 缩放 / 位置改完通知关键帧层（它在本文件末尾那个 IIFE 里，会按当前秒自动打点）
  let chT = 0;
  function changed(kind) {
    clearTimeout(chT);
    chT = setTimeout(() => { try { if (window.__fxViewChanged) window.__fxViewChanged(kind); } catch (e) { } }, 220);
  }
  let drag = null;
  function onDown(e) {
    if (!inBox(e) || e.button !== 0 || !lastP) return;
    e.preventDefault();
    begin();                                          // 从画面当前这一帧的位置开始拖
    drag = { x: e.clientX, y: e.clientY, ox: num(lastP.offsetX, 0), oy: num(lastP.offsetY, 0), k: stagePerScreen() };
    const b = box(); if (b) b.style.cursor = 'grabbing';
  }
  let raf = 0;
  function onMove(e) {
    if (!drag) return;
    lastP.offsetX = Math.round(drag.ox + (e.clientX - drag.x) * drag.k);
    lastP.offsetY = Math.round(drag.oy + (e.clientY - drag.y) * drag.k);
    // 辅助对齐（v24.4）：工作台按其他素材 / 画面的边和中线算吸附，返回修正后的挪动量（按住 Alt 临时不吸）
    try { if (pw.__fxSnap) { const r = pw.__fxSnap(lastP.offsetX - drag.ox, lastP.offsetY - drag.oy, drag.k, e.altKey); if (r) { lastP.offsetX = Math.round(drag.ox + r[0]); lastP.offsetY = Math.round(drag.oy + r[1]); } } } catch (x) { }
    if (!raf) raf = pw.requestAnimationFrame(() => { raf = 0; apply(); });
    hint('位置 X ' + lastP.offsetX + '　Y ' + lastP.offsetY + '　·　双击还原');
  }
  function onUp() {
    if (!drag) return;
    const moved = drag.ox !== num(lastP.offsetX, 0) || drag.oy !== num(lastP.offsetY, 0);
    drag = null; try { if (pw.__fxSnapEnd) pw.__fxSnapEnd(); } catch (x) { } const b = box(); if (b) b.style.cursor = 'grab';
    if (moved) changed('pos');                        // 松手就在这一秒记下位置
    else end();
  }
  function onDbl(e) {
    if (!inBox(e) || !lastP) return;
    e.preventDefault(); e.stopPropagation();
    // v34.1：双击到字 = 就地改字（本文件末尾【预览里直接改字】，规则 45）；没点到字才「还原」
    try { if (window.__fxTextDbl && window.__fxTextDbl(e)) return; } catch (e3) { }
    // 有关键帧时交给关键帧层：只在这一秒打一个「还原」的点，不改原始参数（开场不受影响）
    try { if (window.__fxViewReset && window.__fxViewReset()) { hint('已在这一秒打了一个「还原」关键帧（大小 100%、位置居中、角度 0）'); return; } } catch (e2) { }
    lastP.scale = 1; lastP.offsetX = 0; lastP.offsetY = 0; apply();
    hint('已还原：大小 100%，位置居中');
  }

  // 上一个效果留下的监听先撤掉，再挂这个效果的
  try { if (pw.__fxViewDispose) pw.__fxViewDispose(); } catch (e) {}
  pd.addEventListener('wheel', onWheel, { capture: true, passive: false });
  pd.addEventListener('mousedown', onDown, true);
  pd.addEventListener('mousemove', onMove, true);
  pd.addEventListener('mouseup', onUp, true);
  pd.addEventListener('dblclick', onDbl, true);
  const dispose = () => {
    pd.removeEventListener('wheel', onWheel, { capture: true });
    pd.removeEventListener('mousedown', onDown, true);
    pd.removeEventListener('mousemove', onMove, true);
    pd.removeEventListener('mouseup', onUp, true);
    pd.removeEventListener('dblclick', onDbl, true);
    if (pw.__fxViewDispose === dispose) pw.__fxViewDispose = null;
  };
  pw.__fxViewDispose = dispose;
  window.addEventListener('pagehide', dispose);
  window.addEventListener('unload', dispose);
  const b = box(); if (b) { b.style.cursor = 'grab'; const f = pd.getElementById('frame'); if (f) f.style.pointerEvents = 'none'; }
  hint('滚轮缩放大小　·　按住左键拖动位置　·　按住右键转角度（Shift + 右键转 Z 轴）　·　双击还原');
})();

/* =====================================================================
 * 效果工坊 · 公共关键帧（FXKeys）—— 所有效果通用，v6.9 起
 *
 * 为什么放在 view-controls.js 里：**每一个效果都会加载这个文件**，所以关键帧成了
 * 全局能力 —— 以前做的、以后做的，都自动有，效果本身一行都不用改。
 *
 * 怎么做到不改效果：在 #stage 里插一层 <div id="fx-rot">，把原来 stage 下的内容
 * 整体搬进去，旋转 / 缩放都加在这一层上；透视加在 #stage 上（它是 fx-rot 的父节点）。
 * 效果自己的 DOM 结构、定位、裁剪都不受影响（fx-rot 和 stage 等大、同位置）。
 * 效果如果在 init 里清空过 #stage，init 之后会自动重新搬一次。
 *
 * 每个关键帧记的是【角度 x/y/z + 大小 s + 位置 ox/oy】三件事：
 *   右键拖转角度、滚轮缩放、左键拖位置，松手都会在当前这一秒自动打点。
 *   大小按「比例」、位置按「像素差」叠加到效果自己的 scale / offsetX / offsetY 上，不会打架。
 *   老数据里没有 ox/oy 的记录按默认值算，等于那一项没动过。
 *
 * 【核心语义】关键帧只管中间那一段：
 *   第一个关键帧之前、最后一个之后，角度 / 大小 / 位置回到参数里的默认值，
 *   所以每个效果自带的开场和结尾原样保留，不会被关键帧按住；
 *   两端用「首尾衔接（秒）」平滑过渡。想保持首尾角度就把「关键帧之外」改成「保持首尾」。
 *
 * 效果要做的事：只在 effect.json 里加 rotX / rotY / rotZ / persp / keys 五个参数。
 * 想自己接管（比如 ring-carousel 把关键帧接到它自己的 tilt / roll / startAngle 上）：
 *   window.VIEW_CONTROLS = { live:true, keys:{ apply:false, drag:false,
 *       map:{x:'tilt',y:'startAngle',z:'roll'}, labels:{...} } };
 *   然后自己在 renderAt 里调 FXKeys.at(P, t, 总时长)，在松手处调 FXKeys.recordNow()。
 * ===================================================================== */
(function () {
  const CFG0 = (window.VIEW_CONTROLS || {}).keys;
  if (CFG0 === false) return;                       // 明确关掉关键帧的效果
  const O = (CFG0 && typeof CFG0 === 'object') ? CFG0 : {};
  const MAP = O.map || { x: 'rotX', y: 'rotY', z: 'rotZ' };
  const APPLY = O.apply !== false;                  // false = 效果自己在 renderAt 里应用
  const DRAG = O.drag !== false;                    // false = 效果自己已经接管了右键
  const LB = O.labels || { y: 'Y 轴旋转', x: 'X 轴俯仰', z: 'Z 轴倾斜' };

  const origInit = window.init, origRender = window.renderAt;
  if (typeof origInit !== 'function' || typeof origRender !== 'function') return;

  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const prog = (t, a, b) => (b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1));
  const lerp = (a, b, k) => a + (b - a) * k;
  const smooth = x => x * x * (3 - 2 * x);
  const r1 = x => Math.round(x * 10) / 10;
  const r2 = x => Math.round(x * 100) / 100;

  let P = {}, lastT = 0, wrap = null;
  const K = { dragging: false, map: MAP };
  window.FXKeys = K;

  // ---------- 数据 ----------
  const KDEF = () => ({ on: true, auto: true, scale: true, pos: true, ease: 'smooth', edge: 'blend', fade: 0.6, list: [] });
  let _raw = null, _K = null;
  // 和 AE 一样分三条轨道，每条各自打点、互不牵连：
  //   P 位置 {t,k:'p',ox,oy}　S 大小 {t,k:'s',s}　R 旋转 {t,k:'r',x,y,z}
  // 老数据（一条记录里角度 / 大小 / 位置都有、没有 k）读进来自动拆成三条。
  const fin = v => (Number.isFinite(+v) ? +v : null);
  const norm = k => {
    const t = Math.max(0, r2(+k.t));
    if (k.k === 'p') return { t, k: 'p', ox: Math.round(num(k.ox, 0)), oy: Math.round(num(k.oy, 0)) };
    if (k.k === 's') return { t, k: 's', s: r2(clamp(num(k.s, 1), 0.1, 5)) };
    return { t, k: 'r', x: r1(+k.x || 0), y: r1(+k.y || 0), z: r1(+k.z || 0) };
  };
  const expand = k => (k.k ? [norm(k)] : [norm({ t: k.t, k: 'r', x: k.x, y: k.y, z: k.z })]
    .concat(fin(k.s) != null ? [norm({ t: k.t, k: 's', s: k.s })] : [])
    .concat(fin(k.ox) != null ? [norm({ t: k.t, k: 'p', ox: k.ox, oy: k.oy })] : []));
  const sortL = L => L.sort((a, b) => a.t - b.t || 'prs'.indexOf(a.k) - 'prs'.indexOf(b.k));
  K.norm = norm;
  K.read = p => {
    p = p || P;
    const raw = typeof p.keys === 'string' ? p.keys : JSON.stringify(p.keys || null);
    if (_raw === raw && _K) return _K;
    let v; try { v = typeof p.keys === 'string' ? JSON.parse(p.keys) : p.keys; } catch (e) { v = null; }
    const o = KDEF();
    if (v && typeof v === 'object') {
      o.on = v.on !== false; o.auto = v.auto !== false;
      o.scale = v.scale !== false; o.pos = v.pos !== false;
      o.ease = v.ease === 'linear' ? 'linear' : 'smooth';
      o.edge = v.edge === 'hold' ? 'hold' : 'blend';
      o.fade = Math.max(0, num(v.fade, 0.6));
      if (Array.isArray(v.list)) o.list = v.list;
    }
    o.list = sortL(o.list.filter(k => k && Number.isFinite(+k.t)).flatMap(expand));
    _raw = raw; _K = o;
    return o;
  };

  // ---------- 求值 ----------
  K.at = (p, t, total) => {
    t = Number.isFinite(+t) ? +t : 0;                        // 时间不合法时按 0 秒算，别让求值崩掉
    p = p || P;
    const def = { x: num(p[MAP.x], 0), y: num(p[MAP.y], 0), z: num(p[MAP.z], 0),
      s: clamp(num(p.scale, 1), 0.1, 5), ox: num(p.offsetX, 0), oy: num(p.offsetY, 0) };
    const out = { x: def.x, y: def.y, z: def.z, s: def.s, ox: def.ox, oy: def.oy,
      persp: clamp(num(p.persp, 2400), 400, 20000), on: false };
    const o = K.read(p);
    if (!o.on || !o.list.length) return out;
    // 拖动 / 缩放 / 旋转中（v24.5）：曲线照常走，再加上这次手动改的差值（P 现在 − 按下时的原始值）。
    // 以前是暂停曲线、把当前值塞进参数让效果自己画 —— 效果自己缩放的中心和关键帧那一层不一样，
    // 带「大小」关键帧的素材一按下去就偏一截、松手又弹回来。现在拖动时看到的就是松手后的样子。
    const B = K.dragging && K.dragBase;
    const dv = (f, d) => B ? num(p[f], d) - num(B[f], d) : 0;
    const ease = u => (o.ease === 'linear' ? u : smooth(u));
    // 一条轨道单独求值；边界语义不变：第一个点之前、最后一个点之后回到默认值（开场结尾保留）
    const lane = (kind, F) => {
      const L = o.list.filter(k => k.k === kind); if (!L.length) return null;
      const first = L[0], last = L[L.length - 1];
      const mix = (a, b, u) => { const r = {}; F.forEach(f => (r[f] = lerp(a[f], b[f], u))); return r; };
      if (t <= first.t) return o.edge === 'hold' ? first : o.fade <= 0 ? (t < first.t ? def : first)
        : mix(def, first, ease(prog(t, first.t - o.fade, first.t)));
      if (t >= last.t) return o.edge === 'hold' ? last : o.fade <= 0 ? (t > last.t ? def : last)
        : mix(last, def, ease(prog(t, last.t, last.t + o.fade)));
      let i = 0; while (i < L.length - 1 && L[i + 1].t <= t) i++;
      return mix(L[i], L[i + 1], ease((t - L[i].t) / Math.max(1e-6, L[i + 1].t - L[i].t)));
    };
    const R = lane('r', ['x', 'y', 'z']), S = o.scale ? lane('s', ['s']) : null, Pp = o.pos ? lane('p', ['ox', 'oy']) : null;
    if (R) { out.x = r1(R.x + dv(MAP.x, 0)); out.y = r1(R.y + dv(MAP.y, 0)); out.z = r1(R.z + dv(MAP.z, 0)); }
    if (S) out.s = clamp(S.s * (B ? num(p.scale, 1) / Math.max(0.01, num(B.scale, 1)) : 1), 0.1, 5);
    if (Pp) { out.ox = Math.round(Pp.ox + dv('offsetX', 0)); out.oy = Math.round(Pp.oy + dv('offsetY', 0)); }
    out.on = !!(R || S || Pp);
    return out;
  };

  // ---------- 【画面】在 #stage 里插一层，旋转加在这一层上 ----------
  // 有的老效果没有 #stage（直接往 body 里画），这时候就拿 body 当舞台
  function host() {
    return document.getElementById('stage')
      || (document.body && document.body.firstElementChild ? document.body : null);
  }
  function ensureWrap() {
    const st = host();
    if (!st) return null;
    if (st === document.body && getComputedStyle(st).position === 'static') st.style.position = 'relative';
    if (!wrap || wrap.parentNode !== st) {
      wrap = st.querySelector(':scope > #fx-rot');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.id = 'fx-rot';
        wrap.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;transform-origin:center center';
        st.appendChild(wrap);
      }
    }
    // 把 stage 下除 fx-rot 以外的节点搬进来（效果在 init 里清空过 stage 的话这里会重新搬）
    for (let n = st.firstChild; n;) { const next = n.nextSibling; if (n !== wrap) wrap.appendChild(n); n = next; }
    return wrap;
  }
  function applyRot(t) {
    const R = K.at(P, t, dur());
    const st = host();
    if (st) {
      // 效果自己已经乘过 P.scale / offsetX / offsetY 了，这里只补「关键帧带来的那一份」差值：
      // 大小是比例（没开就是 1），位置是像素差（没开就是 0），所以和效果自己的参数不会打架。
      const k = R.s / Math.max(0.01, num(P.scale, 1));
      const dx = R.ox - num(P.offsetX, 0), dy = R.oy - num(P.offsetY, 0);
      const move = (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5 ? 'translate(' + Math.round(dx) + 'px,' + Math.round(dy) + 'px) ' : '')
        + (Math.abs(k - 1) > 1e-4 ? 'scale(' + k.toFixed(4) + ') ' : '');
      // 角度由效果自己应用时（apply:false，如 ring-carousel），大小和位置仍然由这一层补
      const tr = APPLY
        ? move + 'rotateX(' + R.x + 'deg) rotateY(' + R.y + 'deg) rotateZ(' + R.z + 'deg)'
        : move.trim();
      if (APPLY || tr || wrap) {        // tr 变空时也要写回去，把上一帧的位移 / 缩放清掉
        const w = ensureWrap();
        if (APPLY && st.__p !== R.persp) { st.__p = R.persp; st.style.perspective = R.persp + 'px'; }
        if (w && w.__tr !== tr) { w.__tr = tr; w.style.transform = tr; }
      }
    }
    if (K.live) K.live(t, R.x, R.y, R.z, R.s, R);
    return R;
  }
  const dur = () => { try { return +window.getDuration() || 0; } catch (e) { return 0; } };

  window.init = function (p) {
    P = p || {};
    const r = origInit.apply(this, arguments);
    setTimeout(() => { try { ensureWrap(); mount(); applyRot(lastT); } catch (e) { console.error(e); } }, 0);
    return r;
  };
  window.renderAt = function (t) {
    lastT = +t || 0;
    const r = origRender.apply(this, arguments);
    try { applyRot(lastT); } catch (e) { }
    return r;
  };

  // ================= 工作台里的交互（右键拖动 + 面板 + 轨道接口） =================
  let mounted = false, panelBox = null, redraw = () => { }, field = null;
  let liveT = 0;                      // 放在最前面：面板找不到时 setKey 也会用到它
  let base = null;                    // 操作前存下的原始参数；放在 mount 外面——老效果每拖一下都会重新 init、重新 mount，放里面会被清掉
  function mount() {
    let pw, pd;
    try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
    const box = pd.getElementById('params'); if (!box) return;
    const boxOf = () => pd.getElementById('box');
    const inBox = e => { const b = boxOf(); return b && e.target instanceof pw.Node && b.contains(e.target); };
    const hint = s => { const h = pd.getElementById('hint'); if (h) h.textContent = s; };
    const slider = () => pd.getElementById('slider');
    const nowT = () => { const s = slider(); return s ? +s.value || 0 : 0; };
    const labelOf = el => { const f = el.firstChild; if (!f) return ''; return String(f.nodeType === 3 ? f.textContent : (f.firstChild && f.firstChild.textContent) || '').trim(); };
    const rowsOf = () => [...box.children].flatMap(el => el.classList && el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);

    // 存回参数：**不派发 input 事件**（工作台收到 input 会重新 init 并从 0 秒重播，关键帧就没法调了）。
    // P 就是工作台的 params（init 时按引用传进来的），直接写即可；导出照样读得到。
    const commit = () => {
      const o2 = K.read(P);
      const json = JSON.stringify({ on: o2.on, auto: o2.auto, scale: o2.scale, pos: o2.pos, ease: o2.ease, edge: o2.edge, fade: o2.fade, list: o2.list });
      P.keys = json; _raw = json;
      if (field) field.value = json;
      try { if (pw.markDirty) pw.markDirty(); } catch (e) { }
      try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }
    };
    // kind = 'r' / 's' / 'p'；同一条轨道 0.04 秒内已有点就改它
    function setKey(t, kind) {
      const o2 = K.read(P);
      t = Math.max(0, r2(t));
      const rec = norm(kind === 'p' ? { t, k: 'p', ox: P.offsetX, oy: P.offsetY }
        : kind === 's' ? { t, k: 's', s: P.scale }
          : { t, k: 'r', x: num(P[MAP.x], 0), y: num(P[MAP.y], 0), z: num(P[MAP.z], 0) });
      const hit = o2.list.find(k => k.k === kind && Math.abs(k.t - t) < 0.04);
      if (hit) Object.assign(hit, rec); else o2.list.push(rec);
      sortL(o2.list);
      liveT = 0; commit(); redraw();
    }
    const NAME = { p: '位置 P', s: '大小 S', r: '旋转 R' };
    const said = (t, kind) => hint('已在 ' + t.toFixed(2) + ' 秒记下【' + NAME[kind] + '】关键帧：'
      + (kind === 'p' ? 'X ' + Math.round(num(P.offsetX, 0)) + '　Y ' + Math.round(num(P.offsetY, 0))
        : kind === 's' ? Math.round(num(P.scale, 1) * 100) + '%'
          : 'X ' + r1(num(P[MAP.x], 0)) + '°　Y ' + r1(num(P[MAP.y], 0)) + '°　Z ' + r1(num(P[MAP.z], 0)) + '°'));
    // 在某一秒把三条轨道都打上点（面板按钮 / 轨道双击用）；kinds 不传 = 三条都打
    // 临时把参数改成 vals 去打点，打完马上还原 —— 参数是开场 / 结尾的默认值，打关键帧绝不能改它
    const SIX = () => [MAP.x, MAP.y, MAP.z, 'scale', 'offsetX', 'offsetY'];
    const withTemp = (vals, fn) => {
      const keep = {}; SIX().forEach(f => (keep[f] = P[f]));
      Object.assign(P, vals);
      try { fn(); } finally { Object.assign(P, keep); }
    };
    const keyAll = (t, kinds) => {
      const c = K.at(P, t, dur());
      withTemp({ [MAP.x]: c.x, [MAP.y]: c.y, [MAP.z]: c.z, scale: r2(c.s), offsetX: c.ox, offsetY: c.oy },
        () => (kinds || ['p', 's', 'r']).forEach(k => setKey(t, k)));
    };
    K.setAt = setKey;
    // 滚轮缩放 / 左键拖位置之后，由前面那一层调过来：在当前这一秒记一个关键帧
    // 任何手动操作（右键转 / 滚轮 / 左键拖）开始前：把角度、大小、位置都对齐到画面当前这一帧，
    // 并在操作期间暂停曲线（K.dragging），画面才跟手；松手打点后再恢复。
    // 关键：操作前先存下原始参数（= 开场 / 结尾的默认值），打完关键帧再还原。
    // 以前拖动会直接改掉这些参数，于是第一个关键帧之前的开场也跟着变了。
    const FIELDS = { r: [MAP.x, MAP.y, MAP.z], s: ['scale'], p: ['offsetX', 'offsetY'] };
    const finish = (kind, recorded) => {
      K.dragging = false; K.dragBase = null;
      if (base) {
        // 记成了关键帧：全部还原；没记（关键帧关着等）：这次手动改的那几项保留，其余还原
        const keep = recorded ? [] : (FIELDS[kind] || []);
        Object.keys(base).forEach(f => { if (!keep.includes(f)) P[f] = base[f]; });
        base = null;
      }
      window.renderAt(nowT());
    };
    K.finish = finish;
    window.__fxViewBegin = () => {
      if (K.dragging) return;
      base = {};
      [MAP.x, MAP.y, MAP.z, 'scale', 'offsetX', 'offsetY'].forEach(f => (base[f] = P[f]));
      const c = K.at(P, nowT(), dur());               // 按下这一刻画面上的值（曲线算出来的）
      startV = { x: c.x, y: c.y, z: c.z, s: r2(c.s), ox: Math.round(c.ox), oy: Math.round(c.oy) };
      K.dragBase = base; K.dragging = true;           // 参数先不动：拖动时画面 = 曲线 + 手动改的差值（见 K.at）
    };
    // 松手要记录时：把「原始值 + 差值」换算成「画面上的值」（按下时的曲线值 + 差值），后面打关键帧 / 摆位置都按画面上的值算
    const toScreenVals = () => {
      if (!base || !startV || !K.dragBase) return;    // 只换算一次
      const d = f => num(P[f], 0) - num(base[f], 0);
      P[MAP.x] = r1(startV.x + d(MAP.x)); P[MAP.y] = r1(startV.y + d(MAP.y)); P[MAP.z] = r1(startV.z + d(MAP.z));
      P.scale = r2(startV.s * num(P.scale, 1) / Math.max(0.01, num(base.scale, 1)));
      P.offsetX = Math.round(startV.ox + d('offsetX')); P.offsetY = Math.round(startV.oy + d('offsetY'));
      K.lastKw = startV.s / Math.max(0.01, num(base.scale, 1));   // 关键帧那一层的缩放倍数（位置关键帧不跟着它缩放，下面要换算）
      K.dragBase = null;
    };
    K.toScreenVals = () => toScreenVals();
    window.__fxViewEnd = () => finish(null, false);
    K.placing = () => placing(); K.placeShift = k => placeShift(k);
    // 播放头正停在这一行的某个关键帧上（v33.x）：自动关键帧关着也改这个关键帧，不走「摆位置」（不然手动打的关键帧拖了也不生效）
    K.onKey = kind => { const o2 = K.read(P), t = nowT(); return !!o2.on && o2.list.some(k => k.k === kind && Math.abs(k.t - t) < 0.04); };
    // ---------- 摆位置模式（v24.4）：工作台播放器下面「自动关键帧」关掉时 ----------
    // 拖动 / 缩放 / 旋转不打关键帧，而是把「原始值 + 这条轨道上所有关键帧」一起挪同样多（缩放按同样比例）：
    // 整段动画的样子不变，只是换个地方演。没有关键帧的素材就是直接改原始值。
    let startV = null;
    const placing = () => { try { return !!pw.__fxPlace; } catch (e) { return false; } };
    const placeShift = kind => {
      if (!base || !startV) return finish(kind, false);
      const o2 = K.read(P);
      if (kind === 'p') {
        const dx = num(P.offsetX, 0) - startV.ox, dy = num(P.offsetY, 0) - startV.oy;
        base.offsetX = Math.round(num(base.offsetX, 0) + dx); base.offsetY = Math.round(num(base.offsetY, 0) + dy);
        o2.list.forEach(k => { if (k.k === 'p') { k.ox = Math.round(num(k.ox, 0) + dx); k.oy = Math.round(num(k.oy, 0) + dy); } });
      } else if (kind === 's') {
        const f = startV.s ? num(P.scale, 1) / startV.s : 1;
        base.scale = r2(num(base.scale, 1) * f);
        o2.list.forEach(k => { if (k.k === 's') k.s = r2(num(k.s, 1) * f); });
      } else if (kind === 'r') {
        const d = { x: num(P[MAP.x], 0) - startV.x, y: num(P[MAP.y], 0) - startV.y, z: num(P[MAP.z], 0) - startV.z };
        base[MAP.x] = r1(num(base[MAP.x], 0) + d.x); base[MAP.y] = r1(num(base[MAP.y], 0) + d.y); base[MAP.z] = r1(num(base[MAP.z], 0) + d.z);
        o2.list.forEach(k => { if (k.k === 'r') { k.x = r1(num(k.x, 0) + d.x); k.y = r1(num(k.y, 0) + d.y); k.z = r1(num(k.z, 0) + d.z); } });
      }
      startV = null;
      finish(kind, true);                       // 全部还原成（已经挪过的）原始值
      liveT = 0; commit(); redraw(); window.renderAt(nowT());
      hint('摆位置：整段动画一起' + (kind === 'p' ? '挪了位置' : kind === 's' ? '改了大小' : '转了角度') + '，没有打关键帧');
    };
    window.__fxViewReset = () => {
      const o2 = K.read(P); if (!o2.on || !o2.list.length) return false;
      const t = nowT();
      withTemp({ [MAP.x]: 0, [MAP.y]: 0, [MAP.z]: 0, scale: 1, offsetX: 0, offsetY: 0 }, () => ['p', 's', 'r'].forEach(k => setKey(t, k)));
      window.renderAt(t); return true;
    };
    window.__fxViewChanged = kind => {
      toScreenVals();
      const o2 = K.read(P), k = kind === 'pos' ? 'p' : 's', onK = K.onKey(k);
      if (placing() && !onK) return placeShift(k);
      // 拖动时画面上挪的是「差值 × 关键帧层的缩放」；位置关键帧是在缩放外面平移的，所以记的时候乘上这个倍数，松手后不偏
      if (k === 'p' && o2.on && (o2.auto || onK) && K.lastKw && Math.abs(K.lastKw - 1) > 1e-4) {
        P.offsetX = Math.round(startV.ox + (num(P.offsetX, 0) - startV.ox) * K.lastKw);
        P.offsetY = Math.round(startV.oy + (num(P.offsetY, 0) - startV.oy) * K.lastKw);
      }
      if (!onK && (!o2.on || !o2.auto || (k === 's' && !o2.scale) || (k === 'p' && !o2.pos))) return finish(k, false);
      const t = nowT();
      setKey(t, k); said(t, k);                // 只记这一条轨道，别的轨道不动
      finish(k, true);
    };
    K.recordNow = () => {                 // 给自己接管右键的效果用（ring-carousel）
      toScreenVals();
      const onK = K.onKey('r');
      if (placing() && !onK) return placeShift('r');
      const o2 = K.read(P); if (!onK && (!o2.on || !o2.auto)) return finish('r', false);
      const t = nowT();
      setKey(t, 'r'); said(t, 'r');
      finish('r', true);
      window.renderAt(t);
    };
    // 给播放器下面那条轨道用的接口（挂在效果自己的 window 上，换效果时自动消失）
    window.__fxKeysApi = {
      get: () => K.read(P).list.map(k => ({ ...k })),
      set: list => { const o2 = K.read(P); o2.list = sortL(list.flatMap(expand)); commit(); redraw(); window.renderAt(nowT()); },
      addAt: (t, kind) => { keyAll(t, kind ? [kind] : null); window.renderAt(nowT()); },
      enabled: () => K.read(P).on,
      total: () => dur(),
      // v8.1：播放器下面的「关键帧之外：回到默认 / 保持首尾」按钮用（不用再去右侧面板里找）
      opt: () => { const o2 = K.read(P); return { on: o2.on, edge: o2.edge, fade: o2.fade }; },
      setOpt: o => {
        const o2 = K.read(P);
        if (o && 'edge' in o) o2.edge = o.edge === 'hold' ? 'hold' : 'blend';
        if (o && 'on' in o) o2.on = !!o.on;
        if (o && 'fade' in o) o2.fade = Math.max(0, num(o.fade, 0.6));
        liveT = 0; commit(); redraw(); window.renderAt(nowT());
      }
    };

    // ---------- 右键拖动转 XYZ ----------
    const syncRot = () => {
      const rows = rowsOf();
      [[LB.y, MAP.y], [LB.x, MAP.x], [LB.z, MAP.z]].forEach(([lab, key]) => {
        const row = rows.find(el => labelOf(el).startsWith(lab));
        const inp = row && row.querySelector('input[type=number]');
        if (inp) { inp.value = r1(num(P[key], 0)); if (inp.__fxRange) inp.__fxRange.value = inp.value; }
      });
    };
    if (DRAG && !mounted) {
      let drag = null, raf = 0, lastRight = 0, lastXY = [0, 0];
      const zeroAll = why => {
        const o2 = K.read(P);
        // 已经有旋转关键帧：只在这一秒打一个「归零」的点，原始角度不动（开场不受影响）
        if (o2.on && o2.list.some(k => k.k === 'r')) withTemp({ [MAP.x]: 0, [MAP.y]: 0, [MAP.z]: 0 }, () => setKey(nowT(), 'r'));
        else { P[MAP.x] = 0; P[MAP.y] = 0; P[MAP.z] = 0; }
        window.renderAt(nowT()); syncRot(); hint(why);
      };
      const onCtx = e => { if (inBox(e)) e.preventDefault(); };
      const onDown = e => {
        if (!inBox(e) || e.button !== 2) return;
        e.preventDefault(); e.stopPropagation();
        const now = Date.now();
        // 浏览器的 dblclick 只对左键触发，右键没有这个事件 → 自己判断双击
        if (now - lastRight < 350 && Math.abs(e.clientX - lastXY[0]) < 6 && Math.abs(e.clientY - lastXY[1]) < 6) {
          lastRight = 0; drag = null; K.dragging = false;
          const b0 = boxOf(); if (b0) b0.style.cursor = '';
          zeroAll('三轴角度已归零'); return;
        }
        lastRight = now; lastXY = [e.clientX, e.clientY];
        window.__fxViewBegin();                    // 角度、大小、位置都从当前这一帧开始，画面不跳
        drag = { x: e.clientX, y: e.clientY, rx: num(P[MAP.x], 0), ry: num(P[MAP.y], 0), rz: num(P[MAP.z], 0), shift: e.shiftKey };
        const b = boxOf(); if (b) b.style.cursor = 'move';
      };
      const onMove = e => {
        if (!drag) return;
        e.preventDefault();
        const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (drag.shift || e.shiftKey) P[MAP.z] = r1(clamp(drag.rz + dx * 0.25, -180, 180));
        else { P[MAP.y] = r1(clamp(drag.ry + dx * 0.3, -180, 180)); P[MAP.x] = r1(clamp(drag.rx - dy * 0.3, -90, 90)); }
        if (!raf) raf = pw.requestAnimationFrame(() => { raf = 0; window.renderAt(nowT()); syncRot(); });
        hint('X 轴 ' + r1(num(P[MAP.x], 0)) + '°　Y 轴 ' + r1(num(P[MAP.y], 0)) + '°　Z 轴 ' + r1(num(P[MAP.z], 0))
          + '°　·　Shift + 右键转 Z 轴　·　右键双击归零');
      };
      const onUp = () => {
        if (!drag) return;
        drag = null;
        const b = boxOf(); if (b) b.style.cursor = '';
        K.toScreenVals();                          // 换算成画面上的值再记录
        const onK = K.onKey && K.onKey('r');
        if (K.placeShift && K.placing() && !onK) { K.placeShift('r'); return; }   // 摆位置模式：整段一起转（正停在旋转关键帧上时改这个关键帧）
        const o2 = K.read(P), rec = o2.on && (o2.auto || onK);
        if (rec) {                                 // 松手就在当前这一秒记一个关键帧
          const t = nowT();
          setKey(t, 'r'); said(t, 'r');           // 右键只记旋转这一条轨道
        }
        finish('r', rec);                          // 记成关键帧就把原始参数还原，开场不受影响
      };
      const onDbl = e => { if (inBox(e) && e.button === 0) setTimeout(() => zeroAll('已还原：大小、位置、角度'), 0); };
      try { if (pw.__fxRotDispose) pw.__fxRotDispose(); } catch (e) { }
      pd.addEventListener('contextmenu', onCtx, true);
      pd.addEventListener('mousedown', onDown, true);
      pd.addEventListener('mousemove', onMove, true);
      pd.addEventListener('mouseup', onUp, true);
      pd.addEventListener('dblclick', onDbl, true);
      pw.__fxRotDispose = () => {
        pd.removeEventListener('contextmenu', onCtx, true);
        pd.removeEventListener('mousedown', onDown, true);
        pd.removeEventListener('mousemove', onMove, true);
        pd.removeEventListener('mouseup', onUp, true);
        pd.removeEventListener('dblclick', onDbl, true);
        pw.__fxRotDispose = null;
      };
      mounted = true;
    }

    // ---------- 右侧面板里的「关键帧」一栏 ----------
    const jl = rowsOf().find(el => el.tagName === 'LABEL' && labelOf(el).startsWith('关键帧'));
    field = jl && jl.querySelector('input,textarea');
    if (!field) { redraw = () => { }; try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { } return; }
    if (panelBox && box.contains(panelBox)) { redraw(); try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { } return; }
    box.querySelectorAll('.kfx').forEach(x => x.remove());
    jl.style.display = 'none';

    if (!pd.getElementById('kfx-style')) {
      const st = pd.createElement('style'); st.id = 'kfx-style';
      st.textContent = '.kfx{display:block;font-size:12px;color:#999;margin-bottom:14px}'
        + '.kfx-b{margin-top:8px;padding:10px;background:#101010;border:1px solid #2c2c2c;border-radius:8px}'
        + '.kfx-top{display:flex;align-items:center;gap:8px;margin-bottom:8px}'
        + '.kfx-top>span{flex:1;color:#ccc;font-size:13px}'
        + '.kfx-seg{display:flex;background:#1d1d1d;border:1px solid #333;border-radius:6px;overflow:hidden}'
        + '.kfx-seg button{border:0;background:none;color:#aaa;padding:4px 11px;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap}'
        + '.kfx-seg button.on{background:#f28c0f;color:#000;font-weight:600}'
        + '.kfx-now{padding:7px 9px;background:#0b0b0b;border:1px solid #262626;border-radius:6px;font-size:12px;color:#bbb;line-height:1.7}'
        + '.kfx-now b{color:#f2a33d;font-weight:600}'
        + '.kfx-add{display:block;width:100%;margin-top:8px;padding:9px;font-size:13px;color:#111;border:0;border-radius:6px;cursor:pointer;font-family:inherit;font-weight:600;background:#f28c0f}'
        + '.kfx-add:hover{filter:brightness(1.08)}'
        + '.kfx-row{display:flex;align-items:center;gap:8px;margin-top:9px;color:#aaa}'
        + '.kfx-row>span{flex:1;min-width:0}'
        + '.kfx-clr{display:block;width:100%;margin-top:8px;padding:7px;font-size:12px;border-radius:6px;cursor:pointer;font-family:inherit;background:#262626;color:#bbb;border:1px solid #333}'
        + '.kfx-clr:hover{border-color:#5a1f1f;color:#fff}'
        + '.kfx-note{margin-top:7px;font-size:11.5px;color:#777;line-height:1.7}'
        + '.kfx-note b{color:#f2b56a;font-weight:500}';
      pd.head.appendChild(st);
    }
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const wrapEl = mk('div', 'kfx'); wrapEl.append('关键帧');
    const b = mk('div', 'kfx-b');
    const top = mk('div', 'kfx-top', '<span>关键帧动画</span>');
    const segOn = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    top.appendChild(segOn);
    const now = mk('div', 'kfx-now', '把进度条拖到某一秒，这里会显示那一帧的角度');
    const add = mk('button', 'kfx-add'); add.type = 'button';
    const rowAuto = mk('div', 'kfx-row', '<span>拖完自动打点</span>');
    const segAuto = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowAuto.appendChild(segAuto);
    const rowEase = mk('div', 'kfx-row', '<span>两点之间</span>');
    const segEase = mk('div', 'kfx-seg', '<button type="button" data-v="smooth">平滑</button><button type="button" data-v="linear">匀速</button>');
    rowEase.appendChild(segEase);
    const rowEdge = mk('div', 'kfx-row', '<span>关键帧之外</span>');
    const segEdge = mk('div', 'kfx-seg', '<button type="button" data-v="blend">回到默认</button><button type="button" data-v="hold">保持首尾</button>');
    rowEdge.appendChild(segEdge);
    const rowFade = mk('div', 'kfx-row', '<span>首尾衔接（秒）</span>');
    const fadeIn = mk('input'); fadeIn.type = 'number'; fadeIn.min = '0'; fadeIn.max = '10'; fadeIn.step = '0.1';
    fadeIn.style.cssText = 'width:72px;flex:none;margin:0;padding:5px 7px;text-align:right';
    rowFade.appendChild(fadeIn);
    const rowScale = mk('div', 'kfx-row', '<span>也记录大小（滚轮）</span>');
    const segScale = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowScale.appendChild(segScale);
    const rowPos = mk('div', 'kfx-row', '<span>也记录位置（左键拖）</span>');
    const segPos = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowPos.appendChild(segPos);
    const clr = mk('button', 'kfx-clr'); clr.type = 'button'; clr.textContent = '清空全部关键帧';
    const note = mk('div', 'kfx-note');

    const applyNow = () => { liveT = 0; redraw(); commit(); window.renderAt(nowT()); };
    segOn.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).on = x.dataset.v === '1'; applyNow(); });
    segAuto.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).auto = x.dataset.v === '1'; applyNow(); });
    segEase.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).ease = x.dataset.v; applyNow(); });
    segEdge.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).edge = x.dataset.v; applyNow(); });
    segScale.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).scale = x.dataset.v === '1'; applyNow(); });
    segPos.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).pos = x.dataset.v === '1'; applyNow(); });
    fadeIn.addEventListener('input', () => { K.read(P).fade = Math.max(0, num(fadeIn.value, 0.6)); liveT = 0; commit(); window.renderAt(nowT()); });
    add.onclick = () => { keyAll(nowT()); window.renderAt(nowT()); };
    clr.onclick = () => { K.read(P).list = []; applyNow(); };

    redraw = function () {
      const o2 = K.read(P), t = nowT(), n = o2.list.length;
      segOn.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.on));
      segAuto.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.auto));
      segEase.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.v === o2.ease));
      segEdge.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.v === o2.edge));
      segScale.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.scale));
      segPos.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.pos));
      if (pd.activeElement !== fadeIn) fadeIn.value = o2.fade;
      rowFade.style.display = o2.edge === 'blend' ? '' : 'none';
      add.textContent = '＋ 在 ' + t.toFixed(2) + ' 秒打一个关键帧';
      note.innerHTML = !o2.on
        ? '关键帧动画已关闭，现在用的是固定角度：在预览区按住右键拖动来转（Shift + 右键转 Z 轴，右键双击归零）。'
        : n === 0 ? '还没有关键帧。<b>把进度条拖到某一秒，在预览区按住右键转角度、滚轮缩放、或按住左键把素材拖到想要的位置，松手就自动记下这一帧</b>；播放器下面那条轨道上会出现一个点，可以框选、拖着前后移动。'
          : n + ' 个关键帧。每个点都记着<b>角度 + 大小 + 位置</b>：转一下（右键）、滚轮缩放、左键拖位置，松手都会在当前这一秒自动打点。<b>第一个点之前、最后一个点之后会回到默认值</b>，所以这个效果自带的开场和结尾原样保留；中间这一段才走你打的关键帧。点在播放器下面的轨道上，可以框选、拖动、按 Delete 删除。';
      try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }
    };
    K.live = (t, rx, ry, rz, s, R) => {
      const nn = Date.now(); if (nn - liveT < 80) return; liveT = nn;
      const o2 = K.read(P);
      now.innerHTML = '当前 <b>' + (+t).toFixed(2) + ' 秒</b>　X <b>' + r1(rx) + '°</b>　Y <b>' + r1(ry) + '°</b>　Z <b>' + r1(rz) + '°</b>'
        + (o2.scale ? '　大小 <b>' + Math.round(s * 100) + '%</b>' : '')
        + (o2.pos && R ? '　位置 <b>' + Math.round(R.ox) + ', ' + Math.round(R.oy) + '</b>' : '');
      add.textContent = '＋ 在 ' + (+t).toFixed(2) + ' 秒打一个关键帧';
    };
    b.append(top, now, add, rowAuto, rowEase, rowEdge, rowFade, rowScale, rowPos, clr, note);
    wrapEl.appendChild(b); jl.after(wrapEl);
    panelBox = wrapEl;
    redraw();
  }
})();

/* =====================================================================
 * 【去色 · 高亮关键帧 —— 所有效果通用】（v14.0）
 *
 * 从「缝线标题卡」来的那套「去色 · 高亮关键帧」，现在每个效果都有，效果本身一行不用改：
 *   - 色彩一行：去色 ↔ 彩色（整个画面变黑白再恢复彩色）
 *   - 高亮一行：常态 ↔ 高亮（画面提亮一点 + 一圈高亮色的光晕）
 *   - 每个点 =「从这一秒开始，用『颜色渐变秒数』变成这个状态」，保持到下一个点
 * 1）算法（FXColorKeys）放在这里，因为每个效果都会加载这个文件；公共模块 fx-skin.js 的同名函数也是转到这里来算，只有一份。
 * 2）数据存在 params.__color（和 __dur 一样是工作台层的参数）：{ keys:{c:[{t,v}],h:[{t,v}]}, desat:'on'|'off', fade:秒, hi:'#色' }，
 *    撤销 / 预设 / 导出都照常带着走。
 * 3）画面：滤镜加在 #stage（没有就 body）上，只在数值变化时写；没打任何点、开场也不是黑白时一个字都不写，老画面一个像素不变。
 * 4）面板：右侧参数最后多一块「去色 · 高亮关键帧」+「高亮色」，界面直接用 fx-skin.js 的 keysBlock / colorBlock
 *    （只在工作台预览里按需加载 fx-cards.js + fx-skin.js；导出时不加载，也用不着）。
 * 5）效果自己已经做了这一套的（effect.json 里有 colorKeys 参数：缝线标题卡、焦点格卡片），这一层自动让开，不重复。
 * ===================================================================== */
(function () {
  // ---------- 算法（FXColorKeys）----------
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const prog = (t, a, b) => (b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1));
  const lerp = (a, b, k) => a + (b - a) * k;
  const smooth = x => x * x * (3 - 2 * x);
  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const CK = window.FXColorKeys = window.FXColorKeys || {};
  CK.readKeys = raw => {
    let k = raw;
    if (typeof k === 'string') { try { k = JSON.parse(k); } catch (e) { k = null; } }
    const lane = a => (Array.isArray(a) ? a : [])
      .filter(x => x && Number.isFinite(+x.t))
      .map(x => ({ t: Math.max(0, Math.round(+x.t * 100) / 100), v: +x.v >= 0.5 ? 1 : 0 }))
      .sort((a, b) => a.t - b.t);
    return { c: lane(k && k.c), h: lane(k && k.h) };
  };
  // 某一秒的值：b0 = 第一个点之前的状态；每个点从自己那一秒开始用 fade 秒变过去
  const laneAt = CK.laneAt = (keys, b0, fade, t) => {
    let v = b0;
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      if (t < k.t) break;
      const from = i ? laneAt(keys.slice(0, i), b0, fade, k.t) : b0;   // 这个点开始时，上一段实际停在哪
      v = fade > 0 ? lerp(from, k.v, smooth(prog(t, k.t, k.t + fade))) : k.v;
    }
    return v;
  };
  // 这一秒的状态 { c: 0 黑白 ~ 1 彩色, h: 0 常态 ~ 1 高亮 }；P 里用 desat（开场是否黑白）、fadeK（颜色渐变秒数）
  CK.colorAt = (P, K, t) => {
    const fade = clamp(num(P.fadeK, 0.4), 0, 5);
    return { c: clamp(laneAt(K.c, P.desat === 'on' ? 0 : 1, fade, t), 0, 1),
             h: clamp(laneAt(K.h, 0, fade, t), 0, 1) };
  };
  // 去色的滤镜（c = 1 时为空字符串）
  CK.desatFilter = c => { const g = 1 - c; return g > 0.002 ? `grayscale(${g.toFixed(3)}) brightness(${(1 - 0.1 * g).toFixed(3)}) contrast(${(1 - 0.06 * g).toFixed(3)})` : ''; };
  // 通用的高亮：提亮一点 + 两层高亮色光晕（只在 h > 0 时有）
  const rgb = h => { const m = /^#?([0-9a-f]{6})$/i.exec(String(h || '').trim()); const v = parseInt(m ? m[1] : 'f28c0f', 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; };
  CK.hiFilter = (h, hex) => {
    if (h <= 0.002) return '';
    const [r, g, b] = rgb(hex);
    return `brightness(${(1 + 0.12 * h).toFixed(3)}) saturate(${(1 + 0.3 * h).toFixed(3)}) drop-shadow(0 0 ${(8 * h).toFixed(1)}px rgba(${r},${g},${b},${(0.95 * h).toFixed(3)})) drop-shadow(0 0 ${(26 * h).toFixed(1)}px rgba(${r},${g},${b},${(0.7 * h).toFixed(3)}))`;
  };

  // ---------- 通用层：包住 init / renderAt ----------
  const oi = window.init, or = window.renderAt;
  if (typeof oi !== 'function' || typeof or !== 'function') return;
  let P = null, lastT = 0, K = null, own = false, ED = null;
  const cfg = () => {
    let c = P && P.__color;
    if (typeof c === 'string') { try { c = JSON.parse(c); } catch (e) { c = null; } }
    return c && typeof c === 'object' && !Array.isArray(c) ? c : {};
  };
  const view = () => { const c = cfg(); return { desat: c.desat === 'on' ? 'on' : 'off', fadeK: c.fade == null ? 0.4 : c.fade }; };
  const host = () => document.getElementById('stage') || document.body;
  function paint(t) {
    if (own) return;
    const c = cfg();
    if (!K) K = CK.readKeys(c.keys);
    const on = c.desat === 'on' || K.c.length || K.h.length;
    let fl = '';
    if (on) { const st = CK.colorAt(view(), K, t); fl = [CK.desatFilter(st.c), CK.hiFilter(st.h, c.hi)].filter(Boolean).join(' '); }
    const el = host();
    if (el && el.__fxcf !== fl) { if (fl || el.__fxcf) el.style.filter = fl; el.__fxcf = fl; }
  }
  window.init = function (p) {
    P = p || {}; K = null;
    own = Object.prototype.hasOwnProperty.call(P, 'colorKeys');      // 效果自己有这一套：让开
    const r = oi.apply(this, arguments);
    try { paint(lastT); } catch (e) { }
    if (!own) setTimeout(() => { try { mountUI(); } catch (e) { console.error(e); } }, 30);
    return r;
  };
  window.renderAt = function (t) {
    lastT = +t || 0;
    const r = or.apply(this, arguments);
    try { paint(lastT); } catch (e) { }
    try { if (ED && ED.head) ED.head(lastT); } catch (e) { }
    return r;
  };

  // ---------- 工作台面板（只在预览里）----------
  let pw, pd;
  try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
  const load = src => new Promise(res => { const s = document.createElement('script'); s.src = src; s.onload = s.onerror = res; document.head.appendChild(s); });
  let loading = null;
  const ensure = () => loading || (loading = (async () => {
    if (!window.FXCards) await load('../_shared/fx-cards.js');
    if (!window.FXSkin || !window.FXSkin.keysBlock) await load('../_shared/fx-skin.js');
    if (!window.FXPalettes) await load('../_shared/fx-palettes.js');      // 公共配色库：高亮色多 16 个预设（2026-11-10）
  })());
  const save = c => { P.__color = c; K = CK.readKeys(c.keys); try { pw.markDirty && pw.markDirty(); } catch (e) { } try { pw.histSoon && pw.histSoon(); } catch (e) { } };
  // keysBlock / colorBlock 读写的是 P.colorKeys / desat / fadeK / cText / cHi，这里给它一个「替身」，背后读写 params.__color
  const PP = {
    get colorKeys() { return JSON.stringify(cfg().keys || { c: [], h: [] }); },
    set colorKeys(v) { const c = cfg(); try { c.keys = JSON.parse(v); } catch (e) { } save(c); },
    get desat() { return cfg().desat === 'on' ? 'on' : 'off'; },
    set desat(v) { const c = cfg(); c.desat = v === 'on' ? 'on' : 'off'; save(c); },
    get fadeK() { const c = cfg(); return c.fade == null ? 0.4 : c.fade; },
    set fadeK(v) { const c = cfg(); c.fade = clamp(num(v, 0.4), 0, 5); save(c); },
    get cText() { return '#d6d6d6'; }, set cText(v) { },
    get cHi() { return cfg().hi || '#f28c0f'; },
    set cHi(v) { const c = cfg(); c.hi = v; save(c); }
  };
  let wrapEl = null, mo = null;
  // 换效果时（这个页面要被卸掉了）把监视和面板一起收掉，免得旧面板被放回新效果的面板里
  window.addEventListener('pagehide', () => { try { mo && mo.disconnect(); } catch (e) { } try { wrapEl && wrapEl.remove(); } catch (e) { } mo = null; wrapEl = null; });
  async function mountUI() {
    if (!pd) return;                                   // 单独打开（导出 / 测试）：没有工作台面板
    const box = pd.getElementById('params'); if (!box) return;
    if (wrapEl && box.contains(wrapEl)) { ED && ED.refresh && ED.refresh(); return; }
    await ensure();
    const SK = window.FXSkin; if (!SK || !SK.keysBlock) return;
    box.querySelectorAll('.fxcolor').forEach(x => x.remove());
    SK.injectStyle(pd);
    const mk = SK.mk(pd);
    const render = t => { try { window.renderAt(t == null ? lastT : t); } catch (e) { } };
    const wrap = mk('div', 'stc fxcolor'); wrap.dataset.fxContent = '1';
    const keys = SK.keysBlock({
      pd, pw, P: PP, field: () => null, dirty: () => { },
      total: () => +window.getDuration() || 1, now: () => lastT, inDur: () => 0.5,
      render, setK: k => { K = k; },
      hiWord: ['常态', '高亮'], hiOff: '◆ 这一秒回到常态', hiNone: '一直是常态', hiBack: '回到常态',
      defText: '#d6d6d6', base: () => [40, 40, 40]
    });
    // 颜色渐变秒数：数字框 + 滑杆（规则 5）
    const fadeRow = mk('div', 'stc-lh', '<span>颜色渐变秒数</span>');
    const fadeIn = mk('input'); fadeIn.type = 'number'; fadeIn.min = 0; fadeIn.max = 5; fadeIn.step = 0.05;
    fadeIn.style.cssText = 'width:64px!important;margin:0!important;padding:3px 6px!important;font-size:12px!important';
    const fadeR = mk('input'); fadeR.type = 'range'; fadeR.min = 0; fadeR.max = 5; fadeR.step = 0.05; fadeR.style.cssText = 'flex:1;margin:0 8px!important';
    const setFade = v => { PP.fadeK = v; fadeIn.value = fadeR.value = PP.fadeK; keys.refresh(); render(); };
    fadeIn.oninput = () => setFade(fadeIn.value); fadeR.oninput = () => setFade(fadeR.value);
    fadeRow.append(fadeR, fadeIn);
    keys.el.insertBefore(fadeRow, keys.el.querySelector('.stc-qk'));
    const color = SK.colorBlock({
      pd, pw, P: PP, field: () => null, title: '高亮色', sub: '高亮时画面周围那圈光的颜色',
      keys: [{ key: 'cHi', name: '高亮色', tip: '高亮时画面周围那圈光的颜色', def: '#f28c0f' }],
      presets: [{ c: ['#f28c0f'], name: '橙' }, { c: ['#f5c542'], name: '金黄' }, { c: ['#ffffff'], name: '白' }, { c: ['#4c9aff'], name: '蓝' },
                { c: ['#3ecf8e'], name: '绿' }, { c: ['#f472b6'], name: '粉' }, { c: ['#ef5b5b'], name: '红' }, { c: ['#2dd4e0'], name: '青' }]
        .concat(window.FXPalettes && FXPalettes.forGlow ? FXPalettes.forGlow() : []),
      ls: 'fx-my-colors-hi', apply: () => { render(); keys.refresh(); }
    });
    const head = mk('div', 'stc-note', '这一块所有效果都有（v14.0）：<b>色彩</b>一行让整个画面变黑白再恢复彩色，<b>高亮</b>一行让画面提亮、外面亮起一圈高亮色的光。进度条拖到某一秒，点下面的按钮就在这一秒打一个点。');
    head.style.cssText = 'margin:0 0 10px!important';
    wrap.append(keys.el, color.el);
    keys.el.insertBefore(head, keys.el.children[1]);
    box.appendChild(wrap);
    wrapEl = wrap;
    ED = { head: keys.head, refresh: () => { K = null; fadeIn.value = fadeR.value = PP.fadeK; keys.refresh(); color.refresh(); } };
    ED.refresh();
    // 工作台重排面板（分组、恢复默认、撤销）会清掉这一块：清掉了就放回最后
    if (mo) mo.disconnect();
    mo = new pw.MutationObserver(() => { if (wrapEl && !box.contains(wrapEl) && box.children.length) { box.appendChild(wrapEl); } });
    mo.observe(box, { childList: true });
  }
})();

/* =====================================================================
 * 【清晰度 · 放大 / 转角度不发虚】（v29.0）—— 预览和导出都生效
 *
 * 文字、边框本来都是矢量，放多大都该清楚。发虚的原因：效果里为了流畅给元素写了 will-change: transform，
 * 浏览器会按「第一次画出来时的大小」把它拍成一张图，之后放大 / 转角度只是把这张图拉大，所以糊。
 *   - 导出（效果页单独打开，或在导出用的 comp.html 里）：直接关掉 will-change，每一帧都按真实大小画，最清楚。
 *     导出是一帧一帧截图，不追求实时帧率，关掉没有代价。
 *   - 预览（在工作台里）：保留 will-change（规则 16：关掉会掉帧），只在画面停下来（暂停、拖完进度条、
 *     改完大小 / 角度 / 组合变换）的那一刻把 will-change 摘掉一帧再加回去，浏览器就按现在的大小重新画一张清楚的。
 *     一直在播放时，最多每 1 秒重新画一次。
 * 实测（hierarchy-tree 放大 3 倍）：边缘清晰度从 329 → 1044，和完全不用 will-change 一样。
 * ===================================================================== */
(function () {
  const de = document.documentElement;
  const css = document.createElement('style');
  css.textContent = 'html.fx-crisp *,html.fx-crisp *::before,html.fx-crisp *::after{will-change:auto!important}';
  (document.head || de).appendChild(css);
  let exportMode = true;
  try { const pp = window.parent; exportMode = pp === window || (/\/comp\.html$/.test(pp.location.pathname) && pp.parent === pp); } catch (e) { }
  if (exportMode) { de.classList.add('fx-crisp'); return; }
  const num = v => (Number.isFinite(+v) ? Math.round(+v * 1000) / 1000 : '');
  const sigOf = () => {
    const P = window.__fxCurP ? window.__fxCurP() : null, w = document.getElementById('fx-rot');
    let fe = ''; try { fe = window.frameElement ? window.frameElement.style.transform : ''; } catch (e) { }
    return [innerWidth, innerHeight, fe, w ? w.style.transform.replace(/translate\([^)]*\)\s*/g, '') : '',
      P ? [num(P.scale), num(P.rotX), num(P.rotY), num(P.rotZ)].join(',') : ''].join('|');
  };
  let sig = sigOf(), last = 0, lastR = 0, dirty = false;
  const reraster = () => {
    last = performance.now(); dirty = false; de.classList.add('fx-crisp');
    requestAnimationFrame(() => requestAnimationFrame(() => de.classList.remove('fx-crisp')));
  };
  // 效果自己的动画也会放大元素（比如卡片从小弹到正常大小），所以每画一帧都记一下；
  // 画面停下来（暂停 / 拖完进度条）0.15 秒后重画一次；一直在播放时最多每 1 秒重画一次。
  const or = window.renderAt;
  if (typeof or === 'function') window.renderAt = function () { lastR = performance.now(); dirty = true; return or.apply(this, arguments); };
  setInterval(() => {                               // 每 0.15 秒看一眼，很便宜：只拼一个字符串
    const s = sigOf(); if (s !== sig) { sig = s; dirty = true; lastR = performance.now(); }
    if (!dirty) return;
    const now = performance.now();
    if (now - lastR > 150 || now - last > 1000) reraster();
  }, 150);
})();

/* =====================================================================
 * 【预览里直接改字 · 所有效果通用】（v34.1，规则 45）
 *
 * 用户要求：右侧所有能输入文字的地方，在预览窗口里都能直接改 —— 双击画面上的字，就在原地打字（和剪映一样）。
 *   - 双击到字：找到这行字是哪个参数（或参数 JSON 里的哪一项、哪一行）来的，在字上面盖一个输入框，
 *     字体 / 字号 / 颜色照原样；回车 / 点别处 = 确定，Esc = 取消。确定以后写回参数，
 *     和撤销一样走 buildParams + reinit，停在原来那一秒；整个改动算一步撤销。
 *   - 双击没点到字（或这行字对不上任何文字参数）：照旧「双击还原」。
 *   - 效果自己做了更好的改字（比如要点展开卡，边打边变）：它在自己的双击里先拦下，这一层就不管。
 *   - 不想要的效果：window.VIEW_CONTROLS = { textEdit: false }。
 * 怎么找「这行字是哪来的」：把画面上这行字和所有文字参数比（去掉 **、~~、| 换行、空格再比），
 *   整个参数 / JSON 里某一项的字一样 → 改它；某一行（| 或换行分开的）一样 → 只改那一行。
 *   上传的图片路径、颜色、数字、__ 开头的工作台参数不算。
 * 只在工作台预览里起作用；导出、缩略图、时间线叠加层都不会走到这里。
 * ===================================================================== */
(function () {
  const TE = window.FXTextEdit = window.FXTextEdit || {};
  TE.open = o => {
    let pd, pw; try { if (window.parent === window) return null; pw = window.parent; pd = pw.document; } catch (e) { return null; }
    const f = pd.getElementById('frame'); if (!f || f.contentWindow !== window) return null;
    if (!pd.getElementById('fxe-live-style2')){
      const s = pd.createElement('style'); s.id = 'fxe-live-style2';
      s.textContent = `.fxe-lv{position:fixed;z-index:99999;box-sizing:border-box;border:1px solid rgba(255,255,255,.85);box-shadow:0 0 0 1px rgba(0,0,0,.25);pointer-events:none}
.fxe-lv i{position:absolute;width:9px;height:9px;margin:-5px 0 0 -5px;border-radius:50%;background:#e8e8e8;box-shadow:0 0 0 1px rgba(0,0,0,.35)}
.fxe-lv b{position:absolute;top:50%;width:4px;height:16px;margin:-8px 0 0 -2px;border-radius:2px;background:#e8e8e8;box-shadow:0 0 0 1px rgba(0,0,0,.35)}
.fxe-lv input{position:absolute;inset:0;width:100%;height:100%;box-sizing:border-box;margin:0;padding:0 6px;border:0;outline:none;background:transparent;pointer-events:auto;white-space:pre}
.fxe-lv-m{position:fixed;left:-9999px;top:-9999px;visibility:hidden;white-space:pre}`;
      pd.head.appendChild(s);
    }
    // 上一个还开着就先确定掉（v33.8）。确定会让效果重画，传进来的那行字可能已经换成新的元素了 → 用 o.refind() 重新找
    let el = o.el;
    try { if (pw.__fxLiveEditClose){ pw.__fxLiveEditClose(); if (o.refind) el = o.refind() || el; } } catch (e) {}
    if (!el || !el.isConnected) return null;                 // 字已经不在画面上了：不开输入框（以前会跑到左上角）
    const fr = f.getBoundingClientRect(), sx = fr.width / innerWidth, sy = fr.height / innerHeight;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return null;
    // 字的样子：字号按画面上真实显示的大小（含卡片缩放、预览缩放），字体 / 粗细 / 颜色 / 字距照原样
    const src = el.querySelector('.fxt-g') || el, cs = getComputedStyle(src);
    const scale = (el.offsetHeight ? r.height / el.offsetHeight : 1) * sy;
    const fpx = (parseFloat(cs.fontSize) || 16) * scale;
    const lsEm = (parseFloat(cs.letterSpacing) || 0) / (parseFloat(cs.fontSize) || 16);
    const g = el.querySelector('.fxt-g');
    const align = el.classList.contains('fxp-ts') ? (cs.textAlign === 'center' ? 'center' : 'left')
      : (el.firstElementChild && el.firstElementChild.style.justifyContent === 'flex-start' ? 'left' : 'center');
    // 字实际占的那一块（不是整个格子）
    let tr = r;
    try { const rg = document.createRange(); rg.selectNodeContents(g || el); const q = rg.getBoundingClientRect(); if (q.width) tr = q; } catch (e) {}
    const H = Math.max(fpx * 1.35, 22), cy = fr.top + (tr.top + tr.height / 2) * sy;
    const anchorX = align === 'left' ? fr.left + tr.left * sx : fr.left + (tr.left + tr.width / 2) * sx;
    const box = pd.createElement('div'); box.className = 'fxe-lv';
    box.innerHTML = '<i style="left:0;top:0"></i><i style="left:100%;top:0"></i><i style="left:0;top:100%"></i><i style="left:100%;top:100%"></i><b style="left:0"></b><b style="left:100%"></b>';
    const inp = pd.createElement('input'); inp.type = 'text'; inp.value = o.value == null ? '' : String(o.value);
    const fontCss = `font-family:${cs.fontFamily};font-weight:${cs.fontWeight};font-size:${fpx.toFixed(1)}px;letter-spacing:${lsEm.toFixed(3)}em`;
    inp.style.cssText = `${fontCss};color:${cs.color};caret-color:${cs.color};text-align:${align}`;
    box.appendChild(inp);
    const meas = pd.createElement('span'); meas.className = 'fxe-lv-m'; meas.style.cssText = fontCss;
    pd.body.append(box, meas);
    // 框跟着字的长短变（靠左的字左边不动，居中的字中间不动）
    const fit = () => {
      meas.textContent = inp.value || ' ';
      const w = Math.max(fpx * 1.2, meas.getBoundingClientRect().width + 14 + fpx * 0.15);
      const left = align === 'left' ? anchorX - 7 : anchorX - w / 2;
      box.style.left = left + 'px'; box.style.top = (cy - H / 2) + 'px'; box.style.width = w + 'px'; box.style.height = H + 'px';
    };
    fit();
    const hint = pd.getElementById('hint'), hint0 = hint ? hint.textContent : '';
    if (hint) hint.textContent = '正在改字：回车 = 确定 · Esc = 取消 · **文字** = 重点（高亮色）';
    o.hide && o.hide(true);
    let done = false, tt = 0;
    // 在别处按下鼠标 = 马上确定（预览里按下时浏览器不一定让输入框失去焦点，以前会留着一个没关的输入框）
    const onDocDown = e => { if (e.target !== inp) close(inp.value); };
    pd.addEventListener('mousedown', onDocDown, true);
    const close = v => {
      if (done) return; done = true; clearTimeout(tt);
      pd.removeEventListener('mousedown', onDocDown, true);
      box.remove(); meas.remove(); pw.__fxLiveEditClose = null;
      if (hint) hint.textContent = hint0;
      o.hide && o.hide(false);
      o.onDone && o.onDone(v);
    };
    inp.addEventListener('input', () => { fit(); clearTimeout(tt); tt = setTimeout(() => { if (!done) o.onInput && o.onInput(inp.value); }, 120); });
    inp.addEventListener('keydown', e => {
      e.stopPropagation();
      if (e.key === 'Enter'){ e.preventDefault(); close(inp.value); }
      else if (e.key === 'Escape'){ e.preventDefault(); close(null); }
    });
    inp.addEventListener('blur', () => setTimeout(() => close(inp.value), 0));
    ['mousedown', 'dblclick', 'wheel'].forEach(t => inp.addEventListener(t, e => e.stopPropagation()));
    pw.__fxLiveEditClose = () => close(inp.value);
    setTimeout(() => { inp.focus(); const n = inp.value.length; inp.setSelectionRange(n, n); }, 0);   // 光标放在最后（和剪映一样）
    return { close };
  };

  let pw, pd;
  try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
  const CFG = window.VIEW_CONTROLS || {};
  const norm = s => String(s == null ? '' : s).replace(/\*+|~+/g, '').replace(/[|\r\n\s　]/g, '');
  const frameEl = () => { const f = pd.getElementById('frame'); return f && f.contentWindow === window ? f : null; };
  const local = e => { const f = frameEl(); if (!f) return null; const r = f.getBoundingClientRect(); if (!r.width) return null; return { x: (e.clientX - r.left) / (r.width / innerWidth), y: (e.clientY - r.top) / (r.height / innerHeight) }; };
  // 这个元素在画面上看得见吗（自己和上面几层：没有 display:none / visibility:hidden，透明度乘起来 > 0.15）
  const seen = el => {
    let o = 1;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement){
      const cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
      o *= +cs.opacity; if (o < 0.15) return false;
    }
    return true;
  };
  // 点上的那一行字：所有文字节点里，矩形包住这一点、看得见、面积最小的那个 → 往上找到「一整行字」的元素
  const unitOf = n => {
    const p = n.parentElement; if (!p) return null;
    return p.closest('.fxt-l') || p.closest('.fxt-g') || p;      // 文字转场画的字一个字一个 span，整块才是一行字
  };
  const textAt = (x, y) => {
    let best = null, ba = Infinity;
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const rg = document.createRange(), pad = 4;
    for (let n = w.nextNode(); n; n = w.nextNode()){
      if (!n.nodeValue.trim()) continue;
      const pe = n.parentElement; if (!pe || /^(SCRIPT|STYLE|TITLE)$/.test(pe.tagName)) continue;
      let rects;
      if (pe instanceof SVGElement) rects = [pe.getBoundingClientRect()];
      else { rg.selectNodeContents(n); rects = [...rg.getClientRects()]; }
      for (const r of rects){
        if (r.width < 1 || x < r.left - pad || x > r.right + pad || y < r.top - pad || y > r.bottom + pad) continue;
        const a = r.width * r.height; if (a >= ba || !seen(pe)) continue;
        ba = a; best = n;
      }
    }
    return best ? unitOf(best) : null;
  };
  // 参数里所有的字（参数本身是字，或参数是 JSON / 对象时里面的每一个字），带上「怎么写回去」
  const leaves = P => {
    const out = [];
    const skip = s => !s || /^(#[0-9a-f]{3,8}|rgba?\(|data:|\/uploads\/|https?:\/\/|blob:)/i.test(s.trim()) || /^-?\d+(\.\d+)?$/.test(s.trim());
    const walk = (v, path, top) => {
      if (typeof v === 'string'){ if (!skip(v)) out.push({ top, path, raw: v }); return; }
      if (v && typeof v === 'object') Object.keys(v).forEach(k => { if (!/^(img|src|url|poster|video|font)$/.test(k)) walk(v[k], path.concat(k), top); });
    };
    Object.keys(P || {}).forEach(key => {
      if (key.startsWith('__') || key === 'keys') return;
      const v = P[key];
      if (typeof v === 'string'){
        const s = v.trim();
        if (/^[\[{]/.test(s)){ try { walk(JSON.parse(s), [], { key, json: true, pretty: /\n/.test(s) }); return; } catch (e) {} }
        if (!skip(v)) out.push({ top: { key }, path: [], raw: v });
      } else if (v && typeof v === 'object') walk(v, [], { key, obj: true });
    });
    return out;
  };
  // 画面上这一行字 → 参数里的哪一处：先找整段一样的，再找某一行一样的（| 或换行分开）
  const findSource = (P, shown) => {
    const want = norm(shown); if (!want) return null;
    const L = leaves(P);
    let hit = L.find(l => norm(l.raw) === want);
    if (hit) return Object.assign({ s: 0, e: hit.raw.length }, hit);
    for (const l of L){
      const re = /[^|\n]+/g; let m;
      while ((m = re.exec(l.raw))) if (norm(m[0]) === want) return Object.assign({ s: m.index, e: m.index + m[0].length }, l);
    }
    return null;
  };
  // 最后一招：画面上的字是参数里某一段字的一部分（比如一条字幕里的一句）→ 只改参数里对应的那一段
  const findPart = (P, shown) => {
    const want = norm(shown); if (want.length < 2) return null;
    for (const l of leaves(P)){
      // 一边去掉 ** ~~ | 换行 空格，一边记住每个留下来的字在原文里的位置
      const map = []; let n = '';
      for (let i = 0; i < l.raw.length; i++){ const ch = l.raw[i]; if (/[*~|\r\n\s\u3000]/.test(ch)) continue; map.push(i); n += ch; }
      const at = n.indexOf(want); if (at < 0) continue;
      return Object.assign({ s: map[at], e: map[at + want.length - 1] + 1 }, l);
    }
    return null;
  };
  const writeBack = (P, src, v) => {
    const raw = src.raw.slice(0, src.s) + v + src.raw.slice(src.e);
    const key = src.top.key;
    if (!src.path.length && !src.top.json && !src.top.obj){ P[key] = raw; return; }
    const root = src.top.json ? JSON.parse(P[key]) : JSON.parse(JSON.stringify(P[key]));
    let o = root; for (let i = 0; i < src.path.length - 1; i++) o = o[src.path[i]];
    if (src.path.length) o[src.path[src.path.length - 1]] = raw;
    P[key] = src.top.json ? (src.top.pretty ? JSON.stringify(root, null, 2) : JSON.stringify(root)) : root;
  };
  // 记下工作台最后让画到哪一秒（改完停回这一秒）：包在最外层，只记不改
  let curT = 0;
  { const or = window.renderAt; if (typeof or === 'function') window.renderAt = function (t) { curT = +t || 0; return or.apply(this, arguments); }; }
  let busy = false;
  // view-controls 的双击先问这里：改了字就返回 true（不再「双击还原」）
  window.__fxTextDbl = e => {
    if (CFG.textEdit === false || busy) return false;
    const P = window.__fxCurP ? window.__fxCurP() : null; if (!P) return false;
    const p = local(e); if (!p) return false;
    const el0 = textAt(p.x, p.y); if (!el0) return false;
    // 字常常一个字一个 span：从点中的那一块往外一层层找，哪一层的整段字和参数对得上就用哪一层；都对不上再试「是某段字的一部分」
    let el = null, src = null;
    for (let n = el0, k = 0; n && n !== document.body && k < 8; n = n.parentElement, k++){
      const tx = n.textContent || ''; if (tx.length > 400) break;
      const s0 = findSource(P, tx); if (s0){ el = n; src = s0; break; }
    }
    if (!src){ src = findPart(P, el0.textContent); el = el0; }
    if (!src) return false;
    const val = src.raw.slice(src.s, src.e);
    const tNow = curT;
    TE.open({
      el, value: val,
      refind: () => textAt(p.x, p.y),
      hide: on => { el.style.visibility = on ? 'hidden' : ''; },
      onDone: v => {
        if (v == null || v === val) return;
        busy = true;
        try {
          writeBack(P, src, v);                       // P 就是工作台的 params（init 时按引用传进来的，规则 6）
          // 和撤销 / 拖小旗子一样：面板跟着变（效果自己的编辑器重新挂上），画面停回这一秒，算一步撤销
          try { pw.buildParams(); pw.reinit(false); } catch (er) {}
          setTimeout(() => { try { pw.seek(tNow); } catch (er) {} busy = false; }, 60);
          try { pw.markDirty(); pw.histSoon(); } catch (er) {}
        } catch (er) { busy = false; }
      }
    });
    return true;
  };
})();

/* =====================================================================
 * 【不透明度 · 关键帧 —— 所有素材通用】（v39.0 不透明度；v40.0 加关键帧，照「去色 · 高亮关键帧」的样子做）—— 预览和导出都生效
 *
 * 用户要：所有素材都能调不透明度，还能打关键帧；关键帧的操作要和「去色 · 高亮关键帧」一样（规则 50：以后的关键帧都照这个样子做）。
 * 1）数据（工作台层的参数，撤销 / 多选一起改 / ★ 预设 / 导出都带着走）：
 *    params.__op  = 开场不透明度 0~100（没有 = 100 = 原样）
 *    params.__opk = { keys: [{ t: 秒, v: 0~100 }], fade: 渐变秒数 }：每个点 =「从这一秒开始，用渐变秒数变成 v%」，保持到下一个点
 *    （算法和去色 · 高亮共用 FXColorKeys.laneAt，只是值不是 0 / 1 而是百分比）
 * 2）画面：opacity 写在效果页面的 <html> 上（不碰效果自己的 #stage），只在数值变化时写；都没设过一个字都不写，老画面一个像素不变。
 * 3）面板：「持续时间」「排版」下面一块「不透明度 · 关键帧」，样子和用法跟「去色 · 高亮关键帧」一样：
 *    开场不透明度（数字框 + 滑杆）→ 一行轨道（颜色深浅 = 每一秒有多不透明，菱形 = 关键帧，红线 = 现在）
 *    → ◆ 这一秒透明 0% / ◆ 这一秒显示 100% / ◆ 这一秒打点（右边填百分比）→ 渐变秒数 → 示范：淡入 / 淡出 / 清空。
 *    轨道上：点空白处跳到那一秒，拖菱形改时间，双击菱形 = 改成「打点」框里的百分比，右键菱形删除，点一下菱形 = 跳过去。
 * ===================================================================== */
(function () {
  const oi = window.init, or = window.renderAt;
  if (typeof oi !== 'function' || typeof or !== 'function') return;
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const r2 = x => Math.round(x * 100) / 100;
  let P = null, lastT = 0, KS = null, ui = null;
  const base = () => { const v = P && P.__op !== '' && P.__op != null ? Number(P.__op) : NaN; return Number.isFinite(v) ? clamp(v, 0, 100) : 100; };
  const cfg = () => {
    let c = P && P.__opk;
    if (typeof c === 'string') { try { c = JSON.parse(c); } catch (e) { c = null; } }
    return c && typeof c === 'object' && !Array.isArray(c) ? c : {};
  };
  const fadeOf = () => { const c = cfg(); return clamp(num(c.fade, 0.5), 0, 10); };
  const readKeys = () => (Array.isArray(cfg().keys) ? cfg().keys : [])
    .filter(k => k && Number.isFinite(+k.t) && Number.isFinite(+k.v))
    .map(k => ({ t: Math.max(0, r2(+k.t)), v: clamp(Math.round(+k.v), 0, 100) })).sort((a, b) => a.t - b.t);
  const laneAt = (keys, b0, fade, t) => (window.FXColorKeys && FXColorKeys.laneAt ? FXColorKeys.laneAt(keys, b0, fade, t) : b0);
  const valAt = t => { const K = KS || (KS = readKeys()); return K.length ? clamp(laneAt(K, base(), fadeOf(), t), 0, 100) : base(); };
  const paint = t => {
    const el = document.documentElement, v = valAt(t), s = v >= 99.95 ? '' : String(Math.round(v * 10) / 1000);
    if (el.__fxop !== s) { if (s || el.__fxop) el.style.opacity = s; el.__fxop = s; }
  };
  window.init = function (p) {
    P = p || {}; KS = null;
    const r = oi.apply(this, arguments);
    try { paint(lastT); } catch (e) { }
    setTimeout(() => { try { ui && ui.mount(); } catch (e) { console.error(e); } }, 40);
    return r;
  };
  window.renderAt = function (t) {
    lastT = +t || 0;
    const r = or.apply(this, arguments);
    try { paint(lastT); } catch (e) { }
    try { ui && ui.head(lastT); } catch (e) { }
    return r;
  };

  // ---------- 工作台面板（只在预览里）----------
  let pw, pd;
  try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
  const total = () => Math.max(0.01, +window.getDuration() || 1);
  const dirty = () => { try { pw.markDirty && pw.markDirty(); } catch (e) { } try { pw.histSoon && pw.histSoon(); } catch (e) { } };
  const hint = s => { const h = pd.getElementById('hint'); if (h) h.textContent = s; };
  const seek = t => { try { pw.stop && pw.stop(); pw.seek && pw.seek(Math.max(0, t)); } catch (e) { try { window.renderAt(t); } catch (x) { } } };
  const saveKeys = (K, fade) => {
    const c = cfg(), keys = K.slice().sort((a, b) => a.t - b.t).map(k => ({ t: r2(k.t), v: Math.round(k.v) }));
    const f = fade == null ? (c.fade == null ? 0.5 : c.fade) : fade;
    if (!keys.length && (f === 0.5)) delete P.__opk; else P.__opk = { keys, fade: f };
    KS = null; paint(lastT); dirty();
  };
  const setBase = v => { v = Math.round(clamp(num(v, 100), 0, 100)); if (v >= 100) delete P.__op; else P.__op = v; KS = null; paint(lastT); dirty(); };
  // FXSkin（样式 / mk）：「去色 · 高亮」那一块已经会按需加载；自己画了这一套的效果页面里本来就有。等它到了再建面板
  const waitSkin = n => new Promise(res => { const go = k => { if (window.FXSkin && FXSkin.mk && FXSkin.injectStyle) return res(true); if (k <= 0) return res(false); setTimeout(() => go(k - 1), 100); }; go(n); });
  let el = null, mo = null, parts = null, building = false;
  const place = box => { const top = box.querySelector(':scope > .fxtop') || box.querySelector(':scope > .fxdur'); if (top) top.after(el); else box.prepend(el); };
  function build() {
    const SK = window.FXSkin; SK.injectStyle(pd);
    const mk = SK.mk(pd);
    el = mk('div', 'stc fxop'); el.dataset.fxContent = '1';          // 外面一层 .stc：fx-skin 的样式都写在 .stc 下面（和「去色 · 高亮」那一块一样）
    const bx = mk('div', 'stc-b'); el.appendChild(bx);
    bx.innerHTML = '<div class="stc-t"><b>不透明度 · 关键帧</b><span class="stc-now"></span></div>';
    const nowEl = bx.querySelector('.stc-now');
    // 数字框 + 滑杆一行（规则 5），和「颜色渐变秒数」同一种样子
    const slRow = (label, min, max, step, get, set) => {
      const row = mk('div', 'stc-lh', '<span>' + label + '</span>');
      const n = mk('input'); n.type = 'number'; n.min = min; n.max = max; n.step = step;
      n.style.cssText = 'width:64px!important;margin:0!important;padding:3px 6px!important;font-size:12px!important';
      const r = mk('input'); r.type = 'range'; r.min = min; r.max = max; r.step = step; r.style.cssText = 'flex:1;margin:0 8px!important';
      const put = () => { const v = get(); if (pd.activeElement !== n) n.value = v; r.value = v; };
      n.oninput = () => { if (n.value !== '') { set(n.value); r.value = n.value; } };
      n.onchange = () => put();
      r.oninput = () => { set(r.value); n.value = r.value; };
      row.append(r, n);
      return { row, put };
    };
    const baseRow = slRow('开场不透明度（%）', 0, 100, 1, base, v => { setBase(v); drawLane(); });
    baseRow.row.title = '第一个关键帧之前（没打关键帧时就是整段）的不透明度。100 = 原样';
    bx.appendChild(baseRow.row);
    // 轨道
    const ln = mk('div', 'stc-ln');
    ln.innerHTML = '<div class="stc-lh"><span>不透明度</span><small></small></div>';
    const tr = mk('div', 'stc-tr'); ln.appendChild(tr);
    const cnt = ln.querySelector('small');
    bx.appendChild(ln);
    // ◆ 打点按钮：变透明 / 完全显示 / 打点（自己填百分比）
    const two = mk('div', 'stc-two');
    const addKey = v => {
      const t = r2(lastT), K = readKeys(), hit = K.find(k => Math.abs(k.t - t) < 0.04);
      if (hit) hit.v = v; else K.push({ t, v });
      saveKeys(K); drawLane(); hint('已在 ' + t.toFixed(2) + ' 秒记下【不透明度：' + Math.round(v) + '%】—— 从这一秒开始变过去');
    };
    [[0, '◆ 这一秒透明 0%'], [100, '◆ 这一秒显示 100%']].forEach(([v, txt]) => { const b = mk('button', '', txt); b.type = 'button'; b.onclick = () => addKey(v); two.appendChild(b); });
    bx.appendChild(two);
    const cus = mk('div', 'stc-lh');
    const cb = mk('button', '', '◆ 这一秒打点'); cb.type = 'button';
    cb.style.cssText = 'flex:1!important;margin:6px 0 0!important;padding:6px 4px!important;font-size:12px!important;background:#1d1d1d!important;color:#ccc!important;border:1px solid #333!important;border-radius:6px!important;cursor:pointer!important;font-family:inherit!important';
    const cv = mk('input'); cv.type = 'number'; cv.min = 0; cv.max = 100; cv.step = 1; cv.title = '打点用的百分比（默认 = 现在这一秒的不透明度）';
    cv.style.cssText = 'width:64px!important;margin:6px 0 0!important;padding:3px 6px!important;font-size:12px!important';
    const pc = mk('span', '', '%'); pc.style.cssText = 'margin-top:6px;color:#999';
    cus.append(cb, cv, pc);
    cb.onclick = () => addKey(clamp(Math.round(num(cv.value, valAt(lastT))), 0, 100));
    bx.appendChild(cus);
    const fadeRow = slRow('渐变秒数', 0, 10, 0.05, fadeOf, v => { saveKeys(readKeys(), clamp(num(v, 0.5), 0, 10)); drawLane(); });
    fadeRow.row.title = '每个关键帧从那一秒开始，用几秒变到新的不透明度（0 = 一下子变）';
    bx.appendChild(fadeRow.row);
    // 轨道上的交互：空白处点 = 跳到那一秒；拖菱形 = 改时间；点菱形 = 跳过去；双击菱形 = 改成「打点」框里的百分比；右键菱形 = 删掉
    let K = readKeys();
    const tOf = e => { const r = tr.getBoundingClientRect(); return clamp((e.clientX - r.left) / Math.max(1, r.width), 0, 1) * total(); };
    let drag = null;
    tr.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      const pt = e.target.closest && e.target.closest('.stc-pt');
      K = readKeys();
      if (pt) drag = { k: K[+pt.dataset.i], x: e.clientX, moved: false };
      else { drag = { scrub: true }; seek(tOf(e)); }
      try { tr.setPointerCapture(e.pointerId); } catch (x) { }
      e.preventDefault();
    });
    tr.addEventListener('pointermove', e => {
      if (!drag) return;
      if (drag.scrub) { seek(tOf(e)); return; }
      if (!drag.moved && Math.abs(e.clientX - drag.x) < 3) return;
      drag.moved = true; drag.k.t = r2(tOf(e));
      KS = K.slice().sort((a, b) => a.t - b.t); paint(lastT); drawLane(K);
      hint('移动【不透明度：' + drag.k.v + '%】→ ' + drag.k.t.toFixed(2) + ' 秒');
    });
    const up = () => { if (!drag) return; const d = drag; drag = null; if (d.scrub) return; if (d.moved) { saveKeys(K); drawLane(); } else seek(d.k.t); };
    tr.addEventListener('pointerup', up); tr.addEventListener('pointercancel', up);
    tr.addEventListener('dblclick', e => {
      const pt = e.target.closest && e.target.closest('.stc-pt'); if (!pt) return;
      K = readKeys(); const k = K[+pt.dataset.i]; if (!k) return;
      k.v = clamp(Math.round(num(cv.value, k.v)), 0, 100); saveKeys(K); drawLane();
      hint('已把 ' + k.t.toFixed(2) + ' 秒那个点改成【不透明度：' + k.v + '%】');
    });
    tr.addEventListener('contextmenu', e => {
      const pt = e.target.closest && e.target.closest('.stc-pt'); if (!pt) return;
      e.preventDefault(); K = readKeys(); K.splice(+pt.dataset.i, 1); saveKeys(K); drawLane(); hint('已删掉一个【不透明度】关键帧');
    });
    // 一键示范 / 清空
    const qk = mk('div', 'stc-qk');
    const quick = (txt, fn, tip) => { const b = mk('button', '', txt); b.type = 'button'; b.title = tip; b.onclick = fn; qk.appendChild(b); };
    quick('示范：淡入', () => { const f = Math.min(1, total() * 0.25); setBase(0); saveKeys([{ t: 0, v: 100 }], r2(f)); baseRow.put(); fadeRow.put(); drawLane(); hint('开头从完全透明，用 ' + r2(f) + ' 秒淡入到 100%'); }, '开头从透明慢慢显示出来');
    quick('示范：淡出', () => { const f = Math.min(1, total() * 0.25), t = r2(Math.max(0, total() - f)); const K2 = readKeys().filter(k => k.t < t); K2.push({ t, v: 0 }); saveKeys(K2, r2(f)); fadeRow.put(); drawLane(); hint(t.toFixed(2) + ' 秒开始，用 ' + r2(f) + ' 秒淡出到完全透明'); }, '结尾慢慢变透明消失');
    quick('清空', () => { saveKeys([]); drawLane(); hint('不透明度关键帧已清空（开场不透明度不变）'); }, '关键帧全部删掉');
    bx.appendChild(qk);
    bx.appendChild(mk('div', 'stc-note', '用法：进度条拖到某一秒 → 点上面的 ◆ 按钮，就在这一秒打一个点，从这一秒开始用「渐变秒数」变到这个不透明度。'
      + '<b>轨道上</b>：颜色越亮 = 越不透明；点空白处跳到那一秒，拖菱形改时间，点菱形跳过去，双击菱形 = 改成「打点」框里的百分比，右键菱形删除。'
      + '导出的透明视频里也是这样；多选的素材一起改。'));
    function drawLane(Kd) {
      const T = total(), arr = (Kd || readKeys()).slice().sort((a, b) => a.t - b.t), fade = fadeOf(), b0 = base();
      const N = 120, stops = [];
      for (let i = 0; i <= N; i++) { const v = arr.length ? laneAt(arr, b0, fade, i / N * T) : b0, g = Math.round(28 + (236 - 28) * clamp(v, 0, 100) / 100); stops.push(`rgb(${g},${g},${g}) ${(i / N * 100).toFixed(2)}%`); }
      tr.style.background = `linear-gradient(90deg,${stops.join(',')})`;
      const src = Kd || readKeys();
      tr.innerHTML = src.map((k, i) => `<div class="stc-pt ${k.v >= 50 ? 'v1' : 'v0'}" data-i="${i}" style="left:${clamp(k.t / T * 100, 0, 100).toFixed(2)}%"`
        + ` title="${k.t.toFixed(2)} 秒：变到 ${k.v}%（拖动改时间 · 双击改成打点框里的百分比 · 右键删除）"></div>`).join('') + '<div class="stc-hd"></div>';
      cnt.textContent = src.length ? src.length + ' 个点' : (b0 >= 100 ? '一直 100%（原样）' : '一直 ' + Math.round(b0) + '%');
      head(lastT, true);
    }
    let ht = -1;
    function head(t, force) {
      const q = Math.round(t * 100); if (!force && q === ht) return; ht = q;
      const h = tr.querySelector('.stc-hd'); if (h) h.style.left = clamp(t / total() * 100, 0, 100).toFixed(2) + '%';
      const v = Math.round(valAt(t));
      nowEl.textContent = '当前 ' + t.toFixed(2) + ' 秒 · ' + v + '%';
      if (pd.activeElement !== cv) cv.value = v;
    }
    parts = { head: t => { if (el && el.isConnected) head(t); }, refresh: () => { KS = null; baseRow.put(); fadeRow.put(); drawLane(); } };
    parts.refresh();
  }
  ui = {
    head: t => { parts && parts.head(t); },
    mount: async () => {
      const box = pd.getElementById('params'); if (!box) return;
      if (el) { if (!box.contains(el)) place(box); parts.refresh(); return; }
      if (building) return; building = true;
      const ok = await waitSkin(50);
      if (!ok) { await new Promise(res => { const s = document.createElement('script'); s.src = '../_shared/fx-skin.js'; s.onload = s.onerror = res; document.head.appendChild(s); }); }
      building = false;
      if (!window.FXSkin || !FXSkin.mk || el) return;
      box.querySelectorAll(':scope > .fxop').forEach(x => x.remove());
      build(); place(box);
      if (mo) mo.disconnect();
      mo = new pw.MutationObserver(() => { if (el && !box.contains(el) && box.children.length) place(box); });
      mo.observe(box, { childList: true });
    }
  };
  // 换效果时（这个页面要被卸掉了）把面板和监视一起收掉
  window.addEventListener('pagehide', () => { try { mo && mo.disconnect(); } catch (e) { } try { el && el.remove(); } catch (e) { } mo = null; el = null; parts = null; });
})();

/* ===========================================================================
 * 【字体】用电脑上已经装好的字体（v35.x，所有效果都有）
 *   - 字体不拷进工作台：只记字体的名字（P.__font，跟着素材、撤销、预设、导出走），
 *     画面用 CSS 按名字找电脑上的字体；导出也在这台电脑上渲染，同样找得到。想用新字体 = 在电脑上装好，刷新工作台就有。
 *   - 右侧面板最上面一行「字体」：点开列出电脑上的字体（Chrome 的「本地字体」接口，第一次会问一次权限），
 *     可以搜，每个字体用它自己的样子显示；「默认」= 效果原来的字体。读不到列表时可以直接输入字体名。
 *   - 画在 canvas 里的字（少数效果）不跟着变。
 * =========================================================================== */
(function () {
  if (window.VIEW_CONTROLS && window.VIEW_CONTROLS.font === false) return;
  let P = null, pw = null, pd = null;
  try { if (window.parent !== window) { pw = window.parent; pd = pw.document; } } catch (e) { pw = pd = null; }
  const esc = s => String(s).replace(/["\\]/g, '');
  function apply(f) {
    let st = document.getElementById('fx-font');
    if (!f) { if (st) st.remove(); return; }
    if (!st) { st = document.createElement('style'); st.id = 'fx-font'; document.head.appendChild(st); }
    st.textContent = `body, body *:not(svg):not(path) { font-family: "${esc(f)}", "PingFang SC", "Microsoft YaHei", sans-serif !important; }`;
  }
  const oi = window.init;
  if (typeof oi === 'function') window.init = function (p) { P = p || {}; apply(P.__font); const r = oi.apply(this, arguments); setTimeout(mount, 0); return r; };
  async function fontList() {
    if (pw.__fxFonts) return pw.__fxFonts;
    if (!pw.queryLocalFonts) return null;
    try { const fs = await pw.queryLocalFonts(); pw.__fxFonts = [...new Set(fs.map(f => f.family))].sort((a, b) => a.localeCompare(b, 'zh')); return pw.__fxFonts; } catch (e) { return null; }
  }
  function set(f) {
    if (!P) return; if (f) P.__font = f; else delete P.__font; apply(f);
    try { window.renderAt && window.renderAt(+(pw.slider && pw.slider.value) || 0); } catch (e) { }
    try { pw.markDirty && pw.markDirty(); } catch (e) { } try { pw.histSoon && pw.histSoon(); } catch (e) { }
    mount(true);
  }
  function mount(force) {
    if (!pd || !P) return;
    try { if (!pw.frame || pw.frame.contentWindow !== window) return; } catch (e) { return; }   // 只在主预览里放面板（叠在下面的素材不放）
    const box = pd.getElementById('params'); if (!box) return;
    let row = box.querySelector('.fxfont-row');
    if (row && !force) return;
    if (!row) { row = pd.createElement('div'); row.className = 'fxfont-row'; box.prepend(row); }
    row.style.cssText = 'display:flex;align-items:center;gap:8px;margin:0 0 10px;padding:8px 10px;border:1px solid #333;border-radius:8px;background:#1a1a1a';
    const f = P.__font || '';
    row.innerHTML = `<b style="font-size:12px;color:#aaa;white-space:nowrap">字体</b>`
      + `<button type="button" class="ff-pick" style="flex:1;text-align:left;padding:4px 8px;border:1px solid #444;border-radius:6px;background:#111;color:#eee;cursor:pointer;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;${f ? `font-family:'${esc(f)}'` : ''}">${f ? esc(f) : '默认（效果原来的字体）'} ▾</button>`
      + (f ? `<button type="button" class="ff-def" title="用回效果原来的字体" style="padding:4px 8px;border:1px solid #444;border-radius:6px;background:transparent;color:#aaa;cursor:pointer">默认</button>` : '');
    row.querySelector('.ff-pick').onclick = open;
    const d = row.querySelector('.ff-def'); if (d) d.onclick = () => set(null);
  }
  async function open() {
    const list = await fontList();
    const m = pd.createElement('div');
    m.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center';
    m.innerHTML = `<div style="width:460px;max-height:78vh;display:flex;flex-direction:column;background:#1b1b1b;border:1px solid #444;border-radius:10px;padding:14px;color:#eee;font:13px 'Microsoft YaHei',sans-serif">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><b>选字体（电脑上已经装好的）</b><i class="x" style="cursor:pointer;font-style:normal;color:#aaa">✕</i></div>
      <input class="q" placeholder="${list ? '搜索字体名…（共 ' + list.length + ' 个，回车选第一个）' : '读不到字体列表：直接输入字体名，回车'}" style="padding:7px 9px;border:1px solid #444;border-radius:6px;background:#111;color:#eee;margin-bottom:8px">
      <div class="ls" style="overflow:auto;flex:1;min-height:120px"></div>
      <small style="color:#888;margin-top:8px;line-height:1.5">想用新字体：在电脑上装好，再刷新工作台。字体不会拷进工作台，只记名字。</small></div>`;
    pd.body.appendChild(m);
    const q = m.querySelector('.q'), ls = m.querySelector('.ls'), close = () => m.remove();
    m.querySelector('.x').onclick = close; m.onclick = e => { if (e.target === m) close(); };
    const draw = () => {
      const k = q.value.trim().toLowerCase(), items = ['', ...(list || []).filter(n => !k || n.toLowerCase().includes(k))].slice(0, 120);
      ls.innerHTML = '';
      items.forEach(n => {
        const it = pd.createElement('div');
        it.style.cssText = 'display:flex;justify-content:space-between;align-items:center;gap:10px;padding:7px 8px;border-radius:6px;cursor:pointer' + ((P.__font || '') === n ? ';background:#3a2a10' : '');
        it.innerHTML = n ? `<span style="color:#aaa;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(n)}</span><span style="font-family:'${esc(n)}';font-size:18px;white-space:nowrap">字体样式 Aa 123</span>` : '<span>默认（效果原来的字体）</span>';
        it.onmouseenter = () => { if ((P.__font || '') !== n) it.style.background = '#2a2a2a'; }; it.onmouseleave = () => { if ((P.__font || '') !== n) it.style.background = ''; };
        it.onclick = () => { set(n || null); close(); };
        ls.appendChild(it);
      });
      if (list && items.length >= 120) { const s = pd.createElement('small'); s.style.color = '#777'; s.textContent = '只显示前 120 个，输入名字搜索可以找到更多'; ls.appendChild(s); }
    };
    q.oninput = draw;
    q.onkeydown = e => { if (e.key === 'Escape') close(); if (e.key === 'Enter' && q.value.trim()) { const k = q.value.trim(), hit = (list || []).find(n => n.toLowerCase() === k.toLowerCase()) || (list || []).find(n => n.toLowerCase().includes(k.toLowerCase())); set(hit || k); close(); } /* 回车 = 搜到的第一个；列表里没有就直接用输入的名字 */ };
    draw(); q.focus();
  }
  window.addEventListener('pagehide', () => { try { pd && pd.querySelectorAll('#params .fxfont-row').forEach(x => x.remove()); } catch (e) { } });
})();
