// 效果工坊 · 持续时间 · 预览缩放 / 播放 / 进度（fit / reinit / seek）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 持续时间（v8.1） =================
// 用户最常想做的事：让这个效果正好占满剪辑里的 N 秒。以前要在一堆「入场 / 停留 / 退场」里自己算，
// 现在右侧最上面一个「持续时间」直接填总秒数，工作台按效果的情况自己决定改哪里：
//   native  效果本身有「总时长」参数（dur / total）     → 直接改它
//   minsec  效果用「分钟 + 秒」两个参数（章节进度条）    → 拆成分和秒
//   hold    有「停留」类参数                            → 多出来 / 少掉的时间加减在停留上，动作速度不变
//   ui      卡片类效果（卡片内容里的「停留时长」）        → 同上，加减在卡片停留上
//   stretch 都没有                                      → 整段按比例放慢 / 加快（params.__dur，见 view-controls.js 顶部）
// v42.x（2026-11-17）：素材条上有小旗子的效果（effect.json 写了 marks，或者页面给了「活」旗子 __fxMarks）
//   裁短：所有「秒」参数和每面旗子都乘 新时长 / 原时长，旗子等比例往前挪；
//   拉长（v43.1 用户改的）：旗子都不动，多出来的时间加在「停留」上（和没旗子的效果一样），
//   旗子之间的先后和间隔比例不变（以前只加减「停留」，裁短以后「出」会跑到「灰」「禁」前面，很难控制）。
// 停留减到 0 还不够短时，剩下的部分自动按比例加快。效果也可以在 effect.json 里写 "duration" 指定：
//   "duration": "dur"（直接改这个参数） / {"hold": "hold2"}（加减在这个参数上） / "stretch"（按比例）
const TIME_RE = /（秒|（ms）|\(ms\)|时长|停留|间隔|周期|圈数|等待/;
const r2 = x => Math.round(x * 100) / 100;
const pOf = k => cur && cur.params.find(p => p.key === k);
const isNum = p => p && p.type === 'number' && !p.hidden;
function durPlan() {
  const o = cur.duration, ps = cur.params;
  if (o === 'stretch' || cur.__durFell) return { mode: 'stretch', own: [] };
  if (typeof o === 'string' && pOf(o)) return { mode: 'native', key: o, own: [o] };
  if (o && typeof o === 'object' && o.hold && pOf(o.hold)) return { mode: 'hold', key: o.hold, own: [] };
  if (pOf('durMin') && pOf('durSec')) return { mode: 'minsec', own: ['durMin', 'durSec'] };
  const nat = ps.find(p => isNum(p) && ['dur', 'total', 'duration'].includes(p.key) && /时长|时间/.test(p.label || ''));
  if (nat) return { mode: 'native', key: nat.key, own: [nat.key] };
  const holds = ps.filter(p => isNum(p) && /停留|持续时长/.test(p.label || ''));
  if (holds.length) return { mode: 'hold', key: holds[holds.length - 1].key, own: [] };
  if (ps.some(p => p.key === 'cards')) return { mode: 'ui', own: [] };
  return { mode: 'stretch', own: [] };
}
// 「分段时间」：所有能影响时长的数字参数（入场 / 停留 / 间隔 / 周期……），从「数值调节」里搬到这一块
const durSegKeys = DP => cur.params.filter(p => isNum(p) && !DP.own.includes(p.key) && TIME_RE.test(p.label || '') && !/px|%|度）/.test(p.label || '')).map(p => p.key);
const fw = () => frame.contentWindow;
const nativeDur = () => { const w = fw(); try { return +(w.__fxNativeDur ? w.__fxNativeDur() : w.getDuration()) || 0; } catch (e) { return 0; } };
const cardsObj = () => { const v = params.cards; if (!v) return null; try { return typeof v === 'string' ? JSON.parse(v) : JSON.parse(JSON.stringify(v)); } catch (e) { return null; } };
const cardsPut = o => { params.cards = typeof params.cards === 'string' ? JSON.stringify(o) : o; if (inputs.cards) inputs.cards.value = typeof params.cards === 'string' ? params.cards : JSON.stringify(o); };
const uiHold = () => { const o = cardsObj(); const h = o && o.ui ? +o.ui.hold : NaN; return Number.isFinite(h) ? h : 2; };
function durBuild(DP, nSeg) {
  const d = document.createElement('div'); d.className = 'fxdur';
  const k = 'fxdur:' + cur.id; let off = false; try { off = localStorage.getItem(k) === '0'; } catch (e) { }
  if (off) d.classList.add('off');
  d.innerHTML = '<div class="fxdur-h">⏱ 持续时间<small>整个效果有多长</small></div>'
    + '<div class="fxdur-row"><input type="number" min="0.5" step="0.1"><em>秒</em><button type="button" hidden title="回到这个效果原来的时长">↺ 原长</button></div>'
    + '<input type="range" class="fxdur-rng" min="0.5" step="0.1">'
    + '<div class="fxdur-note"></div>'
    + '<button type="button" class="fxdur-tg"><i>▾</i>分段时间（' + nSeg + ' 项）<small style="margin-left:auto;color:#777">入场 / 停留 / 退场各多长</small></button>'
    + '<div class="fxdur-list"></div>';
  const inp = d.querySelector('input[type=number]'), rng = d.querySelector('.fxdur-rng');
  d.querySelector('.fxdur-tg').onclick = () => { d.classList.toggle('off'); try { localStorage.setItem(k, d.classList.contains('off') ? '0' : '1'); } catch (e) { } };
  d.querySelector('.fxdur-row button').onclick = () => { durReset(); };
  const go = v => { const n = parseFloat(v); if (Number.isFinite(n) && n > 0) setDuration(n); };
  inp.addEventListener('change', () => go(inp.value));
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') { go(inp.value); inp.select(); } });
  let rt = 0;
  rng.addEventListener('input', () => { inp.value = rng.value; clearTimeout(rt); rt = setTimeout(() => go(rng.value), 120); });
  return d;
}
// ---------- 带小旗子的效果：时长按比例（v42.x） ----------
const flagW = () => { const w = fw(); try { return w && typeof w.__fxMarks === 'function' && typeof w.__fxMarkSet === 'function' ? w : null; } catch (e) { return null; } };
const hasFlags = () => !!cur && ((Array.isArray(cur.marks) && cur.marks.length > 0) || !!flagW());
// 要按比例缩放的参数：旗子管的参数（key、from 里的）+ 所有以「秒」为单位的数字参数（入场 / 停留 / 过渡……）
function flagKeys() {
  const ks = new Set();
  (cur.marks || []).forEach(m => { if (m && m.key) ks.add(m.key); ((m && m.from) || []).forEach(f => ks.add(f)); });
  cur.params.forEach(p => { if (p.type === 'number' && /秒|（ms）|\(ms\)/.test(p.label || '') && !/px|%|度）/.test(p.label || '')) ks.add(p.key); });
  const DP = durPlan(); if (DP.mode === 'native') ks.add(DP.key);
  return [...ks].filter(k => { const p = pOf(k); return p && p.type === 'number'; });
}
const numOf = k => { const v = params[k], p = pOf(k); return v !== '' && v != null && Number.isFinite(+v) ? +v : +(p && p.default); };
// 把所有时间乘 k = T / 现在的原长；算完量一下真的是 T 秒，不是就整个退回（返回 false，走原来的办法）
function durScale(T) {
  const w = fw(); if (!w || !w.init) return false;
  try { w.init(params); } catch (e) { return false; }
  const D0 = nativeDur(); if (!(D0 > 0.05)) return false;
  const k = T / D0; if (Math.abs(k - 1) < 1e-4) return true;
  const snap = JSON.stringify(params);
  const fwin = flagW();
  let dyn = []; if (fwin) { try { dyn = (fwin.__fxMarks() || []).filter(m => m && m.id != null && Number.isFinite(+m.t)).map(m => ({ id: m.id, t: +m.t })); } catch (e) { dyn = []; } }
  // 第一次改时长时记下原来的样子（params.__durOrig，跟着素材 / 撤销 / 预设走），「↺ 原长」照它一模一样地放回去
  if (!params.__durOrig) { const ko = {}; flagKeys().forEach(x => { ko[x] = params[x]; }); params.__durOrig = { keys: ko, dyn }; }
  flagKeys().forEach(key => {
    const p = pOf(key), v0 = numOf(key); if (!Number.isFinite(v0)) return;
    let v = Math.round(v0 * k * 1000) / 1000;
    if (p.min != null && v < +p.min) v = +p.min;
    if (p.max != null && v > +p.max) v = +p.max;
    params[key] = v;
  });
  // 「活」旗子（跟内容走的，比如时间轴的每个节点）：参数改完以后一面一面按比例放回去；拉长从后往前放，缩短从前往后放，免得互相挡住
  if (dyn.length) {
    try { w.init(params); } catch (e) { }
    dyn.sort((a, b) => k > 1 ? b.t - a.t : a.t - b.t).forEach(m => { try { fwin.__fxMarkSet(m.id, Math.round(m.t * k * 1000) / 1000); } catch (e) { } });
  }
  try { w.init(params); } catch (e) { }
  // 效果里有写死的秒数（比如时间轴最后一项后面固定 0.6 秒）时差一点点：差的这一点加减在「停留」上
  const D1 = nativeDur(), DP = durPlan();
  if (Math.abs(D1 - T) > 0.06 && DP.mode === 'hold') {
    const p = pOf(DP.key), h = Math.round((numOf(DP.key) + (T - D1)) * 1000) / 1000;
    if (h >= (p.min != null ? +p.min : 0) && (p.max == null || h <= +p.max)) { params[DP.key] = h; try { w.init(params); } catch (e) { } }
  }
  if (Math.abs(nativeDur() - T) > 0.06) {                 // 有的参数到了上下限、或者时长不是按这些参数算的 → 退回
    const o = JSON.parse(snap); Object.keys(params).forEach(x => delete params[x]); Object.assign(params, o);
    try { w.init(params); } catch (e) { }
    return false;
  }
  return true;
}
// ---------- v44.3：缩短的顺序（用户定的） ----------
// 往左缩短带旗子的素材时，按这个顺序吃掉时间：
//   ① 先吃「出」后面多余的那一段（出场时长，最少留 0.2 秒）—— 还没缩到「出」的时候，所有旗子都不动；
//   ② 再把「出」跟着往左推（减「停留」），直到快碰到前面最后一面旗子（留 0.15 秒）；
//   ③ 还要更短，才所有旗子一起按比例往前挤。
// fx = 效果的 effect.json，get(key) = 这个素材现在的参数值；dynTs = 「活」旗子的秒数。22-fx-marks.js 拖的时候也用它预览旗子位置。
function shrinkPlan(fx, get, D0, T, dynTs) {
  const ps = (fx && fx.params) || [], num = k => { const v = +get(k); return Number.isFinite(v) ? v : 0; };
  const hidden = m => [].concat(m.hideWhen || []).some(h => h && ((Array.isArray(h.in) && h.in.includes(get(h.key))) || (Array.isArray(h.notIn) && !h.notIn.includes(get(h.key)))));
  const holdKey = fx && fx.duration && fx.duration.hold ? fx.duration.hold : (ps.filter(p => p.type === 'number' && /停留/.test(p.label || '')).pop() || {}).key;
  const marks = ((fx && fx.marks) || []).filter(m => m && m.key && !hidden(m));
  const tOf = m => num(m.key) + [].concat(m.from || []).reduce((a, k) => a + num(k), 0);
  const hm = holdKey ? marks.find(m => m.key === holdKey) : null;      // 「出」这面旗子（管停留的那面）
  const outP = ps.find(p => p.type === 'number' && (p.key === 'outDur' || /^出场时长/.test(p.label || '')));
  let need = Math.max(0, D0 - T), a = 0, b = 0;
  if (hm && outP) { const v = num(outP.key), keep = Math.min(v, 0.2); a = Math.min(need, Math.max(0, v - keep)); need -= a; }
  if (hm && need > 0) {
    const others = marks.filter(m => m !== hm).map(tOf).concat(dynTs || []);
    const lim = others.length ? Math.max(...others) + 0.15 : 0;
    b = Math.min(need, Math.max(0, tOf(hm) - lim), num(holdKey)); need -= b;
  }
  const rest = D0 - a - b, k = need > 0.0005 && rest > 0 ? T / rest : 1;
  return { a, b, k, outKey: outP && outP.key, holdKey, hm };
}
function durShrink(T, D0) {
  const w = fw(); if (!w || !w.init) return false;
  const snap = JSON.stringify(params), fwin = flagW();
  let dyn = []; if (fwin) { try { dyn = (fwin.__fxMarks() || []).filter(m => m && m.id != null && Number.isFinite(+m.t)).map(m => ({ id: m.id, t: +m.t })); } catch (e) { dyn = []; } }
  if (!params.__durOrig) { const ko = {}; flagKeys().forEach(x => { ko[x] = params[x]; }); params.__durOrig = { keys: ko, dyn }; }
  const get = k => (params[k] != null && params[k] !== '' ? params[k] : (pOf(k) || {}).default);
  const pl = shrinkPlan(cur, get, D0, T, dyn.map(m => m.t));
  const r3 = v => Math.round(v * 1000) / 1000;
  if (pl.a > 0) params[pl.outKey] = r3(numOf(pl.outKey) - pl.a);
  if (pl.b > 0) params[pl.holdKey] = r3(numOf(pl.holdKey) - pl.b);
  let ok;
  if (pl.k !== 1) ok = durScale(T);
  else { try { w.init(params); } catch (e) { } ok = Math.abs(nativeDur() - T) <= 0.06; }
  if (!ok) { const o = JSON.parse(snap); Object.keys(params).forEach(x => delete params[x]); Object.assign(params, o); try { w.init(params); } catch (e) { } }
  return ok;
}
// 把整个效果的时长设成 T 秒
function setDuration(T) {
  if (!cur) return;
  const w = fw(); if (!w || !w.init) return;
  const DP = durPlan(), t0 = +slider.value || 0;
  T = Math.max(0.5, Math.min(7200, r2(T)));
  delete params.__dur;
  // v43.1：只有「缩短」才按比例（旗子等比例往前挪）；「拉长」时旗子都不动，多出来的时间加在最后（停留 / 出场前）
  let Dnow = 0; if (DP.mode !== 'minsec' && hasFlags()) { try { w.init(params); } catch (e) { } Dnow = nativeDur(); }
  if (DP.mode !== 'minsec' && hasFlags() && T < Dnow - 0.005 && durShrink(T, Dnow)) {
    // 面板里的数字、效果自己的编辑器都要重新读一遍
    buildParams(); reinit(false); seek(Math.min(T * (t0 / Math.max(0.01, dur || T)), dur)); durSync();
    return;
  }
  if (DP.mode === 'native') {
    const p = pOf(DP.key);
    params[DP.key] = Math.max(p.min != null ? +p.min : 0.5, p.max != null ? Math.min(+p.max, T) : T);
    if (params[DP.key] !== T) toast('「' + p.label + '」的范围是 ' + (p.min != null ? p.min : 0.5) + ' ~ ' + (p.max != null ? p.max : '∞') + ' 秒');
  } else if (DP.mode === 'minsec') {
    const s = Math.max(1, Math.round(T));
    params.durMin = Math.floor(s / 60); params.durSec = s % 60;
  } else if (DP.mode === 'hold' || DP.mode === 'ui') {
    try { w.init(params); } catch (e) { }
    const D0 = nativeDur();
    const h0 = DP.mode === 'hold' ? (Number.isFinite(+params[DP.key]) ? +params[DP.key] : +pOf(DP.key).default || 0) : uiHold();
    const put = h => {
      if (DP.mode === 'hold') { params[DP.key] = h; if (inputs[DP.key]) { inputs[DP.key].value = h; if (inputs[DP.key].__fxRange) inputs[DP.key].__fxRange.value = h; } }
      else { const o = cardsObj() || {}; o.ui = Object.assign({}, o.ui || {}, { hold: h }); cardsPut(o); }
    };
    let h = r2(h0 + (T - D0));
    const hp = DP.mode === 'hold' ? pOf(DP.key) : null;
    const hMax = hp && hp.max != null ? +hp.max : 1e9;
    if (h < 0) { put(0); params.__dur = T; }                  // 停留减到 0 还不够短：剩下的按比例加快
    else if (h > hMax) { put(hMax); params.__dur = T; }       // 停留到上限还不够长：剩下的按比例放慢
    else put(h);
    // 检查一下真的变成了 T 秒；没变（比如这个卡片效果不看「停留」）就退回按比例伸缩
    try { w.init(params); } catch (e) { }
    const D1 = params.__dur ? T : nativeDur();
    if (Math.abs(D1 - T) > 0.06) {
      put(h0);
      if (DP.mode === 'ui') cur.__durFell = true;
      params.__dur = T;
    }
  } else params.__dur = T;
  const s = Math.max(0, Math.min(t0, T));
  // 卡片内容是效果自己的编辑器在管（它挂载时读一次），改了停留要重建面板，让编辑器重新读到新的停留时长
  if (DP.mode === 'ui') buildParams();
  reinit(false); seek(Math.min(s, dur)); durSync();
}
// 回到原长
function durReset() {
  if (!cur) return;
  const DP = durPlan();
  delete params.__dur;
  if (DP.mode !== 'minsec' && hasFlags()) {                // 带小旗子的：放回第一次改时长之前的样子（没记过就回到默认）
    const o = params.__durOrig; delete params.__durOrig;
    if (o && o.keys) {
      Object.keys(o.keys).forEach(k => { if (o.keys[k] === undefined) delete params[k]; else params[k] = o.keys[k]; });
      const w = fw(), fwin = flagW();
      if (w && fwin && Array.isArray(o.dyn) && o.dyn.length) {
        try { w.init(params); } catch (e) { }
        let now = []; try { now = fwin.__fxMarks() || []; } catch (e) { }
        const tNow = id => { const m = now.find(x => String(x.id) === String(id)); return m ? +m.t : 0; };
        const later = o.dyn.filter(m => m.t > tNow(m.id)).sort((a, b) => b.t - a.t), earlier = o.dyn.filter(m => m.t <= tNow(m.id)).sort((a, b) => a.t - b.t);
        [...later, ...earlier].forEach(m => { try { fwin.__fxMarkSet(m.id, m.t); } catch (e) { } });
      }
    } else flagKeys().forEach(k => { params[k] = defOf(pOf(k)); });
    buildParams(); reinit(false); toast('已回到原来的时长：' + dur.toFixed(1) + ' 秒（旗子也回到原来的位置）');
    return;
  }
  if (DP.mode === 'native') params[DP.key] = defOf(pOf(DP.key));
  else if (DP.mode === 'minsec') { params.durMin = defOf(pOf('durMin')); params.durSec = defOf(pOf('durSec')); }
  else if (DP.mode === 'hold') { params[DP.key] = defOf(pOf(DP.key)); if (inputs[DP.key]) inputs[DP.key].value = params[DP.key]; }
  else if (DP.mode === 'ui') {
    const p = pOf('cards'), o = cardsObj();
    let dh; try { const d0 = typeof p.default === 'string' ? JSON.parse(p.default) : p.default; dh = d0 && d0.ui ? d0.ui.hold : undefined; } catch (e) { }
    if (o) { o.ui = Object.assign({}, o.ui || {}); if (dh === undefined) delete o.ui.hold; else o.ui.hold = dh; cardsPut(o); }
  }
  buildParams(); reinit(false); toast('已回到原来的时长：' + dur.toFixed(1) + ' 秒');
}
// 刷新「持续时间」那一块：数字、滑杆范围、说明文字、「原长」按钮
function durSync() {
  const d = document.querySelector('#params .fxdur'); if (!d || !cur) return;
  const DP = durPlan(), inp = d.querySelector('input[type=number]'), rng = d.querySelector('.fxdur-rng');
  const T = r2(dur || 0), D = r2(nativeDur());
  if (document.activeElement !== inp) inp.value = T;
  rng.max = Math.max(30, Math.ceil(Math.max(T, D) * 3 / 10) * 10, DP.mode === 'minsec' ? 7200 : 0);
  if (document.activeElement !== rng) rng.value = T;
  let changed = !!params.__dur;
  const lab = k => { const p = pOf(k); return p ? p.label.replace(/（.*$/, '') : k; };
  let note;
  if (DP.mode !== 'minsec' && hasFlags()) { changed = changed || !!params.__durOrig || flagKeys().some(k => !sameDef(pOf(k))); note = '<b>缩短</b>：先剪掉「出」后面多余的部分；剪到「出」了，「出」跟着往前推；再短，所有<b>小旗子</b>按比例往前挤。<b>拉长</b>：旗子都不动，多出来的时间加在最后。'; }
  else if (DP.mode === 'native') { changed = changed || !sameDef(pOf(DP.key)); note = '就是这个效果的「' + lab(DP.key) + '」。'; }
  else if (DP.mode === 'minsec') { changed = changed || !sameDef(pOf('durMin')) || !sameDef(pOf('durSec')); note = '= <b>' + Math.floor(T / 60) + ' 分 ' + Math.round(T % 60) + ' 秒</b>（最长 120 分钟）。'; }
  else if (DP.mode === 'hold') { changed = changed || !sameDef(pOf(DP.key)); note = '加长 / 缩短的时间放在<b>「' + lab(DP.key) + '」</b>上，动作速度不变。'; }
  else if (DP.mode === 'ui') { changed = changed || Math.abs(uiHold() - (() => { const p = pOf('cards'); try { const o = typeof p.default === 'string' ? JSON.parse(p.default) : p.default; return o && o.ui && Number.isFinite(+o.ui.hold) ? +o.ui.hold : 2; } catch (e) { return 2; } })()) > 1e-6; note = '加长 / 缩短的时间放在卡片的<b>「停留时长」</b>上，动作速度不变。'; }
  else note = '这个效果没有单独的停留时间，改了以后<b>整段动画按比例放慢 / 加快</b>（原长 ' + D + ' 秒）。';
  if (params.__dur && DP.mode !== 'stretch') note += '停留已经到头，<b>剩下的部分按比例' + (T < D ? '加快' : '放慢') + '</b>（原长 ' + D + ' 秒）。';
  d.querySelector('.fxdur-note').innerHTML = note;
  d.querySelector('.fxdur-row button').hidden = !changed;
}


function applyLive() {
  const w = frame.contentWindow; if (!w || !w.init) return;
  w.init(params); dur = w.getDuration(); slider.max = dur || 0.01; seek(Math.min(+slider.value, dur));
  markDirty();
}
box.addEventListener('wheel', e => {
  const sp = cur && cur.params.find(p => p.key === 'scale'); if (!sp) return;
  e.preventDefault();
  let v = Math.round((+params.scale || 1) * (e.deltaY < 0 ? 1.06 : 1 / 1.06) * 100) / 100;
  v = Math.min(sp.max != null ? sp.max : 5, Math.max(sp.min != null ? sp.min : 0.2, v));
  params.scale = v; if (inputs.scale) inputs.scale.value = v;
  $('#hint').textContent = '卡片大小 ' + Math.round(v * 100) + '%（双击预览区还原）'; applyLive();
}, { passive: false });
box.addEventListener('dblclick', () => {
  const sp = cur && cur.params.find(p => p.key === 'scale'); if (!sp) return;
  params.scale = sp.default != null ? sp.default : 1; if (inputs.scale) inputs.scale.value = params.scale;
  $('#hint').textContent = '卡片大小已还原 100%'; applyLive();
});
function fit() { fitStage(); Hooks.run('fit'); }
// v37.0：中间这一栏往下滚了 → 钉住的预览下面加一条阴影
{ const mn = $('main'), pin = $('#pvpin'); if (mn && pin) mn.addEventListener('scroll', () => pin.classList.toggle('stuck', mn.scrollTop > 2), { passive: true }); }
// v37.0：预览钉在最上面、时间线在下面自己滚（#pvpin，main.css）。所以时间线再高，预览也不用缩成一点点：
//   默认高度里时间线最多只算屏幕的 42%；手动拖过的高度（__stageH）最多到「屏幕高 − 260」，下面至少留一截时间线
function fitStage() {
  const { w, h } = res();
  const tlH = typeof tlFitH === 'function' ? Math.min(tlFitH(), Math.round(innerHeight * 0.42)) : 0;
  const H = window.__stageH ? Math.max(120, Math.min(window.__stageH, innerHeight - 260)) : Math.max(200, innerHeight - 130 - tlH);
  const s = Math.min($('#stagewrap').clientWidth / w, H / h);
  box.style.width = w * s + 'px'; box.style.height = h * s + 'px';
  frame.style.width = w + 'px'; frame.style.height = h + 'px'; frame.style.transform = 'scale(' + s + ')';
}
frame.onload = () => { fit(); reinit(true); setTimeout(() => { if (!hUndo.length) hLast = hSnap(); }, 600); };   // 效果初始化时自己补的默认值不算一步
function reinit(play) { const ctx = { play }; Hooks.run('reinit:before', ctx); reinitEffect(ctx.play); Hooks.run('reinit', ctx); }
function reinitEffect(play) {
  const w = frame.contentWindow; if (!w || !w.init) return;
  try { w.init(params); dur = w.getDuration(); } catch (e) { console.error(e); return; }
  slider.max = dur || 0.01;
  play ? start() : seek(Math.min(+slider.value, dur));
  markDirty(); kfSel = new Set(); kfTrackDraw(); durSync();
}
let kfHeadT = 0;
function seek(t) { seekEffect(t); Hooks.run('seek', t); }
function seekEffect(t) {
  frame.contentWindow.renderAt(Math.min(t, dur)); slider.value = t; $('#tl').textContent = t.toFixed(1) + ' / ' + dur.toFixed(1) + ' s';
  const n = Date.now(); if (n - kfHeadT > 60) { kfHeadT = n; const h = kfTrack && kfTrack.querySelector('.kfhead'); if (h) h.style.left = kfHeadPct(t) + '%';  const kb = $('#kfadd'); if (kb && !kb.hidden) kb.textContent = '◆ 在 ' + t.toFixed(2) + ' 秒打关键帧'; }
}
// 播放状态：原来只有「从头播」，现在支持暂停 / 从当前位置续播
let playing = false;
function ppSync() {
  const b = $('#pp'); if (!b) return;
  const on = playing || (typeof tlPlaying !== 'undefined' && tlPlaying);   // 时间线在播也算
  b.classList.toggle('on', on);
  b.querySelector('i').textContent = on ? '❚❚' : '▶';
  b.querySelector('span').textContent = on ? '暂停' : '播放';
}
function stop() { stopEffect(); Hooks.run('stop'); }
function stopEffect() { cancelAnimationFrame(raf); if (playing) { playing = false; ppSync(); } }
function start(from) {
  stop();
  const begin = Math.max(0, Math.min(from == null ? 0 : +from || 0, dur));
  const t0 = performance.now() - begin * 1000;
  playing = true; ppSync();
  const tick = n => {
    const t = (n - t0) / 1000;
    seek(Math.min(t, dur));
    if (t < dur) raf = requestAnimationFrame(tick);
    else { playing = false; ppSync(); }      // 播到头自动停，按钮变回「播放」
  };
  raf = requestAnimationFrame(tick);
}
// 时间线上有素材时（v24.11）：播放 / 暂停 / 重播 / 进度条都管整条时间线，不再只播「当前这一个效果」
// （以前没选中素材时点播放，播的是藏在后面的那个效果：进度条在走、时间线播放头不动、画面也看不到）
const tlMode = () => TL.clips.some(c => !c.ref);
$('#play').onclick = () => { if (tlMode()) { tlStop(); stop(); tlSeek(0); tlPlay(); return; } reinit(true); };   // 重播 = 从第 0 秒重新来一遍
$('#pp').onclick = () => {
  if (tlMode()) { tlPlay(); return; }                       // tlPlay 自己会在「播放中」时停下
  if (playing) { stop(); return; }
  const t = +slider.value || 0;
  start(t >= dur - 0.02 ? 0 : t);                             // 已经播到头就从头播，否则从当前位置续播
};
ppSync();
slider.oninput = () => {
  if (tlMode() && !tlSel) { tlStop(); stop(); tlSeek(+slider.value); return; }   // 没选中素材：进度条就是整条时间线
  stop(); seek(+slider.value);
};
$('#res').onchange = () => { fit(); reinit(true); };
addEventListener('resize', fit);

// ================= 导出编码 + 文件大小预估（v27.0） =================
// mbps = 1920×1080 / 30 帧时每秒多少 MB（按画面铺满的组合卡片实测；小标题这类画面更空的会更小）。和 server.js 的 CODECS 对应
const CODECS = {
  pq: { ext: '.mov', mbps: 14, name: 'ProRes 4444 标准' }, prores: { ext: '.mov', mbps: 32, name: 'ProRes 4444 最高画质' },
  png: { ext: '.mov', mbps: 17, name: 'PNG 编码 MOV（无损）' }, qtrle: { ext: '.mov', mbps: 20, name: '动画编码 MOV（无损）' },
  mp4: { ext: '.mp4', mbps: 0.3, name: 'H.264 MP4（不透明）' },
  // v49.0 不透明编码 + 自动判断（按 testsrc2 实测比例估：422 约是 4444 标准的 0.6 倍，H.265 和 H.264 差不多）
  p422: { ext: '.mov', mbps: 9, name: 'ProRes 422（不透明）' }, h265: { ext: '.mp4', mbps: 0.28, name: 'H.265 MP4（不透明）' },
  auto: { ext: '', mbps: 14, name: '自动判断（有透明 → ProRes 4444，没有 → 不透明编码）' },
};
const OPAQUE = { p422: 1, h265: 1, mp4: 1 };
const codec2Id = () => OPAQUE[$('#codec2').value] ? $('#codec2').value : 'p422';
const codecId = () => CODECS[$('#codec').value] ? $('#codec').value : 'pq';
const codecExt = () => CODECS[codecId()].ext || (CODECS[codec2Id()].ext === '.mov' ? '.mov' : '.mov / .mp4');   // 自动判断：按检测结果是 .mov 或 .mp4
function estMB(secs) { const { w, h } = res(), fps = +$('#fps').value || 30; return CODECS[codecId()].mbps * (w * h / 2073600) * (fps / 30) * Math.max(0, secs); }
const fmtMB = mb => mb >= 1024 ? (mb / 1024).toFixed(1) + ' GB' : mb >= 10 ? Math.round(mb) + ' MB' : Math.max(0.1, mb).toFixed(1) + ' MB';
function sizeEst() {
  const el = $('#sizeest'); if (!el) return;
  const tl = typeof TL !== 'undefined' && TL.clips.length, secs = (tl ? tlEnd() : dur) + (+$('#hold').value || 0);
  const pr = CODECS.prores.mbps / CODECS[codecId()].mbps;
  if (codecId() === 'auto') { const m2 = CODECS[codec2Id()].mbps / CODECS.pq.mbps; el.innerHTML = '预计' + (tl ? '整条时间线' : '') + ' ' + secs.toFixed(1) + ' 秒：有透明约 <b>' + fmtMB(estMB(secs)) + '</b>，没有透明约 <b>' + fmtMB(estMB(secs) * m2) + '</b><br>每段导出前自动检查，按画面铺满估算'; return; }
  el.innerHTML = '预计' + (tl ? '整条时间线' : '') + ' ' + secs.toFixed(1) + ' 秒约 <b>' + fmtMB(estMB(secs)) + '</b>' + (codecId() !== 'prores' ? '（最高画质要 ' + fmtMB(estMB(secs) * pr) + '）' : '') + '<br>按画面铺满估算，画面越空文件越小';
}
try { const v = store.get('codec', 'auto'); if (CODECS[v]) $('#codec').value = v; } catch (e) {}
try { if (!store.get('codecAuto49', false)) { store.set('codecAuto49', true); $('#codec').value = 'auto'; store.set('codec', 'auto'); } } catch (e) {}   // v49.0：升级后先切到「自动判断」一次，之后按用户自己选的
try { const v = store.get('codec2', 'p422'); if (OPAQUE[v]) $('#codec2').value = v; } catch (e) {}
const ALPHA_CODEC = { pq: 1, prores: 1, png: 1, qtrle: 1, auto: 1 };
const alphaMode = () => $('#alphaFor').value === 'straight' ? 'straight' : 'premul';
try { if (store.get('alphaFor', '') === 'straight') $('#alphaFor').value = 'straight'; } catch (e) {}
$('#alphaFor').addEventListener('change', () => store.set('alphaFor', alphaMode()));
const codec2Show = () => { $('#codec2w').style.display = codecId() === 'auto' ? '' : 'none'; $('#alphaw').style.display = ALPHA_CODEC[codecId()] ? '' : 'none'; };
codec2Show();
$('#codec').addEventListener('change', () => { store.set('codec', codecId()); codec2Show(); sizeEst(); });
$('#codec2').addEventListener('change', () => { store.set('codec2', codec2Id()); sizeEst(); });
['#res', '#fps', '#hold'].forEach(q => $(q).addEventListener('change', sizeEst));
setInterval(sizeEst, 1500);
$('#export').onclick = async () => {
  // 很长的效果（比如 2 小时的章节进度条）：先提醒大概要多久、多大
  { const { w, h } = res(), fps = +$('#fps').value, secs = dur + (+$('#hold').value || 0), frames = Math.round(secs * fps);
    if (frames > 9000) {
      const mpx = w * h / 1e6;                                    // 实测：每帧约 (40 + 55×百万像素) 毫秒、(90 + 12×百万像素) KB
      const mins = Math.max(1, Math.round(frames * (0.04 + 0.055 * mpx) / 60));
      const gb = (estMB(secs) / 1024).toFixed(1);
      const tip = (fps > 10 ? '\n· 进度条这类变化很慢的效果，帧率选 5 或 10，看起来一样，快好几倍' : '') + (h >= 720 ? '\n· 分辨率选「1920×160 横条」，只导出进度条那一条，文件小很多，放进剪辑软件再摆到顶部/底部' : '');
      if (!confirm(`这个效果有 ${Math.floor(secs / 60)} 分 ${Math.round(secs % 60)} 秒，要导出 ${frames} 帧。\n预计需要约 ${mins} 分钟，文件约 ${gb} GB（粗略估算）。${tip}\n\n继续导出吗？`)) return;
    } }
  const name = prompt('请输入文件名（不用写 ' + codecExt() + '）：\n编码：' + CODECS[codecId()].name + '，预计约 ' + fmtMB(estMB(dur + (+$('#hold').value || 0))), cur.id);
  if (name === null) return;
  const b = $('#export'), msg = $('#msg'), prog = $('#prog');
  const { w, h } = res(); b.disabled = true; prog.style.display = 'block'; prog.firstChild.style.width = '0'; msg.textContent = '正在导出…';
  try {
    const r = await (await fetch('/api/export', { method: 'POST', body: JSON.stringify({ effect: cur.id, name, params, width: w, height: h, fps: +$('#fps').value, hold: +$('#hold').value || 0, codec: codecId(), codec2: codec2Id(), alphaMode: alphaMode() }) })).json();
    if (r.error) throw new Error(r.error);
    while (true) {
      await new Promise(r => setTimeout(r, 500));
      const j = await (await fetch('/api/job?id=' + r.id)).json();
      prog.firstChild.style.width = (j.progress * 100 || 0) + '%'; msg.textContent = j.stage || ('正在导出… ' + Math.round((j.progress || 0) * 100) + '%');
      if (j.status === 'done') { msg.textContent = '完成：output/' + j.file + (j.codecName ? '（' + (codecId() === 'auto' ? (j.alpha ? '有透明 → ' : '没有透明 → ') : '') + j.codecName + '）' : '') + (j.note ? '　' + j.note : ''); break; }
      if (j.status === 'error') throw new Error(j.message);
    }
  } catch (e) { msg.textContent = '出错：' + e.message; }
  b.disabled = false;
};
$('#open').onclick = () => fetch('/api/open-output', { method: 'POST' });
