// 效果工坊 · 折叠 · 缩放 · 复制粘贴 · 时间线撤销 · Delete · 快捷键说明 · 多选一起改
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ---------- 折叠：素材时间线 / 关键帧（v16.0），点标题收起或展开，会记住 ----------
function foldable(root, head, key, label) {
  const tg = document.createElement('span'); tg.className = 'fdt'; head.prepend(tg);
  const set = on => { root.classList.toggle('fold', on); tg.textContent = on ? '▸' : '▾'; tg.title = on ? '展开' + label : '收起' + label; store.set(key, on); fit(); };
  tg.onclick = e => { e.stopPropagation(); set(!root.classList.contains('fold')); };
  head.querySelector('b').style.cursor = 'pointer'; head.querySelector('b').onclick = tg.onclick;
  set(!!store.get(key, false));
}
foldable(panel, $('#tlp-h'), 'foldTL', '素材时间线');
foldable($('#kft'), $('#kft-h'), 'foldKF', '关键帧');
rvSync();

// ---------- 时间线缩放（v17.0）：+ / − 放大缩小「素材时间线」或「关键帧」—— 鼠标在哪个上面就缩放哪个，否则缩放最后点过的那个 ----------
// 放大 = 把轨道加宽、外面横向滚动；像素 ↔ 时间都是按轨道自己的位置算的，所以拖动 / 打点 / 框选不用改。
const tlSc = document.createElement('div'); tlSc.id = 'tlp-sc';
rvRow.before(tlSc); tlSc.append(rvRow, $('#tlp-b'), sgRow);
const kfSc = document.createElement('div'); kfSc.id = 'kft-sc';
kfTrack.before(kfSc); kfSc.append(kfTrack);
let kfZ = 1, zLast = 'tl', zHover = null;
[[panel, 'tl'], [$('#kft'), 'kf']].forEach(([el, k]) => {
  el.addEventListener('mouseenter', () => zHover = k); el.addEventListener('mouseleave', () => { if (zHover === k) zHover = null; });
  el.addEventListener('mousedown', () => zLast = k, true);
});
const tlNW = () => (names.offsetWidth || 40) + 6;      // 左边标签列实际宽度 + 间距（v25.1：标签列会变宽，比如加了眼睛 / 锁按钮，不能写死）
// 关键帧轨道和素材时间线对齐（v25.2）：时间线上选着素材 / 组合时，关键帧的时间区左右边缘 = 上面轨道此刻露出来的那一段，
// 用同一把尺子（跟着时间线放大 / 滚动），两个播放头在同一条竖线上。没选素材（单个效果模式）时不对齐，照旧。
kfAlignFn = ir => {
  if (!TL.clips.length || kfT.hidden) return null;
  let off;
  if (tlGrp) { const m = TL.clips.filter(c => c.group === tlGrp); if (!m.length) return null; off = Math.min(...m.map(c => c.start)); }
  else { const c = clip(tlSel); if (!c) return null; off = c.start; }
  const tr = trk.getBoundingClientRect(), sc = tlSc.getBoundingClientRect(); if (!tr.width) return null;
  const L = Math.max(tr.left, sc.left + (tlZ > 1 ? tlNW() : 0)), R = Math.min(tr.right, sc.right);
  if (R - L < 20 || L < ir.left + 40) return null;      // 关键帧那边放不下标签列时不对齐
  const T = x => (x - tr.left) / tr.width * tlV;
  return { left: L, width: R - L, t0: T(L) - off, span: Math.max(0.01, T(R) - T(L)), off, al: true };
};
let kfRaf = 0; const kfRe = () => { if (!kfRaf) kfRaf = requestAnimationFrame(() => { kfRaf = 0; if (kfZ > 1 && kfMap().al) { kfZ = 1; kfTrack.style.width = ''; } kfTrackDraw(); }); };
tlSc.addEventListener('scroll', kfRe);
Hooks.on('tlDraw', () => kfRe());
Hooks.on('headPos', () => { const m = kfMap(); if (!m.al) return; const h = kfTrack.querySelector('.kfhead'); if (h) h.style.left = kfHeadPct(0) + '%'; });
function zApply(k, anchorT) {
  if (k === 'tl') {
    const NW = tlNW(), base = Math.max(100, tlSc.clientWidth - NW), tw = base * tlZ, vx = tlSc.scrollLeft;
    const px0 = NW + anchorT / tlV * (tlSc.classList.contains('zm') ? parseFloat(tlSc.style.getPropertyValue('--tw')) : base) - vx;
    tlSc.classList.toggle('zm', tlZ > 1); tlSc.style.setProperty('--tw', tw + 'px');
    tlDraw(); tlSc.scrollLeft = Math.max(0, NW + anchorT / tlV * tw - px0);
  } else {
    const base = Math.max(100, kfSc.clientWidth), w = base * kfZ, D = kfD() || 0.01;
    const px0 = 24 + anchorT / D * (kfTrack.offsetWidth - 30) - kfSc.scrollLeft;
    kfTrack.style.width = kfZ > 1 ? w + 'px' : ''; kfTrackDraw();
    kfSc.scrollLeft = Math.max(0, 24 + anchorT / D * (w - 30) - px0);
  }
}
addEventListener('keydown', e => {
  const a = document.activeElement;
  if (e.ctrlKey || e.metaKey || e.altKey || (a && (a.tagName === 'TEXTAREA' || a.tagName === 'SELECT' || (a.tagName === 'INPUT' && a.type !== 'range') || a.isContentEditable)) || document.querySelector('.mask')) return;
  const up = e.key === '+' || e.key === '=' || e.code === 'NumpadAdd', dn = e.key === '-' || e.key === '_' || e.code === 'NumpadSubtract';
  if (!up && !dn) return;
  let k = zHover || zLast; if (k === 'kf' && ($('#kft').hidden || kfMap().al)) k = 'tl';   // 关键帧和时间线对齐时，放大缩小就是放大缩小时间线（同一把尺子）
  if (k === 'tl' && !TL.clips.length && !REF) return;
  const f = up ? 1.5 : 1 / 1.5;
  if (k === 'tl') { tlZ = Math.min(400, Math.max(1, tlZ * f)); if (tlZ < 1.01) tlZ = 1; zApply('tl', tlT); toast('素材时间线 ' + (tlZ > 1 ? '放大 ' + tlZ.toFixed(1) + ' 倍' : '已还原') + '（+ 放大，− 缩小）', false, 1200); }
  else { kfZ = Math.min(100, Math.max(1, kfZ * f)); if (kfZ < 1.01) kfZ = 1; zApply('kf', kfNow()); toast('关键帧 ' + (kfZ > 1 ? '放大 ' + kfZ.toFixed(1) + ' 倍' : '已还原') + '（+ 放大，− 缩小）', false, 1200); }
  e.preventDefault(); e.stopPropagation();
}, true);
// Ctrl + 滚轮 = 放大 / 缩小时间线（v33.x，和 Premiere 一样），以鼠标所在的那一秒为中心；
// 网页本身的缩放（Ctrl + 滚轮、Ctrl + + / − / 0）锁死，布局不会被放大缩小。
let zWheel = null;
addEventListener('wheel', e => {
  if (!e.ctrlKey && !e.metaKey) return;
  e.preventDefault();                                            // 不让浏览器缩放整个网页
  let k = zHover || (e.target.closest && e.target.closest('#box') ? null : zLast);   // 鼠标在预览画面上：交给预览自己（缩放素材）
  if (k === 'kf' && ($('#kft').hidden || kfMap().al)) k = 'tl';
  if (!k || (k === 'tl' && !TL.clips.length && !REF)) return;
  const f = Math.exp(-Math.max(-300, Math.min(300, e.deltaY)) * 0.002);   // 一格滚轮约 1.2 倍，触控板捏合也顺
  if (zWheel) { zWheel.f *= f; return; }                         // 一帧里来好几个滚轮事件：合并成一次重画
  zWheel = { f, k, x: e.clientX };
  requestAnimationFrame(() => {
    const w = zWheel; zWheel = null;
    if (w.k === 'tl') {
      const NW = tlNW(), r = tlSc.getBoundingClientRect(), tw = tlSc.classList.contains('zm') ? parseFloat(tlSc.style.getPropertyValue('--tw')) : Math.max(100, tlSc.clientWidth - NW);
      const t = Math.max(0, Math.min(tlV, (w.x - r.left + tlSc.scrollLeft - NW) / tw * tlV));
      tlZ = Math.min(400, Math.max(1, tlZ * w.f)); if (tlZ < 1.01) tlZ = 1; zApply('tl', t);
    } else { kfZ = Math.min(100, Math.max(1, kfZ * w.f)); if (kfZ < 1.01) kfZ = 1; zApply('kf', kfNow()); }
  });
}, { passive: false, capture: true });
addEventListener('keydown', e => {                               // Ctrl + + / − / 0 也不让缩放网页
  if ((e.ctrlKey || e.metaKey) && ['+', '=', '-', '_', '0'].includes(e.key)) e.preventDefault();
}, true);
addEventListener('resize', () => { if (tlZ > 1) zApply('tl', tlT); if (kfZ > 1) zApply('kf', kfNow()); });
// 放大后播放：播放头跑出可见范围就自动翻页跟上
// v33.x 两种跟随（时间线标题栏的「跟随」按钮切换，记在 fxnav:tlFollow）：
//   翻页 = 播放头走到右边快出去时，整条时间线挪一下，把播放头放回中间；
//   居中 = 播放头一直停在中间，素材往左走。
let tlFollow = store.get('tlFollow', 'page');
Hooks.on('headPos', () => {
  if (!(tlPlaying || playing) || tlSc.scrollWidth <= tlSc.clientWidth + 1) return;
  const NW = tlNW(), tw = parseFloat(tlSc.style.getPropertyValue('--tw')) || (tlSc.scrollWidth - NW), x = NW + tlT / tlV * tw, v = tlSc.scrollLeft;
  const mid = x - NW - (tlSc.clientWidth - NW) / 2;              // 让播放头落在可见区中间的 scrollLeft
  if (tlFollow === 'center') {
    // 居中不抖：滚动条只能停在整数像素上，播放头却是小数位置 → 每帧差零点几像素，看着在左右抖。
    // 播放头和滚动位置都取整、两者差一个固定的整数，屏幕上的播放头就纹丝不动。
    const xi = Math.round(x - NW), k = Math.round((tlSc.clientWidth - NW) / 2);
    if (xi < k) return;                                          // 还没走到中间：照常往右走
    tlSc.scrollLeft = xi - k;
    if (tlSc.scrollLeft === xi - k) document.querySelectorAll('#tlp-t .tlhd, #tlp-rt .rvhd').forEach(h => { h.style.left = xi + 'px'; });   // 原视频那一行的播放头也一样
  }
  else if (x < v + NW || x > v + tlSc.clientWidth - 40) tlSc.scrollLeft = Math.max(0, mid);
});
{
  const b = document.createElement('button'); b.type = 'button'; b.id = 'tl-follow';
  const lab = () => { b.textContent = tlFollow === 'center' ? '跟随：居中' : '跟随：翻页'; b.title = '播放时时间线怎么跟着播放头走（点一下切换）\n翻页：播放头走到右边时，整条时间线挪一下，把播放头放回中间\n居中：播放头一直在中间，素材往左走'; };
  b.onclick = () => { tlFollow = tlFollow === 'center' ? 'page' : 'center'; store.set('tlFollow', tlFollow); lab(); toast(b.textContent); };
  b.style.cssText = 'font-size:11px;padding:2px 8px;margin-left:auto;margin-right:4px';
  const rt = $('#rv-tools'); if (rt) { rt.style.marginLeft = '0'; rt.before(b); } else $('#tlp-k').before(b);   // 放在「设为参照」那一排左边
  lab();
}

// ---------- Ctrl+C / Ctrl+V 复制粘贴素材（v20.0）：复制选中的素材 / 多选 / 组合的全部属性，粘贴到播放头那一秒、最上面一层 ----------
// 粘贴出来的是独立的一份（新 id，参数深拷贝），改它不影响原来那个。鼠标在关键帧上（或最后点的是关键帧）时，Ctrl+C / V 仍然是复制关键帧。
let tlClipb = null;
addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey) return;
  const k = e.key.toLowerCase(); if (k !== 'c' && k !== 'v') return;
  const a = document.activeElement;
  if (a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && a.type !== 'range') || a.isContentEditable)) return;
  if (String(getSelection ? getSelection() : '').trim() || document.querySelector('.mask,.xpm')) return;
  if ((zHover || zLast) !== 'tl') return;
  if (k === 'c') {
    syncSel();
    const g = grp(tlGrp), cs = g ? TL.clips.filter(c => c.group === g.id) : (tlMulti.size > 1 ? [...tlMulti] : [tlSel]).map(clip).filter(Boolean);
    if (!cs.length) return;
    tlClipb = { clips: clone(cs), groups: g ? [clone(g)] : [] };
    toast('已复制' + (g ? '组合「' + g.name + '」' : cs.length > 1 ? ' ' + cs.length + ' 个素材' : '「' + ((fxOf(cs[0]) || {}).name || cs[0].fx) + '」') + '，把播放头拖到要放的地方，按 Ctrl+V 粘贴');
  } else {
    if (!tlClipb) return;
    const src = tlClipb.clips, t0 = Math.min(...src.map(c => c.start)), lo = Math.min(...src.map(c => c.layer));
    const top = TL.clips.length ? Math.max(...TL.clips.map(o => o.layer)) + 1 : 0, gm = {};
    tlClipb.groups.forEach(g => { const ng = Object.assign(clone(g), { id: nid('g'), name: g.name + ' 副本' }); gm[g.id] = ng.id; TL.groups.push(ng); });
    // v35.x：先试着贴回原来那几层（和复制的素材同一轨道）；那段时间那一层已经有素材挡着，才整体放到最上面的新层
    const busy = (L, s, len) => TL.clips.some(o => !o.ref && o.layer === L && o.start < s + len - 0.001 && s < o.start + o.len - 0.001);
    const same = !tlClipb.groups.length && src.every(c => !busy(c.layer, r2(tlT + c.start - t0), c.len));
    const made = src.map(c => { const n = Object.assign(clone(c), { id: nid('c'), start: r2(tlT + c.start - t0), layer: same ? c.layer : top + c.layer - lo }); if (n.group && gm[n.group]) n.group = gm[n.group]; else delete n.group; delete n.ref; TL.clips.push(n); return n; });
    normLayers(); made.forEach(n => ghost(n));
    if (tlClipb.groups.length) selGroup(gm[tlClipb.groups[0].id]);
    else { tlSelect(made[0].id); if (made.length > 1) { tlMulti = new Set(made.map(n => n.id)); tlDraw(); } }
    tlRender(); tlSave(); toast('已粘贴到 ' + tlT.toFixed(2) + ' 秒' + (same ? '，和原来同一层' : '，那里被挡住了，放到了新的一层') + '（独立的一份，改它不影响原来的）');
  }
  e.preventDefault(); e.stopImmediatePropagation();
}, true);


// Ctrl+A 全选时间线上的素材（v21.0）：全选后可以一起拖时间、一起拖右边缘改时长、Delete、Ctrl+C
addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey || e.key.toLowerCase() !== 'a') return;
  const a = document.activeElement;
  if (a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && a.type !== 'range') || a.isContentEditable)) return;
  if (document.querySelector('.mask,.xpm') || (zHover || zLast) !== 'tl') return;
  const ids = TL.clips.filter(c => !c.ref && !c.lock).map(c => c.id); if (!ids.length) return;   // 锁定的不选
  e.preventDefault(); e.stopImmediatePropagation();
  if (!ids.includes(tlSel)) { tlKeepT = true; tlSelect(ids[0], true); tlKeepT = false; }
  if (tlGrp) { tlGrp = null; gpBuild(); }
  tlMulti = new Set(ids); tlDraw(); kfTrackDraw();
  toast('已全选 ' + ids.length + ' 个素材：拖任意一个 = 一起挪时间，拖右边缘 = 一起改时长');
}, true);

// ---------- 时间线模式的撤销 / 重做（v22.0）：任何操作都能撤 —— 删素材、粘贴、拖动、改时长、改参数、原视频裁剪…… ----------
// 做法和参数撤销一样：每次操作结束后给「整条时间线（含每个素材的参数）+ 原视频设置」拍一张快照，和上一张不同就记一步。
// 时间线上有素材（或有原视频）时，Ctrl+Z / Ctrl+Shift+Z 走这里；没有时照旧走单个效果的参数撤销。
let tU = [], tR = [], tLast = null, tQuiet = 0;
const tSnap = () => JSON.stringify({ clips: TL.clips.map(c => { const o = Object.assign({}, c); delete o._len; return o; }), groups: TL.groups, ref: REF });
function tlHistCheck() {
  if (!TL.clips.length && !REF && !tU.length && tLast == null) return;   // 一直是空的：不记。v24.7：以前这里会把「删光之前」的底子清掉，一次删光所有素材后 Ctrl+Z 退不回来
  if (histBusy() || tlDragS || tlLoading || rvDrag || sgDrag) { setTimeout(tlHistCheck, 300); return; }
  syncSel(); const s = tSnap();
  if (tLast == null || Date.now() < tQuiet) { tLast = s; return; }          // 刚撤销完、素材正在重新加载：只更新底子，不算新的一步
  if (s === tLast) return;
  tU.push(tLast); if (tU.length > 100) tU.shift(); tR = []; tLast = s;
}
Hooks.on('histCheck', () => tlHistCheck());
function tlHistGo(dir) {
  clearTimeout(hT); tlHistCheck();
  const from = dir < 0 ? tU : tR, to = dir < 0 ? tR : tU;
  if (!from.length) return toast(dir < 0 ? '没有可以撤销的操作了' : '没有可以重做的操作了');
  const s = from.pop(); to.push(tLast); tLast = s; tQuiet = Date.now() + 1500;
  const o = JSON.parse(s), keep = tlSel;
  tlStop(); stop(); tlSel = null; Object.keys(G).forEach(dropGhost);
  TL.clips = o.clips || []; TL.groups = o.groups || []; REF = o.ref || null; rvSave();
  tlMulti = new Set(); tlGrp = null; tlIn = null; gpBuild();
  if (keep && clip(keep)) { tlKeepT = true; tlSelect(keep); tlKeepT = false; } else tlPreview = !TL.clips.length;
  tlRender(); tlDraw(); tlSave(); rvSync(); fit(); kfTrackDraw();
  toast((dir < 0 ? '↶ 已撤销上一步' : '↷ 已重做') + '　（Ctrl+Z 撤销 · Ctrl+Shift+Z 重做）');
}
addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
  const k = e.key.toLowerCase(), undo = k === 'z' && !e.shiftKey, redo = (k === 'z' && e.shiftKey) || k === 'y';
  if (!undo && !redo) return;
  const a = document.activeElement;
  if (a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && /^(text|search|url|email)$/i.test(a.type)) || a.isContentEditable)) return;
  if (document.querySelector('.mask,.xpm')) return;
  if (!TL.clips.length && !REF && !tU.length && !tR.length) return;      // 单个效果模式：交给原来的参数撤销
  e.preventDefault(); e.stopImmediatePropagation();
  if (a && a.tagName === 'INPUT') a.blur();
  tlHistGo(undo ? -1 : 1);
}, true);

// ---------- Delete 只删「最后点过的那一块」里选中的东西（v22.0） ----------
// 最后点的是右侧面板：删面板里选中的关键帧（去色 / 高亮轨道上的菱形），绝不删时间线上的素材；
// 最后点的是时间线：删素材（原来的逻辑）。
let zone = 'other', pk = null;   // pk = 右侧面板里选中的菱形 { tr: 所在轨道, i: 第几个 }
const pkMark = () => { document.querySelectorAll('.stc-pt.fx-selk').forEach(x => x.classList.remove('fx-selk')); const el = pk && pk.tr.isConnected && pk.tr.querySelector('.stc-pt[data-i="' + pk.i + '"]'); if (el) el.classList.add('fx-selk'); else pk = null; };
addEventListener('pointerdown', e => {
  const t = e.target; zone = t.closest('aside.r') ? 'panel' : t.closest('#tlp') ? 'tl' : t.closest('#kft') ? 'kf' : 'other';
  const pt = t.closest && t.closest('.stc-pt');
  pk = pt && e.button === 0 && pt.closest('.stc-tr') ? { tr: pt.closest('.stc-tr'), i: pt.dataset.i } : null;
  setTimeout(pkMark, 60);
}, true);
addEventListener('pointerup', () => setTimeout(pkMark, 80), true);
addEventListener('keydown', e => {
  if (e.key !== 'Delete' && e.key !== 'Backspace') return;
  const a = document.activeElement;
  if (a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && a.type !== 'range' && a.type !== 'checkbox') || a.isContentEditable)) return;
  if (zone !== 'panel') return;
  e.preventDefault(); e.stopImmediatePropagation();
  const el = pk && pk.tr.isConnected && pk.tr.querySelector('.stc-pt[data-i="' + pk.i + '"]');
  if (el) { el.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true })); pk = null; histSoon(); }
  else toast('先点一下要删的关键帧（菱形），再按 Delete');
}, true);

// ---------- 快捷键说明（v22.0）：鼠标放上去显示，点一下弹出完整说明 ----------
$('#tlp-k').addEventListener('click', () => {
  const sec = (t, rows) => '<div class="kbs"><b>' + t + '</b>' + rows.map(([k, v]) => '<div class="kbr"><kbd>' + k + '</kbd><span>' + v + '</span></div>').join('') + '</div>';
  const m = document.createElement('div'); m.className = 'xpm';
  m.innerHTML = '<div class="kbd-d"><div class="xph"><b>快捷键</b><span>鼠标在哪一块上，快捷键就作用在哪一块</span><button type="button" class="xpx">✕</button></div><div class="kbg">' +
    sec('通用', [['Ctrl+Z', '撤销上一步（删除、粘贴、拖动、改参数……都能撤）'], ['Ctrl+Shift+Z / Ctrl+Y', '重做'], ['空格', '播放 / 暂停'], ['Esc', '取消选择 / 关弹窗']]) +
    sec('素材时间线', [['点空白处', '跳到那一秒 + 取消选择'], ['Ctrl+A', '全选素材'], ['Ctrl / Shift + 点击', '加选 / 减选'], ['空白处拖框', '框选'], ['拖素材', '换时间 / 换层（多选时一起动，靠近播放头会吸上去）'], ['拖素材右边缘', '改时长（多选时一起改）'], ['Ctrl+C / Ctrl+V', '复制 / 粘贴到播放头（独立的一份）'], ['Ctrl+D', '原地复制一份'], ['Delete', '删除选中的素材'], ['Ctrl+G', '合成组合'], ['Ctrl+Shift+G', '解散组合'], ['Ctrl+] / Ctrl+[', '上移 / 下移一层'], ['← →', '选中的素材前后挪 0.1 秒（Shift：1 秒）'], ['Home / End', '跳到开头 / 结尾'], ['+ / −', '放大 / 缩小时间线']]) +
    sec('关键帧', [['双击空白处', '在那一秒打点'], ['点选 / 拖框', '选中关键帧'], ['拖菱形', '改时间'], ['Delete', '删除选中的关键帧'], ['Ctrl+C / Ctrl+V', '复制 / 粘贴关键帧'], ['← →', '微调选中的关键帧'], ['+ / −', '放大 / 缩小关键帧轨道']]) +
    sec('右侧面板（去色 · 高亮）', [['点菱形 → Delete', '删除这个点'], ['右键菱形', '删除这个点'], ['双击菱形', '切换状态'], ['拖菱形', '改时间']]) +
    sec('预览区', [['左键拖', '移动位置'], ['滚轮', '缩放'], ['右键拖', '转 X / Y 轴（Shift：转 Z 轴）'], ['双击', '还原大小 / 位置'], ['Alt + 点击', '选下面一层的素材']]) +
    '</div></div>';
  document.body.appendChild(m);
  const close = () => { m.remove(); removeEventListener('keydown', esc, true); };
  const esc = e => { if (e.key === 'Escape') { e.stopImmediatePropagation(); close(); } };
  addEventListener('keydown', esc, true);
  m.querySelector('.xpx').onclick = close; m.addEventListener('mousedown', e => { if (e.target === m) close(); });
});

// ---------- 多选时一起改（v23.0）：选中多个素材后，在右侧面板改的参数、打 / 删的关键帧，所有选中的素材都做同样的事 ----------
// 规则：右侧面板显示的是「主素材」（最后点的那个）。每次操作结束，比较主素材的参数和上一次的差别，把变了的那几项同步给其他选中的素材：
//  · 样式类（下拉、数字、颜色、去色 · 高亮关键帧……）→ 直接用同样的值；关键帧时间按各自的开始时间换算，保证在时间线同一刻
//  · 位置 / 大小 / 角度关键帧（keys）→ 主素材在某一秒打了点，其他素材也在同一刻打点；删点同理
//    v24.3：在预览里拖动 / 缩放 / 旋转主素材时，其他选中的素材「一起动」：挪同样多、按同样比例缩放、转同样角度（各自的相对位置不变）
//  · 没开关键帧时直接改位置 / 大小 / 角度：同样按「挪了多少」同步给其他素材
//  · 文字、图片、卡片内容 → 不同步（每个素材各是各的）
let bcSel = null, bcBase = null;
const BC_SKIP = new Set(['keys', 'scale', 'offsetX', 'offsetY', 'rotX', 'rotY', 'rotZ', 'persp', '__dur', 'cards', 'images', 'media']);
const BC_MOVE = { offsetX: 'add', offsetY: 'add', rotX: 'add', rotY: 'add', rotZ: 'add', scale: 'mul' };   // 没开关键帧时：按变化量同步
const bcNum = (v, d) => { const n = +v; return isFinite(n) ? n : d; };
const bcOthers = () => tlMulti.size > 1 && !tlGrp ? [...tlMulti].filter(id => id !== tlSel).map(clip).filter(c => c && !c.ref) : [];
const bcDef = (c, k) => ((fxOf(c) || {}).params || []).find(p => p.key === k);
const bcShift = (v, off) => {                          // 关键帧时间 → 换算成对方素材自己的时间
  if (!off) return clone(v);
  const walk = o => { if (Array.isArray(o)) return o.map(walk); if (o && typeof o === 'object') { const r = {}; for (const k in o) r[k] = k === 't' && typeof o[k] === 'number' ? Math.max(0, r2(o[k] + off)) : walk(o[k]); return r; } return o; };
  if (typeof v === 'string') { try { return JSON.stringify(walk(JSON.parse(v))); } catch (e) { return v; } }
  return walk(v);
};
const bcCanSync = (c, k) => {
  if (BC_SKIP.has(k)) return false;
  if (k === '__color' || k === '__op' || k === '__opk') return true;    // __op = 不透明度、__opk = 不透明度关键帧（v39.0 / v40.0，所有素材都有）
  const d = bcDef(c, k); if (!d || d.hidden) return false;
  if (d.type === 'text') return /color|^c[A-Z]/.test(k);              // 文字类参数里只同步颜色相关（颜色关键帧、自定义色）
  return d.type === 'select' || d.type === 'number' || d.type === 'color' || d.type === 'checkbox';
};
const bcWin = c => { try { const w = G[c.id].contentWindow.document.getElementById('fx').contentWindow; return w && w.FXKeys ? w : null; } catch (e) { return null; } };   // 叠加层里那个效果自己的窗口（有关键帧引擎 FXKeys）
const bcList = v => { try { const o = typeof v === 'string' ? JSON.parse(v) : v; return (o && Array.isArray(o.list) ? o.list : []).map(p => p.t.toFixed(2) + '|' + (p.k || 'r')); } catch (e) { return []; } };
function bcCheck() {
  if (tlSel !== bcSel) { if (tlLoading) return; bcSel = tlSel; bcBase = tlSel ? JSON.stringify(params) : null; return; }   // 刚换主素材：等它加载完再记底子，免得把换素材当成改参数
  if (!tlSel || tlLoading || histBusy()) return;
  const now = JSON.stringify(params); if (now === bcBase) return;
  const old = JSON.parse(bcBase || '{}'); bcBase = now;
  const others = bcOthers(), me = clip(tlSel); if (!others.length || !me) return;
  const keys = Object.keys(params).filter(k => JSON.stringify(params[k]) !== JSON.stringify(old[k]));
  let n = 0;
  others.forEach(c => {
    const off = r2(me.start - c.start); let hit = false;
    keys.forEach(k => {
      if (k === 'keys' && window.__fxPlace) return;          // 摆位置模式：主素材的关键帧是整体平移的，下面按原始值的变化量一起挪，这里不另打点
      if (k === 'keys' && bcDef(c, 'keys')) {                // 位置 / 大小 / 角度关键帧：同一刻打点，记它自己当前的画面
        const a = bcList(old.keys), b = bcList(params.keys), W = bcWin(c); if (!W) return;
        const MW = (() => { try { return frame.contentWindow.FXKeys ? frame.contentWindow : null; } catch (e) { return null; } })();
        const mainList = (() => { try { return JSON.parse(params.keys).list || []; } catch (e) { return []; } })();
        const recs = v => { const m = {}; try { (JSON.parse(v).list || []).forEach(q => m[q.t.toFixed(2) + '|' + (q.k || 'r')] = JSON.stringify(q)); } catch (e) { } return m; };
        const ra = recs(old.keys), rb = recs(params.keys);
        const add = b.filter(x => !a.includes(x) || ra[x] !== rb[x]), del = a.filter(x => !b.includes(x));   // 改了已有关键帧的值也算（v24.3）
        if (!add.length && !del.length) return;
        const FK = W.FXKeys, o = clone(FK.read(c.params)), id = q => q.t.toFixed(2) + '|' + (q.k || 'r');
        const mv = x => { const [t, l] = x.split('|'); return [Math.max(0, r2(+t + off)), l]; };
        const gone = new Set(del.map(x => { const [t, l] = mv(x); return t.toFixed(2) + '|' + l; }));
        o.list = (o.list || []).filter(q => !gone.has(id(q)));
        add.forEach(x => {                                   // 用它自己在这一刻的画面（关键帧曲线上的值）打点
          const [t, l] = mv(x), R = FK.at(c.params, t, +W.getDuration() || 0);
          // 主素材这一刻「打点之前」和「打点之后」差了多少 → 其他素材在自己的画面上加同样的变化（一起动）
          let d = null;
          const [tm] = x.split('|'), nr = mainList.find(q => q.t.toFixed(2) === tm && (q.k || 'r') === l);
          if (MW && nr) { try { const R0 = MW.FXKeys.at(old, +tm, dur || 0); d = l === 'p' ? { ox: nr.ox - R0.ox, oy: nr.oy - R0.oy } : l === 's' ? { s: R0.s ? nr.s / R0.s : 1 } : { x: nr.x - R0.x, y: nr.y - R0.y, z: nr.z - R0.z }; } catch (e) { d = null; } }
          const n0 = (v, k) => bcNum(v, 0) + (d ? bcNum(d[k], 0) : 0);
          const rec = l === 'p' ? { t, k: 'p', ox: Math.round(n0(R.ox, 'ox')), oy: Math.round(n0(R.oy, 'oy')) } : l === 's' ? { t, k: 's', s: r2(bcNum(R.s, 1) * (d ? bcNum(d.s, 1) : 1)) } : { t, k: 'r', x: n0(R.x, 'x'), y: n0(R.y, 'y'), z: n0(R.z, 'z') };
          o.list = o.list.filter(q => id(q) !== id(rec)); o.list.push(FK.norm ? FK.norm(rec) : rec);
        });
        o.list.sort((p1, p2) => p1.t - p2.t || 'prs'.indexOf(p1.k) - 'prs'.indexOf(p2.k));
        o.on = true; c.params.keys = JSON.stringify(o); hit = true; return;
      }
      if (BC_MOVE[k] && bcDef(c, k)) {                     // 没开关键帧时直接改了位置 / 大小 / 角度：按变化量同步
        const was = bcNum(old[k], BC_MOVE[k] === 'mul' ? 1 : 0), now2 = bcNum(params[k], was), mine = bcNum(c.params[k], BC_MOVE[k] === 'mul' ? 1 : 0);
        // 位置：按「画面上挪的距离一样」换算（各自的大小不同，参数里要挪的量也不同）
        const rr = BC_MOVE[k] === 'add' && /^offset/.test(k) && typeof visScale === 'function' ? visScale() / visScale(c) : 1;
        const v = BC_MOVE[k] === 'mul' ? (was ? mine * now2 / was : now2) : mine + (now2 - was) * rr;
        c.params[k] = k === 'scale' ? r2(v) : Math.round(v * 100) / 100; hit = true;
        if (window.__fxPlace && c.params.keys) {           // 摆位置模式：它自己这条轨道上的关键帧也一起挪（整段动画平移）
          const F = { offsetX: ['p', 'ox'], offsetY: ['p', 'oy'], scale: ['s', 's'], rotX: ['r', 'x'], rotY: ['r', 'y'], rotZ: ['r', 'z'] }[k];
          try { const o = JSON.parse(c.params.keys); (o.list || []).forEach(q => { if (q.k !== F[0] || q[F[1]] == null) return;
            q[F[1]] = BC_MOVE[k] === 'mul' ? (was ? r2(q[F[1]] * now2 / was) : q[F[1]]) : Math.round((q[F[1]] + (now2 - was) * rr) * 100) / 100; });
            c.params.keys = JSON.stringify(o); } catch (e) { }
        }
        return;
      }
      if (!bcCanSync(c, k)) return;
      c.params[k] = bcShift(params[k], k === '__color' || k === '__opk' || /Keys$/.test(k) ? off : 0); hit = true;
    });
    if (hit) { n++; ghostInit(c); }
    if (typeof liveClear === 'function') liveClear(c.id);   // 参数已同步：撤掉拖动时的临时跟随（18-place-snap.js）
  });
  if (n) $('#hint').textContent = '已同步给另外 ' + n + ' 个选中的素材';
}
Hooks.on('histCheck:before', () => bcCheck());
// 右侧面板顶上提示「正在同时改几个素材」
const bcBar = document.createElement('div'); bcBar.id = 'bcbar'; $('#params').before(bcBar);
setInterval(() => {
  const n = bcOthers().length; bcBar.style.display = n ? '' : 'none';
  if (n) bcBar.textContent = '正在同时改 ' + (n + 1) + ' 个素材：样式、颜色、关键帧会一起改，在预览里拖动 / 缩放 / 旋转会一起动；文字、图片各改各的';
}, 600);

// ---------- 入点 / 出点（v35.x，和剪辑软件一样）：I = 入点、O = 出点，都打在播放头那一秒 ----------
// 打上以后导出只出 [入点, 出点] 之间的那一段（分段照常切，只是两头被裁到入出点）；范围外的时间线变暗。
// 两头各有一个「✕」= 取消出入点。只记一个时：另一头当成时间线开头 / 结尾。存在 fxnav:tlIO。
let tlIO = store.get('tlIO', null);
const ioRange = () => { if (!tlIO || (tlIO.i == null && tlIO.o == null)) return null; const a = tlIO.i == null ? 0 : tlIO.i, b = tlIO.o == null ? Math.max(tlEnd(), a + 0.1) : tlIO.o; return b - a >= 0.05 ? [a, b] : null; };
function ioSet(k) {
  tlIO = Object.assign({ i: null, o: null }, tlIO || {}); tlIO[k] = r2(tlT);
  if (tlIO.i != null && tlIO.o != null && tlIO.o < tlIO.i) tlIO[k === 'i' ? 'o' : 'i'] = null;   // 入点打到出点后面（或反过来）：另一头作废
  store.set('tlIO', tlIO); ioDraw(); toast((k === 'i' ? '入点' : '出点') + '：' + tlT.toFixed(2) + ' 秒　·　导出只出入点到出点这一段');
}
function ioClear() { tlIO = null; store.set('tlIO', null); ioDraw(); toast('已取消出入点'); }
function ioDraw() {
  trk.querySelectorAll('.tlio').forEach(e => e.remove());
  const R = ioRange(); if (!R || !(TL.clips.length || REF)) return;
  const pc = t => Math.max(0, Math.min(100, t / tlV * 100)) + '%';
  const dim = (l, r) => { const d = document.createElement('div'); d.className = 'tlio'; d.style.cssText = `position:absolute;top:0;bottom:0;left:${l};right:${r};background:rgba(0,0,0,.55);z-index:4;pointer-events:none`; trk.appendChild(d); };
  dim('0', `calc(100% - ${pc(R[0])})`); dim(pc(R[1]), '0');
  [[R[0], 'I', '入点'], [R[1], 'O', '出点']].forEach(([t, k, n]) => {
    const m = document.createElement('div'); m.className = 'tlio';
    m.style.cssText = `position:absolute;top:0;bottom:0;left:${pc(t)};width:0;border-left:2px solid #4cc2ff;z-index:6;pointer-events:none`;
    m.innerHTML = `<span style="position:absolute;top:2px;${k === 'I' ? 'left:3px' : 'right:3px'};display:flex;gap:3px;align-items:center;pointer-events:auto">`
      + `<b style="background:#4cc2ff;color:#111;font:700 11px/16px sans-serif;padding:0 4px;border-radius:3px" title="${n} ${t.toFixed(2)} 秒">${k}</b>`
      + `<i title="取消出入点" style="cursor:pointer;font-style:normal;background:#333;color:#ddd;font:12px/16px sans-serif;padding:0 4px;border-radius:3px">✕</i></span>`;
    m.querySelector('i').onclick = e => { e.stopPropagation(); ioClear(); };
    m.querySelector('span').addEventListener('mousedown', e => e.stopPropagation());
    trk.appendChild(m);
  });
}
Hooks.on('tlDraw', ioDraw);
addEventListener('keydown', e => {
  if (e.ctrlKey || e.metaKey || e.altKey || e.repeat) return;
  const t = e.target; if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
  if (!(TL.clips.length || REF)) return;
  const k = e.key.toLowerCase(); if (k === 'i' || k === 'o') { e.preventDefault(); ioSet(k); }
});
ioDraw();

// ---------- 磁吸开关（v35.x）：标题栏一个不起眼的小磁铁，点一下开 / 关；开着时拖动、拉长素材会吸到播放头和别的素材边 ----------
{
  const b = document.createElement('button'); b.type = 'button'; b.id = 'tl-mag';
  const lab = () => { b.textContent = '🧲'; b.style.opacity = tlMag ? '1' : '.35'; b.title = '磁吸：' + (tlMag ? '开' : '关') + '（点一下切换）\n开着时拖动 / 拉长素材会吸到播放头、别的素材头尾'; };
  b.style.cssText = 'font-size:12px;padding:1px 5px;margin-right:4px;background:transparent;border:1px solid #444;border-radius:4px;cursor:pointer';
  b.onclick = () => { tlMag = !tlMag; store.set('tlMag', tlMag); lab(); toast('磁吸' + (tlMag ? '已打开' : '已关闭')); };
  lab(); const f = $('#tl-follow'); if (f) f.before(b); else $('#tlp-k').before(b);
}

// ---------- Alt + 滚轮 = 时间线左右滚动（v35.x）：鼠标在素材时间线上，按住 Alt 滚滚轮，往下滚 = 往右（往后），往上滚 = 往左 ----------
addEventListener('wheel', e => {
  if (!e.altKey || e.ctrlKey || e.metaKey) return;
  if (!(e.target.closest && e.target.closest('#tlp'))) return;
  e.preventDefault();
  if (tlSc.scrollWidth <= tlSc.clientWidth + 1) return toast('时间线没放大，已经全部看得到；先按 Ctrl + 滚轮放大');
  const d = Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
  tlSc.scrollLeft += d * (e.deltaMode === 1 ? 30 : 1) * 1.5;
}, { passive: false, capture: true });
