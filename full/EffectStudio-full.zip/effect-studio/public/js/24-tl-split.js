// 效果工坊 · 时间线自己的竖向滚动条 + 时间线和关键帧之间的分割线（v38.0）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// · 素材层多了，只在时间线里面竖着滚（#tlp-sc 限高 + overflow），下面的关键帧不跟着动；
//   原视频那一行贴顶、分段那一行贴底（timeline.css 的 sticky），刻度尺、播放头的小三角、层名上面那一格跟着滚动量往下挪（CSS 变量 --tls）。
// · 时间线有多高：
//   - 默认（自动）：把中间这一栏剩下的高度都给时间线（预览 → 时间线 → 分割线 → 关键帧，正好一屏，不用整栏滚）；
//   - 拖分割线 #split2（时间线和关键帧之间，和预览下面那根一样）= 自己定高度，记在 store('tlH')；双击 = 回到自动。
// · 没素材时分割线藏起来；时间线不够高时不出滚动条（和以前一样）。
const tlSc2 = $('#tlp-sc');
// ---------- 竖着滚：刻度尺跟着挪 ----------
const tlsApply = () => { const b = $('#tlp-b'); if (b) b.style.setProperty('--tls', tlSc2.scrollTop + 'px'); };
tlSc2.addEventListener('scroll', tlsApply, { passive: true });
// ---------- 分割线 ----------
const split2 = document.createElement('div'); split2.id = 'split2'; split2.title = '上下拖动：调整素材时间线的高度（双击 = 自动，占满剩下的空间）';
panel.after(split2);
let tlHMan = store.get('tlH', null);
const mainEl = $('main');
// 中间这一栏里，除了时间线滚动框，其他东西一共占多高（按最后一个看得见的块的下沿算，不受滚动框自己高度影响）
function tlOther() {
  const mr = mainEl.getBoundingClientRect();
  let last = null; for (const el of mainEl.children) if (el.offsetParent !== null && el.getBoundingClientRect().height > 0) last = el;
  if (!last) return 0;
  const bottom = last.getBoundingClientRect().bottom - mr.top + mainEl.scrollTop + (parseFloat(getComputedStyle(last).marginBottom) || 0) + 20;   // 20 = main 的下内边距
  return bottom - tlSc2.offsetHeight;
}
function tlLayout() {
  const has = $('#tlp-b').style.display !== 'none';
  mainEl.classList.toggle('hastl', has);
  split2.hidden = !has;
  if (!has) { tlSc2.style.maxHeight = ''; return; }
  const minH = 90, maxH = Math.max(minH, mainEl.clientHeight - 120);
  const H = tlHMan ? Math.max(minH, Math.min(maxH, tlHMan)) : Math.max(140, Math.min(maxH, mainEl.clientHeight - tlOther()));
  const v = Math.round(H) + 'px';
  if (tlSc2.style.maxHeight !== v) tlSc2.style.maxHeight = v;
  tlsApply();
}
let tlLT = 0; const tlLayoutSoon = () => { if (tlLT) return; tlLT = requestAnimationFrame(() => { tlLT = 0; tlLayout(); }); };
// 层名上面那一格（刻度尺左边）：滚动时盖住滚上去的层名
Hooks.on('tlDraw', () => { const n = $('#tlp-names'); if (n && !n.querySelector('.tlncap')) n.insertAdjacentHTML('afterbegin', '<i class="tlncap"></i>'); tlLayoutSoon(); });
['fit', 'select', 'reinit'].forEach(h => Hooks.on(h, () => tlLayoutSoon()));
addEventListener('resize', tlLayoutSoon);
// 预览、关键帧面板、时间线标题这些变高变矮时（选别的素材、关键帧面板出现 / 消失……）也重算
try { const ro = new ResizeObserver(() => tlLayoutSoon()); [$('#pvpin'), $('#kft'), $('#tlp-h')].forEach(el => el && ro.observe(el)); } catch (e) { }
let sp2 = null;
split2.addEventListener('mousedown', e => { if (e.button) return; sp2 = { y: e.clientY, h: tlSc2.offsetHeight }; split2.classList.add('on'); document.body.style.cursor = 'row-resize'; e.preventDefault(); });
addEventListener('mousemove', e => { if (!sp2) return; tlHMan = Math.round(Math.max(90, sp2.h + e.clientY - sp2.y)); tlLayout(); });
addEventListener('mouseup', () => { if (!sp2) return; sp2 = null; split2.classList.remove('on'); document.body.style.cursor = ''; store.set('tlH', tlHMan); });
split2.addEventListener('dblclick', () => { tlHMan = null; store.set('tlH', null); tlLayout(); toast('素材时间线高度：自动（占满剩下的空间）'); });
tlLayout();
