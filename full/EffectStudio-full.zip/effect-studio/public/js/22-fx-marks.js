// 效果工坊 · 素材条上的时间小旗子（v30.0）
// ---------------------------------------------------------------------------
// 做什么：效果在 effect.json 顶层写了 "marks"，时间线上这个效果的素材条里就画一面白色小旗子，
//         标出「某件事从第几秒开始」（例：圆形闪光换色卡的「闪」= 闪烁开始）。按住小旗子左右拖 = 改这个秒数。
// effect.json 写法：
//   "marks": [{ "key": "flashAt",          // 对应哪个秒数参数（从素材开头算）
//               "label": "闪",             // 旗子上的字（一两个字）
//               "tip": "闪烁开始",          // 鼠标提示
//               "keep": "hold",           // 可选：拖的时候把差值从这个参数里扣回来，素材总长不变
//               "min": 0,                 // 可选：最早能拖到第几秒（from 时 = 参数本身最小多少）
//               "from": ["soloIn"],       // 可选：参数是「从这几个参数加起来那一秒往后多久」（例：出场 = 入场时长 + 停留），旗子画在加起来的位置
//               "hideWhen": { "key": "layout", "in": ["soloP"] } }]   // 可选：某个参数是这些值时不画（notIn = 不是这些值时不画；也可以写成数组，任一条成立就不画）
// 点一下小旗子（不拖）= 右侧跳到管这件事的那一块、闪两下：效果在那一块上写 data-fx-mark="参数key"；
//   效果的 window.__fxMarkFocus(key) 有的话先调它（比如把折叠块打开）。没选中的素材先选中再跳。
// 不改任何老文件的逻辑：只挂在 Hooks.on('tlDraw') 后面补画，鼠标用 window 捕获阶段、只在按中小旗子时拦下（规则 29）。
//
// v32.1 · 效果自己给的「活」旗子（一条线一面、一个节点一面……，数量跟着内容变，effect.json 写不死）：
//   效果页面里挂三个函数（只在「选中的素材」上画，没选中的素材不画）：
//   window.__fxMarks()          → [{ id, t: 第几秒, label, tip, cls: 'n'|'x'|'e'|'f'（颜色）, d: 可选，后面画一段条（例：连线画多久）, lo: true 画在下半行 }]
//   window.__fxMarkSet(id, 秒)  → 改参数（直接改工作台的 params，效果的 P 就是它）并重画；返回「预览停在第几秒」
//   window.__fxMarkFocus(id)    → 右侧对应那一行（点一下旗子时跳过去、闪两下）
(function () {
  // 旗子的字、抓取宽度、持续条都跟着层高（--tlr，23-row-height.js）变大：层拉高就是为了好拖旗子（v33.0）
  const st = document.createElement('style');
  st.textContent = `
#tlp-t .tlc .tlmk{position:absolute;top:0;bottom:0;width:2px;margin-left:-1px;background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.45);cursor:ew-resize;z-index:3}
#tlp-t .tlc .tlmk::before{content:"";position:absolute;left:calc(-1 * clamp(6px, var(--tlr, 30px) / 5, 14px));right:calc(-1 * clamp(6px, var(--tlr, 30px) / 5, 14px));top:0;bottom:0}
#tlp-t .tlc .tlmk span{position:absolute;left:2px;top:1px;font:700 clamp(7px, var(--tlr, 30px) * .28, 15px)/1.15 system-ui,sans-serif;color:#111;background:#fff;border-radius:0 3px 3px 0;padding:0 3px;white-space:nowrap;pointer-events:none}
#tlp-t .tlc .tlmk.drag,#tlp-t .tlc .tlmk:hover{background:#f28c0f}
#tlp-t .tlc .tlmk.drag span,#tlp-t .tlc .tlmk:hover span{background:#f28c0f}
#tlp-t.mkdrag,#tlp-t.mkdrag .tlc{cursor:ew-resize}
#tlp-t .tlc .tlmk.lo span{top:50%}
#tlp-t .tlc .tlmk.n{background:#3ecf8e}#tlp-t .tlc .tlmk.n span{background:#3ecf8e}
#tlp-t .tlc .tlmk.x{background:#ef5b5b}#tlp-t .tlc .tlmk.x span{background:#ef5b5b;color:#fff}
#tlp-t .tlc .tlmk.e{background:#6db3ff}#tlp-t .tlc .tlmk.e span{background:#6db3ff}
#tlp-t .tlc .tlmk.f{background:#c78bff}#tlp-t .tlc .tlmk.f span{background:#c78bff}
#tlp-t .tlc .tlmk em{position:absolute;left:1px;bottom:0;height:clamp(4px, var(--tlr, 30px) / 8, 9px);background:inherit;opacity:.55;pointer-events:none}
#tlp-t .tlc .tlmk.dyn.drag,#tlp-t .tlc .tlmk.dyn:hover{background:#fff;z-index:4}#tlp-t .tlc .tlmk.dyn.drag span,#tlp-t .tlc .tlmk.dyn:hover span{background:#fff;color:#111}`;
  document.head.appendChild(st);

  const marksOf = c => { const f = fxOf(c); return f && Array.isArray(f.marks) ? f.marks : []; };
  const defOf = (c, key) => { const f = fxOf(c), p = f && (f.params || []).find(x => x.key === key); return p ? p.default : undefined; };
  const pv = (c, key) => (c.params && c.params[key] != null ? c.params[key] : defOf(c, key));
  const baseOf = (c, m) => [].concat(m.from || []).reduce((a, k) => a + (Number(pv(c, k)) || 0), 0);
  const valOf = (c, m) => { const v = Number(pv(c, m.key)); return Number.isFinite(v) ? baseOf(c, m) + v : NaN; };   // 旗子在第几秒
  // hideWhen 每一条：{ key, in: [...] } = 是这些值时不画；{ key, notIn: [...] } = 不是这些值时不画
  const hidden = (c, m) => [].concat(m.hideWhen || []).some(h => h && ((Array.isArray(h.in) && h.in.includes(pv(c, h.key))) || (Array.isArray(h.notIn) && !h.notIn.includes(pv(c, h.key)))));
  const lenOf = c => (c._len != null ? c._len : c.len);
  // 选中的素材、效果页面给了 __fxMarks 才有「活」旗子
  const dynW = c => {
    if (!c || c.id !== tlSel || tlLoading) return null;
    try { const w = frame.contentWindow; return w && typeof w.__fxMarks === 'function' && typeof w.__fxMarkSet === 'function' ? w : null; } catch (e) { return null; }
  };

  function draw() {
    trk.querySelectorAll('.tlc[data-id]').forEach(el => {
      const c = clip(el.dataset.id); if (!c) return;
      marksOf(c).forEach((m, i) => {
        if (hidden(c, m)) return;
        const t = valOf(c, m), len = lenOf(c); if (!(t >= 0) || t > len) return;
        const b = document.createElement('b'); b.className = 'tlmk'; b.dataset.i = i;
        b.style.left = (t / len * 100) + '%';
        b.title = (m.tip || m.label || m.key) + '：第 ' + t.toFixed(2) + ' 秒　按住左右拖动改时间';
        b.innerHTML = '<span>' + esc(m.label || '') + '</span>';
        el.appendChild(b);
      });
      const w = dynW(c); if (!w) return;
      let list = []; try { list = w.__fxMarks() || []; } catch (er) { list = []; }
      const len = lenOf(c), px = el.offsetWidth / Math.max(0.01, len);
      list.forEach(m => {
        const t = +m.t; if (!(t >= 0) || t > len) return;
        const b = document.createElement('b'); b.className = 'tlmk dyn ' + (m.cls || '') + (m.lo ? ' lo' : '');
        b.dataset.dyn = m.id; b.dataset.t = t;
        b.style.left = (t / len * 100) + '%';
        b.title = (m.tip || m.label || '') + '：第 ' + t.toFixed(2) + ' 秒　按住左右拖动改时间 · 点一下跳到设置';
        b.innerHTML = '<span>' + esc(m.label || '') + '</span>' + (m.d > 0 ? '<em style="width:' + Math.max(2, Math.min(len - t, m.d) * px).toFixed(1) + 'px"></em>' : '');
        el.appendChild(b);
      });
    });
  }
  Hooks.on('tlDraw', draw);
  draw();

  // ---------- 拖动 ----------
  let D = null;
  addEventListener('mousedown', e => {
    const b = e.button === 0 && e.target.closest && e.target.closest('#tlp-t .tlmk'); if (!b) return;
    const el = b.closest('.tlc'), c = el && clip(el.dataset.id); if (!c || c.lock) return;
    e.preventDefault(); e.stopPropagation();
    if (c.id === tlSel) { try { syncSel(); } catch (er) {} }
    if (b.dataset.dyn != null) {                                             // 效果给的「活」旗子
      const w = dynW(c); if (!w) return;
      const t0 = +b.dataset.t;
      D = { dyn: b.dataset.dyn, w, c, b, t0, x0: e.clientX, w0: el.getBoundingClientRect().width / lenOf(c), v: t0, last: 0, tip: (b.title || '').split('：')[0] };
      b.classList.add('drag'); trk.classList.add('mkdrag');
      return;
    }
    const m = marksOf(c)[+b.dataset.i]; if (!m) return;
    const t0 = valOf(c, m), k0 = m.keep ? Number(pv(c, m.keep)) || 0 : 0;
    D = { c, m, b, t0, k0, base: baseOf(c, m), x0: e.clientX, w: el.getBoundingClientRect().width / lenOf(c), v: t0, last: 0 };
    b.classList.add('drag'); trk.classList.add('mkdrag');
  }, true);
  addEventListener('mousemove', e => {
    if (!D) return;
    if (D.dyn != null) {
      const { c, b, t0 } = D, len = lenOf(c);
      let v = Math.round((t0 + (e.clientX - D.x0) / D.w0) * 20) / 20;
      v = Math.min(len - 0.05, Math.max(0, v)); if (v === D.v) return; D.v = v;
      b.style.left = (v / len * 100) + '%';
      if (typeof toast === 'function') toast(D.tip + '：第 ' + v.toFixed(2) + ' 秒');
      const now = performance.now();
      if (now - D.last > 80) { D.last = now; liveDyn(D, v); }
      return;
    }
    const { c, m, b, t0, k0, base } = D, len = lenOf(c);
    const hi = m.keep ? t0 + k0 : len - 0.05, lo = Math.max(0, base + (Number(m.min) || 0));
    let v = Math.round((t0 + (e.clientX - D.x0) / D.w) * 20) / 20;           // 0.05 秒一格
    v = Math.min(hi, Math.max(lo, v)); if (v === D.v) return; D.v = v;
    c.params = c.params || {}; c.params[m.key] = Math.round((v - base) * 100) / 100;
    if (m.keep) c.params[m.keep] = Math.round((k0 - (v - t0)) * 100) / 100;
    b.style.left = (v / len * 100) + '%';
    b.title = (m.tip || m.label || m.key) + '：第 ' + v.toFixed(2) + ' 秒';
    if (typeof toast === 'function') toast((m.tip || m.label) + '：第 ' + v.toFixed(2) + ' 秒');
    // 选中的素材：边拖边让预览停在这一秒（限流，最多 12 次 / 秒）
    const now = performance.now();
    if (c.id === tlSel && now - D.last > 80) { D.last = now; live(c, m, v); }
  }, true);
  addEventListener('mouseup', () => {
    if (!D) return;
    if (D.dyn != null) { upDyn(); return; }
    const { c, m, b, v, t0 } = D; D = null;
    b.classList.remove('drag'); trk.classList.remove('mkdrag');
    if (v === t0) {                                                           // 没拖动 = 点了一下：右侧跳到对应的参数
      if (c.id === tlSel && !tlLoading) focus(m.key);
      else { tlSelect(c.id); whenReady(() => setTimeout(() => focus(m.key), 200)); }
      return;
    }
    if (c.id === tlSel) {
      params[m.key] = c.params[m.key]; if (m.keep) params[m.keep] = c.params[m.keep];
      // 右侧面板里的数字跟着变：和撤销一样走 buildParams + reinit（效果自己的编辑器会重新挂上），再停到这一秒
      try { buildParams(); reinit(false); } catch (er) {}
      setTimeout(() => { try { seek(Math.max(0, v + 0.05)); } catch (er) {} }, 60);
      try { markDirty(); histSoon(); } catch (er) {}
    } else { try { const g = ghost(c); if (g._ok) ghostInit(c); } catch (er) {} }
    try { tlSave(); tlDraw(); } catch (er) {}
  }, true);
  function focus(key) {
    let el = null;
    try { const w = frame.contentWindow; if (w && w.__fxMarkFocus) el = w.__fxMarkFocus(key); } catch (er) {}
    el = document.querySelector('#params [data-fx-mark="' + key + '"]') || el; if (!el) return;
    el.classList.remove('off');
    const g = el.closest('.fxg'); if (g) g.classList.remove('off');
    fxScrollMid(el);   // 滚到右侧中间（01-base-nav.js）
    el.classList.remove('kf-flash'); void el.offsetWidth; el.classList.add('kf-flash');   // 和关键帧面板同一个「闪两下」（timeline.css）
    clearTimeout(el.__mkft); el.__mkft = setTimeout(() => el.classList.remove('kf-flash'), 1300);
  }
  function liveDyn(d, v) {
    try { const pt = d.w.__fxMarkSet(d.dyn, v); const t = Math.max(0, +pt || v); d.w.renderAt(t); tlT = Math.round((d.c.start + t) * 100) / 100; headPos(); } catch (er) {}
  }
  function upDyn() {
    const { c, b, v, t0, w, dyn } = D; D = null;
    b.classList.remove('drag'); trk.classList.remove('mkdrag');
    if (v === t0) { focus(dyn); return; }                                    // 没拖 = 点了一下：跳到右侧那一行
    let pt = v;
    try { pt = Math.max(0, +w.__fxMarkSet(dyn, v) || v); } catch (er) {}
    // 效果已经把新值写进 params；和撤销一样 buildParams + reinit，总时长、右侧数字一起更新，再停到这一秒
    try { buildParams(); reinit(false); } catch (er) {}
    setTimeout(() => { try { seek(pt); } catch (er) {} }, 60);
    try { markDirty(); histSoon(); } catch (er) {}
    try { tlSave(); tlDraw(); } catch (er) {}
  }
  function live(c, m, v) {
    params[m.key] = c.params[m.key]; if (m.keep) params[m.keep] = c.params[m.keep];
    try {
      const w = frame.contentWindow;
      if (w && w.init) { w.init(params); const t = Math.max(0, v + 0.05); w.renderAt(t); tlT = Math.round((c.start + t) * 100) / 100; headPos(); }
    } catch (er) {}
  }
})();
