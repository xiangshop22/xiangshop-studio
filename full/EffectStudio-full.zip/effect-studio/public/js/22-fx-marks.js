// 效果工坊 · 素材条上的时间小旗子（v30.0）
// ---------------------------------------------------------------------------
// 做什么：效果在 effect.json 顶层写了 "marks"，时间线上这个效果的素材条里就画一面白色小旗子，
//         标出「某件事从第几秒开始」（例：圆形闪光换色卡的「闪」= 闪烁开始）。按住小旗子左右拖 = 改这个秒数。
// effect.json 写法：
//   "marks": [{ "key": "flashAt",          // 对应哪个秒数参数（从素材开头算）
//               "label": "闪",             // 旗子上的字（一两个字）
//               "tip": "闪烁开始",          // 鼠标提示
//               "keep": "hold",           // 可选：拖的时候把差值从这个参数里扣回来，素材总长不变
//               "min": 0,                 // 可选：最早能拖到第几秒（from 时 = 参数本身最小多少）
//               "from": ["soloIn"],       // 可选：参数是「从这几个参数加起来那一秒往后多久」（例：出场 = 入场时长 + 停留），旗子画在加起来的位置
//               "hideWhen": { "key": "layout", "in": ["soloP"] } }]   // 可选：某个参数是这些值时不画（notIn = 不是这些值时不画；也可以写成数组，任一条成立就不画）
// 点一下小旗子（不拖）= 右侧跳到管这件事的那一块、闪两下：效果在那一块上写 data-fx-mark="参数key"；
//   效果的 window.__fxMarkFocus(key) 有的话先调它（比如把折叠块打开）。没选中的素材先选中再跳。
// 不改任何老文件的逻辑：只挂在 Hooks.on('tlDraw') 后面补画，鼠标用 window 捕获阶段、只在按中小旗子时拦下（规则 29）。
//
// v35.9 · 旗子不压在右边「拉长度」手柄上：最多画到离右边 20px，再靠右就往里挪一点（虚线）、字画到线左边（见 place()）。
//
// v32.1 · 效果自己给的「活」旗子（一条线一面、一个节点一面……，数量跟着内容变，effect.json 写不死）：
//   效果页面里挂三个函数（只在「选中的素材」上画，没选中的素材不画）：
//   window.__fxMarks()          → [{ id, t: 第几秒, label, tip, cls: 'n'|'x'|'e'|'f'（颜色）, d: 可选，后面画一段条（例：连线画多久）, lo: true 画在下半行 }]
//   window.__fxMarkSet(id, 秒)  → 改参数（直接改工作台的 params，效果的 P 就是它）并重画；返回「预览停在第几秒」
//   window.__fxMarkFocus(id)    → 右侧对应那一行（点一下旗子时跳过去、闪两下）
(function () {
  // 旗子的字、抓取宽度、持续条都跟着层高（--tlr，23-row-height.js）变大：层拉高就是为了好拖旗子（v33.0）
  const st = document.createElement('style');
  st.textContent = `
#tlp-t .tlc .tlmk{position:absolute;top:0;bottom:0;width:2px;margin-left:-1px;background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.45);cursor:ew-resize;z-index:3}
#tlp-t .tlc .tlmk::before{content:"";position:absolute;left:calc(-1 * clamp(6px, var(--tlr, 30px) / 5, 14px));right:calc(-1 * clamp(6px, var(--tlr, 30px) / 5, 14px));top:0;bottom:0}
#tlp-t .tlc .tlmk span{position:absolute;left:2px;top:1px;font:700 clamp(7px, var(--tlr, 30px) * .28, 15px)/1.15 system-ui,sans-serif;color:#111;background:#fff;border-radius:0 3px 3px 0;padding:0 3px;white-space:nowrap;pointer-events:none}
#tlp-t .tlc .tlmk.drag,#tlp-t .tlc .tlmk:hover{background:#f28c0f}
#tlp-t .tlc .tlmk.drag span,#tlp-t .tlc .tlmk:hover span{background:#f28c0f}
#tlp-t.mkdrag,#tlp-t.mkdrag .tlc{cursor:ew-resize}
#tlp-t .tlc .tlmk.lo span{top:50%}
#tlp-t .tlc .tlmk.n{background:#3ecf8e}#tlp-t .tlc .tlmk.n span{background:#3ecf8e}
#tlp-t .tlc .tlmk.x{background:#ef5b5b}#tlp-t .tlc .tlmk.x span{background:#ef5b5b;color:#fff}
#tlp-t .tlc .tlmk.e{background:#6db3ff}#tlp-t .tlc .tlmk.e span{background:#6db3ff}
#tlp-t .tlc .tlmk.f{background:#c78bff}#tlp-t .tlc .tlmk.f span{background:#c78bff}
#tlp-t .tlc .tlmk em{position:absolute;left:1px;bottom:0;height:clamp(4px, var(--tlr, 30px) / 8, 9px);background:inherit;opacity:.55;pointer-events:none}
#tlp-t .tlc .tlmk.re span{left:auto;right:2px;border-radius:3px 0 0 3px}
#tlp-t .tlc .tlmk.re::before{right:0}
#tlp-t .tlc .tlmk.push{background:repeating-linear-gradient(180deg,#fff 0 3px,transparent 3px 5px);box-shadow:none}
#tlp-t .tlc .tlmk.push.drag,#tlp-t .tlc .tlmk.push:hover{background:repeating-linear-gradient(180deg,#f28c0f 0 3px,transparent 3px 5px)}
#tlp-t .tlc .tlmk.dyn.drag,#tlp-t .tlc .tlmk.dyn:hover{background:#fff;z-index:4}#tlp-t .tlc .tlmk.dyn.drag span,#tlp-t .tlc .tlmk.dyn:hover span{background:#fff;color:#111}`;
  document.head.appendChild(st);

  const marksOf = c => { const f = fxOf(c); return f && Array.isArray(f.marks) ? f.marks : []; };
  const defOf = (c, key) => { const f = fxOf(c), p = f && (f.params || []).find(x => x.key === key); return p ? p.default : undefined; };
  const pv = (c, key) => (c.params && c.params[key] != null ? c.params[key] : defOf(c, key));
  const baseOf = (c, m) => [].concat(m.from || []).reduce((a, k) => a + (Number(pv(c, k)) || 0), 0);
  const valOf = (c, m) => { const v = Number(pv(c, m.key)); return Number.isFinite(v) ? baseOf(c, m) + v : NaN; };   // 旗子在第几秒
  // hideWhen 每一条：{ key, in: [...] } = 是这些值时不画；{ key, notIn: [...] } = 不是这些值时不画
  const hidden = (c, m) => [].concat(m.hideWhen || []).some(h => h && ((Array.isArray(h.in) && h.in.includes(pv(c, h.key))) || (Array.isArray(h.notIn) && !h.notIn.includes(pv(c, h.key)))));
  const lenOf = c => (c._len != null ? c._len : c.len);
  // 选中的素材、效果页面给了 __fxMarks 才有「活」旗子
  const dynW = c => {
    if (!c || c.id !== tlSel || tlLoading) return null;
    try { const w = frame.contentWindow; return w && typeof w.__fxMarks === 'function' && typeof w.__fxMarkSet === 'function' ? w : null; } catch (e) { return null; }
  };

  // v35.9 · 旗子别压在素材条右边的「拉长度」手柄上（.tlr，8px）：
  //   · 旗子最多画到离右边 GAP px 的地方（真实时间更靠右时往里挪一点，线变成虚线，鼠标提示写真实秒数）；
  //   · 靠右的旗子，字画在线的左边、抓取范围只往左伸，不盖住手柄。拖动照样按真实秒数算。
  const GAP = 20;
  function place(b, t, len, el) {
    const p = t / Math.max(0.01, len) * 100;
    b.style.left = 'min(' + p.toFixed(4) + '%, calc(100% - ' + GAP + 'px))';
    const w = el.clientWidth || 0, x = w * p / 100;
    b.classList.toggle('push', w > 0 && x > w - GAP + 0.5);
    b.classList.toggle('re', w > 0 && x > w - GAP - 26);
  }
  const pushNote = b => b.classList.contains('push') ? '（离右边手柄太近，旗子往里挪了一点，方便点）' : '';

  // v35.x 修：素材被改过总时长（右侧「持续时间」，__dur）时，效果里的动作整体按比例快 / 慢了，
  // 参数里的秒数是「原来的时间」，画旗子要乘 s = 现在的时长 / 原来的时长；拖动时再除回去写参数。
  const winOf = c => { try { if (c.id === tlSel) return frame.contentWindow; const g = G[c.id], i = g && g.contentDocument && g.contentDocument.querySelector('iframe'); return i && i.contentWindow; } catch (er) { return null; } };
  const scl = c => { const T = +((c.params || {}).__dur); if (!(T > 0)) return 1; const w = winOf(c); let N = 0; try { N = w && w.__fxNativeDur ? +w.__fxNativeDur() : 0; } catch (er) { } return N > 0 ? T / N : 1; };
  // 所见即所得（v35.x）：素材改过总时长时，改一个时间点会让「原来的总时长」也变，比例跟着变，松手后旗子会跳。
  // 这里反复几次：按新比例重新算要写的值，直到松手后旗子正好落在拖到的那一秒（vd = 画面上的秒数）。
  function solve(c, setN, vd, s0) {
    const T = +((c.params || {}).__dur), w = winOf(c);
    let vn = vd / (s0 || 1); setN(vn);
    if (!(T > 0) || !w || !w.__fxNativeDur) return vn;
    for (let k = 0; k < 8; k++) {
      let N = 0; try { N = +w.__fxNativeDur(); } catch (er) { } if (!(N > 0)) break;
      const nv = Math.round(vd * N / T * 100) / 100; if (Math.abs(nv - vn) < 0.006) break;
      vn = Math.max(0, nv); setN(vn);
    }
    return vn;
  }
  // 拖旗子时靠近播放头（8 像素以内）就吸过去，和素材的磁吸一样（磁吸关掉时不吸）
  const headSnap = (c, vd, pxPerS) => { if (typeof tlMag !== 'undefined' && !tlMag) return vd; const h = tlT - c.start; return Math.abs(h - vd) * pxPerS < 8 ? Math.round(h * 100) / 100 : vd; };
  function draw() {
    trk.querySelectorAll('.tlc[data-id]').forEach(el => {
      const c = clip(el.dataset.id); if (!c) return;
      const s = scl(c);
      marksOf(c).forEach((m, i) => {
        if (hidden(c, m)) return;
        const t = valOf(c, m) * s, len = lenOf(c); if (!(t >= 0) || t > len) return;
        const b = document.createElement('b'); b.className = 'tlmk'; b.dataset.i = i;
        b.innerHTML = '<span>' + esc(m.label || '') + '</span>';
        const dragging = D && D.m === m && D.c === c;
        el.appendChild(b); place(b, dragging ? D.v * (D.s || 1) : t, len, el);
        if (dragging) { b.classList.add('drag'); D.b = b; }
        b.title = (m.tip || m.label || m.key) + '：第 ' + t.toFixed(2) + ' 秒' + pushNote(b) + '　按住左右拖动改时间';
      });
      const w = dynW(c); if (!w) return;
      let list = []; try { list = w.__fxMarks() || []; } catch (er) { list = []; }
      const len = lenOf(c), px = el.offsetWidth / Math.max(0.01, len);
      list.forEach(m => {
        const t = +m.t * s; if (!(t >= 0) || t > len) return;
        const b = document.createElement('b'); b.className = 'tlmk dyn ' + (m.cls || '') + (m.lo ? ' lo' : '');
        b.dataset.dyn = m.id; b.dataset.t = +m.t;
        b.innerHTML = '<span>' + esc(m.label || '') + '</span>' + (m.d > 0 ? '<em style="width:' + Math.max(2, Math.min(len - t, m.d * s) * px).toFixed(1) + 'px"></em>' : '');
        const dragging = D && D.dyn != null && D.c === c && String(D.dyn) === String(m.id);
        el.appendChild(b); place(b, dragging ? D.v * (D.s || 1) : t, len, el);              // 正在拖的这面旗子留在鼠标下面（拖的过程中比例在变）
        if (dragging) { b.classList.add('drag'); D.b = b; }
        b.title = (m.tip || m.label || '') + '：第 ' + t.toFixed(2) + ' 秒' + pushNote(b) + '　按住左右拖动改时间 · 点一下跳到设置';
      });
    });
  }
  Hooks.on('tlDraw', draw);
  draw();

  // ---------- 拖动 ----------
  let D = null;
  addEventListener('mousedown', e => {
    const b = e.button === 0 && e.target.closest && e.target.closest('#tlp-t .tlmk'); if (!b) return;
    const el = b.closest('.tlc'), c = el && clip(el.dataset.id); if (!c || c.lock) return;
    e.preventDefault(); e.stopPropagation();
    if (c.id === tlSel) { try { syncSel(); } catch (er) {} }
    if (b.dataset.dyn != null) {                                             // 效果给的「活」旗子
      const w = dynW(c); if (!w) return;
      const t0 = +b.dataset.t, s = scl(c);                                  // t0 / v 都是「原来的时间」，画和显示时乘 s
      D = { dyn: b.dataset.dyn, w, c, b, t0, s, x0: e.clientX, w0: el.getBoundingClientRect().width * s / lenOf(c), v: t0, last: 0, tip: (b.title || '').split('：')[0] };
      b.classList.add('drag'); trk.classList.add('mkdrag');
      return;
    }
    const m = marksOf(c)[+b.dataset.i]; if (!m) return;
    const t0 = valOf(c, m), k0 = m.keep ? Number(pv(c, m.keep)) || 0 : 0, s = scl(c);
    D = { c, m, b, t0, k0, s, base: baseOf(c, m), x0: e.clientX, w: el.getBoundingClientRect().width * s / lenOf(c), v: t0, last: 0 };
    b.classList.add('drag'); trk.classList.add('mkdrag');
  }, true);
  addEventListener('mousemove', e => {
    if (!D) return;
    if (D.dyn != null) {
      const { c, b, t0, s } = D, len = lenOf(c);
      let v = Math.round((t0 + (e.clientX - D.x0) / D.w0) * 20) / 20;
      v = headSnap(c, v * s, D.w0 / s) / s;
      v = Math.min(len / s - 0.05, Math.max(0, v)); if (v === D.v) return; D.v = v;
      place(b, v * s, len, b.parentNode);
      if (typeof toast === 'function') toast(D.tip + '：第 ' + (v * s).toFixed(2) + ' 秒');
      const now = performance.now();
      if (now - D.last > 80) { D.last = now; liveDyn(D, v); }
      return;
    }
    const { c, m, b, t0, k0, base, s } = D, len = lenOf(c);
    const hi = m.keep ? t0 + k0 : len / s - 0.05, lo = Math.max(0, base + (Number(m.min) || 0));
    let v = Math.round((t0 + (e.clientX - D.x0) / D.w) * 20) / 20;           // 0.05 秒一格
    v = headSnap(c, v * s, D.w / s) / s;
    v = Math.min(hi, Math.max(lo, v)); if (v === D.v) return; D.v = v;
    c.params = c.params || {}; c.params[m.key] = Math.round((v - base) * 100) / 100;
    if (m.keep) c.params[m.keep] = Math.round((k0 - (v - t0)) * 100) / 100;
    place(b, v * s, len, b.parentNode);
    b.title = (m.tip || m.label || m.key) + '：第 ' + (v * s).toFixed(2) + ' 秒';
    if (typeof toast === 'function') toast((m.tip || m.label) + '：第 ' + (v * s).toFixed(2) + ' 秒');
    // 选中的素材：边拖边让预览停在这一秒（限流，最多 12 次 / 秒）
    const now = performance.now();
    if (c.id === tlSel && now - D.last > 80) { D.last = now; live(c, m, v, s); }
  }, true);
  addEventListener('mouseup', () => {
    if (!D) return;
    if (D.dyn != null) { upDyn(); return; }
    const { c, m, b, v, t0, s } = D; D = null;
    b.classList.remove('drag'); trk.classList.remove('mkdrag');
    if (v === t0) {                                                           // 没拖动 = 点了一下：右侧跳到对应的参数
      if (c.id === tlSel && !tlLoading) focus(m.key);
      else { tlSelect(c.id); whenReady(() => setTimeout(() => focus(m.key), 200)); }
      return;
    }
    if (c.id === tlSel) {
      const { k0, base } = { k0: m.keep ? Number(pv(c, m.keep)) || 0 : 0, base: baseOf(c, m) };
      const keep0 = m.keep ? (Number(c.params[m.keep]) || 0) + (v - t0) : 0;   // 拖之前的「停留」
      solve(c, x => { c.params[m.key] = Math.round((x - base) * 100) / 100; if (m.keep) c.params[m.keep] = Math.round((keep0 - (x - t0)) * 100) / 100;
        params[m.key] = c.params[m.key]; if (m.keep) params[m.keep] = c.params[m.keep]; }, v * s, s);
      // 右侧面板里的数字跟着变：和撤销一样走 buildParams + reinit（效果自己的编辑器会重新挂上），再停到这一秒
      try { buildParams(); reinit(false); } catch (er) {}
      // 和「活」旗子一样：重画后看旗子实际落在哪，差多少补多少（所见即所得）
      for (let k = 0; k < 12; k++) {
        const s2 = scl(c), cur = valOf(c, m) * s2, vd = v * s; if (Math.abs(cur - vd) < 0.01) break;
        const x = vd / s2, kp = m.keep ? (Number(c.params[m.keep]) || 0) - (x - valOf(c, m)) : 0;
        c.params[m.key] = Math.round((x - base) * 100) / 100; if (m.keep) c.params[m.keep] = Math.round(kp * 100) / 100;
        params[m.key] = c.params[m.key]; if (m.keep) params[m.keep] = c.params[m.keep];
        try { buildParams(); reinit(false); } catch (er) { break; }
      }
      setTimeout(() => { try { seek(Math.max(0, v * s + 0.05));   /* 停在拖到的那一秒（画面上的秒数） */ } catch (er) {} }, 60);
      try { markDirty(); histSoon(); } catch (er) {}
    } else { try { const g = ghost(c); if (g._ok) ghostInit(c); } catch (er) {} }
    try { tlSave(); tlDraw(); } catch (er) {}
  }, true);
  function focus(key) {
    let el = null;
    try { const w = frame.contentWindow; if (w && w.__fxMarkFocus) el = w.__fxMarkFocus(key); } catch (er) {}
    el = document.querySelector('#params [data-fx-mark="' + key + '"]') || el; if (!el) return;
    el.classList.remove('off');
    const g = el.closest('.fxg'); if (g) g.classList.remove('off');
    fxScrollMid(el);   // 滚到右侧中间（01-base-nav.js）
    el.classList.remove('kf-flash'); void el.offsetWidth; el.classList.add('kf-flash');   // 和关键帧面板同一个「闪两下」（timeline.css）
    clearTimeout(el.__mkft); el.__mkft = setTimeout(() => el.classList.remove('kf-flash'), 1300);
  }
  // 把「活」旗子设到画面上的第 vd 秒：素材改过总时长时，改时间点会让比例跟着变，所以按新比例反复校正，直到差不到 1 像素
  function setDisp(c, w, dyn, vd) {
    const elC = trk.querySelector('.tlc[data-id="' + c.id + '"]'), tol = Math.max(0.002, 1 / Math.max(1, (elC ? elC.offsetWidth : 500) / Math.max(0.01, lenOf(c))));
    let sc = scl(c), pt = vd / sc, last = null;
    for (let k = 0; k < 12; k++) {
      const x = Math.max(0, Math.round(vd / sc * 100) / 100); if (x === last) break; last = x;
      try { pt = Math.max(0, +w.__fxMarkSet(dyn, x) || x); } catch (er) { break; }
      const s2 = scl(c); if (Math.abs(x * s2 - vd) < tol) { sc = s2; break; } sc = s2;
    }
    return { pt, s: sc };
  }
  function liveDyn(d, v) {
    try { const pt = d.w.__fxMarkSet(d.dyn, v); const t = Math.max(0, +pt || v) * (d.s || 1); d.w.renderAt(t); tlT = Math.round((d.c.start + t) * 100) / 100; headPos(); } catch (er) {}
  }
  function upDyn() {
    const { c, b, v, t0, w, dyn, s } = D; D = null;
    b.classList.remove('drag'); trk.classList.remove('mkdrag');
    if (v === t0) { focus(dyn); return; }                                    // 没拖 = 点了一下：跳到右侧那一行
    // 所见即所得：按画面上松手的那一秒（vd）写回。素材改过总时长时，改时间点会让比例跟着变（重画后才知道新比例），
    // 所以写一次 → 重画 → 看旗子实际落在哪 → 差多少补多少，直到差不到 1 像素
    const vd = v * (s || 1), elC = trk.querySelector('.tlc[data-id="' + c.id + '"]');
    const tol = Math.max(0.002, 1 / Math.max(1, (elC ? elC.offsetWidth : 500) / Math.max(0.01, lenOf(c))));
    let pt = v;
    try { pt = Math.max(0, +w.__fxMarkSet(dyn, v) || v); } catch (er) {}
    try { buildParams(); reinit(false); } catch (er) {}
    for (let k = 0; k < 12; k++) {
      const w2 = winOf(c), s2 = scl(c); let cur = null;
      try { cur = ((w2 && w2.__fxMarks && w2.__fxMarks()) || []).find(m => String(m.id) === String(dyn)); } catch (er) { }
      if (!cur || Math.abs(+cur.t * s2 - vd) < tol) break;
      try { pt = Math.max(0, +w2.__fxMarkSet(dyn, Math.round(vd / s2 * 100) / 100) || vd / s2); buildParams(); reinit(false); } catch (er) { break; }
    }
    const sF = scl(c);
    setTimeout(() => { try { seek(Math.max(0, pt * sF)); } catch (er) {} }, 60);
    try { markDirty(); histSoon(); } catch (er) {}
    try { tlSave(); tlDraw(); } catch (er) {}
  }
  function live(c, m, v, s) {
    params[m.key] = c.params[m.key]; if (m.keep) params[m.keep] = c.params[m.keep];
    try {
      const w = frame.contentWindow;
      if (w && w.init) { w.init(params); const t = Math.max(0, v * (s || 1) + 0.05); w.renderAt(t); tlT = Math.round((c.start + t) * 100) / 100; headPos(); }
    } catch (er) {}
  }
})();
