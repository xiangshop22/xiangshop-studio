// 效果工坊 · 素材互相引用（v1 2026-11-26；v60.0 层级编辑）：效果里的内容可以选「时间线素材」（公共模块 effects/_shared/fx-ref.js，FXRef）
// 【区域R1 查素材】  __fxRefClip(id)：给效果里的 FXRef 用 —— 这条素材的效果名 + 参数 + 「出」旗子在第几秒（stop：播到这里就停住）
// 【区域R2 列表】    __fxRefList()：右侧「时间线素材」里列出来的素材（不含正在改的这条、不含嵌在别的素材里的拷贝；near = 离这条素材开头多远）
// 【区域R3 拷贝一份】__fxRefCopy(id)：复制一条嵌在父素材里的拷贝（embedIn = 父素材，眼睛关着），不占轨道、不建组合；
//                   v61.0 它是一条独立的素材：时间线上左右拖 = 改开始时间（embAt = 比父素材晚几秒，父素材挪了它跟着挪），拉右边 = 改时长
// 【区域R4 整理】    embSync()：拷贝跟着父素材的轨道、父素材挪了跟着挪；父素材不再用它（换了素材、删了父素材）就删掉它
// 【区域R5 编辑】    __fxRefEdit(id) 选中它（父素材那一行展开）；__fxRefEnter(id) 双击进到它里面（时间线只显示它、预览只显示它）；__fxRefExit() 回到父素材
// 【区域R6 拾取】    __fxRefPick(cb)：像 AE 的拾取线 —— 点时间线上的素材条就选中它，Esc 取消
// 【区域R7 路径】    选中的是嵌着的拷贝：右侧顶上显示「推进 › 标注」，进到里面时时间线顶上也有一排；点父素材名 / Esc 返回
// 【区域R8 时间线】  父素材条上的 ▸ 展开 / 收起；点子素材条 = 改它的参数（不能拖），双击 = 进到里面
// 【区域R9 版本】    参数一改 __fxRefVer 加 1，嵌着它的素材下一帧重新拿参数；改的是被引用的素材时，马上重画一次时间线
// 【区域R10 导出打包】fxRefPack(params)：导出时把引用到的素材参数塞进 params.__refs（没引用 = 原样返回同一个对象，画面不变）
// 没有素材用「时间线素材」时，这个文件只多了几个函数、一个计数器和几个只在用到时才起作用的鼠标 / 键盘监听。
(function () {
  let ver = 0, rq = 0;
  // 参数里哪些值是「时间线素材」（P.bg 这种 JSON 字符串：{"type":"clip","ref":"…"}）
  const refsIn = p => {
    const out = []; if (!p) return out;
    for (const k in p) { const v = p[k]; if (typeof v !== 'string' || v.indexOf('"clip"') < 0) continue; try { const m = JSON.parse(v); if (m && m.type === 'clip' && m.ref) out.push(m.ref); } catch (e) { } }
    return out;
  };
  const paramsOf = c => (c.id === tlSel && cur && cur.id === c.fx) ? params : c.params;
  const stopOf = c => { try { return typeof __fxMarkOutN === 'function' ? __fxMarkOutN({ fx: c.fx, params: paramsOf(c) || {} }) : null; } catch (e) { return null; } };
  const atOf = c => { const p = embP(c); return p ? r2(c.start - p.start) : 0; };   // 嵌着的拷贝比父素材晚开始几秒
  const pack = c => ({ fx: c.fx, params: clone(paramsOf(c)), ci: cIn(c), len: c.len, stop: stopOf(c), at: atOf(c) });
  const nameOf = c => { const f = c && fxOf(c); return f ? f.name : c ? c.fx : ''; };
  const eat = e => { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };
  const typing = () => { const a = document.activeElement; return !!(a && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable)); };
  // 【区域R1】
  window.__fxEmbStop = c => {                          // 选中的嵌着的拷贝（预览里单独显示时）停在第几秒：和合成画面里一样停在「出」
    const s = stopOf(c); if (s == null) return Infinity;
    const T = +((paramsOf(c) || {}).__dur) || 0; let N = 0; try { N = T > 0 && frame.contentWindow.__fxNativeDur ? +frame.contentWindow.__fxNativeDur() : 0; } catch (e) { }
    return Math.max(cIn(c), N > 0 ? s * T / N : s);
  };
  window.__fxRefVer = () => ver;
  window.__fxRefClip = id => { const c = clip(id); return c ? pack(c) : null; };
  // 【区域R2】
  window.__fxRefList = () => {
    const me = clip(tlSel), t0 = me ? me.start : tlT;
    return TL.clips.filter(c => c.id !== tlSel && !c.ref && (!c.embedIn || c.embedIn === tlSel)).map(c => ({
      id: c.id, fx: c.fx, name: nameOf(c), start: c.start, len: c.len, hide: !!c.hide, embedded: !!c.embedIn, src: c.copyOf || null, near: Math.abs(c.start - t0)
    })).sort((a, b) => a.near - b.near || a.start - b.start);
  };
  // 【区域R3】拷贝一份：嵌在这条素材里（眼睛关着、只在这里显示），开头 / 时长 / 轨道和父素材一样
  window.__fxRefCopy = id => {
    const s = clip(id), p = clip(tlSel); if (!s || !p) return null;
    const c = clone(s); c.id = nid('c'); c.hide = true; c.embedIn = p.id; c.copyOf = s.copyOf || s.id; c.start = p.start; c.layer = p.layer; c.embAt = 0; c.embP0 = p.start;   // 时长 = 原素材自己的时长
    delete c.group; delete c.sub; delete c._len; delete c.embOpen; delete c.lock;
    TL.clips.push(c); ver++; return c.id;
  };
  window.__fxRefAfterCopy = id => setTimeout(() => {
    const c = clip(id), p = clip(tlSel); if (!c || !p) return;
    syncSel(); p.embOpen = true;                       // 父素材刚改的参数（背景 = 这条）先存回去；父素材那一行展开，看得到拷贝
    tlRender(); tlDraw(); tlSave(); Hooks.run('histCheck');
    toast('已拷贝一份「' + nameOf(c) + '」嵌进来：点素材条上的 ▾ 下面那条就能改它，双击进到它里面');
  }, 0);
  // 【区域R4】整理嵌着的拷贝（每次记撤销之前走一遍）
  function embSync() {
    if (!TL.clips.some(c => c.embedIn)) return;
    const by = new Map(); TL.clips.forEach(o => { if (!o.embedIn) refsIn(paramsOf(o)).forEach(id => { if (!by.has(id)) by.set(id, o); }); });
    const kill = []; let ch = false;
    TL.clips.forEach(c => {
      if (!c.embedIn) return;
      let p = clip(c.embedIn); const u = by.get(c.id);
      if (!u) { kill.push(c); return; }                // 没人用它了（换了素材、父素材删了）
      if (!p || p.embedIn || refsIn(paramsOf(p)).indexOf(c.id) < 0) { c.embedIn = u.id; p = u; ch = true; }   // 原来的父素材删了，另一条（比如复制出来的）还在用它
      if (c.layer !== p.layer || c.group) { c.layer = p.layer; delete c.group; delete c.sub; ch = true; }
      if (follow(c, p)) ch = true;
    });
    if (kill.length) { removeClips(kill); return; }
    if (ch) { normLayers(); tlSave(); drawSoon(); }
    embGrow();
  }
  Hooks.on('histCheck:before', embSync);
  // 【区域R4 整理 · 父素材跟着变长】（v62.0）子素材（嵌着的拷贝）比父素材晚结束 → 父素材自动拉长到和它一样晚结束。
  // 和拖父素材右边一样走 setDuration：旗子不动，多出来的时间加在「停」之后（规则 56）；剪过尾巴的先把尾巴放出来。
  // 只拉长、不缩短；拖动中不做，松手（histCheck）后做一次；做完回到原来选中的素材（「进到里面」的状态也还原）。
  let growQ = 0;
  function embGrow() {
    if (growQ || tlDragS) return;
    const need = new Map();
    TL.clips.forEach(c => { const p = c.embedIn && embP(c); if (!p) return; const e = r2(c.start + c.len - p.start); if (e > p.len + 0.01) need.set(p, Math.max(need.get(p) || 0, e)); });
    if (!need.size) return;
    growQ = setTimeout(async () => {
      try {
        const sel = tlSel, keep = [...tlMulti], F = tlEmbF; let sw = false;
        for (const [p, L] of need) {
          if (!clip(p.id) || L <= p.len + 0.01) continue;
          const co = cOut(p);
          if (co > 0.001) { const d = Math.min(co, L - p.len); p.co = r2(co - d); p.len = r2(p.len + d); if (p.co <= 0.001) delete p.co; if (L <= p.len + 0.01) continue; }
          delete p.co;
          if (tlSel !== p.id) { tlKeepT = true; tlSelect(p.id, true); tlKeepT = false; sw = true; }
          await new Promise(r => whenReady(r)); setDuration(r2(L + cIn(p))); syncSel();
          toast('「' + nameOf(p) + '」自动拉长到 ' + p.len.toFixed(2) + ' 秒：里面的素材比它晚结束');
        }
        if (sw && clip(sel)) { tlKeepT = true; tlSelect(sel, true); tlKeepT = false; tlMulti = new Set(keep); if (F && clip(F)) tlEmbF = F; }
        tlRender(); tlDraw(); tlSave(); histCheck();
      } catch (e) { console.error(e); } finally { growQ = 0; }
    }, 0);
  }
  // 父素材挪了（开头变了）→ 拷贝跟着挪、和父素材的间隔不变；拷贝自己挪了 → 记下新的间隔
  function follow(c, p) {
    if (c.embP0 == null) { c.embP0 = p.start; c.embAt = r2(c.start - p.start); return false; }
    if (Math.abs(p.start - c.embP0) > 1e-6) { c.embP0 = p.start; const s = r2(Math.max(0, p.start + (+c.embAt || 0))); if (s !== c.start) { c.start = s; return true; } return false; }
    c.embAt = r2(c.start - p.start); return false;
  }
  Hooks.on('tlDraw', () => {
    const d = tlDragS;
    if (d && d.c && d.c.embedIn) { ver++; if (!rq) rq = requestAnimationFrame(() => { rq = 0; try { tlRender(); } catch (e) { } }); return; }   // 拖拷贝的素材条：合成画面跟着变
    if (d) return;
    let mv = false; TL.clips.forEach(c => { const p = c.embedIn && embP(c); if (p && follow(c, p)) mv = true; });
    if (mv) { ver++; tlRender(); drawSoon(); }
  });
  // 【区域R5】
  window.__fxRefEdit = id => {
    const c = clip(id); if (!c) return;
    const p = embP(c); if (p) p.embOpen = true;
    if (c.group) { const g = grp(c.group); if (g) g.col = false; }
    tlSelect(id); tlRender(); tlDraw(); tlSave();
  };
  window.__fxRefEnter = id => {
    const c = clip(id), p = embP(c); if (!p) { window.__fxRefEdit(id); return; }
    tlStop(); p.embOpen = true; tlSelect(id); tlEmbF = p.id;
    tlRender(); tlDraw(); try { fit(); } catch (e) { }
    toast('已进到「' + nameOf(c) + '」里面：时间线只显示它，预览只显示它。点上面的「← ' + nameOf(p) + '」或按 Esc 回去');
  };
  window.__fxRefExit = () => {
    const c = clip(tlSel), p = embP(c); const was = tlEmbF; tlEmbF = null;
    if (p) tlSelect(p.id); else if (was) { tlRender(); tlDraw(); }
    try { fit(); } catch (e) { }
  };
  // 【区域R6】拾取
  let pick = null;
  const pickEnd = () => { if (!pick) return; pick = null; document.documentElement.classList.remove('fxpick'); try { $('#hint').textContent = ''; } catch (e) { } };
  // 拾取鼠标 = 🎯（v62.0）：第一次拾取时用 canvas 把 🎯 画成一张 32×32 的图当鼠标（以前那张 SVG 里的 # 没转义，浏览器读不出来）；
  // 拾取中所有 iframe（预览、时间线叠加层）不接鼠标，鼠标移到上面也还是 🎯，点下去照样落在时间线素材条上
  let curOk = false;
  const pickCursor = () => {
    if (curOk) return; curOk = true;
    let u = '';
    try {
      const c = document.createElement('canvas'); c.width = c.height = 32; const g = c.getContext('2d');
      g.font = '26px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText('🎯', 16, 17); u = c.toDataURL('image/png');
    } catch (e) { }
    const st = document.createElement('style'); st.id = 'fxpick-cur';
    st.textContent = (u ? 'html.fxpick:root,html.fxpick:root *{cursor:url(' + u + ') 16 16,crosshair!important}' : '') + 'html.fxpick:root iframe{pointer-events:none!important}';   // :root 加一级：timeline.css 在 body 里，排在这张表后面
    document.head.appendChild(st);
  };
  window.__fxRefPick = cb => {
    if (pick) { pickEnd(); return false; }
    pickCursor(); pick = { cb }; document.documentElement.classList.add('fxpick');
    try { $('#hint').textContent = '🎯 拾取：点时间线上的一条素材当背景 · Esc 取消'; } catch (e) { }
    return true;
  };
  window.__fxRefPicking = () => !!pick;
  addEventListener('mousedown', e => {
    if (!pick) return;
    const t = e.target; if (!(t instanceof Element)) return;
    if (t.closest('[data-fxpick]')) return;            // 再点一下「拾取」按钮 = 取消（按钮自己处理）
    const el = t.closest('#tlp-t .tlc[data-id]');
    if (!el) { pickEnd(); return; }                    // 点了别处 = 取消拾取（这一下照常生效）
    eat(e);
    const id = el.dataset.id, it = window.__fxRefList().find(x => x.id === id);
    if (id === tlSel) { toast('不能选自己：点另一条素材'); return; }
    if (!it) { toast(clip(id) && clip(id).ref ? '原视频不能嵌进来' : '这条素材嵌在别的素材里，不能再拿来用'); return; }
    const cb = pick.cb; pickEnd(); try { cb(it); } catch (er) { console.error(er); }
  }, true);
  // 【区域R7】路径
  const tp = document.createElement('div'); tp.id = 'tlp-path'; tp.hidden = true;
  const ep = $('#tlp-e'); ep.parentNode.insertBefore(tp, ep);
  const rp = document.createElement('div'); rp.id = 'fxpath'; rp.hidden = true;
  $('aside.r').prepend(rp);
  const pathHtml = (p, c) => '<button type="button" data-fxback title="回到「' + esc(nameOf(p)) + '」（Esc）">← ' + esc(nameOf(p)) + '</button><span>›</span><b>' + esc(nameOf(c)) + '</b>';
  let pk = '';
  function pathSync() {
    const c = clip(tlSel), p = embP(c), F = embF();
    const k = p ? [p.id, c.id, nameOf(p), nameOf(c), F || ''].join('|') : '';
    if (k === pk) return; pk = k;
    rp.hidden = !p; tp.hidden = !(p && F);
    if (!p) { rp.innerHTML = tp.innerHTML = ''; return; }
    rp.innerHTML = pathHtml(p, c) + '<i>' + (F ? '正在它里面改 · Esc 返回' : '嵌在「' + esc(nameOf(p)) + '」里的拷贝 · 预览是整个画面 · Esc 返回') + '</i>';
    tp.innerHTML = F ? pathHtml(p, c) + '<i>时间线只显示「' + esc(nameOf(p)) + '」里面的素材 · Esc 返回</i>' : '';
  }
  ['tlDraw', 'select', 'reinit'].forEach(n => Hooks.on(n, pathSync));
  [tp, rp].forEach(el => el.addEventListener('click', e => { if (e.target.closest('[data-fxback]')) { e.preventDefault(); window.__fxRefExit(); } }));
  addEventListener('keydown', e => {                   // 冒泡阶段：效果自己用 Esc 的（画重点、改字…）先拦住，轮不到这里
    if (e.key !== 'Escape' || e.defaultPrevented) return;
    if (pick) { eat(e); pickEnd(); toast('已取消拾取'); return; }
    if (typing() || document.querySelector('.mask,.xpm')) return;
    if (embP(clip(tlSel)) && tlMulti.size <= 1) { eat(e); window.__fxRefExit(); }
  });
  addEventListener('keydown', e => { if (e.key === 'Escape' && pick && !typing()) { eat(e); pickEnd(); toast('已取消拾取'); } }, true);
  // 【区域R8】时间线：▸ 展开、点子素材、双击进到里面
  let last = { id: null, t: 0 };
  addEventListener('mousedown', e => {
    if (e.button !== 0 || pick) return;
    const t = e.target; if (!(t instanceof Element) || !t.closest('#tlp-t')) return;
    const tg = t.closest('.tlemb');
    if (tg) { eat(e); const c = clip(tg.closest('.tlc').dataset.id); if (c) { c.embOpen = !c.embOpen; tlDraw(); tlSave(); } return; }
    const el = t.closest('.tlc.emb'); if (!el || t.classList.contains('tlr')) return;
    const id = el.dataset.id, now = Date.now();
    const dbl = last.id === id && now - last.t < 450; last = { id, t: dbl ? 0 : now };
    if (dbl) { eat(e); window.__fxRefEnter(id); }       // 单击照常交给时间线：选中、左右拖 = 改开始时间、拉右边 = 改时长
  }, true);
  // 【区域R9】
  const bump = () => {
    ver++;
    if (!tlSel || rq) return;
    if (!TL.clips.some(c => c.id !== tlSel && refsIn(c.params).indexOf(tlSel) >= 0)) return;   // 没人引用正在改的这条：不多画
    rq = requestAnimationFrame(() => { rq = 0; try { tlRender(); } catch (e) { } });
  };
  Hooks.on('markDirty', bump); Hooks.on('histCheck', bump); Hooks.on('reinit', () => { ver++; });
  // 【区域R10】导出：引用到的素材（包括眼睛关着的拷贝）一起打包；只打一层
  window.fxRefPack = p => {
    const ids = refsIn(p); if (!ids.length) return p;
    const o = Object.assign({}, p), R = {};
    ids.forEach(id => { const c = clip(id); if (c) R[id] = pack(c); });
    o.__refs = R; return o;
  };
})();
