// 效果工坊 · 剪辑快捷键 Q / W / C（v43.0）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// 选中素材（单个 / 多选 / 整个组合都行），播放头停在素材中间：
//   Q = 剪掉播放头【前面】那一段（素材从播放头开始，后面的画面位置不动）
//   W = 剪掉播放头【后面】那一段
//   C = 在播放头处剪成两段（两段是独立的素材，参数一样，各自接着原来的画面）
// 不改效果本身：素材上记 c.ci（前面剪掉效果的多少秒）、c.co（后面剪掉多少秒），时长 = 效果总时长 − ci − co（10-timeline.js cLen）。
// 剪掉的部分没丢：拖右边缘往外拉，会先把剪掉的尾巴拉回来。Ctrl+Z 可以撤销。锁住的素材不剪。
function cutTargets() {
  const ids = tlGrp ? TL.clips.filter(c => c.group === tlGrp).map(c => c.id) : tlMulti.size > 1 ? [...tlMulti] : tlSel ? [tlSel] : [];
  const T = tlT, all = ids.map(clip).filter(c => c && !c.lock && !c.ref);
  return { all, hit: all.filter(c => T > c.start + 0.04 && T < c.start + c.len - 0.04) };
}
function tlCut(k) {
  const { all, hit } = cutTargets();
  if (!all.length) return toast('先选中一个素材，再把播放头放到要剪的位置');
  if (!hit.length) return toast('播放头不在选中的素材中间（离头尾太近也不剪）');
  try { syncSel(); } catch (e) { }
  const T = r2(tlT); let sel = tlSel;
  hit.forEach(c => {
    const d = r2(T - c.start), rest = r2(c.len - d);
    if (k === 'q') { c.ci = r2(cIn(c) + d); c.start = T; c.len = rest; }
    else if (k === 'w') { c.co = r2(cOut(c) + rest); c.len = d; }
    else {
      const n = Object.assign(clone(c), { id: nid('c'), start: T, len: rest, ci: r2(cIn(c) + d) });
      c.co = r2(cOut(c) + rest); c.len = d;
      TL.clips.push(n);
    }
  });
  // 选中的素材前面被剪掉时，#frame 里的效果要按新的起点重新对时间
  tlStop(); tlRender(); tlDraw(); tlSave(); Hooks.run('histCheck'); try { kfTrackDraw(); } catch (e) { }
  const n = hit.length > 1 ? hit.length + ' 个素材' : '素材';
  toast(k === 'q' ? '✂ 已剪掉' + n + '播放头前面的部分（Q）' : k === 'w' ? '✂ 已剪掉' + n + '播放头后面的部分（W）' : '✂ 已把' + n + '在播放头处剪成两段（C）　Ctrl+Z 撤销');
}
addEventListener('keydown', e => {
  if (e.ctrlKey || e.metaKey || e.altKey || e.repeat) return;
  const k = e.key.toLowerCase(); if (k !== 'q' && k !== 'w' && k !== 'c') return;
  const a = document.activeElement;
  if (a && (a.tagName === 'TEXTAREA' || a.tagName === 'SELECT' || (a.tagName === 'INPUT' && a.type !== 'range') || a.isContentEditable)) return;
  if (document.querySelector('.mask,.xpm') || !TL.clips.length) return;
  e.preventDefault(); tlCut(k);
});
