// 效果工坊 · 启动：恢复上次的时间线
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ---------- 启动：等效果列表加载完，恢复上次的时间线 ----------
(function boot(n) {
  if (!effects.length || !cur) { if (n < 150) setTimeout(() => boot(n + 1), 200); else tlDraw(); return; }
  const s = store.get('timeline', null);
  if (s && Array.isArray(s.clips)) {
    TL.clips = s.clips.filter(c => c && effects.some(e => e.id === c.fx));
    TL.groups = Array.isArray(s.groups) ? s.groups : []; normLayers();
    // v49.2：纯背景改成自己铺满画布。以前双击放进来时「大小」被设成画布比例倍数（9:16 时约 316%），现在会放大两遍 → 改回 100%。
    // 只改「大小正好等于以前自动算的倍数、位置居中、没有大小关键帧」的，手动调过的不动。
    { const { w, h } = res(), a = w / 1920, b = h / 1080, k0 = Math.round(Math.max(a, b) / Math.min(a, b) * 100) / 100; let n = 0;
      if (k0 !== 1) TL.clips.forEach(c => { const p = c.params || {}; if (!/^bg-/.test(c.fx) || Math.abs((+p.scale || 1) - k0) > 0.011 || +p.offsetX || +p.offsetY || /"k":"s"/.test(typeof p.keys === 'string' ? p.keys : JSON.stringify(p.keys || null))) return; p.scale = 1; n++; });
      if (n) { tlSave(); setTimeout(() => toast('纯背景现在自己铺满画布，' + n + ' 个背景的「大小」已从 ' + Math.round(k0 * 100) + '% 改回 100%（画面不变）'), 1000); } }
    tlT = +s.t || 0; TL.clips.forEach(ghost);
    if (TL.clips.length) { fit(); if (clip(s.sel)) tlSelect(s.sel); else { tlPreview = false; tlRender(); }  /* v35.x：打开时没选中素材 → 不把上次点过的效果盖在节目上（以前的残留） */ }
  }
  tlDraw();
  if (typeof tlViewRestore === 'function') setTimeout(() => tlViewRestore(), 500);   // 等界面排好版再放（太早量到的宽度不对）   // v43.1：放大倍数、滚动位置和刷新前一样
})(0);
