// 效果工坊 · 原视频（垫底的尺子）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ---------- 原视频（v16.0）：上传一条原视频垫在最底下当「尺子」，可裁剪；只在预览里显示，不参与分段、不导出 ----------
// 时间线第 0 秒 = 原视频的「开头」（REF.in）。改开头时，时间线上的素材一起前后挪，和画面的对应关系不变。
REF = store.get('refVideo', null);
const rvSave = () => store.set('refVideo', REF);
const fmtV = t => { t = Math.max(0, t); return Math.floor(t / 60) + ':' + (t % 60).toFixed(1).padStart(4, '0'); };
const parseV = s => { const m = String(s).trim().match(/^(?:(\d+)[:：])?(\d+(?:\.\d+)?)$/); return m ? (+m[1] || 0) * 60 + +m[2] : NaN; };
const rvEl = document.createElement('video'); rvEl.id = 'refv'; rvEl.muted = false;   // 原视频带声音播放（预览视频 v33.x 起保留音轨） rvEl.playsInline = true; rvEl.preload = 'auto';
box.insertBefore(rvEl, box.firstChild);
rvEl.addEventListener('loadedmetadata', () => rvSync());
function rvSync() {
  if (!REF) { rvEl.style.display = 'none'; return; }
  if (!rvEl.src.endsWith(REF.url)) rvEl.src = REF.url;
  const L = refLen(), vis = tlT <= L + 0.0001; rvEl.style.display = vis ? '' : 'none';
  const vt = REF.in + Math.min(tlT, L);
  if (tlPlaying && vis) {
    if (rvEl.paused) { rvEl.currentTime = vt; rvEl.play().catch(() => { }); }
    else if (Math.abs(rvEl.currentTime - vt) > 0.25) rvEl.currentTime = vt;
  } else {
    if (!rvEl.paused) rvEl.pause();
    if (Math.abs(rvEl.currentTime - vt) > 0.02) rvEl.currentTime = vt;
  }
}
Hooks.on('tlSeek', () => rvSync());
Hooks.on('tlStop', () => rvSync());

// 时间线上的「原视频」一行
const rvRow = document.createElement('div'); rvRow.id = 'tlp-rv';
rvRow.innerHTML = '<div class="sgn">原视频</div><div id="tlp-rt"></div>';
$('#tlp-b').before(rvRow);
const rvT = $('#tlp-rt');
function rvDraw() {
  rvRow.style.display = REF ? '' : 'none'; rvBtns();
  if (!REF) { rvT.innerHTML = ''; return; }
  const L = refLen();
  rvT.innerHTML = '<div class="rvb" style="width:' + Math.min(100, L / tlV * 100) + '%" title="原视频：' + esc(REF.name) + '\n用的是原视频 ' + fmtV(REF.in) + ' → ' + fmtV(REF.out) + '（' + L.toFixed(1) + ' 秒），时间线第 0 秒 = 原视频 ' + fmtV(REF.in) + '\n点一下：跳到这里；双击：裁剪；拖右边的竖条：改结尾">🎬 ' + esc(REF.name) + '<i>原视频 ' + fmtV(REF.in) + ' → ' + fmtV(REF.out) + '</i><b class="sgh r" title="拖：改结尾（拖的时候时间线会临时拉到原视频全长）；双击：结尾恢复到原视频最后"></b></div>' + (REF.out < REF.vdur - 0.05 ? '<div class="rvg" style="left:' + Math.min(100, L / tlV * 100) + '%;width:' + Math.max(0, Math.min(100, (REF.vdur - REF.in) / tlV * 100) - L / tlV * 100) + '%" title="剪掉的部分（原视频还有 ' + fmtV(REF.vdur - REF.out) + '）：拖蓝条右边的竖条可以拉回来"></div>' : '') + '<div class="rvhd" style="left:' + Math.min(100, tlT / tlV * 100) + '%"></div>';
}
Hooks.on('tlDraw', () => rvDraw());
Hooks.on('headPos', () => { const h = rvT.querySelector('.rvhd'); if (h) h.style.left = Math.min(100, tlT / tlV * 100) + '%'; });
let rvDrag = null;
rvT.addEventListener('mousedown', e => {
  if (!REF || e.button) return;
  const r = rvT.getBoundingClientRect(), t = Math.max(0, (e.clientX - r.left) / r.width * tlV);
  if (e.target.classList.contains('sgh')) { rvDrag = true; rvSpan = REF.vdur - REF.in; tlDraw(); document.body.style.cursor = 'ew-resize'; e.preventDefault(); return; }
  tlStop(); tlSeek(Math.min(t, refLen()));
});
rvT.addEventListener('dblclick', e => { if (!REF) return; if (e.target.classList.contains('sgh')) { REF.out = REF.vdur; rvSave(); tlDraw(); rvSync(); toast('结尾已恢复到原视频最后'); } else rvTrim(); });
addEventListener('mousemove', e => {
  if (!rvDrag) return;
  const r = rvT.getBoundingClientRect(), t = Math.max(0.5, (e.clientX - r.left) / r.width * tlV);
  REF.out = r2(Math.min(REF.vdur, REF.in + t)); rvDraw(); headPos();
});
addEventListener('mouseup', () => { if (!rvDrag) return; rvDrag = false; rvSpan = 0; document.body.style.cursor = ''; rvSave(); tlDraw(); rvSync(); });

// 标题栏按钮：上传 / 裁剪 / 移除
const rvTools = document.createElement('span'); rvTools.id = 'rv-tools';
$('#tlp-k').before(rvTools);
const rvFile = document.createElement('input'); rvFile.type = 'file'; rvFile.accept = 'video/*,.mp4,.mov,.m4v,.mkv,.webm,.avi'; rvFile.hidden = true; document.body.appendChild(rvFile);
function rvBtns() {
  const k = REF ? 'on' : 'off'; if (rvTools.dataset.k === k) return; rvTools.dataset.k = k;
  rvTools.innerHTML = REF ? '<button type="button" data-a="ref" title="把选中的素材标成「参照」：只在预览里垫着对照，不参与分段、不导出（再点一次取消）">设为参照</button><button type="button" data-a="trim" title="选用原视频的哪一段（开头 / 结尾）">✂ 裁剪原视频</button><button type="button" data-a="full" title="开头回到 0、结尾回到原视频最后（效果跟着挪，对应关系不变）">↔ 恢复全长</button><button type="button" data-a="up" title="换一条原视频（只引用，不拷贝）">换</button><button type="button" data-a="del" title="移除原视频（时间线上的效果不受影响）">✕</button>'
    : '<button type="button" data-a="ref" title="把选中的素材标成「参照」：只在预览里垫着对照，不参与分段、不导出（再点一次取消）">设为参照</button><button type="button" data-a="up" class="pri" title="选一条电脑上的原视频垫在最底下，照着它的画面摆效果的时间。只引用原片、不拷贝；它只用来对照，不会被导出。">⬆ 选择原视频</button>';
}
rvTools.addEventListener('click', e => {
  const a = e.target.dataset && e.target.dataset.a; if (!a) return;
  if (a === 'up') rvPick();
  else if (a === 'ref') sgRefToggle();
  else if (a === 'full') rvFull();
  else if (a === 'trim') rvTrim();
  else if (a === 'del' && confirm('移除原视频？（时间线上的效果不受影响）')) { REF = null; rvSave(); rvEl.removeAttribute('src'); rvEl.load(); tlDraw(); rvSync(); fit(); }
});
function rvSetNew(r, fname) {
  const old = REF; REF = { url: r.video, poster: r.poster || '', name: String(fname).replace(/^.*[\\/]/, '').replace(/\.[^.]+$/, ''), vdur: +r.vdur || 0, w: r.w, h: r.h, in: 0, out: +r.vdur || 0 };
  if (r.src) REF.src = r.src;                                    // v19.0：引用的本机原视频路径（没拷贝原片）
  if (old) { REF.in = Math.min(old.in, REF.vdur); REF.out = Math.min(REF.vdur, Math.max(REF.in + 0.5, old.out)); }
  rvSave(); tlDraw(); rvSync(); fit(); toast((r.src ? '已引用原视频（没有拷贝原片）：' + r.src : '原视频已放到时间线最底下') + '\n长 ' + fmtV(REF.vdur) + '，先选一下要用哪一段');
  rvTrim();
}
// 选原视频（v19.0）：在电脑上弹出选文件窗口，只引用原片路径；不是 Windows 或弹窗失败时，退回「上传一份」
async function rvPick() {
  // 等待提示放在屏幕正中（v19.0 补丁），选完 / 取消后自动关掉
  const w = document.createElement('div'); w.className = 'xpm';
  w.innerHTML = '<div class="pkw"><div class="pki">📂</div><b>请在弹出的窗口里选择原视频</b><p>只引用你电脑上的原片，不会拷贝。<br>选好后会生成一份很小的预览视频，长视频要等一会儿。</p><span class="pkh">窗口没看到？按 Alt + Tab 切换一下</span></div>';
  document.body.appendChild(w);
  let r = {};
  try { r = await (await fetch('/api/pick-video', { method: 'POST', headers: { 'x-fx': '1' } })).json(); } catch (e) { r = { error: e.message }; }
  w.remove();
  if (r.cancel) return toast('没有选文件');
  if (r.video) return rvSetNew(r, r.src);
  toast('没法弹出选文件窗口（' + (r.error || '未知原因') + '），改成上传一份原视频', true);
  rvFile.click();
}
// 改开头（Δ 秒）：时间线上的素材一起挪，和画面的对应关系不变
function rvSetIn(a) {
  const d = r2(a - REF.in); if (!d) return;
  let cut = 0; TL.clips.forEach(c => { c.start = r2(c.start - d); if (c.start < 0) { cut++; c.start = 0; } });
  REF.in = a; tlSeek(Math.max(0, tlT - d));
  if (cut) toast(cut + ' 个效果在新开头之前，已经挪到第 0 秒，记得检查一下它们的时间', true);
}
function rvFull() { if (!REF) return; rvSetIn(0); REF.out = REF.vdur; rvSave(); tlSave(); tlRender(); tlDraw(); rvSync(); fit(); toast('原视频已恢复全长（' + fmtV(REF.vdur) + '）'); }
rvFile.onchange = () => {
  const f = rvFile.files[0]; rvFile.value = ''; if (!f) return;
  const x = new XMLHttpRequest(); x.open('POST', '/api/upload-video');
  x.setRequestHeader('x-fx', '1'); x.setRequestHeader('x-file-name', encodeURIComponent(f.name));
  x.upload.onprogress = ev => { if (ev.lengthComputable) toast('正在上传原视频… ' + Math.round(ev.loaded / ev.total * 100) + '%' + (ev.loaded >= ev.total ? '\n上传完了，正在转成预览用的小视频（长视频要等一会儿）…' : ''), false, 600000); };
  x.onload = () => {
    let r = {}; try { r = JSON.parse(x.responseText); } catch (e) { }
    if (x.status !== 200 || !r.video) return toast('原视频没传上去：' + (r.error || x.status), true);
    rvSetNew(r, f.name);
  };
  x.onerror = () => toast('原视频上传失败（网络中断）', true);
  x.send(f);
};

// 裁剪窗口：拖进度看画面，「设为开头 / 设为结尾」，或者直接输入时间
async function rvTrim() {
  if (!REF) return;
  const pr = dialog({ title: '裁剪原视频：选用哪一段', html:
    '<video class="rvv" muted playsinline preload="auto"' + (REF.poster ? ' poster="' + REF.poster + '"' : '') + '></video>' +
    '<div class="rvsc"><input type="range" class="rvs" min="0" step="0.04"><span class="rvn"></span></div>' +
    '<div class="rvio"><button type="button" data-a="in">[ 设为开头</button><input class="rvi" title="开头（分:秒，例如 2:53.0）"><span>→</span><input class="rvo" title="结尾（分:秒）"><button type="button" data-a="out">设为结尾 ]</button><button type="button" data-a="pv">▶ 播放这一段</button></div>' +
    '<p class="rvtip">只在开头到结尾之间做效果。时间线第 0 秒 = 原视频的开头；改了开头，时间线上已经摆好的效果会跟着一起挪，和画面的对应关系不变。原视频本身不会被导出。</p>',
    buttons: [{ text: '确定', value: 'ok', cls: 'pri' }, { text: '取消', value: null }] });
  const bx = document.querySelector('.mask .dlg'); bx.classList.add('wide');
  const v = bx.querySelector('.rvv'), s = bx.querySelector('.rvs'), n = bx.querySelector('.rvn'), ii = bx.querySelector('.rvi'), oo = bx.querySelector('.rvo');
  let a = REF.in, b = REF.out, pv = false;
  v.src = REF.url; s.max = REF.vdur;
  const show = () => { ii.value = fmtV(a); oo.value = fmtV(b); n.textContent = fmtV(+s.value) + ' / ' + fmtV(REF.vdur) + '　选用 ' + (b - a).toFixed(1) + ' 秒'; s.style.setProperty('--a', a / REF.vdur * 100 + '%'); s.style.setProperty('--b', b / REF.vdur * 100 + '%'); };
  const go = t => { s.value = t; v.currentTime = t; show(); };
  s.oninput = () => { pv = false; v.pause(); v.currentTime = +s.value; show(); };
  v.ontimeupdate = () => { if (!pv) return; s.value = v.currentTime; show(); if (v.currentTime >= b) { v.pause(); pv = false; } };
  const setIn = t => { if (isNaN(t)) return show(); a = r2(Math.max(0, Math.min(t, b - 0.5))); show(); };
  const setOut = t => { if (isNaN(t)) return show(); b = r2(Math.min(REF.vdur, Math.max(t, a + 0.5))); show(); };
  ii.onchange = () => { setIn(parseV(ii.value)); go(a); }; oo.onchange = () => { setOut(parseV(oo.value)); go(b); };
  bx.querySelector('.rvio').addEventListener('click', e => {
    const k = e.target.dataset.a;
    if (k === 'in') setIn(+s.value); else if (k === 'out') setOut(+s.value);
    else if (k === 'pv') { go(a); pv = true; v.play().catch(() => { }); }
  });
  go(Math.min(REF.in + tlT, REF.out));
  if ((await pr) !== 'ok') return;
  rvSetIn(a); REF.out = b; rvSave(); tlSave(); tlRender(); tlDraw(); rvSync(); fit();
}
