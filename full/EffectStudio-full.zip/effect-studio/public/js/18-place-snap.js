// 效果工坊 · 摆位置模式 + 辅助对齐（v24.4）：「自动关键帧」在「关键帧之外」后面，「辅助对齐」在进度条上方右边
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// 【自动关键帧 开 / 关】
//   开 = 做动画：在预览里拖动 / 缩放 / 旋转，会在播放头这一刻自动打关键帧（和以前一样）
//   关 = 摆位置：不打关键帧，整段动画（原始值 + 这条轨道上所有关键帧）一起挪 / 缩放 / 转，动画样子不变
//   具体怎么挪在效果自己的 view-controls.js（placeShift）里；这里只把开关状态放到 window.__fxPlace 给它读。
// 【辅助对齐 开 / 关】
//   左键拖动素材时，它的左 / 中 / 右、上 / 中 / 下 靠近其他素材或画面的边、中线 6 像素以内，就吸过去并画一条对齐线。
//   按住 Alt 拖动临时不吸。效果拖动时调 window.__fxSnap(挪了多少 x, y, 画布像素/屏幕像素, 按着 Alt) 拿修正后的挪动量。

// ---------- 开关（v24.8 布局）----------
// 自动关键帧：和「关键帧之外」同一种样子（左边文字，右边「开 / 关」两个按钮），放在它后面；默认关（= 摆位置）
// 辅助对齐：小开关（一整个按钮，点一下换到另一边），放在进度条上方的右边，和提示文字同一行，不额外占地方
function pillToggle({ id, label, title, get, set }) {
  const b = document.createElement('button'); b.type = 'button'; b.id = id; b.className = 'gpill'; b.title = title;
  b.innerHTML = `<span class="gl">${label}</span><span class="gv" data-v="1">开</span><span class="gv" data-v="0">关</span>`;
  const sync = () => b.querySelectorAll('.gv').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === get()));
  b.onclick = () => { set(!get()); sync(); };
  sync(); return b;
}
let autoKey = store.get('autoKey', false), snapOn = store.get('snapOn', true);
window.__fxPlace = !autoKey;
const akEdge = document.createElement('div'); akEdge.id = 'akedge';
akEdge.title = '开 = 做动画：在预览里拖动 / 缩放 / 旋转，会在播放头这一刻自动打关键帧\n关 = 摆位置：不打关键帧，整段动画一起挪 / 缩放 / 转（先摆好位置，再打开做动画）';
akEdge.innerHTML = '<span>自动关键帧</span><button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>';
const akSync = () => akEdge.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === autoKey));
akEdge.querySelectorAll('button').forEach(x => x.onclick = () => {
  const v = x.dataset.v === '1'; if (v === autoKey) return;
  autoKey = v; window.__fxPlace = !v; store.set('autoKey', v); akSync();
  $('#hint').textContent = v ? '自动关键帧已打开：现在拖动会在这一刻打关键帧' : '摆位置模式：拖动 / 缩放 / 旋转不打关键帧，整段动画一起挪';
});
akSync(); $('#pbar').appendChild(akEdge);
const snapBtn = pillToggle({ id: 'snapbtn', label: '辅助对齐', get: () => snapOn,
  title: '拖动素材时，靠近其他素材或画面的边、中线会自动吸过去，并显示对齐线（按住 Alt 拖动临时不吸）',
  set: v => { snapOn = v; store.set('snapOn', v); } });
{ const h = $('#hint'), row = document.createElement('div'); row.id = 'hintrow'; h.before(row); row.append(h, snapBtn); }
const gst = document.createElement('style');
gst.textContent = `#akedge{display:flex;align-items:center;background:#1d1d1d;border:1px solid #333;border-radius:8px;overflow:hidden;font-size:12.5px}
#akedge span{padding:0 6px 0 11px;color:#888;white-space:nowrap}
#akedge button{border:0;padding:9px 12px;cursor:pointer;font-family:inherit;font-size:12.5px;white-space:nowrap}
#akedge button:not(.on){background:none;color:#bbb}
#akedge button:not(.on):hover{color:#fff}
#akedge button.on{background:#f28c0f;color:#111;font-weight:600}
#hintrow{position:relative}
#hintrow #snapbtn{position:absolute;right:0;top:50%;transform:translateY(-50%)}
.gpill{display:flex;align-items:center;padding:0;border:1px solid #2c2c2c;border-radius:6px;background:#1a1a1a;cursor:pointer;font-family:inherit;font-size:11px;overflow:hidden}
.gpill:hover{border-color:#555}
.gpill .gl{padding:3px 6px 3px 8px;color:#888;white-space:nowrap}
.gpill .gv{padding:3px 8px;color:#666}
.gpill .gv.on{background:#f28c0f;color:#000;font-weight:700}
html.light .gpill,html.light #akedge{background:#f4f4f4;border-color:#d0d0d0} html.light .gpill .gl{color:#666}`;
document.head.appendChild(gst);

// ---------- 辅助对齐 ----------
const snapSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
snapSvg.id = 'snapguide';
snapSvg.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;overflow:visible;pointer-events:none;z-index:99991';
box.appendChild(snapSvg);
const SNAP = 6;                                       // 屏幕上差几像素以内就吸
let snapS = null;                                     // 这一次拖动：开始时被拖素材的范围 + 可以对齐的线
function snapRectOf(el) {                             // 一个素材在预览框里（屏幕像素）看得见的范围，复用选中框的算法
  if (!el || el.style.visibility === 'hidden') return null;
  const r = sbContentRect(el); if (!r) return null;
  const pts = [[r.x0, r.y0], [r.x1, r.y0], [r.x1, r.y1], [r.x0, r.y1]].map(p => sbProject(el, p[0], p[1]));
  if (pts.some(p => !p)) return null;
  const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
  return { l: Math.min(...xs), r: Math.max(...xs), t: Math.min(...ys), b: Math.max(...ys) };
}
// 素材在画面上的缩放倍数（关键帧那一层的「大小」/ 参数里的大小）：参数里的位置挪 1，画面上挪「这个倍数」
// c 不传 = 选中的主素材（#frame）；t = 素材自己的时间
function visScale(c) {
  try {
    const cc = c || clip(tlSel); if (!cc) return 1;
    const w = c ? bcWin(c) : frame.contentWindow, ps = c ? c.params : params;
    if (!w || !w.FXKeys) return 1;
    const t = Math.max(0, tlT - cc.start + cIn(cc)), R = w.FXKeys.at(ps, t, +w.getDuration() || 0);
    const v = R.s / Math.max(0.01, +ps.scale || 1); return v > 0.01 ? v : 1;
  } catch (e) { return 1; }
}
let dragRho = 1;                                       // 这一次拖动：主素材在画面上的倍数
function snapStart() {
  const me = snapRectOf(frame); if (!me) return null;
  const W = box.clientWidth, H = box.clientHeight;
  const xs = [{ v: 0, a: 0, b: H }, { v: W / 2, a: 0, b: H }, { v: W, a: 0, b: H }];            // 画面左 / 中 / 右
  const ys = [{ v: 0, a: 0, b: W }, { v: H / 2, a: 0, b: W }, { v: H, a: 0, b: W }];            // 画面上 / 中 / 下
  const moving = new Set(tlMulti.size > 1 ? [...tlMulti] : []); if (tlSel) moving.add(tlSel);   // 一起动的素材不当目标
  TL.clips.forEach(c => {
    if (moving.has(c.id)) return;
    const r = snapRectOf(G[c.id]); if (!r) return;
    [r.l, (r.l + r.r) / 2, r.r].forEach(v => xs.push({ v, a: r.t, b: r.b }));
    [r.t, (r.t + r.b) / 2, r.b].forEach(v => ys.push({ v, a: r.l, b: r.r }));
  });
  return { me, xs, ys };
}
function snapPick(edges, lines) {                     // 被拖素材的三条线 vs 所有目标线：找最近的一对
  let best = null;
  for (const e of edges) for (const L of lines) { const d = L.v - e; if (Math.abs(d) <= SNAP && (!best || Math.abs(d) < Math.abs(best.d))) best = { d, L }; }
  return best;
}
window.__fxSnap = (dx, dy, k, alt) => {
  if (!k) return null;
  if (!snapS) { dragRho = visScale(); snapS = snapStart() || { none: true }; }
  const rho = dragRho, sx = dx / k * rho, sy = dy / k * rho;   // 参数里挪的 → 画面上实际挪的（屏幕像素）
  if (!snapOn || alt || snapS.none) { snapSvg.innerHTML = ''; liveMove(sx, sy); return null; }
  const m = snapS.me;
  const l = m.l + sx, r = m.r + sx, t = m.t + sy, b = m.b + sy;
  const bx = snapPick([l, (l + r) / 2, r], snapS.xs), by = snapPick([t, (t + b) / 2, b], snapS.ys);
  const fx = bx ? bx.d : 0, fy = by ? by.d : 0;
  let g = '';
  const line = (x1, y1, x2, y2) => `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#ff3ea5" stroke-width="1" stroke-dasharray="4 3"/>`;
  if (bx) { const x = bx.L.v; g += line(x, Math.min(bx.L.a, t + fy) - 8, x, Math.max(bx.L.b, b + fy) + 8); }
  if (by) { const y = by.L.v; g += line(Math.min(by.L.a, l + fx) - 8, y, Math.max(by.L.b, r + fx) + 8, y); }
  snapSvg.innerHTML = g;
  liveMove(sx + fx, sy + fy);
  return [(sx + fx) * k / rho, (sy + fy) * k / rho];
};
window.__fxSnapEnd = () => { snapS = null; snapSvg.innerHTML = ''; };
addEventListener('mouseup', () => { if (snapS) window.__fxSnapEnd(); });

// ---------- 多选时其他素材「实时跟着动」（v24.5） ----------
// 主素材拖动 / 滚轮缩放的过程中，其他选中的素材先在画面上临时挪 / 缩放同样多（只是 CSS，不改参数）；
// 松手后参数真正同步完（15-timeline-tools.js 的 bcCheck → ghostInit），再撤掉这层临时变换 —— 画面无缝衔接，不再「松手才跳过去」。
const live = new Map();                               // clip.id → { base: 原来的 transform, x, y, f, cx, cy }
function liveSet(c, fn) {
  const g = G[c.id]; if (!g || g.style.visibility === 'hidden') return;
  let L = live.get(c.id);
  if (!L) { const r = snapRectOf(g); L = { base: g.style.transform, x: 0, y: 0, f: 1, cx: r ? (r.l + r.r) / 2 : 0, cy: r ? (r.t + r.b) / 2 : 0 }; live.set(c.id, L); }
  fn(L);
  // 先按自己内容的中心缩放，再平移（transform-origin 是 0 0，所以手动绕中心）
  g.style.transform = `translate(${(L.x + L.cx).toFixed(2)}px,${(L.y + L.cy).toFixed(2)}px) scale(${L.f.toFixed(4)}) translate(${(-L.cx).toFixed(2)}px,${(-L.cy).toFixed(2)}px) ` + L.base;
  liveGuard();
}
function liveMove(sx, sy) { if (tlMulti.size > 1) bcOthers().forEach(c => liveSet(c, L => { L.x = sx; L.y = sy; })); }
window.__fxLive = (kind, a, b) => {                   // 效果滚轮缩放时调：('s', 改之前的大小, 改之后的大小)
  if (kind !== 's' || !(a > 0) || !(b > 0) || tlMulti.size < 2) return;
  bcOthers().forEach(c => liveSet(c, L => { L.f *= b / a; }));
};
function liveClear(id) {                              // 参数同步好了（或者放弃了）：撤掉临时变换
  const L = live.get(id); if (!L) return; live.delete(id);
  const g = G[id]; if (g) g.style.transform = L.base;
}
let liveT = 0;
function liveGuard() {                                // 保底：3 秒没同步（比如什么都没改成）就撤掉，免得画面一直歪着
  clearTimeout(liveT); liveT = setTimeout(() => [...live.keys()].forEach(liveClear), 3000);
}
// 松手后尽快同步（原来要等「撤销」那边 0.45 秒才检查一次）
Hooks.on('markDirty', () => { if (live.size) setTimeout(() => { if (live.size) histCheck(); }, 0); });

// ---------- 参考线（v35.x，和 PS 一样）：从预览窗口的上边 / 左边（鼠标靠过去出现一条细尺子）往里拖，拉出一条参考线 ----------
// 拖参考线可以挪；拖回尺子 / 拖出预览窗口 = 删掉；双击参考线 = 删掉；双击尺子 = 全部清掉；Ctrl + ; = 显示 / 隐藏。
// 位置按画面比例存（fxnav:guides），换分辨率也在同一个地方；只在工作台里看，不会导出。
// 垫了原视频、比例又和画面不一样时，自动画一个橙色虚线框 = 原视频那块范围（导出尺寸不变，只是提醒框外放回原视频时看不到）。
{
  const box = $('#box'); let G = store.get('guides', []), show = store.get('guidesOn', true);
  const ov = document.createElement('div'); ov.id = 'guides';
  ov.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:9500';
  box.appendChild(ov);
  const rul = (v) => { const r = document.createElement('div'); r.className = 'gd-rul'; r.dataset.v = v ? 1 : '';
    r.style.cssText = `position:absolute;${v ? 'left:0;top:0;bottom:0;width:10px;cursor:ew-resize' : 'left:0;top:0;right:0;height:10px;cursor:ns-resize'};pointer-events:auto;z-index:9600;background:rgba(76,194,255,0);transition:background .15s`;
    r.title = '往里拖 = 拉一条参考线（双击 = 清掉全部参考线）';
    r.onmouseenter = () => r.style.background = 'rgba(76,194,255,.35)'; r.onmouseleave = () => r.style.background = 'rgba(76,194,255,0)';
    r.onmousedown = e => { if (e.button !== 0) return; e.preventDefault(); e.stopPropagation(); const g = { v: !!v, p: 0 }; G.push(g); drag(g, e); };
    r.ondblclick = e => { e.stopPropagation(); G = []; save(); draw(); toast('参考线已全部清掉'); };
    box.appendChild(r); return r; };
  rul(true); rul(false);
  const save = () => store.set('guides', G);
  const tip = document.createElement('div'); tip.style.cssText = 'position:absolute;z-index:9700;pointer-events:none;background:#4cc2ff;color:#111;font:600 11px/16px sans-serif;padding:0 5px;border-radius:3px;display:none';
  box.appendChild(tip);
  function drag(g, e0) {
    const R = box.getBoundingClientRect(), { w, h } = res();
    const mv = e => {
      const p = g.v ? (e.clientX - R.left) / R.width : (e.clientY - R.top) / R.height;
      g.p = Math.round(Math.min(1.02, Math.max(-0.02, p)) * 10000) / 10000; g.out = p < 0.008 || p > 0.992;   // 拖回边上 / 拖出去 = 要删
      draw();
      tip.style.display = ''; tip.textContent = g.out ? '松手删掉' : (g.v ? 'X ' : 'Y ') + Math.round(g.p * (g.v ? w : h)) + ' px';
      tip.style.left = (e.clientX - R.left + 12) + 'px'; tip.style.top = (e.clientY - R.top + 12) + 'px';
    };
    const up = () => { removeEventListener('mousemove', mv, true); removeEventListener('mouseup', up, true); tip.style.display = 'none'; if (g.out) G = G.filter(x => x !== g); delete g.out; save(); draw(); };
    addEventListener('mousemove', mv, true); addEventListener('mouseup', up, true); mv(e0);
    if (!show) { show = true; store.set('guidesOn', true); }
  }
  function draw() {
    ov.innerHTML = ''; ov.style.display = show ? '' : 'none';
    G.forEach(g => {
      const l = document.createElement('div'), pc = (g.p * 100).toFixed(3) + '%';
      l.style.cssText = g.v ? `position:absolute;top:0;bottom:0;left:${pc};width:9px;margin-left:-4px;cursor:ew-resize;pointer-events:auto`
        : `position:absolute;left:0;right:0;top:${pc};height:9px;margin-top:-4px;cursor:ns-resize;pointer-events:auto`;
      l.innerHTML = `<i style="position:absolute;${g.v ? 'left:4px;top:0;bottom:0;width:1px' : 'top:4px;left:0;right:0;height:1px'};background:${g.out ? '#ff5a5a' : '#4cc2ff'}"></i>`;
      l.title = '拖动挪位置 · 拖出预览窗口或双击 = 删掉';
      l.onmousedown = e => { if (e.button !== 0) return; e.preventDefault(); e.stopPropagation(); drag(g, e); };
      l.ondblclick = e => { e.stopPropagation(); G = G.filter(x => x !== g); save(); draw(); };
      ov.appendChild(l);
    });
    // 原视频比例和画面不一样：画出导出时会留下的范围（橙色虚线 + 小字）
    const { w, h } = res();
    if (typeof REF !== 'undefined' && REF && REF.w > 0 && REF.h > 0 && Math.abs(REF.w / REF.h - w / h) > 0.02) {
      const ar = REF.w / REF.h, fx = ar < w / h ? h * ar / w : 1, fy = ar < w / h ? 1 : w / ar / h;
      const a = document.createElement('div');
      a.style.cssText = `position:absolute;left:${(1 - fx) / 2 * 100}%;top:${(1 - fy) / 2 * 100}%;width:${fx * 100}%;height:${fy * 100}%;border:1px dashed rgba(242,140,15,.85);box-sizing:border-box;pointer-events:none`;
      a.innerHTML = `<span style="position:absolute;left:4px;top:3px;font:11px sans-serif;color:#f2a33d;text-shadow:0 0 3px #000">原视频 ${REF.w}×${REF.h} 的范围（放回原视频时，框外面看不到）</span>`;
      ov.appendChild(a);
    }
  }
  addEventListener('keydown', e => {
    if (!(e.ctrlKey || e.metaKey) || e.key !== ';') return; e.preventDefault();
    show = !show; store.set('guidesOn', show); draw(); toast(show ? '参考线：显示' : '参考线：隐藏（Ctrl + ; 再按一次显示）');
  });
  let lastRef = '';
  setInterval(() => { const k = (typeof REF !== 'undefined' && REF ? REF.w + 'x' + REF.h : '') + '|' + res().w + 'x' + res().h; if (k !== lastRef) { lastRef = k; draw(); } }, 1000);
  draw();
}
