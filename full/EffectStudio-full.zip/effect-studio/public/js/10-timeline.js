// 效果工坊 · 素材时间线：数据 · 叠加 iframe · 画面 · 选中 · 播放 · 画时间线 · 鼠标 · 按钮
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 素材时间线（v10.2，组合 v10.4） =================
// 时间线上没有素材时，工作台和以前一模一样（下面所有挂钩都先判断 TL.clips.length）。
// 每个素材 = 一个效果 + 它自己的一份参数 + 开始时间 + 层。
// 选中的素材用原来的 #frame（右侧参数面板、关键帧、持续时间都照旧管它）；其余素材各开一个透明 iframe 叠在 #box 里。
let TR = Math.max(22, Math.min(96, +store.get('tlRowH', 30) || 30)); const RUL = 18;   // TR = 每一层的高度，在层名下沿上下拖可以改（v33.0，23-row-height.js）
const COLORS = ['#c9cfd8', '#5fb3b3', '#6d9cf0', '#7dc58c', '#d4a24c', '#d9806e', '#c7b07a', '#a98be0'];
const TL = { clips: [], groups: [] };
let tlKeepT = false, tlSel = null, tlT = 0, tlV = 10, tlLoading = false, tlPreview = true, tlInSel = false, tlInside = false, tlRaf = 0, tlQ = [], tlDragS = null, tlMulti = new Set(), tlGrp = null, tlIn = null, baseTf = '', tlEmbF = null;   // tlIn = 双击「进到里面」正在改的组合（v12.1）
const grp = id => TL.groups.find(g => g.id === id);
// v60.0 嵌在别的素材里的拷贝（28-fx-ref.js，c.embedIn = 父素材 id）：不占轨道、不进组合，画面由父素材自己画。
// tlEmbF = 「双击进到里面」时的父素材 id：时间线只列它的子素材，预览只显示选中的子素材；选中的不再是它的子素材就自动退出来。
const embP = c => (c && c.embedIn ? TL.clips.find(o => o.id === c.embedIn) || null : null);
const embF = () => { if (tlEmbF) { const c = TL.clips.find(o => o.id === tlSel); if (!c || c.embedIn !== tlEmbF || !embP(c)) tlEmbF = null; } return tlEmbF; };
const G = {};                                       // clip.id → 叠加用的 iframe
const clone = o => JSON.parse(JSON.stringify(o == null ? {} : o));
const clip = id => TL.clips.find(c => c.id === id);
const fxOf = c => effects.find(e => e.id === c.fx);
const fxName0 = c => { const f = c && fxOf(c); return f ? f.name : c ? c.fx : ''; };
const colorOf = fx => { let h = 0; for (const ch of fx) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; };
var REF = null, tlZ = 1, rvSpan = 0;               // rvSpan：拖原视频结尾时临时把时间线拉到原视频剩下的全长（v19.0）                            // tlZ = 素材时间线放大倍数（v17.0）                                     // 原视频（v16.0）：{ url, name, vdur, in, out }，见下面【原视频】
function refLen() { return REF ? Math.max(0, REF.out - REF.in) : 0; }
const tlEnd = () => TL.clips.reduce((m, c) => Math.max(m, c.start + (c._len != null ? c._len : c.len)), refLen());
const panel = document.createElement('div'); panel.id = 'tlp';
panel.innerHTML = '<div id="tlp-h"><b>素材时间线</b><span id="tlp-time"></span><i id="tlp-k" title="点一下看完整的快捷键说明\n\n空格　播放 / 暂停\nDelete　删除选中的素材\nCtrl+A　全选素材\nCtrl+C / Ctrl+V　复制选中的素材 / 组合，粘贴到播放头那一秒（独立的一份）\nCtrl+D　原地复制一份\nCtrl / Shift + 点击　多选素材\nCtrl+G（或 Ctrl+Shift+C）　把选中的素材合成一个组合（预合成）\nCtrl+Shift+G　解散组合\nEsc　取消选中组合 / 多选\nCtrl+]　/　Alt+↑　上移一层\nCtrl+[　/　Alt+↓　下移一层\n← →　选中的素材前后挪 0.1 秒（加 Shift 是 1 秒）\nHome / End　跳到开头 / 结尾\nQ　剪掉选中素材播放头前面那一段\nW　剪掉选中素材播放头后面那一段\nC　在播放头处把选中素材剪成两段\n\n鼠标：把左边的效果拖到预览窗口或这里 = 加素材；拖素材条换时间 / 换层；拖右边缘改时长；点空白处跳时间">⌨ 快捷键</i></div>' +
  '<div id="tlp-e"></div><div id="tlp-b"><div id="tlp-names"></div><div id="tlp-t" tabindex="0"></div></div>';
$('main').insertBefore(panel, $('#kft'));
const trk = $('#tlp-t'), names = $('#tlp-names');
// v38.0：时间线有了自己的竖向滚动条（24-tl-split.js 限制 #tlp-sc 的高度），这里按「不限高时有多高」算，预览大小不跟着滚动框变
window.tlFitH = () => { if (!(TL.clips.length || REF)) return 0; const sc = document.getElementById('tlp-sc'); return panel.offsetHeight + 12 + (sc ? sc.scrollHeight - sc.clientHeight : 0); };
// 时间线竖着滚了多少（刻度尺跟着往下挪这么多，一直贴在顶上）
const tlSY = () => { const sc = document.getElementById('tlp-sc'); return sc ? sc.scrollTop : 0; };

// ---------- 保存 / 恢复（存在这台电脑的浏览器里） ----------
let saveT = 0;
const tlSave = () => { clearTimeout(saveT); saveT = setTimeout(() => store.set('timeline', { clips: TL.clips.map(c => { const o = Object.assign({}, c); delete o._len; return o; }), groups: TL.groups, sel: tlSel, t: tlT }), 400); };

// ---------- 叠加 iframe ----------
// v43.0 剪辑（25-tl-cut.js）：c.ci = 素材前面剪掉了效果的多少秒，c.co = 后面剪掉多少秒。
// 时间线上看到的长度 = 效果总时长 − ci − co；效果的第 0 秒在时间线上的位置 = c.start − ci。
const cIn = c => +(c && c.ci) || 0, cOut = c => +(c && c.co) || 0;
const cLen = (c, d) => r2(Math.max(0.05, d - cIn(c) - cOut(c)));
function ghost(c) {
  let g = G[c.id];
  if (!g) {
    g = document.createElement('iframe'); g.className = 'tlg'; g.tabIndex = -1; G[c.id] = g;
    g.style.width = frame.style.width; g.style.height = frame.style.height; g.style.transform = baseTf || frame.style.transform;
    // v11.2：套一层 ghost.html —— 效果直接挂在工作台下面的话，它的拖动 / 缩放监听会把「选中素材」的抢走（见 ghost.html 开头）
    g.src = '/ghost.html?fx=' + encodeURIComponent(c.fx);
    g.onload = () => { try { if (!g.contentWindow.init) return; } catch (e) { return; } g._ok = true; ghostInit(c); };
    box.insertBefore(g, frame);
  }
  return g;
}
function ghostInit(c) {
  const g = G[c.id]; if (!g || !g._ok) return;
  try { const w = g.contentWindow; w.init(clone(c.params)); const d = +w.getDuration(); if (d > 0 && c.id !== tlSel) c.len = cLen(c, d); } catch (e) { console.error(e); }
  tlRender(); tlDraw();
}
function dropGhost(id) { const g = G[id]; if (g) { g.remove(); delete G[id]; } }

// ---------- 画面：把全局时间 tlT 分给每个素材 ----------
// v51.0 轨道：同一层（轨道）里按 开始时间 → 组内层号 → 自己的开始 排；组合里的素材都在组合那一条轨道上，谁盖谁看组内层号 c.sub
function zOf(c) {
  const gs = new Map(), k0 = o => { if (!o.group) return o.start; if (!gs.has(o.group)) { const g = grp(o.group); gs.set(o.group, g ? gRange(g)[0] : o.start); } return gs.get(o.group); };
  const same = TL.clips.filter(o => o.layer === c.layer).map(o => [o, k0(o), o.group ? (o.sub || 0) : 0]).sort((a, b) => a[1] - b[1] || a[2] - b[2] || a[0].start - b[0].start).map(x => x[0]);
  return 10 + c.layer * 100 + same.indexOf(c);
}
function tlRender() {
  if (!TL.clips.length) { frame.style.visibility = typeof emptyShowFrame !== 'function' || emptyShowFrame() ? '' : 'hidden'; frame.style.zIndex = ''; return; }   // 时间线为空：只有在左侧点过效果才露出来（19-empty-state.js）
  const T = tlT, F = embF();
  TL.clips.forEach(c => {
    if (c.embedIn && c.id !== tlSel && embP(c)) { if (G[c.id]) dropGhost(c.id); return; }   // v60.0 嵌在父素材里：父素材自己画，不单独开叠加页面
    const pp = c.id === tlSel && embP(c), loc = T - c.start, vis = loc >= -0.0001 && loc <= (pp ? Math.max(c.len, pp.start + pp.len - c.start) : c.len) + 0.0001, z = zOf(c);   // v61.0 嵌着的拷贝：和合成画面一样，播完停在「出」一直到父素材结束
    if (c.id === tlSel) {
      const g = G[c.id]; if (g) g.style.visibility = 'hidden';
      frame.style.zIndex = z; frame.style.visibility = vis && !tlLoading && (!c.hide || F) ? '' : 'hidden';   // 进到子素材里面（F）：眼睛关着也显示它自己
      applyTf(frame, c);
      if (vis && !tlLoading) { tlInside = true; try { seek(Math.max(0, Math.min(loc + cIn(c), dur, c.embedIn && typeof __fxEmbStop === 'function' ? __fxEmbStop(c) : Infinity))); } catch (e) { } tlInside = false; }   // v60.0 嵌着的拷贝：和合成画面一样停在「出」
    } else {
      // v35.x 省内存：只给播放头前 30 秒 ~ 后 10 秒内的素材留着效果页面，其余卸掉（走近时提前装好，播放不等）。
      // 装 / 卸的范围错开一点（装：前 30 后 10；卸：前 45 后 25），播放头在边上来回拖时不会反复装卸。
      const g0 = G[c.id];
      if (loc < (g0 ? -45 : -30) || loc > c.len + (g0 ? 25 : 10)) { if (g0) dropGhost(c.id); return; }
      const g = ghost(c); g.style.zIndex = z; g.style.visibility = vis && !c.hide && !F ? '' : 'hidden'; applyTf(g, c);   // 眼睛关了 = 不显示；进到子素材里面 = 别的都不显示
      if (vis && !F && g._ok) { try { g.contentWindow.renderAt(Math.max(0, Math.min(loc, c.len)) + cIn(c)); } catch (e) { } }
    }
  });
  if (!tlSel) { frame.style.zIndex = 9000; frame.style.visibility = tlPreview ? '' : 'hidden'; if (frame._tf) { frame.style.transform = baseTf; frame.style.opacity = ''; frame._tf = 0; } }
}
function tlSeek(T) { tlSeekTo(T); Hooks.run('tlSeek'); }
// 没选中素材时，上面的进度条显示整条时间线的时间（选中了素材时进度条是它自己的时间，由 seek 负责）
const tlBarSync = () => {
  if (tlSel || !TL.clips.some(c => !c.ref)) return;
  const E = Math.max(0.01, tlEnd()); slider.max = E; slider.value = tlT; $('#tl').textContent = tlT.toFixed(1) + ' / ' + E.toFixed(1) + ' s';
};
Hooks.on('tlSeek', tlBarSync); Hooks.on('tlDraw', tlBarSync); Hooks.on('seek', tlBarSync);   // 后台那个效果自己播的时候也别把进度条抢走
function tlSeekTo(T) { tlT = Math.max(0, r2(T)); tlRender(); headPos(); if (tlGrp) gpSync(); tlSave(); }
function headPos() { headPosTrack(); Hooks.run('headPos'); }
function headPosTrack() {
  const h = trk.querySelector('.tlhd'); if (h) h.style.left = Math.min(100, tlT / tlV * 100) + '%';
  $('#tlp-time').textContent = tlT.toFixed(2) + ' / ' + tlEnd().toFixed(2) + ' s';
}

// ---------- 选中素材 = 把它装进原来的 #frame，右侧面板就是它的参数 ----------
function syncSel() {
  const c = clip(tlSel); if (!c || tlLoading || !cur || cur.id !== c.fx) return;
  c.params = clone(params); if (dur > 0) c.len = cLen(c, dur); tlSave();
}
function commitSel() {                               // 离开当前选中的素材：参数存回去，交给它自己的叠加 iframe
  const c = clip(tlSel); if (!c) return;
  syncSel(); const g = ghost(c); if (g._ok) ghostInit(c);
}
function tlSelect(id, keepMulti) {
  const c = clip(id); if (!c) return;
  if (!keepMulti) tlMulti = new Set([id]);
  tlIn = c.group || null;                            // 选中组合里的素材 = 在组合里面改它
  if (tlGrp) { tlGrp = null; gpBuild(); }
  if (tlSel === id) { tlDraw(); return; }
  tlStop(); commitSel();
  tlSel = id; tlPreview = false;
  // v50.0 用户要求：选中素材时播放头一律不动（要跳到素材头尾用 ↑ / ↓，见 15-timeline-tools.js【跳到剪辑点】）
  tlLoading = true; tlRender();
  if (cur && cur.id === c.fx && frame.contentWindow && frame.contentWindow.init) {
    params = clone(c.params); buildParams(); histReset(); reinit(false);
  } else {
    tlInSel = true; select(c.fx); tlInSel = false;
    params = clone(c.params); buildParams(); histReset();   // 页面加载完 frame.onload → reinit 用的就是这份参数
  }
  tlDraw();
}
const frameIs = fx => { try { return frame.contentWindow.location.pathname.indexOf('/effects/' + fx + '/') >= 0; } catch (e) { return false; } };
function whenReady(fn) { tlLoading ? tlQ.push(fn) : fn(); }

// ---------- 接到工作台原来的流程上（没有素材时原样放行） ----------
Hooks.on('reinit:before', ctx => { ctx.clip = tlLoading && clip(tlSel); if (ctx.clip) ctx.play = false; });   // 素材正在装进 #frame：先别自动播放
Hooks.on('reinit', ctx => {
  const c = ctx.clip;
  if (c && frameIs(c.fx) && cur && cur.id === c.fx) {
    tlLoading = false; if (dur > 0) c.len = cLen(c, dur);
    tlRender(); tlDraw();
    const q = tlQ; tlQ = []; q.forEach(f => f());
  }
});
Hooks.on('seek', t => {
  if (tlInside || !tlSel || tlLoading || !TL.clips.length) return;
  const c = clip(tlSel); if (!c) return;
  tlT = r2(c.start + t - cIn(c));                             // 用原来的播放 / 进度条时，别的素材跟着走
  TL.clips.forEach(o => {
    if (o.id === tlSel) return;
    const g = G[o.id]; if (!g) return; const loc = tlT - o.start, vis = loc >= 0 && loc <= o.len;
    g.style.visibility = vis ? '' : 'hidden'; applyTf(g, o); if (vis && g._ok) { try { g.contentWindow.renderAt(loc + cIn(o)); } catch (e) { } }
  });
  applyTf(frame, c); headPos(); if (tlGrp) gpSync();
});
Hooks.on('markDirty', () => { if (tlSel && !tlLoading) { syncSel(); drawSoon(); } });
Hooks.on('select:before', () => { if (!tlInSel && TL.clips.length) { tlStop(); commitSel(); tlSel = null; tlPreview = true; } });
Hooks.on('select', () => { tlRender(); tlDraw(); });
Hooks.on('stop', () => { if (!tlPlaying) tlStop(); });
let lastSz = '';
Hooks.on('fit', () => {          // 其余素材的叠加 iframe 跟着 #frame 一起缩放（窗口大小变了也会走这里）
  const sz = frame.style.width + 'x' + frame.style.height;
  baseTf = frame.style.transform; frame._tf = 0;
  Object.keys(G).forEach(id => { const g = G[id]; g.style.width = frame.style.width; g.style.height = frame.style.height; g.style.transform = baseTf; g._tf = 0; });
  if (sz !== lastSz) { const first = !lastSz; lastSz = sz; if (!first) TL.clips.forEach(c => { if (c.id !== tlSel) ghostInit(c); }); }
  if (TL.groups.length) tlRender();
});

// ---------- 播放整条时间线 ----------
let tlPlaying = false;
function tlStop() { tlStopPlay(); Hooks.run('tlStop'); }
function tlStopPlay() { cancelAnimationFrame(tlRaf); tlRaf = 0; if (tlPlaying) { tlPlaying = false; ppTxt(); } tlSetRate(1); }   // 停下 = 倍速回到 1 倍（再按空格是正常速度）
// 倍速（v33.x）：L 键 2 → 4 → 8 倍，和剪辑软件一样；tlPB = 这一段从时间线第几秒、哪个时刻开始按 tlRate 走
let tlRate = 1, tlPB = null;
function tlSetRate(r) {
  if (tlPB) { tlPB.from = tlT; tlPB.t0 = performance.now(); }      // 改倍速时从当前这一秒接着走，不跳
  tlRate = r; const b = $('#tl-rate'); if (b) b.style.display = r > 1 && tlPlaying ? '' : 'none', b.firstChild.textContent = '▶▶ ' + r + ' 倍速 ';
  try { rvSync(); } catch (e) {}
}
function tlFaster() { if (!tlPlaying) { tlPlay(); tlSetRate(2); } else tlSetRate(Math.min(8, tlRate * 2)); }
function tlPlay() {
  if (tlPlaying) { tlStop(); return; }
  const end = tlEnd(); if (!end) return;
  stop(); tlPlaying = true; ppTxt();
  tlPB = { from: tlT >= end - 0.02 ? 0 : tlT, t0: performance.now() };
  const tick = n => { const T = tlPB.from + Math.max(0, n - tlPB.t0) / 1000 * tlRate; tlSeek(Math.min(T, end)); if (T < end && tlPlaying) tlRaf = requestAnimationFrame(tick); else tlStop(); };
  tlRaf = requestAnimationFrame(tick);
}
{ // 标题栏上的倍速提示：「▶▶ 4 倍速 ✕」，点 ✕ 回到正常速度
  const b = document.createElement('span'); b.id = 'tl-rate'; b.style.cssText = 'display:none;margin-left:10px;padding:1px 8px;border-radius:10px;background:#f2a33d;color:#111;font-size:12px;font-weight:600';
  b.innerHTML = '▶▶ 2 倍速 <i style="cursor:pointer;font-style:normal;margin-left:4px" title="回到正常速度">✕</i>';
  b.querySelector('i').onclick = () => tlSetRate(1);
  $('#tlp-time').after(b);
}
const ppTxt = () => ppSync();                        // 播放按钮显示「播放 / 暂停」也跟着时间线（v24.11）

// ---------- 画时间线 ----------
// 行：最上面一条「新层」，然后从最上层往下。
// v51.0 所有轨道都能自由放素材：一个组合就像一个素材，只占一条轨道（组合条画在轨道里），时间不重叠就能和普通素材、别的组合放在同一条。
// 组合展开时，在它那条轨道下面临时列出组内的几层（{ t:'sub', L, g, s }），折叠后只剩轨道那一行。
function buildRows() {
  const F = embF(), fp = F && clip(F);
  if (fp) return [{ t: 'emb', L: fp.layer, p: fp.id, f: true }];   // v60.0 进到子素材里面：只有一行
  const top = TL.clips.length ? Math.max(...TL.clips.map(c => c.layer)) : -1;
  const R = [{ t: 'new', L: top + 1 }];
  for (let L = top; L >= 0; L--) {
    R.push({ t: 'layer', L });
    const gids = [...new Set(TL.clips.filter(c => c.layer === L && c.group).map(c => c.group))].filter(id => grp(id) && !grp(id).col).sort((a, b) => gRange(grp(a))[0] - gRange(grp(b))[0]);
    gids.forEach(id => { const mx = Math.max(0, ...TL.clips.filter(c => c.group === id).map(c => c.sub || 0)); for (let k = mx; k >= 0; k--) R.push({ t: 'sub', L, g: id, s: k }); });
  }
  // v60.0 父素材条上点 ▸ 展开：它那一行下面多一行，列出嵌在它里面的拷贝
  TL.clips.filter(p => p.embOpen && !p.embedIn && TL.clips.some(c => c.embedIn === p.id) && !(p.group && grp(p.group) && grp(p.group).col)).sort((a, b) => a.start - b.start).forEach(p => {
    let i = rowIdx(R, p.layer, p); while (i + 1 < R.length && R[i + 1].t === 'emb') i++;
    R.splice(i + 1, 0, { t: 'emb', L: p.layer, p: p.id });
  });
  return R;
}
const rowIdx = (R, L, c) => {
  let i = -1;
  if (c && c.group) i = R.findIndex(r => r.t === 'sub' && r.g === c.group && r.s === (c.sub || 0));
  if (i < 0) i = R.findIndex(r => r.t === 'layer' && r.L === L);
  return i >= 0 ? i : 0;
};
// 每一行多高（v33.1）：层可以单独调高 / 调矮（23-row-height.js 的 rowHeightOf），其余行用默认 TR
const rowHOf = r => (typeof rowHeightOf === 'function' ? rowHeightOf(r) : TR);
function rowTops(R) { const Y = []; let y = 0; R.forEach(r => { Y.push(y); y += rowHOf(r); }); Y.push(y); return Y; }   // Y[i] = 第 i 行顶部，Y[R.length] = 总高
const rowAt = (R, y) => { const Y = rowTops(R), d = y - W().top - RUL; for (let i = 0; i < R.length; i++) if (d < Y[i + 1]) return R[i]; return R[R.length - 1]; };
const rowLayer = r => r.L;
let drawT = 0; const drawSoon = () => { clearTimeout(drawT); drawT = setTimeout(tlDraw, 80); };
function tlDraw() { drawTrack(); Hooks.run('tlDraw'); }
// v44.2 修：素材条最短宽度以前是「整条时间线的 0.4%」—— 原视频很长（16 分钟）又放大以后，0.4% 能有好几百像素，
// 短素材被画得比真实时长宽得多，旗子跟着画错位置（「出」看着还在后面，画面已经没了）。现在最短只保留 6 像素。
function drawTrack() {
  const has = TL.clips.length > 0 || !!REF;
  $('#tlp-e').hidden = has; $('#tlp-b').style.display = has ? '' : 'none';
  $('#tlp-e').textContent = '还没有素材：把左边的效果直接拖到上面的预览窗口（或拖到这里），它就出现在时间线上；再拖别的效果进来，就一层一层叠上去。';
  if (!has) { trk.innerHTML = ''; names.innerHTML = ''; headPos(); if (lastPH) { lastPH = 0; fit(); } return; }
  if (!tlDragS) {                                     // 时间线刻度（v24.6）：变长时一次多留些余量，变短时不急着缩 —— 拉长 / 拉短素材时整条时间线不再跟着跳
    const need = Math.max(10, Math.ceil(Math.max(tlEnd(), rvSpan) * 1.12));
    if (need > tlV) tlV = Math.max(need, Math.ceil(Math.max(tlEnd(), rvSpan) * 1.3));
    else if (need < tlV * 0.5) tlV = need;             // 内容短到不到一半（比如删了素材）才缩回来
  }
  const R = tlDragS && tlDragS.R ? tlDragS.R : buildRows(), V = tlV, F = embF();
  const Y = rowTops(R);
  trk.style.height = RUL + Y[R.length] + 'px';
  let h = '<div class="tlrul notranslate" translate="no">';   // 不让翻译插件（沉浸式翻译等）翻刻度：每次重画都会在「0s / 1s…」后面挂一个转圈图标
  const step = [0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300].find(s => V / s <= 14 * tlZ) || 600;
  for (let t = 0; t <= V + 0.001; t += step) h += '<div class="tltk" style="left:' + t / V * 100 + '%">' + (t >= 60 ? Math.floor(t / 60) + ':' + String(Math.round(t % 60)).padStart(2, '0') : +t.toFixed(1) + 's') + '</div>';
  h += '</div>';
  let nm = '';
  R.forEach((r, i) => {
    const vh = '--tlr:' + rowHOf(r) + 'px';            // 这一行的高度：行、层名、素材条、旗子都按它（CSS 里用 var(--tlr)）
    h += '<div class="tlrow' + (r.t === 'new' ? ' nw' : r.g || r.t === 'emb' ? ' ing' : '') + '" style="top:' + (RUL + Y[i]) + 'px;' + vh + '"></div>';
    nm += r.t === 'new' ? '<div class="nw" style="' + vh + '">新层</div>'
      : r.t === 'emb' ? '<div class="gm" style="' + vh + '" title="嵌在「' + esc(fxName0(clip(r.p))) + '」里的素材">└ ' + esc(fxName0(clip(r.p))) + ' 里面</div>'
      : r.t === 'sub' ? '<div class="gm" style="' + vh + '" title="组合「' + esc((grp(r.g) || {}).name || '') + '」里的第 ' + (r.s + 1) + ' 层">└ ' + esc((grp(r.g) || {}).name || '组合') + ' · ' + (r.s + 1) + '</div>'
      : '<div style="' + vh + '">' + (typeof lyBtns === 'function' ? lyBtns(r.L) : '') + '层 ' + (r.L + 1) + '</div>';   // 眼睛 / 锁：20-layer-lock.js
  });
  if (!F) TL.groups.forEach(g => {                           // 组合条：画在组合所在的那条轨道里，和普通素材一样
    const [gs, ge, m] = gRange(g); if (!m.length) return;
    const i = rowIdx(R, m[0].layer), vh = '--tlr:' + rowHOf(R[i]) + 'px';
    let dm = ''; if (g.anim) g.keys.forEach(k => dm += '<b class="tlgk" style="left:' + (k.t / Math.max(0.01, ge - gs) * 100) + '%"></b>');
    h += '<div class="tlgb' + (g.id === tlGrp ? ' on' : '') + (g.id === tlIn ? ' in' : '') + '" data-g="' + g.id + '" style="top:' + (RUL + Y[i] + 3) + 'px;' + vh + ';left:' + gs / V * 100 + '%;width:max(6px,' + (ge - gs) / V * 100 + '%)" title="' + esc(g.name) + '：点一下选中整个组合（预览区拖动 / 旋转 / 关键帧都是整组的）；双击进到里面改单个素材；拖动 = 换时间 / 换轨道（和普通素材一样）">' +
      '<span class="tgt" title="' + (g.col ? '展开看里面的素材' : '折叠成一条') + '">' + (g.col ? '▸' : '▾') + '</span>▣ ' + esc(g.name) + '<i>' + m.length + ' 个素材</i>' + dm + '</div>';
  });
  TL.clips.forEach(c => {
    const g = c.group && grp(c.group); if (g && g.col) return;
    if (F ? c.embedIn !== F : c.embedIn && embP(c) && !R.some(r => r.t === 'emb' && r.p === c.embedIn)) return;   // v60.0 嵌着的拷贝只画在父素材展开的那一行
    const ri = c.embedIn && embP(c) ? R.findIndex(r => r.t === 'emb' && r.p === c.embedIn) : rowIdx(R, c.layer, c), len = c._len != null ? c._len : c.len, top = RUL + Y[ri] + 3;
    const f = fxOf(c), nmx = esc(f ? f.name : c.fx);
    h += '<div class="tlc' + (c.id === tlSel && !tlGrp ? ' on' : '') + (tlMulti.has(c.id) && tlMulti.size > 1 ? ' ms' : '') + (g ? ' ing' : '') + (c.lock ? ' lk' : '') + (c.hide ? ' hd' : '') + (c.embedIn ? ' emb' : '') + '" data-id="' + c.id + '" style="top:' + top + 'px;--tlr:' + rowHOf(R[ri]) + 'px;left:' + c.start / V * 100 + '%;width:max(6px,' + len / V * 100 + '%);background:' + colorOf(c.fx) + '" title="' + nmx + '　' + c.start.toFixed(2) + ' → ' + (c.start + len).toFixed(2) + ' 秒（' + len.toFixed(2) + ' 秒）' + (c.embedIn ? '\n嵌在父素材里的拷贝：点一下改它的参数（预览照样是整个画面），左右拖 = 改开始时间，拉右边 = 改时长，双击进到它里面' : '') + '">' + (!c.embedIn && !F && TL.clips.some(o => o.embedIn === c.id) ? '<span class="tlemb" title="' + (c.embOpen ? '收起嵌在里面的素材' : '展开：看嵌在里面的素材') + '">' + (c.embOpen ? '▾' : '▸') + '</span>' : '') + nmx + '<i>' + len.toFixed(1) + 's</i><div class="tlr" title="拖动改时长"></div></div>';
  });
  h += '<div class="tlhd"></div>';
  trk.innerHTML = h; names.innerHTML = nm; headPos();
  if (panel.offsetHeight !== lastPH) { lastPH = panel.offsetHeight; fit(); }
}
let lastPH = 0;

// ---------- 鼠标 ----------
const W = () => trk.getBoundingClientRect();
const xT = x => { const r = W(); return Math.max(0, (x - r.left) / r.width * tlV); };
// v35.x 磁吸开关（时间线标题栏的小磁铁按钮，15-timeline-tools.js）；关掉 = 拖动 / 拉长都不吸
let tlMag = store.get('tlMag', true), tlMagHit = null;
// 吸上了：在吸住的那一秒画一条竖线（和剪映一样），不再弹提示；x = 吸住的那个时间点，null = 没吸住（线藏起来）
let tlSnapX = null;   // 当前吸住的时间点（拖动时时间线会重画，重画后按它把线补回来）
Hooks.on('tlDraw', () => { if (tlSnapX != null) snapFx(tlSnapX); });
function snapFx(x) {
  let ln = trk.querySelector('#tl-snapln'); tlSnapX = x == null ? null : x;
  if (x == null) { if (ln) ln.style.display = 'none'; tlMagHit = null; return; }
  if (!ln) { ln = document.createElement('div'); ln.id = 'tl-snapln'; ln.style.cssText = 'position:absolute;top:0;bottom:0;width:1px;margin-left:-0.5px;background:#4cc2ff;box-shadow:0 0 4px #4cc2ff;z-index:40;pointer-events:none'; }
  if (ln.parentNode !== trk) trk.appendChild(ln);
  ln.style.left = Math.max(0, Math.min(100, x / tlV * 100)) + '%'; ln.style.display = '';
  tlMagHit = r2(x);
}
function snap(ex, s, len) {                          // 吸附：别的素材的头尾、播放头、0 秒（6 像素以内）
  if (!tlMag) return Math.max(0, r2(s));
  const tol = 6 / W().width * tlV; let best = s, d0 = tol;
  const pts = [0, tlT]; TL.clips.forEach(o => { if (!ex.has(o.id)) pts.push(o.start, o.start + o.len); });
  pts.forEach(p => { if (Math.abs(p - s) < d0) { d0 = Math.abs(p - s); best = p; } if (Math.abs(p - (s + len)) < d0) { d0 = Math.abs(p - s - len); best = p - len; } });
  const tolH = 10 / W().width * tlV;                 // v21.0：播放头吸得更远一点（10 像素），方便「拖到播放头」
  if (best === s) { if (Math.abs(tlT - s) < tolH) best = tlT; else if (Math.abs(tlT - s - len) < tolH) best = tlT - len; }
  // 吸住的是哪一个点：开头对上某个点就是开头，不然就是结尾
  snapFx(best === s ? null : (Math.abs(best - tlT) < 1e-6 || pts.some(p => Math.abs(p - best) < 1e-6) ? best : best + len));
  return Math.max(0, r2(best));
}
// 放到某一层：那一层同一时间段已经有东西，就不挤在一起，而是插成新的一层（往上去 → 插在它上面，往下去 → 插在它下面）
// v51.0 「一块」= 一个普通素材，或者一整个组合（组合的所有成员都在同一条轨道上，占的时间 = 组合从头到尾）
const overlaps = (a, b) => a !== b && a.start < b.start + b.len - 0.001 && b.start < a.start + a.len - 0.001;
const unitOf = c => c.group && grp(c.group) ? TL.clips.filter(o => o.group === c.group) : [c];
const spanOf = c => c.group && grp(c.group) ? gRange(grp(c.group)) : [c.start, c.start + c.len];
function busyAt(L, a, b, ex) {                       // 第 L 条轨道在 a~b 这段时间有没有别的东西（ex = 不算的素材 id）
  return TL.clips.some(o => o.layer === L && !ex.has(o.id) && !o.ref && !o.embedIn && (([x, y]) => a < y - 0.001 && x < b - 0.001)(spanOf(o)));
}
function placeAt(c, L, up, force) {
  const u = unitOf(c), ex = new Set(u.map(o => o.id)), [a, b] = c.group && grp(c.group) ? gRange(grp(c.group)) : [c.start, c.start + c.len];
  if (!force && !busyAt(L, a, b, ex)) { u.forEach(o => o.layer = L); normLayers(); return; }
  if (up) { TL.clips.forEach(o => { if (!ex.has(o.id) && o.layer > L) o.layer++; }); u.forEach(o => o.layer = L + 1); }
  else { TL.clips.forEach(o => { if (!ex.has(o.id) && o.layer >= L) o.layer++; }); u.forEach(o => o.layer = L); }
  normLayers();
}
// 挪完以后撞上了别的东西（多选 / 整组挪时间、组合里的素材挪出了组合原来的范围）：往上插一条新轨道
function unjam(cs) {
  const done = new Set();
  cs.forEach(c => { const k = c.group || c.id; if (done.has(k) || !clip(c.id)) return; done.add(k);
    const u = unitOf(c), [a, b] = spanOf(c); if (busyAt(c.layer, a, b, new Set(u.map(o => o.id)))) placeAt(c, c.layer, true, true); });
}
// 老工程（v50 以前）：组合的成员各占一层 → 换成「同一条轨道 + 组内层号 c.sub」。成员原来谁在上，组内层号就大，画面不变。
function gMig() {
  TL.groups.forEach(g => {
    const m = TL.clips.filter(c => c.group === g.id); if (!m.length) return;
    if (m.every(c => c.layer === m[0].layer && Number.isInteger(c.sub))) return;
    const key = c => c.layer * 10000 + (c.sub || 0), ks = [...new Set(m.map(key))].sort((x, y) => x - y), top = Math.max(...m.map(c => c.layer));
    m.forEach(c => { c.sub = ks.indexOf(key(c)); c.layer = top; });
  });
}
function gSubNorm(g) {                               // 组内层号去掉空号：0、1、2…
  const m = TL.clips.filter(c => c.group === g.id), ks = [...new Set(m.map(c => c.sub || 0))].sort((x, y) => x - y);
  m.forEach(c => c.sub = ks.indexOf(c.sub || 0));
}
// 层整理：去掉空层、空组合；不在组合里的素材没有组内层号
function normLayers() {
  TL.clips.forEach(c => { const p = embP(c); if (p) { c.layer = p.layer; delete c.group; delete c.sub; } });   // v60.0 嵌着的拷贝跟着父素材那条轨道、不进组合
  TL.groups = TL.groups.filter(g => TL.clips.some(c => c.group === g.id));
  TL.clips.forEach(c => { if (c.group && !grp(c.group)) delete c.group; if (!c.group) delete c.sub; });
  gMig(); TL.groups.forEach(gSubNorm);
  const ls = [...new Set(TL.clips.map(c => c.layer))].sort((a, b) => a - b), M = new Map(ls.map((L, i) => [L, i]));
  TL.clips.forEach(c => c.layer = M.get(c.layer));
}
// 左侧层名那一列的「组合」前面也有折叠按钮（v46.x）：点一下折叠 / 展开，和组合条上的 ▾ 一样
names.addEventListener('mousedown', e => {
  const b = e.button === 0 && e.target.closest && e.target.closest('.gfold'); if (!b) return;
  e.preventDefault(); e.stopImmediatePropagation();
  const gs = b.dataset.g.split(',').map(grp).filter(Boolean); if (!gs.length) return;
  const open = gs.every(g => g.col); gs.forEach(g => g.col = !open); tlDraw(); tlSave();   // 组合轨道上有几个组合：一起展开 / 一起折叠
}, true);
let gbLast = { id: null, t: 0 };                     // 双击组合条 = 进到组合里面（单击会重画时间线，浏览器的 dblclick 收不到，自己判断）
// v46.x 播放头那条竖线：鼠标靠近（左右 5 像素）变成 ⇹ 光标，按住就能左右拖播放头（比素材条优先）
const nearHead = x => { const r = W(); return r.width > 0 && Math.abs(x - (r.left + tlT / tlV * r.width)) <= 5; };
trk.addEventListener('mousemove', e => { if (tlDragS) return; const on = nearHead(e.clientX) && !e.target.closest('.tlmk'); trk.style.cursor = on ? 'col-resize' : ''; });
trk.addEventListener('mouseleave', () => { if (!tlDragS) trk.style.cursor = ''; });
trk.addEventListener('mousedown', e => {
  if (e.button !== 0) return; trk.focus(); e.preventDefault();
  if (nearHead(e.clientX) && !e.target.closest('.tlmk')) { tlStop(); stop(); tlDragS = { k: 'scrub' }; document.body.style.cursor = 'col-resize'; return; }
  const R = buildRows();
  const gb = e.target.closest('.tlgb');
  if (gb) {
    const g = grp(gb.dataset.g); if (!g) return;
    if (e.target.classList.contains('tgt')) { g.col = !g.col; tlDraw(); tlSave(); return; }
    const now = Date.now();
    if (gbLast.id === g.id && now - gbLast.t < 400) { gbLast = { id: null, t: 0 }; enterGroup(g, tlSel); return; }
    gbLast = { id: g.id, t: now };
    selGroup(g.id);
    const m = TL.clips.filter(c => c.group === g.id);
    tlDragS = { k: 'gmove', g, R, x: e.clientX, y: e.clientY, s0: new Map(m.map(c => [c, c.start])), gs0: gRange(g)[0], len: gRange(g)[1] - gRange(g)[0], ex: new Set(m.map(c => c.id)), l0: m[0].layer, moved: false };
    trk.classList.add('mv'); tlDraw(); return;
  }
  const ce0 = e.target.closest('.tlc'), ce = ce0 && !(clip(ce0.dataset.id) || {}).lock ? ce0 : null;   // 锁定的素材点不中（v24.10）
  if (ce) {
    const c = clip(ce.dataset.id); if (!c) return;
    if (e.ctrlKey || e.metaKey || e.shiftKey) {               // 多选：Ctrl / Shift + 点击
      if (tlGrp) { tlGrp = null; gpBuild(); }
      if (!tlMulti.size && tlSel) tlMulti.add(tlSel);
      tlMulti.has(c.id) ? tlMulti.delete(c.id) : tlMulti.add(c.id);
      if (!tlSel) tlSelect(c.id);
      tlDraw(); return;
    }
    const multi = tlMulti.size > 1 && tlMulti.has(c.id) ? [...tlMulti].map(clip).filter(Boolean) : null;
    if (tlSel !== c.id || tlGrp) { tlKeepT = true; tlSelect(c.id, !!multi); tlKeepT = false; }   // v21.0：按下时播放头不跳，方便拖到播放头吸附
    if (e.target.classList.contains('tlr')) tlDragS = { k: 'len', c, R, x: e.clientX, len0: c.len, m: multi ? multi.map(o => [o, o.len]) : null };   // v21.0：多选时一起改时长
    else if (multi) tlDragS = { k: 'mmove', c, R, x: e.clientX, s0: new Map(multi.map(o => [o, o.start])), ex: new Set(multi.map(o => o.id)), moved: false };
    else tlDragS = { k: 'move', c, R, x: e.clientX, y: e.clientY, s0: c.start, l0: c.layer, sub0: c.sub, moved: false };
    if (e.altKey && tlDragS.k !== 'len' && !c.embedIn) {           // v46.x 按住 Alt 拖 = 复制：原地留一份副本，拖走的是原来那个（和 PR / 剪映一样）；没拖动就不复制
      tlDragS.dup = (multi || [c]).map(o => { const n = Object.assign(clone(o), { id: nid('c') }); delete n._len; TL.clips.push(n); ghost(n); return n; });
    }
    trk.classList.add(tlDragS.k === 'len' ? 'rs' : 'mv');
  } else if (e.clientY - W().top - tlSY() < RUL) { tlStop(); stop(); tlDragS = { k: 'scrub' }; tlSeek(xT(e.clientX)); }   // 顶上的刻度尺：拖 = 拖时间
  else {                                             // 空白处：按住左键拉一个框 = 框选素材（v13.1）；没拉开就当单击 = 跳到那一秒
    const add = e.ctrlKey || e.metaKey || e.shiftKey;
    tlDragS = { k: 'band', x: e.clientX, y: e.clientY, add: add ? new Set(tlMulti.size ? tlMulti : tlSel ? [tlSel] : []) : new Set(), moved: false };
    return;
  }
  tlDraw();
});
// 框选：框碰到的素材条（折叠的组合碰到组合条 = 里面的素材全算）都选上；Ctrl / Shift 按住再框 = 加选
function bandPick(d, e) {
  const x0 = Math.min(d.x, e.clientX), x1 = Math.max(d.x, e.clientX), y0 = Math.min(d.y, e.clientY), y1 = Math.max(d.y, e.clientY);
  let bx = trk.querySelector('.tlband'); if (!bx) { bx = document.createElement('div'); bx.className = 'tlband'; trk.appendChild(bx); }
  const r = W(); bx.style.cssText = 'left:' + (x0 - r.left) + 'px;top:' + (y0 - r.top) + 'px;width:' + (x1 - x0) + 'px;height:' + (y1 - y0) + 'px';
  const hit = el => { const b = el.getBoundingClientRect(); return b.right >= x0 && b.left <= x1 && b.bottom >= y0 && b.top <= y1; };
  const ids = new Set(d.add);
  trk.querySelectorAll('.tlc:not(.lk):not(.emb)').forEach(el => { if (hit(el)) ids.add(el.dataset.id); });
  trk.querySelectorAll('.tlgb').forEach(el => { if (hit(el)) TL.clips.forEach(c => { if (c.group === el.dataset.g) ids.add(c.id); }); });
  trk.querySelectorAll('.tlc').forEach(el => el.classList.toggle('ms', ids.has(el.dataset.id) && ids.size > 1));
  d.ids = ids;
  $('#hint').textContent = '框选：' + ids.size + ' 个素材（松手选中 · 按住 Ctrl / Shift 再框是加选）';
}
addEventListener('mousemove', e => {
  const d = tlDragS; if (!d) return;
  if (d.k === 'scrub') {   // v35.x 拖播放头：靠近素材头尾（6 像素以内）吸过去，并画一条线提示；磁吸关掉时不吸
    let t = xT(e.clientX);
    if (tlMag) { const tol = 6 / W().width * tlV; let b = null, d0 = tol; TL.clips.forEach(o => [o.start, o.start + o.len].forEach(p => { if (Math.abs(p - t) < d0) { d0 = Math.abs(p - t); b = p; } })); if (b != null) t = b; snapFx(b); }
    tlSeek(t); return; }
  if (d.k === 'band') { if (!d.moved && Math.abs(e.clientX - d.x) < 4 && Math.abs(e.clientY - d.y) < 4) return; d.moved = true; bandPick(d, e); return; }
  const dt = (e.clientX - d.x) / W().width * tlV;
  if (d.k === 'len') { d.c._len = Math.max(0.5, r2(snap(new Set([d.c.id]), d.c.start + d.len0 + dt, 0) - d.c.start)); /* 拉长 / 缩短时尾巴也吸播放头、别的素材边 */ if (d.m) d.m.forEach(([o, l0]) => o._len = Math.max(0.5, r2(l0 + dt))); $('#hint').textContent = (d.m ? d.m.length + ' 个素材一起' : '素材') + '时长：' + (dt >= 0 ? '+' : '') + dt.toFixed(2) + ' 秒（松手生效）'; tlDraw(); return; }
  if (!d.moved && Math.abs(e.clientX - d.x) < 3 && (d.y == null || Math.abs(e.clientY - d.y) < 3)) return;
  d.moved = true;
  if (d.k === 'gmove' || d.k === 'mmove') {           // 整组 / 多选一起挪时间
    const first = Math.min(...[...d.s0.values()]), last = Math.max(...[...d.s0.keys()].map(o => d.s0.get(o) + o.len));
    const ns = Math.abs(e.clientX - d.x) < 3 ? first : snap(d.ex, Math.max(0, first + dt), last - first), k = ns - first;   // 只是上下拖（换组合轨道）时不动时间
    if (d.k === 'gmove') { d.ey = e.clientY; const r = rowAt(d.R, e.clientY), L = Math.abs(e.clientY - d.y) < 4 ? d.l0 : rowLayer(r); d.s0.forEach((s, o) => o.layer = L); }   // v51.0 组合条和普通素材一样：上下拖 = 换轨道
    d.s0.forEach((s, o) => o.start = r2(s + k));
    $('#hint').textContent = '移动 ' + d.s0.size + ' 个素材：' + (k >= 0 ? '+' : '') + k.toFixed(2) + ' 秒';
    tlRender(); tlDraw(); return;
  }
  d.c.start = snap(new Set([d.c.id]), Math.max(0, d.s0 + dt), d.c.len);
  if (d.c.group && grp(d.c.group)) {                 // 组合里的素材：上下只在组内的几层之间换（换组内层号），出不了组合
    const r = rowAt(d.R, e.clientY); if (r.t === 'sub' && r.g === d.c.group) d.c.sub = r.s;
  } else if (!d.c.embedIn) d.c.layer = rowLayer(rowAt(d.R, e.clientY));   // v61.0 嵌着的拷贝只能左右挪（改开始时间），不换轨道
  $('#hint').textContent = '移动素材：从 ' + d.c.start.toFixed(2) + ' 秒开始';
  tlRender(); tlDraw();
});
addEventListener('mouseup', () => {
  const d = tlDragS; if (!d) return; snapFx(null);
  tlDragS = null; trk.classList.remove('rs', 'mv'); if (d.k === 'scrub') document.body.style.cursor = '';
  if (d.k === 'band') {
    if (!d.moved) {                                  // 没拉开 = 单击空白处：跳时间 + 取消选择（v21.0 补丁，和一般软件一样；按住 Ctrl / Shift 点空白处不取消）
      // v24.10：点图层后面的空白处只取消选中，播放头不动；要跳到某一秒，点上面的刻度条
      if (!d.add.size && (tlSel || tlGrp || tlMulti.size)) { commitSel(); tlSel = null; tlPreview = false; tlMulti = new Set(); tlGrp = null; tlIn = null; gpBuild(); tlRender(); kfTrackDraw(); }
      if (!d.add.size) { tlStop(); stop(); tlSeek(xT(d.x)); }   // v46.x 用户要求：点空白处播放头也跟过去
      tlDraw(); return;
    }
    const ids = [...(d.ids || [])].filter(id => clip(id));
    if (tlGrp) { tlGrp = null; gpBuild(); }
    tlMulti = new Set(ids);
    if (ids.length && !ids.includes(tlSel)) tlSelect(ids[0], true);
    tlDraw(); kfTrackDraw();
    toast(ids.length > 1 ? '已框选 ' + ids.length + ' 个素材：可以一起拖时间、Delete 删除、Ctrl+G 合成组合' : ids.length ? '已选中 1 个素材' : '框里没有素材');
    return;
  }
  if (d.k === 'len' && d.m) {                        // v21.0：多选一起改时长 —— 逐个选中、用和单个一样的 setDuration（停留 / 原生时长 / 拉伸自动判断），最后恢复多选
    const list = d.m.map(([o]) => { const L = o._len; delete o._len; return [o, L]; }).filter(([o, L]) => L != null && Math.abs(L - o.len) > 0.01);
    const keep = [...tlMulti], sel = tlSel; tlDraw();
    if (list.length) (async () => {
      for (let i = 0; i < list.length; i++) {
        const [o, L] = list[i]; $('#hint').textContent = '正在改时长 ' + (i + 1) + ' / ' + list.length + '…';
        tlKeepT = true; tlSelect(o.id, true); tlKeepT = false;
        await new Promise(r => whenReady(r)); setDuration(L); syncSel();
      }
      tlKeepT = true; tlSelect(sel, true); tlKeepT = false; tlMulti = new Set(keep);
      tlRender(); tlDraw(); tlSave(); toast(list.length + ' 个素材的时长一起改好了（每个右侧「持续时间」都同步变了）');
    })();
    return;
  }
  if (d.k === 'len') {
    const L = d.c._len; delete d.c._len;
    if (L != null && Math.abs(L - d.c.len) > 0.01 && (d.c.ci || d.c.co)) {   // 剪过的素材：先在剪掉的尾巴里放长 / 剪短，不改效果本身的时长
      const full = d.c.len + cIn(d.c) + cOut(d.c);
      if (L <= full - cIn(d.c) + 0.001) { d.c.co = r2(full - cIn(d.c) - L); d.c.len = r2(L); if (d.c.co <= 0.001) delete d.c.co; tlRender(); tlDraw(); tlSave(); toast('素材长度 ' + L.toFixed(2) + ' 秒（剪掉的尾巴拉回来了 / 又剪掉一些）'); return; }
      delete d.c.co; whenReady(() => { setDuration(L + cIn(d.c)); syncSel(); tlRender(); tlDraw(); toast('素材时长改为 ' + d.c.len.toFixed(2) + ' 秒'); }); return;
    }
    if (L != null && Math.abs(L - d.c.len) > 0.01) whenReady(() => { setDuration(L); syncSel(); tlRender(); tlDraw(); toast('素材时长改为 ' + dur.toFixed(2) + ' 秒（右侧「持续时间」同步变了）'); });
  }
  if (d.dup && !d.moved) { TL.clips = TL.clips.filter(o => !d.dup.includes(o)); d.dup.forEach(n => dropGhost(n.id)); }   // Alt 点了一下没拖：不复制
  if (d.k === 'move' && d.moved) {
    if (d.c.group && grp(d.c.group)) {               // 组合里的素材：组内同一层撞上了 → 组内往上插一层；组合整体撞上轨道上别的东西 → 整组往上一条
      const m = TL.clips.filter(o => o.group === d.c.group);
      if (m.some(o => o !== d.c && (o.sub || 0) === (d.c.sub || 0) && overlaps(o, d.c))) { const up = (d.c.sub || 0) >= (d.sub0 || 0), k = d.c.sub || 0; m.forEach(o => { if (o !== d.c && (o.sub || 0) > (up ? k : k - 1)) o.sub++; }); d.c.sub = up ? k + 1 : k; }
      gSubNorm(grp(d.c.group)); unjam([d.c]);
    } else if (!d.c.embedIn) placeAt(d.c, d.c.layer, d.c.layer >= d.l0);
    tlRender();
  }
  if (d.k === 'gmove' && d.moved) { const c0 = [...d.s0.keys()][0]; placeAt(c0, c0.layer, c0.layer >= d.l0); tlRender(); }   // v51.0 和普通素材一样：那一段被占了就插一条新轨道
  if (d.k === 'mmove' && d.moved && !d.dup) { unjam([...d.s0.keys()]); tlRender(); }
  if (d.dup && d.moved) {
    if (d.k === 'mmove') unjam([...d.s0.keys()]);   // 和副本叠在同一层：挪到上面一层
    tlRender(); setTimeout(() => Hooks.run('histCheck'), 0); toast('已复制 ' + d.dup.length + ' 个素材（按住 Alt 拖动 = 复制，Ctrl+Z 撤销）');
  }
  tlDraw(); tlSave(); if (tlGrp) gpBuild();
});

// ---------- 按钮 / 键盘 ----------
// 从左边拖进来：用效果的默认参数新建一个素材，然后选中它（右侧面板就是它的参数）
function addFx(id, start, layer, extra) {   // extra：额外参数（比如纯背景双击时的放大倍数）
  const e = effects.find(x => x.id === id); if (!e) return;
  if (e.combo && Array.isArray(e.combo.clips) && e.combo.clips.length) return addCombo(e, start);   // 组合预设：整组放进去（v25.0）
  const ps = {}; e.params.forEach(p => ps[p.key] = (p.default && typeof p.default === 'object') ? clone(p.default) : p.default);
  Object.assign(ps, clone(e.presetExtra || {}), extra || {});
  const top = TL.clips.length ? Math.max(...TL.clips.map(c => c.layer)) + 1 : 0;
  const c = { id: 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), fx: id, params: ps, start: Math.max(0, r2(start)), len: 5, layer: top };
  TL.clips.push(c);
  if (layer != null && layer < top) placeAt(c, Math.max(0, layer), true); else c.layer = top;
  tlT = c.start; tlSelect(c.id); fit(); tlSave();
  toast('「' + e.name + '」已放到第 ' + (c.layer + 1) + ' 层，从 ' + c.start.toFixed(2) + ' 秒开始');
}
// 组合预设（v25.0）：把保存时的几个素材按原来的上下层、前后时间整组放到最上面；有组合就连组合关键帧一起恢复
function addCombo(e, start) {
  const s0 = Math.max(0, r2(start)), top = TL.clips.length ? Math.max(...TL.clips.map(c => c.layer)) + 1 : 0;
  const g = e.combo.group ? Object.assign(clone(e.combo.group), { id: nid('g'), name: e.name }) : null;
  if (g) TL.groups.push(g);
  const ids = e.combo.clips.map(k => {
    const c = { id: nid('c'), fx: k.fx, params: clone(k.params), start: r2(s0 + (+k.start || 0)), len: +k.len || 5, layer: top + (+k.layer || 0) };
    if (g) c.group = g.id; TL.clips.push(c); return c.id;
  });
  normLayers(); tlT = s0;
  if (g) selGroup(g.id); else tlSelect(ids[0]);
  fit(); tlRender(); tlDraw(); tlSave();
  toast('组合预设「' + e.name + '」已放进时间线：' + ids.length + ' 个素材，从 ' + s0.toFixed(2) + ' 秒开始');
}
function moveLayer(dir) {                          // Ctrl+] / Ctrl+[：往上 / 往下一层（组合整组挪；在组合里面改单个素材时 = 组内上下换）
  const g = grp(tlGrp), c = g ? TL.clips.find(o => o.group === g.id) : clip(tlSel); if (!c) return;
  if (!g && c.group && grp(c.group) && tlIn === c.group) {
    const m = TL.clips.filter(o => o.group === c.group), mx = Math.max(...m.map(o => o.sub || 0)), k = c.sub || 0, alone = !m.some(o => o !== c && (o.sub || 0) === k);
    if (dir > 0 && k >= mx && alone) return toast('已经在组合里最上面一层');
    if (dir < 0 && k <= 0 && alone) return toast('已经在组合里最下面一层');
    if (dir > 0 && k >= mx) c.sub = mx + 1;
    else if (dir < 0 && k <= 0) { m.forEach(o => { if (o !== c) o.sub = (o.sub || 0) + 1; }); c.sub = 0; }
    else { const t = k + dir; m.forEach(o => { if (o !== c && (o.sub || 0) === t) o.sub = k; }); c.sub = t; }
    gSubNorm(grp(c.group)); tlRender(); tlDraw(); tlSave(); return;
  }
  const top = Math.max(...TL.clips.map(o => o.layer)), alone = unitOf(c).length === TL.clips.filter(o => o.layer === c.layer).length;
  if (dir > 0) { if (c.layer >= top && alone) return toast('已经在最上面一层'); placeAt(c, c.layer + 1, true, c.layer >= top); }
  else if (c.layer > 0) placeAt(c, c.layer - 1, false);
  else if (!alone) placeAt(c, 0, false, true);       // 最底层还有别的素材：把它单独压到最下面
  else return toast('已经在最下面一层');
  tlRender(); tlDraw(); tlSave();
}
function removeClips(cs) {
  cs.forEach(c => dropGhost(c.id));
  TL.clips = TL.clips.filter(o => !cs.includes(o));
  if (cs.some(c => c.id === tlSel)) { tlSel = null; tlPreview = false; }
  tlMulti = new Set(); normLayers(); if (!TL.clips.length) tlPreview = true;
  if (tlGrp && !grp(tlGrp)) { tlGrp = null; gpBuild(); }
  fit(); tlRender(); tlDraw(); tlSave();
}
async function delSel() {
  const g = grp(tlGrp);
  if (g) {
    const m = TL.clips.filter(c => c.group === g.id);
    const ok = await dialog({ title: '删除「' + g.name + '」？', html: '组合和里面的 ' + m.length + ' 个素材都会从时间线删掉。只想拆开、保留素材，请用 Ctrl+Shift+G 解散组合。', buttons: [{ text: '取消', value: false, cls: 'ghost' }, { text: '删除', value: true, cls: 'pri' }] });
    if (ok) { removeClips(m); toast('已删除组合'); }
    return;
  }
  const cs = (tlMulti.size > 1 ? [...tlMulti] : [tlSel]).map(clip).filter(Boolean); if (!cs.length) return;
  removeClips(cs); toast(cs.length > 1 ? '已删掉 ' + cs.length + ' 个素材' : '已从时间线删掉');
}
const nid = p => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
function dupSel() {
  syncSel();
  const g = grp(tlGrp);
  if (g) {                                           // 复制整个组合（连同它的变换和关键帧），放到最上面
    const top = Math.max(...TL.clips.map(o => o.layer)) + 1, m = TL.clips.filter(c => c.group === g.id), lo = Math.min(...m.map(c => c.layer));
    const ng = Object.assign(clone(g), { id: nid('g'), name: g.name + ' 副本' }); TL.groups.push(ng);
    m.forEach(c => TL.clips.push(Object.assign(clone(c), { id: nid('c'), group: ng.id, layer: top + c.layer - lo })));
    normLayers(); selGroup(ng.id); tlRender(); tlSave(); return;
  }
  const c = clip(tlSel); if (!c) return;
  const n = Object.assign(clone(c), { id: nid('c'), layer: Math.max(...TL.clips.map(o => o.layer)) + 1 });
  delete n.group;
  TL.clips.push(n); normLayers(); ghost(n); tlSelect(n.id); tlSave();
}
