// 效果工坊 · 多选对齐 / 平均分布（v47.0）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// · 位置：预览区下面那一条，「抓取静帧」左边（#hintr 里）。只有选中 2 个及以上素材（多选或组合）时才出现。
// · 按钮：左对齐 / 水平居中 / 右对齐 / 顶对齐 / 垂直居中 / 底对齐 / 水平平均分布 / 垂直平均分布（分布要 3 个及以上）。
// · 量的是每个素材在播放头这一刻「真正画出来的部分」（和白色选中框同一套：17-select-box.js sbContentRect），
//   以选中素材合起来的大框为准（和 Photoshop 一样）。只挪位置，不改大小。
// · 怎么挪：没开位置关键帧 → 改 offsetX / offsetY（1920×1080 画布像素）；开了位置关键帧 → 所有位置关键帧一起平移，动作不变。
//   先挪一次，再量一次，按实际挪了多少补一次（效果自己有缩放 / 组合有变换时也能对准）。
// · 锁住的素材、原视频、播放头这一刻看不见的素材不动。整个对齐算一步，Ctrl+Z 撤销。
const alWrap = document.createElement('div'); alWrap.id = 'alignbar'; alWrap.hidden = true;
const AL_ICONS = {
  l: '<path d="M2 1v14"/><rect x="4" y="3" width="9" height="3"/><rect x="4" y="10" width="5" height="3"/>',
  hc: '<path d="M8 1v14"/><rect x="3" y="3" width="10" height="3"/><rect x="5" y="10" width="6" height="3"/>',
  r: '<path d="M14 1v14"/><rect x="3" y="3" width="9" height="3"/><rect x="7" y="10" width="5" height="3"/>',
  t: '<path d="M1 2h14"/><rect x="3" y="4" width="3" height="9"/><rect x="10" y="4" width="3" height="5"/>',
  vc: '<path d="M1 8h14"/><rect x="3" y="3" width="3" height="10"/><rect x="10" y="5" width="3" height="6"/>',
  b: '<path d="M1 14h14"/><rect x="3" y="3" width="3" height="9"/><rect x="10" y="7" width="3" height="5"/>',
  dh: '<path d="M1 1v14M15 1v14"/><rect x="6.5" y="4" width="3" height="8"/>',
  dv: '<path d="M1 1h14M1 15h14"/><rect x="4" y="6.5" width="8" height="3"/>',
};
const AL_TIPS = { l: '左对齐', hc: '水平居中对齐', r: '右对齐', t: '顶对齐', vc: '垂直居中对齐', b: '底对齐', dh: '水平平均分布（3 个以上）', dv: '垂直平均分布（3 个以上）' };
alWrap.innerHTML = Object.keys(AL_ICONS).map((k, i) => (i === 3 || i === 6 ? '<i class="alsep"></i>' : '')
  + `<button type="button" data-al="${k}" title="${AL_TIPS[k]}"><svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.3">${AL_ICONS[k]}</svg></button>`).join('');
{ const r = $('#hintr'); if (r) r.prepend(alWrap); else $('#hintrow').appendChild(alWrap); }
{ const st = document.createElement('style');
  st.textContent = '#alignbar{display:flex;gap:2px;align-items:center;padding:2px 4px;border:1px solid #333;border-radius:6px;background:#161616;margin-right:4px}'
    + '#alignbar[hidden]{display:none}#alignbar button{background:transparent;border:0;color:#bbb;padding:3px 4px;border-radius:4px;cursor:pointer;line-height:0}'
    + '#alignbar button:hover{color:#f28c0f;background:#222}#alignbar button.off{opacity:.3;cursor:default}#alignbar .alsep{width:1px;height:14px;background:#333;margin:0 3px}';
  document.head.appendChild(st); }

const alTargets = () => {
  const ids = tlGrp ? TL.clips.filter(c => c.group === tlGrp).map(c => c.id) : tlMulti.size > 1 ? [...tlMulti] : [];
  return ids.map(clip).filter(c => c && !c.ref);
};
function alSync() {
  const n = alTargets().length, show = n > 1;
  if (alWrap.hidden === show) alWrap.hidden = !show;
  alWrap.querySelectorAll('[data-al^="d"]').forEach(b => b.classList.toggle('off', n < 3));
}
['tlDraw', 'select'].forEach(h => Hooks.on(h, alSync));

// 铺满整个画面的素材（纯背景、背景库……）：不算进对齐 / 框选
function alFull(c, el, r) {
  if (/^bg-/.test(c.fx)) return true;
  try { const w = pickDoc(el).defaultView; return r.x1 - r.x0 >= w.innerWidth * 0.95 && r.y1 - r.y0 >= w.innerHeight * 0.95; } catch (e) { return false; }
}
// 素材在预览框里的范围（预览像素，轴对齐的外框）+ 1 个画布像素在预览上有多大
function alRect(c) {
  const el = sbEl(c); if (!el || el.style.visibility === 'hidden') return null;
  const r = sbContentRect(el); if (!r) return null;
  if (alFull(c, el, r)) return null;                  // 整屏的背景不参与对齐（不然「顶对齐」会对到画面最上边）
  const pts = [[r.x0, r.y0], [r.x1, r.y0], [r.x1, r.y1], [r.x0, r.y1]].map(p => sbProject(el, p[0], p[1]));
  if (pts.some(p => !p)) return null;
  const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
  return { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys), k: Math.hypot(pts[1][0] - pts[0][0], pts[1][1] - pts[0][1]) / (r.x1 - r.x0) || 1 };
}
// 把素材挪 (dx, dy) 个画布像素：有位置关键帧就平移所有位置关键帧，否则改 offsetX / offsetY
function alShift(c, dx, dy) {
  const P = c.id === tlSel ? params : c.params;
  let moved = false;
  if (typeof P.keys === 'string' || (P.keys && typeof P.keys === 'object')) {
    try {
      const o = typeof P.keys === 'string' ? JSON.parse(P.keys) : clone(P.keys);
      const ps = (o && Array.isArray(o.list) ? o.list : []).filter(q => q.k === 'p');
      if (ps.length) {
        ps.forEach(q => { q.ox = Math.round((+q.ox || 0) + dx); q.oy = Math.round((+q.oy || 0) + dy); });
        P.keys = typeof P.keys === 'string' ? JSON.stringify(o) : o; moved = true;
      }
    } catch (e) { }
  }
  if (!moved) { P.offsetX = Math.round((+P.offsetX || 0) + dx); P.offsetY = Math.round((+P.offsetY || 0) + dy); }
  if (c.id === tlSel) c.params = clone(params);
}
function alApply(list) {
  if (list.some(c => c.id === tlSel)) {
    try { bcBase = JSON.stringify(params); } catch (e) { }       // 主素材是我们自己改的：别当成「改了参数」再同步给其他选中的素材（15-timeline-tools.js）
    try { buildParams(); reinit(false); } catch (e) { }
    try { bcBase = JSON.stringify(params); } catch (e) { }
  }
  list.forEach(c => { if (c.id !== tlSel && G[c.id] && G[c.id]._ok) ghostInit(c); });
  tlRender();
}
// 算每个素材要挪到哪（预览像素）：返回 Map(c → [dx, dy])
function alPlan(how, items) {
  const B = { x0: Math.min(...items.map(i => i.r.x0)), y0: Math.min(...items.map(i => i.r.y0)), x1: Math.max(...items.map(i => i.r.x1)), y1: Math.max(...items.map(i => i.r.y1)) };
  const m = new Map();
  if (how === 'dh' || how === 'dv') {
    const H = how === 'dh', a = H ? 'x0' : 'y0', b = H ? 'x1' : 'y1';
    const s = items.slice().sort((p, q) => (p.r[a] + p.r[b]) - (q.r[a] + q.r[b]));
    const total = s.reduce((n, i) => n + i.r[b] - i.r[a], 0), gap = (B[b] - B[a] - total) / (s.length - 1);
    let pos = B[a];
    s.forEach(i => { const d = pos - i.r[a]; m.set(i.c, H ? [d, 0] : [0, d]); pos += i.r[b] - i.r[a] + gap; });
    return m;
  }
  items.forEach(i => {
    const r = i.r, cx = (r.x0 + r.x1) / 2, cy = (r.y0 + r.y1) / 2;
    const d = how === 'l' ? [B.x0 - r.x0, 0] : how === 'r' ? [B.x1 - r.x1, 0] : how === 'hc' ? [(B.x0 + B.x1) / 2 - cx, 0]
      : how === 't' ? [0, B.y0 - r.y0] : how === 'b' ? [0, B.y1 - r.y1] : [0, (B.y0 + B.y1) / 2 - cy];
    m.set(i.c, d);
  });
  return m;
}
let alBusy = false;
async function alDo(how) {
  if (alBusy) return;
  const all = alTargets();
  if ((how === 'dh' || how === 'dv') && all.length < 3) return toast('平均分布要选 3 个及以上素材');
  try { syncSel(); } catch (e) { }
  const items = [], skip = [];
  all.forEach(c => { const r = !c.lock && alRect(c); r ? items.push({ c, r }) : skip.push(c); });
  if (items.length < 2) return toast('能对齐的素材不到 2 个（锁住的、铺满画面的背景、播放头这一刻看不见的不算）');
  alBusy = true; tlStop();
  const want = alPlan(how, items);
  const wait = () => new Promise(r => setTimeout(r, 120));
  // 第一次：按预览像素 ÷ 每个画布像素在预览上的大小 = 要挪多少画布像素
  const moved = [];
  items.forEach(i => { const [px, py] = want.get(i.c); if (Math.abs(px) < 0.3 && Math.abs(py) < 0.3) return; alShift(i.c, px / i.r.k, py / i.r.k); moved.push(i); });
  alApply(moved.map(i => i.c)); await wait();
  // 第二次：量一下实际挪了多少，按比例补齐剩下的（效果自己的缩放、组合变换等）
  const fix = [];
  moved.forEach(i => {
    const r2_ = alRect(i.c); if (!r2_) return;
    const [px, py] = want.get(i.c), ax = r2_.x0 - i.r.x0, ay = r2_.y0 - i.r.y0;
    const gx = Math.abs(px) > 0.5 && Math.abs(ax) > 0.1 ? ax / px : 1, gy = Math.abs(py) > 0.5 && Math.abs(ay) > 0.1 ? ay / py : 1;
    const rx = px - ax, ry = py - ay;
    if (Math.abs(rx) > 0.6 || Math.abs(ry) > 0.6) { alShift(i.c, rx / i.r.k / (gx || 1), ry / i.r.k / (gy || 1)); fix.push(i.c); }
  });
  if (fix.length) { alApply(fix); await wait(); }
  tlSave(); Hooks.run('histCheck'); try { sbSoon(); } catch (e) { }
  alBusy = false;
  toast('✓ ' + AL_TIPS[how].replace(/（.*）/, '') + '：' + items.length + ' 个素材' + (skip.length ? '（' + skip.length + ' 个是背景 / 锁住 / 此刻看不见，没动）' : '') + '　Ctrl+Z 撤销');
}
alWrap.addEventListener('mousedown', e => e.preventDefault());
alWrap.addEventListener('click', e => { const b = e.target.closest('[data-al]'); if (b && !b.classList.contains('off')) alDo(b.dataset.al); });
alSync();
