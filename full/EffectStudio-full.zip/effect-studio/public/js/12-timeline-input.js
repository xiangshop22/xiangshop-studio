// 效果工坊 · 拖进来 · 预览里点选素材 · 快捷键 · 预览高度分割线
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ---------- 从左边把效果拖进来 ----------
new MutationObserver(() => document.querySelectorAll('#list .item:not([draggable])').forEach(b => b.draggable = true)).observe($('#list'), { childList: true, subtree: true });
document.querySelectorAll('#list .item').forEach(b => b.draggable = true);
let dragFx = null;
addEventListener('dragstart', e => { const it = e.target.closest && e.target.closest('#list .item'); if (!it) return; dragFx = it.dataset.id; e.dataTransfer.effectAllowed = 'copy'; e.dataTransfer.setData('text/plain', 'fx:' + dragFx); });
addEventListener('dragend', () => { dragFx = null; panel.classList.remove('dropok'); $('#stagewrap').classList.remove('dropok'); });
[[panel, true], [$('#stagewrap'), false]].forEach(([el, onTl]) => {
  el.addEventListener('dragover', e => { if (!dragFx) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; el.classList.add('dropok'); });
  el.addEventListener('dragleave', e => { if (!el.contains(e.relatedTarget)) el.classList.remove('dropok'); });
  el.addEventListener('drop', e => {
    if (!dragFx) return; e.preventDefault(); el.classList.remove('dropok');
    const id = dragFx; dragFx = null; tlStop(); stop();
    let start = TL.clips.length ? tlT : 0, layer = null;
    if (onTl && TL.clips.length) {
      const r = W();
      if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top + RUL + tlSY() && e.clientY <= r.bottom) {
        start = xT(e.clientX); layer = rowLayer(rowAt(buildRows(), e.clientY));
      }
    }
    addFx(id, start, layer);
  });
});

// ---------- 从电脑把图片拖到素材时间线上（v33.x）：在播放头那一秒建一个「单张图片」素材 ----------
// 文件先放在 window.__fxPendingImg，效果页面（effects/image-layer）加载好后自己接过去上传、弹出裁剪。一次放一张。
const imgFiles = e => e.dataTransfer && [...(e.dataTransfer.items || [])].some(it => it.kind === 'file' && /^image\//.test(it.type));   // 只管图片；效果压缩包照旧交给「加载效果」
// v35.x：拖到预览窗口上也行（放在最上面一层）；拖到时间线上落在哪一行就放哪一层
[[panel, true], [$('#stagewrap'), false]].forEach(([el, onTl]) => {
  el.addEventListener('dragover', e => { if (dragFx || !imgFiles(e)) return; e.preventDefault(); e.stopPropagation(); e.dataTransfer.dropEffect = 'copy'; el.classList.add('dropok'); });
  el.addEventListener('dragleave', e => { if (!el.contains(e.relatedTarget)) el.classList.remove('dropok'); });
  el.addEventListener('drop', e => {
    if (dragFx || !imgFiles(e)) return;
    const fs = [...e.dataTransfer.files].filter(f => /^image\/(png|jpeg|webp|gif)$/.test(f.type));
    e.preventDefault(); e.stopPropagation(); el.classList.remove('dropok');
    if (!fs.length) return toast('只支持 PNG / JPG / WEBP / GIF 图片');
    if (!effects.some(x => x.id === 'image-layer')) return toast('没找到「单张图片」效果');
    tlStop(); stop();
    let layer = null;
    if (onTl) { const r = W(); if (TL.clips.length && e.clientY >= r.top + RUL + tlSY() && e.clientY <= r.bottom) layer = rowLayer(rowAt(buildRows(), e.clientY)); }
    window.__fxPendingImg = fs[0];
    addFx('image-layer', tlT, layer);
    if (fs.length > 1) toast('一次放一张：先放了「' + fs[0].name + '」');
  }, true);
});

// ---------- 在预览窗口里点素材 = 在时间线上选中它（v12.0，所有效果通用；v12.1 加了组合规则） ----------
// 点下去的那一点，从最上面一层往下找：哪个素材在这一点上「画了东西」（不是透明的、不是整屏的空容器），就选中哪个。
// 点到的就是已经选中的素材 → 照常拖动 / 缩放；点到别的素材 → 只切换选中，这一下不拖（画面要先换成它的参数）。
// Alt + 点：重叠时选「下面一层」的那个（每点一次往下换一层）。点在空白处：什么都不变。
// 效果本身一行不用改：判断用的是效果页面自己的 DOM（document.elementFromPoint），所以以后的新效果也自动支持。
function pickDoc(el) {                               // 素材对应的效果页面：选中的在 #frame，没选中的在 ghost.html 里面那层
  try {
    const d = el.contentDocument; if (!d) return null;
    if (el === frame) return d;
    const inner = d.getElementById('fx'); return inner ? inner.contentDocument : null;
  } catch (e) { return null; }
}
// 预览区里的一点 → 这个 iframe 里的坐标。iframe 套着变换（缩放适配 + 组合的位置 / 大小 / 三轴旋转 / 透视），
// 这里把变换矩阵反过来解：求 iframe 平面（z = 0）上哪一点投影到鼠标这里，旋转过的组合也点得准（v12.1）
function toLocal(el, cx, cy) {
  const br = box.getBoundingClientRect(), sx = cx - br.left - box.clientLeft, sy = cy - br.top - box.clientTop;
  const tf = getComputedStyle(el).transform;
  const m = !tf || tf === 'none' ? new DOMMatrix() : new DOMMatrix(tf);
  const a1 = m.m11 - sx * m.m14, b1 = m.m21 - sx * m.m24, c1 = sx * m.m44 - m.m41;
  const a2 = m.m12 - sy * m.m14, b2 = m.m22 - sy * m.m24, c2 = sy * m.m44 - m.m42;
  const det = a1 * b2 - a2 * b1; if (Math.abs(det) < 1e-9) return null;      // 转到正侧面（看不见了）
  const x = (c1 * b2 - c2 * b1) / det, y = (a1 * c2 - a2 * c1) / det;
  if (m.m14 * x + m.m24 * y + m.m44 <= 0) return null;                       // 在镜头后面
  return [x, y];
}
// v35.2：这个元素在点的那一点上「真的画了东西」吗？（和 17-select-box.js 的选中框用同一套判断）
// 修的 bug：效果里包着内容的排版容器（比如时间轴的 #lay）本身是透明的、但比内容大一圈，
// 以前它也算「点中」—— 在下面一层的卡片上点，却选中了上面的时间轴。
function pickPaints(n, x, y, w, d, rb) {
  const tag = n.tagName;
  if (n instanceof w.SVGElement) return tag.toLowerCase() !== 'svg' || pickBox(w.getComputedStyle(n), x, y, rb);   // SVG 图形：浏览器只在画到的地方返回它
  if (/^(IMG|VIDEO|IFRAME|INPUT|TEXTAREA)$/.test(tag)) return true;
  const cs = w.getComputedStyle(n);
  if (pickBox(cs, x, y, rb)) return true;
  for (const ps of ['::before', '::after']) {         // 伪元素画的东西（色块、角花）
    const p = w.getComputedStyle(n, ps);
    if (p.content && p.content !== 'none' && p.content !== 'normal' && p.display !== 'none' &&
      (!/^(transparent|rgba\(.*, 0\))$/.test(p.backgroundColor) || p.backgroundImage !== 'none' || p.content.length > 2)) return true;
  }
  const range = d.createRange(), pad = 3;             // 文字：点在字上（不是点在字所在那一大块 div 的空白里）
  for (const t of n.childNodes) {
    if (t.nodeType !== 3 || !t.nodeValue.trim()) continue;
    range.selectNodeContents(t);
    for (const r of range.getClientRects()) if (x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad) return true;
  }
  return false;
}
function pickBox(cs, x, y, rb) {                      // 底色 / 底图 / 边框（只算点在边框那一圈上）
  if (!/^(transparent|rgba\(.*, 0\))$/.test(cs.backgroundColor) || cs.backgroundImage !== 'none') return true;
  if (cs.borderStyle === 'none' || cs.borderStyle === 'hidden') return false;
  const bt = parseFloat(cs.borderTopWidth) || 0, br = parseFloat(cs.borderRightWidth) || 0, bb = parseFloat(cs.borderBottomWidth) || 0, bl = parseFloat(cs.borderLeftWidth) || 0;
  if (!(bt + br + bb + bl)) return false;
  const k = rb.width / (parseFloat(cs.width) || rb.width) || 1;   // 元素被缩放时，边框宽度也跟着缩放
  return x <= rb.left + bl * k + 2 || x >= rb.right - br * k - 2 || y <= rb.top + bt * k + 2 || y >= rb.bottom - bb * k - 2;
}
function hitClip(el, cx, cy) {
  if (!el || el.style.visibility === 'hidden') return false;
  const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false;
  if (cx < r.left || cx > r.right || cy < r.top || cy > r.bottom) return false;
  const d = pickDoc(el); if (!d || !d.defaultView) return false;
  const w = d.defaultView, vw = w.innerWidth, vh = w.innerHeight;
  const pt = toLocal(el, cx, cy); if (!pt) return false;
  const x = pt[0], y = pt[1];
  if (x < 0 || y < 0 || x > vw || y > vh) return false;
  let list = [];
  try { list = d.elementsFromPoint(x, y); } catch (e) { return false; }
  // 这一点上叠着的所有元素，从上往下：只要有一个是「看得见的东西」就算点中（高亮层这种透明的叠层会跳过）
  return list.some(hit => {
    if (hit === d.documentElement || hit === d.body) return false;
    const rb = hit.getBoundingClientRect();
    if (rb.width >= vw * 0.97 && rb.height >= vh * 0.97 && hit.tagName !== 'CANVAS') return false;   // 整屏的容器不算
    if (hit.tagName === 'CANVAS') {                  // 画布：看这一点的像素是不是透明的
      try { const g2 = hit.getContext('2d'); const px = g2 && g2.getImageData(Math.floor((x - rb.left) * hit.width / rb.width), Math.floor((y - rb.top) * hit.height / rb.height), 1, 1).data;
        if (px && px[3] < 8) return false; } catch (e) { }
    } else if (!pickPaints(hit, x, y, w, d, rb)) return false;   // v35.2：透明的排版容器（没底色、没边框、点的地方没字）不算

    let op = 1;                                       // 淡没了（还没入场 / 已经退场 / 透明的叠层）的不算
    for (let n = hit; n && n.nodeType === 1; n = n.parentElement) {
      const cs = w.getComputedStyle(n);
      if (cs.visibility === 'hidden' || cs.display === 'none') return false;
      op *= +cs.opacity; if (op < 0.04) return false;
    }
    return true;
  });
}
let pickLast = null, pickT = 0;
// ---------- v46.x 预览框外面按住左键拉框 = 框选素材（框碰到素材「画出来的部分」就选上；Ctrl / Shift 按住 = 加选） ----------
let pvBand = null;
addEventListener('mousedown', e => {
  if (e.button !== 0 || tlLoading || !TL.clips.length) return;
  const pin = $('#pvpin'), M = $('main'), t = e.target;   // 预览四周（中间这一栏、预览下沿以上）的空地方都能起框
  if (!pin || !M || !(t instanceof Node) || !M.contains(t) || e.clientY > pin.getBoundingClientRect().bottom || box.contains(t) || (t.closest && t.closest('button,input,select,textarea,a,label,#hintrow,#split'))) return;
  e.preventDefault(); e.stopImmediatePropagation();
  const add = e.ctrlKey || e.metaKey || e.shiftKey;
  pvBand = { x: e.clientX, y: e.clientY, add: add ? new Set(tlMulti.size ? tlMulti : tlSel ? [tlSel] : []) : new Set(), moved: false, el: null, ids: null };
}, true);
function pvBandRects() {                               // 每个看得见的素材：画出来的部分在屏幕上的范围
  const br = box.getBoundingClientRect(), ox = br.left + box.clientLeft, oy = br.top + box.clientTop, out = [];
  TL.clips.forEach(c => {
    if (c.lock || c.hide || c.ref) return;
    const el = c.id === tlSel ? frame : G[c.id]; if (!el || el.style.visibility === 'hidden') return;
    let r = null; try { r = sbContentRect(el); } catch (er) { } if (!r) return;
    if (typeof alFull === 'function' && alFull(c, el, r)) return;   // 铺满画面的背景框不进来（要选它去时间线上点）
    const pts = [[r.x0, r.y0], [r.x1, r.y0], [r.x1, r.y1], [r.x0, r.y1]].map(p => sbProject(el, p[0], p[1])); if (pts.some(p => !p)) return;
    const xs = pts.map(p => p[0] + ox), ys = pts.map(p => p[1] + oy);
    out.push({ c, x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) });
  });
  return out;
}
addEventListener('mousemove', e => {
  const d = pvBand; if (!d) return;
  if (!d.moved && Math.abs(e.clientX - d.x) < 4 && Math.abs(e.clientY - d.y) < 4) return;
  if (!d.moved) { d.moved = true; d.rs = pvBandRects(); d.el = document.createElement('div'); d.el.style.cssText = 'position:fixed;z-index:99999;border:1px dashed #f28c0f;background:rgba(242,140,15,.08);pointer-events:none'; document.body.appendChild(d.el); }
  const x0 = Math.min(d.x, e.clientX), x1 = Math.max(d.x, e.clientX), y0 = Math.min(d.y, e.clientY), y1 = Math.max(d.y, e.clientY);
  Object.assign(d.el.style, { left: x0 + 'px', top: y0 + 'px', width: x1 - x0 + 'px', height: y1 - y0 + 'px' });
  const ids = new Set(d.add);
  d.rs.forEach(r => { if (r.x1 >= x0 && r.x0 <= x1 && r.y1 >= y0 && r.y0 <= y1) ids.add(r.c.id); });
  d.ids = ids; $('#hint').textContent = '框选：' + ids.size + ' 个素材（松手选中 · 按住 Ctrl / Shift 再框是加选）';
}, true);
addEventListener('mouseup', () => {
  const d = pvBand; if (!d) return; pvBand = null; if (d.el) d.el.remove();
  if (!d.moved) {                                      // 没拉开 = 点了一下预览外面：取消选中（按住 Ctrl / Shift 不取消）
    if (!d.add.size && (tlSel || tlGrp || tlMulti.size)) { commitSel(); tlSel = null; tlPreview = false; tlMulti = new Set(); tlGrp = null; tlIn = null; gpBuild(); tlRender(); tlDraw(); kfTrackDraw(); }
    return;
  }
  const ids = [...(d.ids || [])].filter(id => clip(id));
  if (tlGrp) { tlGrp = null; gpBuild(); }
  tlStop(); tlMulti = new Set(ids);
  if (ids.length && !ids.includes(tlSel)) tlSelect(ids[0], true);
  tlDraw(); kfTrackDraw(); try { sbSoon(); } catch (er) { }
  toast(ids.length > 1 ? '已框选 ' + ids.length + ' 个素材：可以用预览下面的对齐按钮，或一起拖动' : ids.length ? '已选中 1 个素材' : '框里没有素材');
}, true);                       // Alt + 点：记住上一次点的位置和选到第几个；pickT = 刚切换的时间
function hitsAt(cx, cy) {                             // 这一点上看得见的素材，从最上面一层往下
  return TL.clips.slice().sort((a, b) => zOf(b) - zOf(a)).filter(c => !c.lock && (embF() ? c.id === tlSel : !c.hide) && hitClip(c.id === tlSel ? frame : G[c.id], cx, cy));
}
const fxName = c => { const f = fxOf(c); return f ? f.name : c.fx; };
// v12.1 组合规则：组合（预合成）是一个整体 —— 点组合里的任何一个素材，选中的是整个组合，拖 / 滚轮 / 右键转都是整组一起；
// 要改里面某一个素材，双击它进到组合里面（Esc 退出来）。
// v24.3：在预览里按下鼠标（准备拖动 / 缩放 / 旋转）之前，先把效果自己的进度条对齐到时间线播放头。
// 效果拖完是按这根进度条的时间自动打关键帧的；两边差一点点，关键帧就会记在别的时刻，松手后画面「跳走」。
// 用捕获阶段，保证比效果自己的按下监听（view-controls.js）先执行。
addEventListener('mousedown', e => {
  if (!inSw(e) || tlLoading || !tlSel) return;
  const c = clip(tlSel); if (!c) return;
  const loc = Math.max(0, Math.min(r2(tlT - c.start + cIn(c)), dur || 0));
  if (Math.abs(+slider.value - loc) > 0.001) slider.value = loc;
  if (tlMulti.size > 1 && typeof bcCheck === 'function') bcCheck();   // 多选：先记下「改之前」的底子，松手后才知道改了多少（v24.5）
}, true);
addEventListener('mousedown', e => {
  if (!inSw(e) || tlLoading || !TL.clips.length) return;
  const g0 = grp(tlGrp);
  let hits = (e.button === 0 || e.button === 2) ? hitsAt(e.clientX, e.clientY) : [];
  let pk = hits[0];
  if (e.button === 0 && (e.ctrlKey || e.metaKey || e.shiftKey) && !e.altKey) {   // v46.x Ctrl / Shift + 点 = 多选（加选 / 取消），和时间线上一样
    eat(e); if (!pk) return;
    const pg = pk.group && tlIn !== pk.group && grp(pk.group);
    const ids = pg ? TL.clips.filter(c => c.group === pg.id).map(c => c.id) : [pk.id];
    if (tlGrp) { const was = TL.clips.filter(c => c.group === tlGrp).map(c => c.id); tlGrp = null; gpBuild(); tlMulti = new Set(was); }
    if (!tlMulti.size && tlSel) tlMulti.add(tlSel);
    const off = ids.every(id => tlMulti.has(id));
    ids.forEach(id => off ? tlMulti.delete(id) : tlMulti.add(id));
    pickT = Date.now(); tlStop();
    if (!tlSel || !tlMulti.has(tlSel)) { const f = [...tlMulti][0]; if (f) tlSelect(f, true); }
    tlDraw(); kfTrackDraw(); try { sbSoon(); } catch (er) { }
    toast(tlMulti.size > 1 ? '已多选 ' + tlMulti.size + ' 个素材（Ctrl / Shift + 点 = 加选或取消；预览外面按住拖 = 框选）' : '已选中 1 个素材');
    return;
  }
  if (e.button === 0 && e.altKey && hits.length) {
    const cx = e.clientX, cy = e.clientY;
    const same = pickLast && Math.abs(pickLast.x - cx) < 6 && Math.abs(pickLast.y - cy) < 6;
    const i = same ? (pickLast.i + 1) % hits.length : (hits.findIndex(c => c.id === tlSel) + 1) % hits.length;
    pk = hits[i]; pickLast = { x: cx, y: cy, i };
  } else if (e.button === 0) pickLast = null;
  if (!pk) { if (g0) grpDown(e); return; }            // 空白处：选着组合时照样拖组合；否则照旧
  const pg = pk.group && grp(pk.group);
  if (g0 && pk.group === g0.id) { grpDown(e); return; }                  // 选着这个组合：整组一起动
  if (pg && tlIn !== pg.id) {                         // 点到组合里的素材（没进到里面）：选中整个组合，并且这一下就能拖 / 转
    tlStop(); selGroup(pg.id); grpDown(e); pickT = Date.now();
    toast('已选中组合「' + pg.name + '」：拖动 / 滚轮 / 右键转都是整组一起。双击里面的素材可以单独改它');
    return;
  }
  if (!g0 && pk.id !== tlSel && tlMulti.size > 1 && tlMulti.has(pk.id) && e.button === 0) {   // 多选里的另一个：多选不变，它变成主素材（再按住拖就一起动）
    eat(e); pickT = Date.now(); tlStop(); tlSelect(pk.id, true); tlDraw(); return;
  }
  if (g0 || pk.id !== tlSel) {                        // 点到别的素材：只切换，这一下不拖（画面要先换成它的参数）
    if (e.button !== 0) { if (g0) grpDown(e); return; }
    eat(e); pickT = Date.now(); tlStop(); tlSelect(pk.id);
    toast('已选中「' + fxName(pk) + '」（第 ' + (pk.layer + 1) + ' 层）' + (hits.length > 1 ? '　·　重叠的地方按住 Alt 点，选下面一层' : ''));
  }
  // 点的就是选中的素材：什么都不拦，照常拖动 / 缩放 / 转角度
}, true);
addEventListener('dblclick', e => {
  if (!inSw(e)) return;
  const g0 = grp(tlGrp);
  if (g0) {                                           // 选着组合时双击里面的素材 = 进到组合里面改它
    eat(e);
    const pk = hitsAt(e.clientX, e.clientY).find(c => c.group === g0.id);
    if (pk) enterGroup(g0, pk.id);                    // 双击组合里的素材 = 进到里面改它
    else gReset();                                    // 双击空白处 = 整个组合还原到刚合成时的样子（v13.1）
    return;
  }
  if (Date.now() - pickT < 600) eat(e);               // 刚切换完紧跟的双击不要传给效果（不然会把新选中的素材「双击还原」）
}, true);
// 关键帧轨道（播放器下面那条）在选中组合时显示组合自己的关键帧：给它一个和效果 __fxKeysApi 一样用法的接口
window.__kfGroupApi = () => {
  const g = grp(tlGrp); if (!g) return null;
  FXGroup.norm(g);
  const span = () => { const [a, b] = gRange(g); return [a, Math.max(0.01, b - a)]; };
  const toT = k => {                                  // 组合的点 → 轨道上的点（字段名和效果的一样，提示文字直接能用）
    const o = { t: k.t, k: k.k };
    if (k.k === 'p') { o.ox = Math.round(k.x); o.oy = Math.round(k.y); }
    else if (k.k === 's') o.s = k.s / 100;
    else if (k.k === 'r') { o.x = k.rx; o.y = k.ry; o.z = k.rz; }
    else o.o = k.o;
    return o;
  };
  const fromT = k => {
    const o = { t: Math.max(0, r2(k.t)), k: k.k };
    if (k.k === 'p') { o.x = +k.ox; o.y = +k.oy; } else if (k.k === 's') o.s = +k.s * 100;
    else if (k.k === 'r') { o.rx = +k.x; o.ry = +k.y; o.rz = +k.z; } else o.o = +k.o;
    return o;
  };
  const after = () => { tlRender(); gpSync(); tlDraw(); tlSave(); };
  return {
    get: () => g.keys.map(toT),
    set: list => {
      g.keys = FXGroup.sortK(list.filter(k => FXGroup.LANES[k.k]).map(fromT));
      if (!g.keys.length && g.anim) { g.tf = Object.assign({}, TF0, pick(gVal(g, tlT))); g.anim = false; }
      else if (g.keys.length) g.anim = true;
      after();
    },
    addAt: (t, lane) => {
      if (!g.anim) { g.anim = true; if (!g.keys.length) g.keys = []; }
      gKeyAll(g, Math.max(0, r2(t)), gVal(g, span()[0] + t), lane ? [lane] : null); after();
    },
    enabled: () => true, total: () => span()[1], opt: null,
    dur: () => span()[1], now: () => Math.max(0, Math.min(span()[1], tlT - span()[0])),
    seek: t => { tlStop(); tlSeek(span()[0] + t); },
    lanes: () => [['P', '位置（左键拖）', 'p'], ['S', '大小（滚轮）', 's'], ['R', '旋转（右键拖）', 'r'], ['O', '不透明度（右侧面板）', 'o']]
  };
};

// ---------- 快捷键（不在输入框里打字时全局生效） ----------
addEventListener('keydown', e => {
  const a = document.activeElement;
  if (a && (a.tagName === 'TEXTAREA' || a.tagName === 'SELECT' || (a.tagName === 'INPUT' && a.type !== 'range') || a.isContentEditable)) return;
  if (document.querySelector('.mask') || a === kfTrack) return;     // 弹窗开着 / 在关键帧轨道上：交给它们自己
  const c = clip(tlSel), k = e.key, ctrl = e.ctrlKey || e.metaKey;
  if (k === ' ' && !ctrl) { if (TL.clips.length || REF) tlPlay(); else $('#pp').click(); }
  else if ((k === 'l' || k === 'L') && !ctrl && !e.altKey && (TL.clips.length || REF)) tlFaster();   // L = 倍速播放 2 → 4 → 8
  else if (!TL.clips.length) return;
  else if ((k === 'Delete' || k === 'Backspace') && (c || tlGrp) && zone !== 'panel') delSel();   // v22.0：最后点的是右侧面板时不删素材（删面板里选中的关键帧）
  else if (ctrl && !e.shiftKey && k.toLowerCase() === 'g') makeGroup();
  else if (ctrl && e.shiftKey && k.toLowerCase() === 'c' && (tlMulti.size || c)) makeGroup();
  else if (ctrl && e.shiftKey && k.toLowerCase() === 'g') unGroup();
  else if (k === 'Escape' && tlIn && !tlGrp && tlMulti.size <= 1 && grp(tlIn)) { commitSel(); selGroup(tlIn); toast('已回到整个组合'); }   // 从组合里面退出来
  else if (k === 'Escape' && (tlGrp || tlMulti.size > 1)) { tlGrp = null; tlMulti = new Set(tlSel ? [tlSel] : []); gpBuild(); tlDraw(); kfTrackDraw(); }
  else if (ctrl && k.toLowerCase() === 'd' && (c || tlGrp)) dupSel();
  else if ((c || tlGrp) && ((ctrl && k === ']') || (e.altKey && k === 'ArrowUp'))) moveLayer(1);
  else if ((c || tlGrp) && ((ctrl && k === '[') || (e.altKey && k === 'ArrowDown'))) moveLayer(-1);
  else if ((c || tlGrp) && !ctrl && !e.altKey && (k === 'ArrowLeft' || k === 'ArrowRight') && (a === trk || a === document.body || !a)) {
    const st = (k === 'ArrowLeft' ? -1 : 1) * (e.shiftKey ? 1 : 0.1);
    const cs = tlGrp ? TL.clips.filter(o => o.group === tlGrp) : tlMulti.size > 1 ? [...tlMulti].map(clip).filter(Boolean) : [c];
    const k0 = Math.max(st, -Math.min(...cs.map(o => o.start)));
    cs.forEach(o => o.start = r2(o.start + k0)); tlRender(); tlDraw(); tlSave();
  }
  else if (!ctrl && !e.altKey && (k === 'ArrowUp' || k === 'ArrowDown')) tlJumpEdit(k === 'ArrowUp' ? -1 : 1);   // v50.0 ↑ / ↓ = 跳到上一个 / 下一个剪辑点（素材入点、出点）
  else if (k === 'Home') { tlStop(); tlSeek(0); }
  else if (k === 'End') { tlStop(); tlSeek(tlEnd()); }
  else return;
  e.preventDefault(); e.stopPropagation();
}, true);

// ---------- 预览窗口下面的分割线：上下拖改预览窗口高度，双击还原 ----------
const split = document.createElement('div'); split.id = 'split'; split.title = '上下拖动：调整预览窗口大小（双击还原）';
$('#stagewrap').after(split);
const applyStageH = () => { $('#stagewrap').style.flex = window.__stageH ? '0 0 auto' : ''; fit(); };
window.__stageH = store.get('stageH', null); if (window.__stageH) applyStageH();
let sp = null;
split.addEventListener('mousedown', e => { if (e.button) return; sp = { y: e.clientY, h: box.offsetHeight }; split.classList.add('on'); document.body.style.cursor = 'row-resize'; e.preventDefault(); });
addEventListener('mousemove', e => { if (!sp) return; window.__stageH = Math.round(Math.max(120, Math.min(innerHeight - 120, sp.h + e.clientY - sp.y))); applyStageH(); });
addEventListener('mouseup', () => { if (!sp) return; sp = null; split.classList.remove('on'); document.body.style.cursor = ''; store.set('stageH', window.__stageH); });
split.addEventListener('dblclick', () => { window.__stageH = null; store.set('stageH', null); applyStageH(); });
