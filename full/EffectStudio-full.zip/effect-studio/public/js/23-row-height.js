// 效果工坊 · 素材时间线层高可调（v33.0；v33.1 每一层单独调）
// 鼠标放到左边层名（层 1、层 2…）的下沿附近，光标变成上下箭头：
//   按住上下拖 = 只调这一层的高度；按住 Shift 拖 = 所有层一起调（清掉单独设过的）。
//   双击这条边 = 这一层回到默认高度（Shift + 双击 = 全部回到默认）。
// 高度记在浏览器里：fxnav:tlRowH（默认层高）、fxnav:tlRowHs（单独调过的层：{ 层号: 高度 }），下次打开还是这样。
// 10-timeline.js 每一行用 rowHeightOf(行) 取高度，并把它写成这一行元素上的 CSS 变量 --tlr（素材条、旗子都跟着它）。
const TR_MIN = 22, TR_MAX = 96, TR_DEF = 30, TR_EDGE = 5;   // 下沿上下各 5 像素算「抓得到」
const clampH = h => Math.max(TR_MIN, Math.min(TR_MAX, Math.round(h)));
let RH = (() => { const o = store.get('tlRowHs', {}); return o && typeof o === 'object' ? o : {}; })();
// v35.x 选中哪层哪层临时变宽：层高不到 45 像素时，选中这一层的素材 → 这一层临时放大到 2.5 倍（至少 60）；
// 选回别的层就自动缩回去。只是显示，不改存下来的层高。
// v35.x「只看这一层」：选中素材后按 ` 键（键盘左上角、数字 1 左边，和 Premiere 放大面板同一个键）→ 这一层展开，其他层压窄；再按一下恢复原样
let rhSolo = null, rhAuto = store.get('tlAutoFold', true);   // rhAuto：空层自动收起的开关（标题栏小按钮 ⇕）
// v35.x 空层自动收起：时间线当前看得见的这一段里没有素材的层压到最窄（22 像素），左右滚动停下后重新算
const rhBusy = () => {
  const NW = tlNW(), tw = tlSc.classList.contains('zm') ? parseFloat(tlSc.style.getPropertyValue('--tw')) : Math.max(100, tlSc.clientWidth - NW);
  const a = tlSc.scrollLeft / tw * tlV, b = (tlSc.scrollLeft + tlSc.clientWidth - NW) / tw * tlV, set = new Set();
  TL.clips.forEach(c => { if (!c.ref && c.start < b && c.start + c.len > a) set.add(c.layer); }); return set;
};
function rowHeightOf(r) {
  if (r && r.t === 'layer' && rhSolo != null) return r.L === rhSolo ? Math.max(70, clampH(RH[r.L] || TR)) : TR_MIN;
  if (rhAuto && r && r.t === 'layer' && TL.clips.length > 3) { try { if (!rhBusy().has(r.L) && !(tlSel && (clip(tlSel) || {}).layer === r.L)) return TR_MIN; } catch (e) { } }
  const h = r && r.t === 'layer' && RH[r.L] ? clampH(RH[r.L]) : TR;
  if (r && r.t === 'layer' && h < 45 && typeof tlSel !== 'undefined' && tlSel && !tlGrp) { const c = clip(tlSel); if (c && !c.ref && c.layer === r.L) return Math.min(TR_MAX, Math.max(60, Math.round(h * 2.5))); }
  return h;
}
function tlSetRowH(h, save) {
  TR = clampH(h);
  $('#tlp').style.setProperty('--tlr', TR + 'px');
  if (save) store.set('tlRowH', TR);
}
tlSetRowH(TR, false);
// 指针在哪一行的下沿：返回 { i: 第几行, r: 那一行 }，不在返回 null
function rowEdgeAt(e) {
  const kids = names.children, R = buildRows();
  for (let i = 0; i < kids.length; i++) {
    const b = kids[i].getBoundingClientRect().bottom;
    if (Math.abs(e.clientY - b) <= TR_EDGE) return { i, r: R[i] };
  }
  return null;
}
let rhDrag = null;
names.addEventListener('mousemove', e => { if (!rhDrag) names.style.cursor = rowEdgeAt(e) ? 'row-resize' : ''; });
names.addEventListener('mouseleave', () => { if (!rhDrag) names.style.cursor = ''; });
names.addEventListener('mousedown', e => {
  const k = rowEdgeAt(e); if (!k || e.button !== 0) return;
  e.preventDefault(); e.stopPropagation();
  const one = !e.shiftKey && k.r && k.r.t === 'layer';    // 只调这一层；按 Shift 或拖「新层 / 组合」那一行 = 全部一起
  if (!one) RH = {};
  rhDrag = { one, L: k.r ? k.r.L : -1, y0: e.clientY, h0: one ? rowHeightOf(k.r) : TR };
  document.documentElement.style.cursor = 'row-resize';
}, true);
addEventListener('mousemove', e => {
  if (!rhDrag) return;
  const h = clampH(rhDrag.h0 + (e.clientY - rhDrag.y0));
  if (rhDrag.one) { if (RH[rhDrag.L] === h) return; RH[rhDrag.L] = h; } else { if (h === TR) return; tlSetRowH(h, false); }
  tlDraw();
});
addEventListener('mouseup', () => {
  if (!rhDrag) return;
  const d = rhDrag; rhDrag = null; document.documentElement.style.cursor = ''; names.style.cursor = '';
  store.set('tlRowHs', RH); tlSetRowH(TR, true);
  $('#hint').textContent = d.one ? '层 ' + (d.L + 1) + ' 高度：' + RH[d.L] + ' 像素（双击层名下沿回到默认；按住 Shift 拖 = 所有层一起调）'
    : '所有层高度：' + TR + ' 像素';
});
names.addEventListener('dblclick', e => {
  const k = rowEdgeAt(e); if (!k) return;
  e.preventDefault(); e.stopPropagation();
  if (!e.shiftKey && k.r && k.r.t === 'layer') { delete RH[k.r.L]; $('#hint').textContent = '层 ' + (k.r.L + 1) + ' 回到默认高度'; }
  else { RH = {}; tlSetRowH(TR_DEF, true); $('#hint').textContent = '所有层回到默认高度（' + TR_DEF + ' 像素）'; }
  store.set('tlRowHs', RH); tlDraw();
}, true);

{ let st = 0; tlSc.addEventListener('scroll', () => { clearTimeout(st); st = setTimeout(() => { if (!tlPlaying) tlDraw(); }, 250); }, { passive: true }); }
addEventListener('keydown', e => {
  if (e.key !== '`' && e.code !== 'Backquote') return;
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const t = e.target; if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
  e.preventDefault();
  if (rhSolo != null) { rhSolo = null; tlDraw(); return toast('已恢复原来的层高'); }
  const c = tlSel && clip(tlSel); if (!c || c.ref) return toast('先选中一个素材，再按 ` 只看它这一层');
  rhSolo = c.layer; tlDraw(); toast('只看第 ' + (c.layer + 1) + ' 层（其他层压窄）· 再按 ` 恢复');
});
{ // 空层自动收起的开关：标题栏磁铁旁边一个不起眼的 ⇕
  const b = document.createElement('button'); b.type = 'button'; b.id = 'tl-fold';
  b.style.cssText = 'font-size:12px;padding:1px 6px;margin-right:4px;background:transparent;border:1px solid #444;border-radius:4px;cursor:pointer;color:#ddd';
  const lab = () => { b.textContent = '⇕'; b.style.opacity = rhAuto ? '1' : '.35'; b.title = '空层自动收起：' + (rhAuto ? '开' : '关') + '（点一下切换）\n开着时，时间线看得见的这一段里没有素材的层压到最窄'; };
  b.onclick = () => { rhAuto = !rhAuto; store.set('tlAutoFold', rhAuto); lab(); tlDraw(); toast('空层自动收起' + (rhAuto ? '已打开' : '已关闭')); };
  lab(); const m = $('#tl-mag'); if (m) m.after(b); else $('#tlp-k').before(b);
}
