// 效果工坊 · 素材时间线层高可调（v33.0；v33.1 每一层单独调）
// 鼠标放到左边层名（层 1、层 2…）的下沿附近，光标变成上下箭头：
//   按住上下拖 = 只调这一层的高度；按住 Shift 拖 = 所有层一起调（清掉单独设过的）。
//   双击这条边 = 这一层回到默认高度（Shift + 双击 = 全部回到默认）。
// 高度记在浏览器里：fxnav:tlRowH（默认层高）、fxnav:tlRowHs（单独调过的层：{ 层号: 高度 }），下次打开还是这样。
// 10-timeline.js 每一行用 rowHeightOf(行) 取高度，并把它写成这一行元素上的 CSS 变量 --tlr（素材条、旗子都跟着它）。
const TR_MIN = 22, TR_MAX = 96, TR_DEF = 30, TR_EDGE = 5;   // 下沿上下各 5 像素算「抓得到」
const clampH = h => Math.max(TR_MIN, Math.min(TR_MAX, Math.round(h)));
let RH = (() => { const o = store.get('tlRowHs', {}); return o && typeof o === 'object' ? o : {}; })();
function rowHeightOf(r) { return r && r.t === 'layer' && RH[r.L] ? clampH(RH[r.L]) : TR; }
function tlSetRowH(h, save) {
  TR = clampH(h);
  $('#tlp').style.setProperty('--tlr', TR + 'px');
  if (save) store.set('tlRowH', TR);
}
tlSetRowH(TR, false);
// 指针在哪一行的下沿：返回 { i: 第几行, r: 那一行 }，不在返回 null
function rowEdgeAt(e) {
  const kids = names.children, R = buildRows();
  for (let i = 0; i < kids.length; i++) {
    const b = kids[i].getBoundingClientRect().bottom;
    if (Math.abs(e.clientY - b) <= TR_EDGE) return { i, r: R[i] };
  }
  return null;
}
let rhDrag = null;
names.addEventListener('mousemove', e => { if (!rhDrag) names.style.cursor = rowEdgeAt(e) ? 'row-resize' : ''; });
names.addEventListener('mouseleave', () => { if (!rhDrag) names.style.cursor = ''; });
names.addEventListener('mousedown', e => {
  const k = rowEdgeAt(e); if (!k || e.button !== 0) return;
  e.preventDefault(); e.stopPropagation();
  const one = !e.shiftKey && k.r && k.r.t === 'layer';    // 只调这一层；按 Shift 或拖「新层 / 组合」那一行 = 全部一起
  if (!one) RH = {};
  rhDrag = { one, L: k.r ? k.r.L : -1, y0: e.clientY, h0: one ? rowHeightOf(k.r) : TR };
  document.documentElement.style.cursor = 'row-resize';
}, true);
addEventListener('mousemove', e => {
  if (!rhDrag) return;
  const h = clampH(rhDrag.h0 + (e.clientY - rhDrag.y0));
  if (rhDrag.one) { if (RH[rhDrag.L] === h) return; RH[rhDrag.L] = h; } else { if (h === TR) return; tlSetRowH(h, false); }
  tlDraw();
});
addEventListener('mouseup', () => {
  if (!rhDrag) return;
  const d = rhDrag; rhDrag = null; document.documentElement.style.cursor = ''; names.style.cursor = '';
  store.set('tlRowHs', RH); tlSetRowH(TR, true);
  $('#hint').textContent = d.one ? '层 ' + (d.L + 1) + ' 高度：' + RH[d.L] + ' 像素（双击层名下沿回到默认；按住 Shift 拖 = 所有层一起调）'
    : '所有层高度：' + TR + ' 像素';
});
names.addEventListener('dblclick', e => {
  const k = rowEdgeAt(e); if (!k) return;
  e.preventDefault(); e.stopPropagation();
  if (!e.shiftKey && k.r && k.r.t === 'layer') { delete RH[k.r.L]; $('#hint').textContent = '层 ' + (k.r.L + 1) + ' 回到默认高度'; }
  else { RH = {}; tlSetRowH(TR_DEF, true); $('#hint').textContent = '所有层回到默认高度（' + TR_DEF + ' 像素）'; }
  store.set('tlRowHs', RH); tlDraw();
}, true);
