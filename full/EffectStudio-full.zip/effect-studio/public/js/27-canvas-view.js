// 效果工坊 · 画布按预览框实际大小画（v57.0）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// 为什么：素材页面都按 1920 宽排版再缩进预览框；用画布画的效果以前按「屏幕倍数」建画布，屏幕缩放 200% 时就是 3840×2160，
//   可预览框只有一千来像素宽 —— 6 段素材叠在同一秒，内存就爆了（Out of Memory）。
// 怎么做：效果那边用 effects/_shared/view-controls.js【区域V】的 FXView 算画布倍数：
//   最外层是工作台（下面这个 __fxStudio）时，把「页面被缩小了多少」乘进去；导出时最外层是 comp.html / effect.html，不受影响。
// 这里做三件事：① 标记「我是工作台」；② 预览框大小变了（Hooks 'fit'）→ 叫每个素材页面重新量一次，倍数变了它自己重建画布；
// ③ 播放按钮那一行的「预览清晰度」下拉菜单，四档（v58.0）。

window.__fxStudio = true;
{
  let rq = 0;
  // 一层层往里找所有页面（选中的 #frame、叠加层 ghost.html 里的效果、左侧缩略图 thumb.html 里的效果）
  const poke = w => {
    try { if (typeof w.__fxRescale === 'function') w.__fxRescale(); } catch (e) { }
    let n = 0; try { n = w.frames.length; } catch (e) { }
    for (let i = 0; i < n; i++) { try { poke(w.frames[i]); } catch (e) { } }
  };
  // 同一帧里 fit 可能连着触发好几次，合成一次
  const rescaleAll = () => { if (rq) return; rq = requestAnimationFrame(() => { rq = 0; poke(window); }); };
  Hooks.on('fit', rescaleAll);
  Hooks.on('reinit', rescaleAll);
  window.__fxRescaleAll = rescaleAll;

  // ---------- 预览清晰度（v58.0）：播放按钮那一行最右边，小下拉菜单，四档 ----------
  // 只影响预览（用画布画的效果：纯背景、镜头推进、点线网、国家地图、圆形闪光换色卡、文字走廊、卡片背景动效），导出永远按正常分辨率。
  // 省 = 一半清晰度，最省内存，略糊；标准 = 刚好等于预览框在屏幕上的像素（默认）；清晰 = 1.5 倍，放大看细节时边缘更利落。
  const LV = [['0.5', '省', '一半清晰度：最省内存和显卡，画面略糊（只影响预览，导出不受影响）'],
              ['0.75', '均衡', '四分之三清晰度：比「标准」省将近一半，基本看不出糊'],
              ['1', '标准', '和预览框在屏幕上的像素一样多：刚好清楚（默认）'],
              ['1.5', '清晰', '1.5 倍：边缘更利落，占用多一些；最多也不超过按整屏画的量']];
  let cur = String(store.get('pvQ', '1')); if (!LV.some(l => l[0] === cur)) cur = '1';
  window.__fxPreviewQ = +cur;
  const bar = $('#pbar');
  if (bar) {
    // 小下拉菜单（用户要求：按钮组太占地方）：「预览」两个字 + 一个下拉框，选项上悬停有说明
    const g = document.createElement('label'); g.id = 'pvq'; g.title = '预览清晰度：只影响预览，导出永远按正常分辨率\n省 = 最省资源、略糊；标准 = 刚好清楚（默认）；清晰 = 更利落、多占一些';
    g.innerHTML = '<span>预览</span><select>' + LV.map(l => `<option value="${l[0]}" title="${l[2]}">${l[1]}</option>`).join('') + '</select>';
    const sel = g.querySelector('select'); sel.value = cur;
    sel.addEventListener('change', () => {
      cur = sel.value; window.__fxPreviewQ = +cur; store.set('pvQ', cur); rescaleAll(); sel.blur();   // 失焦：免得空格 / 方向键还在改它
      const h = $('#hint'); if (h) h.textContent = '预览清晰度：' + sel.options[sel.selectedIndex].text + '（只影响预览，导出不受影响）';
    });
    bar.appendChild(g);
  }
}
