// 效果工坊 · 拖进来 · 预览里点选素材 · 快捷键 · 预览高度分割线
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ---------- 从左边把效果拖进来 ----------
new MutationObserver(() => document.querySelectorAll('#list .item:not([draggable])').forEach(b => b.draggable = true)).observe($('#list'), { childList: true, subtree: true });
document.querySelectorAll('#list .item').forEach(b => b.draggable = true);
let dragFx = null;
addEventListener('dragstart', e => { const it = e.target.closest && e.target.closest('#list .item'); if (!it) return; dragFx = it.dataset.id; e.dataTransfer.effectAllowed = 'copy'; e.dataTransfer.setData('text/plain', 'fx:' + dragFx); });
addEventListener('dragend', () => { dragFx = null; panel.classList.remove('dropok'); $('#stagewrap').classList.remove('dropok'); });
[[panel, true], [$('#stagewrap'), false]].forEach(([el, onTl]) => {
  el.addEventListener('dragover', e => { if (!dragFx) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; el.classList.add('dropok'); });
  el.addEventListener('dragleave', e => { if (!el.contains(e.relatedTarget)) el.classList.remove('dropok'); });
  el.addEventListener('drop', e => {
    if (!dragFx) return; e.preventDefault(); el.classList.remove('dropok');
    const id = dragFx; dragFx = null; tlStop(); stop();
    let start = TL.clips.length ? tlT : 0, layer = null;
    if (onTl && TL.clips.length) {
      const r = W();
      if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top + RUL && e.clientY <= r.bottom) {
        start = xT(e.clientX); layer = rowLayer(rowAt(buildRows(), e.clientY));
      }
    }
    addFx(id, start, layer);
  });
});

// ---------- 在预览窗口里点素材 = 在时间线上选中它（v12.0，所有效果通用；v12.1 加了组合规则） ----------
// 点下去的那一点，从最上面一层往下找：哪个素材在这一点上「画了东西」（不是透明的、不是整屏的空容器），就选中哪个。
// 点到的就是已经选中的素材 → 照常拖动 / 缩放；点到别的素材 → 只切换选中，这一下不拖（画面要先换成它的参数）。
// Alt + 点：重叠时选「下面一层」的那个（每点一次往下换一层）。点在空白处：什么都不变。
// 效果本身一行不用改：判断用的是效果页面自己的 DOM（document.elementFromPoint），所以以后的新效果也自动支持。
function pickDoc(el) {                               // 素材对应的效果页面：选中的在 #frame，没选中的在 ghost.html 里面那层
  try {
    const d = el.contentDocument; if (!d) return null;
    if (el === frame) return d;
    const inner = d.getElementById('fx'); return inner ? inner.contentDocument : null;
  } catch (e) { return null; }
}
// 预览区里的一点 → 这个 iframe 里的坐标。iframe 套着变换（缩放适配 + 组合的位置 / 大小 / 三轴旋转 / 透视），
// 这里把变换矩阵反过来解：求 iframe 平面（z = 0）上哪一点投影到鼠标这里，旋转过的组合也点得准（v12.1）
function toLocal(el, cx, cy) {
  const br = box.getBoundingClientRect(), sx = cx - br.left - box.clientLeft, sy = cy - br.top - box.clientTop;
  const tf = getComputedStyle(el).transform;
  const m = !tf || tf === 'none' ? new DOMMatrix() : new DOMMatrix(tf);
  const a1 = m.m11 - sx * m.m14, b1 = m.m21 - sx * m.m24, c1 = sx * m.m44 - m.m41;
  const a2 = m.m12 - sy * m.m14, b2 = m.m22 - sy * m.m24, c2 = sy * m.m44 - m.m42;
  const det = a1 * b2 - a2 * b1; if (Math.abs(det) < 1e-9) return null;      // 转到正侧面（看不见了）
  const x = (c1 * b2 - c2 * b1) / det, y = (a1 * c2 - a2 * c1) / det;
  if (m.m14 * x + m.m24 * y + m.m44 <= 0) return null;                       // 在镜头后面
  return [x, y];
}
function hitClip(el, cx, cy) {
  if (!el || el.style.visibility === 'hidden') return false;
  const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false;
  if (cx < r.left || cx > r.right || cy < r.top || cy > r.bottom) return false;
  const d = pickDoc(el); if (!d || !d.defaultView) return false;
  const w = d.defaultView, vw = w.innerWidth, vh = w.innerHeight;
  const pt = toLocal(el, cx, cy); if (!pt) return false;
  const x = pt[0], y = pt[1];
  if (x < 0 || y < 0 || x > vw || y > vh) return false;
  let list = [];
  try { list = d.elementsFromPoint(x, y); } catch (e) { return false; }
  // 这一点上叠着的所有元素，从上往下：只要有一个是「看得见的东西」就算点中（高亮层这种透明的叠层会跳过）
  return list.some(hit => {
    if (hit === d.documentElement || hit === d.body) return false;
    const rb = hit.getBoundingClientRect();
    if (rb.width >= vw * 0.97 && rb.height >= vh * 0.97 && hit.tagName !== 'CANVAS') return false;   // 整屏的容器不算
    if (hit.tagName === 'CANVAS') {                  // 画布：看这一点的像素是不是透明的
      try { const g2 = hit.getContext('2d'); const px = g2 && g2.getImageData(Math.floor((x - rb.left) * hit.width / rb.width), Math.floor((y - rb.top) * hit.height / rb.height), 1, 1).data;
        if (px && px[3] < 8) return false; } catch (e) { }
    }
    let op = 1;                                       // 淡没了（还没入场 / 已经退场 / 透明的叠层）的不算
    for (let n = hit; n && n.nodeType === 1; n = n.parentElement) {
      const cs = w.getComputedStyle(n);
      if (cs.visibility === 'hidden' || cs.display === 'none') return false;
      op *= +cs.opacity; if (op < 0.04) return false;
    }
    return true;
  });
}
let pickLast = null, pickT = 0;                       // Alt + 点：记住上一次点的位置和选到第几个；pickT = 刚切换的时间
function hitsAt(cx, cy) {                             // 这一点上看得见的素材，从最上面一层往下
  return TL.clips.slice().sort((a, b) => zOf(b) - zOf(a)).filter(c => hitClip(c.id === tlSel ? frame : G[c.id], cx, cy));
}
const fxName = c => { const f = fxOf(c); return f ? f.name : c.fx; };
// v12.1 组合规则：组合（预合成）是一个整体 —— 点组合里的任何一个素材，选中的是整个组合，拖 / 滚轮 / 右键转都是整组一起；
// 要改里面某一个素材，双击它进到组合里面（Esc 退出来）。
addEventListener('mousedown', e => {
  if (!inSw(e) || tlLoading || !TL.clips.length) return;
  const g0 = grp(tlGrp);
  let hits = (e.button === 0 || e.button === 2) ? hitsAt(e.clientX, e.clientY) : [];
  let pk = hits[0];
  if (e.button === 0 && e.altKey && hits.length) {
    const cx = e.clientX, cy = e.clientY;
    const same = pickLast && Math.abs(pickLast.x - cx) < 6 && Math.abs(pickLast.y - cy) < 6;
    const i = same ? (pickLast.i + 1) % hits.length : (hits.findIndex(c => c.id === tlSel) + 1) % hits.length;
    pk = hits[i]; pickLast = { x: cx, y: cy, i };
  } else if (e.button === 0) pickLast = null;
  if (!pk) { if (g0) grpDown(e); return; }            // 空白处：选着组合时照样拖组合；否则照旧
  const pg = pk.group && grp(pk.group);
  if (g0 && pk.group === g0.id) { grpDown(e); return; }                  // 选着这个组合：整组一起动
  if (pg && tlIn !== pg.id) {                         // 点到组合里的素材（没进到里面）：选中整个组合，并且这一下就能拖 / 转
    tlStop(); selGroup(pg.id); grpDown(e); pickT = Date.now();
    toast('已选中组合「' + pg.name + '」：拖动 / 滚轮 / 右键转都是整组一起。双击里面的素材可以单独改它');
    return;
  }
  if (g0 || pk.id !== tlSel) {                        // 点到别的素材：只切换，这一下不拖（画面要先换成它的参数）
    if (e.button !== 0) { if (g0) grpDown(e); return; }
    eat(e); pickT = Date.now(); tlStop(); tlSelect(pk.id);
    toast('已选中「' + fxName(pk) + '」（第 ' + (pk.layer + 1) + ' 层）' + (hits.length > 1 ? '　·　重叠的地方按住 Alt 点，选下面一层' : ''));
  }
  // 点的就是选中的素材：什么都不拦，照常拖动 / 缩放 / 转角度
}, true);
addEventListener('dblclick', e => {
  if (!inSw(e)) return;
  const g0 = grp(tlGrp);
  if (g0) {                                           // 选着组合时双击里面的素材 = 进到组合里面改它
    eat(e);
    const pk = hitsAt(e.clientX, e.clientY).find(c => c.group === g0.id);
    if (pk) enterGroup(g0, pk.id);                    // 双击组合里的素材 = 进到里面改它
    else gReset();                                    // 双击空白处 = 整个组合还原到刚合成时的样子（v13.1）
    return;
  }
  if (Date.now() - pickT < 600) eat(e);               // 刚切换完紧跟的双击不要传给效果（不然会把新选中的素材「双击还原」）
}, true);
// 关键帧轨道（播放器下面那条）在选中组合时显示组合自己的关键帧：给它一个和效果 __fxKeysApi 一样用法的接口
window.__kfGroupApi = () => {
  const g = grp(tlGrp); if (!g) return null;
  FXGroup.norm(g);
  const span = () => { const [a, b] = gRange(g); return [a, Math.max(0.01, b - a)]; };
  const toT = k => {                                  // 组合的点 → 轨道上的点（字段名和效果的一样，提示文字直接能用）
    const o = { t: k.t, k: k.k };
    if (k.k === 'p') { o.ox = Math.round(k.x); o.oy = Math.round(k.y); }
    else if (k.k === 's') o.s = k.s / 100;
    else if (k.k === 'r') { o.x = k.rx; o.y = k.ry; o.z = k.rz; }
    else o.o = k.o;
    return o;
  };
  const fromT = k => {
    const o = { t: Math.max(0, r2(k.t)), k: k.k };
    if (k.k === 'p') { o.x = +k.ox; o.y = +k.oy; } else if (k.k === 's') o.s = +k.s * 100;
    else if (k.k === 'r') { o.rx = +k.x; o.ry = +k.y; o.rz = +k.z; } else o.o = +k.o;
    return o;
  };
  const after = () => { tlRender(); gpSync(); tlDraw(); tlSave(); };
  return {
    get: () => g.keys.map(toT),
    set: list => {
      g.keys = FXGroup.sortK(list.filter(k => FXGroup.LANES[k.k]).map(fromT));
      if (!g.keys.length && g.anim) { g.tf = Object.assign({}, TF0, pick(gVal(g, tlT))); g.anim = false; }
      else if (g.keys.length) g.anim = true;
      after();
    },
    addAt: (t, lane) => {
      if (!g.anim) { g.anim = true; if (!g.keys.length) g.keys = []; }
      gKeyAll(g, Math.max(0, r2(t)), gVal(g, span()[0] + t), lane ? [lane] : null); after();
    },
    enabled: () => true, total: () => span()[1], opt: null,
    dur: () => span()[1], now: () => Math.max(0, Math.min(span()[1], tlT - span()[0])),
    seek: t => { tlStop(); tlSeek(span()[0] + t); },
    lanes: () => [['P', '位置（左键拖）', 'p'], ['S', '大小（滚轮）', 's'], ['R', '旋转（右键拖）', 'r'], ['O', '不透明度（右侧面板）', 'o']]
  };
};

// ---------- 快捷键（不在输入框里打字时全局生效） ----------
addEventListener('keydown', e => {
  const a = document.activeElement;
  if (a && (a.tagName === 'TEXTAREA' || a.tagName === 'SELECT' || (a.tagName === 'INPUT' && a.type !== 'range') || a.isContentEditable)) return;
  if (document.querySelector('.mask') || a === kfTrack) return;     // 弹窗开着 / 在关键帧轨道上：交给它们自己
  const c = clip(tlSel), k = e.key, ctrl = e.ctrlKey || e.metaKey;
  if (k === ' ' && !ctrl) { if (TL.clips.length || REF) tlPlay(); else $('#pp').click(); }
  else if (!TL.clips.length) return;
  else if ((k === 'Delete' || k === 'Backspace') && (c || tlGrp) && zone !== 'panel') delSel();   // v22.0：最后点的是右侧面板时不删素材（删面板里选中的关键帧）
  else if (ctrl && !e.shiftKey && k.toLowerCase() === 'g') makeGroup();
  else if (ctrl && e.shiftKey && k.toLowerCase() === 'c' && (tlMulti.size || c)) makeGroup();
  else if (ctrl && e.shiftKey && k.toLowerCase() === 'g') unGroup();
  else if (k === 'Escape' && tlIn && !tlGrp && tlMulti.size <= 1 && grp(tlIn)) { commitSel(); selGroup(tlIn); toast('已回到整个组合'); }   // 从组合里面退出来
  else if (k === 'Escape' && (tlGrp || tlMulti.size > 1)) { tlGrp = null; tlMulti = new Set(tlSel ? [tlSel] : []); gpBuild(); tlDraw(); kfTrackDraw(); }
  else if (ctrl && k.toLowerCase() === 'd' && (c || tlGrp)) dupSel();
  else if ((c || tlGrp) && ((ctrl && k === ']') || (e.altKey && k === 'ArrowUp'))) moveLayer(1);
  else if ((c || tlGrp) && ((ctrl && k === '[') || (e.altKey && k === 'ArrowDown'))) moveLayer(-1);
  else if ((c || tlGrp) && !ctrl && !e.altKey && (k === 'ArrowLeft' || k === 'ArrowRight') && (a === trk || a === document.body || !a)) {
    const st = (k === 'ArrowLeft' ? -1 : 1) * (e.shiftKey ? 1 : 0.1);
    const cs = tlGrp ? TL.clips.filter(o => o.group === tlGrp) : tlMulti.size > 1 ? [...tlMulti].map(clip).filter(Boolean) : [c];
    const k0 = Math.max(st, -Math.min(...cs.map(o => o.start)));
    cs.forEach(o => o.start = r2(o.start + k0)); tlRender(); tlDraw(); tlSave();
  }
  else if (k === 'Home') { tlStop(); tlSeek(0); }
  else if (k === 'End') { tlStop(); tlSeek(tlEnd()); }
  else return;
  e.preventDefault(); e.stopPropagation();
}, true);

// ---------- 预览窗口下面的分割线：上下拖改预览窗口高度，双击还原 ----------
const split = document.createElement('div'); split.id = 'split'; split.title = '上下拖动：调整预览窗口大小（双击还原）';
$('#stagewrap').after(split);
const applyStageH = () => { $('#stagewrap').style.flex = window.__stageH ? '0 0 auto' : ''; fit(); };
window.__stageH = store.get('stageH', null); if (window.__stageH) applyStageH();
let sp = null;
split.addEventListener('mousedown', e => { if (e.button) return; sp = { y: e.clientY, h: box.offsetHeight }; split.classList.add('on'); document.body.style.cursor = 'row-resize'; e.preventDefault(); });
addEventListener('mousemove', e => { if (!sp) return; window.__stageH = Math.round(Math.max(120, Math.min(innerHeight - 120, sp.h + e.clientY - sp.y))); applyStageH(); });
addEventListener('mouseup', () => { if (!sp) return; sp = null; split.classList.remove('on'); document.body.style.cursor = ''; store.set('stageH', window.__stageH); });
split.addEventListener('dblclick', () => { window.__stageH = null; store.set('stageH', null); applyStageH(); });
