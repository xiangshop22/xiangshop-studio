// 效果工坊 · 加载效果 / 导出效果 / 导出 MOV
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 加载效果 / 导出效果（v6） =================
// 【拖入】zip 直接上传；文件夹先在网页里打成 zip 再上传（server.js 负责解压、放进 effects、同名备份）
const toastEl = $('#toast'); let toastT = 0;
function toast(t, err, ms) { toastEl.textContent = t; toastEl.className = 'on' + (err ? ' err' : ''); clearTimeout(toastT); toastT = setTimeout(() => toastEl.className = '', ms || (err ? 7000 : 4000)); }
// 弹窗：返回用户点的按钮的 value（点遮罩 = 取消）
function dialog({ title, html, buttons }) {
  return new Promise(ok => {
    const m = document.createElement('div'); m.className = 'mask';
    m.innerHTML = '<div class="dlg"><h3></h3><div class="bd"></div><div class="btns"></div></div>';
    m.querySelector('h3').textContent = title; m.querySelector('.bd').innerHTML = html;
    const close = v => { m.remove(); ok(v); };
    buttons.forEach(b => { const x = document.createElement('button'); x.type = 'button'; x.className = b.cls || ''; x.textContent = b.text; x.onclick = () => close(b.value); m.querySelector('.btns').appendChild(x); });
    m.addEventListener('mousedown', e => { if (e.target === m) close(null); });
    document.body.appendChild(m);
  });
}
const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// 网页里打 zip（不压缩，只是装在一起），用于拖进来的是文件夹的情况
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = u => { let c = 0xffffffff; for (let i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
function makeZip(files) {               // files: [{ path, data: Uint8Array }]
  const enc = new TextEncoder(), parts = [], cd = []; let off = 0;
  for (const f of files) {
    const nm = enc.encode(f.path), d = f.data, crc = crc32(d);
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x800, true);
    lh.setUint32(14, crc, true); lh.setUint32(18, d.length, true); lh.setUint32(22, d.length, true); lh.setUint16(26, nm.length, true);
    parts.push(lh, nm, d);
    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x800, true);
    ch.setUint32(16, crc, true); ch.setUint32(20, d.length, true); ch.setUint32(24, d.length, true); ch.setUint16(28, nm.length, true); ch.setUint32(42, off, true);
    cd.push(ch, nm); off += 30 + nm.length + d.length;
  }
  const cdLen = cd.reduce((a, x) => a + x.byteLength, 0), end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cdLen, true); end.setUint32(16, off, true);
  return new Blob([...parts, ...cd, end], { type: 'application/zip' });
}
// 把拖进来的文件夹里的文件全部读出来
async function readEntry(entry, prefix, out) {
  if (entry.isFile) {
    const f = await new Promise((ok, no) => entry.file(ok, no));
    out.push({ path: prefix + entry.name, data: new Uint8Array(await f.arrayBuffer()) });
  } else if (entry.isDirectory) {
    const rd = entry.createReader(); let batch;
    do { batch = await new Promise((ok, no) => rd.readEntries(ok, no)); for (const e of batch) await readEntry(e, prefix + entry.name + '/', out); } while (batch.length);
  }
}
const api = (url, body, name) => fetch(url, { method: 'POST', headers: { 'X-FX': '1', 'X-File-Name': encodeURIComponent(name || '') }, body }).then(r => r.json());
async function reloadEffects(pick) {
  effects = await (await fetch('/api/effects')).json(); window.__fxList = effects;
  navBuilt = false; Object.keys(navCards).forEach(k => delete navCards[k]);
  if (!effects.length) { $('#list').textContent = 'effects 文件夹里还没有效果'; return; }
  const id = effects.some(e => e.id === pick) ? pick : cur && effects.some(e => e.id === cur.id) ? cur.id : effects[0].id;
  renderList(); select(id);
  const card = navCards[id]; if (card) card.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
async function waitRestart() {
  toast('工作台已升级，正在重启…', false, 60000);
  await new Promise(r => setTimeout(r, 1500));
  for (let i = 0; i < 60; i++) { try { const r = await fetch('/api/info'); if (r.ok) { location.reload(); return; } } catch (e) {} await new Promise(r => setTimeout(r, 1000)); }
  toast('工作台没有自动重启。请关闭黑窗口，重新双击 start.bat', true, 15000);
}
// 装一个 zip：先问服务器里面有什么 → 有同名就弹窗问 → 安装 → 刷新左侧列表
async function installZip(blob, name) {
  const chk = await api('/api/install?mode=check', blob, name);
  if (chk.error) { toast('「' + name + '」没装上：' + chk.error, true); return; }
  if (chk.same) { toast('你已经有这些效果了，内容完全一样，不用再装：\n' + chk.unchanged.join('、')); const e = effects.find(x => x.name === chk.unchanged[0]); if (e && (!cur || cur.id !== e.id)) select(e.id); return; }
  const same = chk.effects.filter(e => e.exists), fresh = chk.effects.filter(e => !e.exists);
  let mode = 'overwrite';
  if (chk.studio) {
    const li = chk.effects.map(e => '<li>' + esc(e.name) + (e.exists ? '<em>已有，同名</em>' : '<em>新效果</em>') + '</li>').join('');
    mode = await dialog({ title: '升级整个工作台',
      html: '<p>这是<b>整个工作台</b>的压缩包' + (chk.studio.version ? '（' + esc(chk.studio.version) + '，你现在是 ' + esc(chk.studio.current) + '）' : '') + '。会更新工作台程序，旧文件自动备份到 _backup 文件夹。</p>'
        + (li ? '<p>里面有 ' + chk.effects.length + ' 个新的或改过的效果：</p><ul>' + li + '</ul>' : '')
        + (chk.unchanged && chk.unchanged.length ? '<p style="color:#888">另外 ' + chk.unchanged.length + ' 个效果和你现在的一模一样，不用动。</p>' : ''),
      buttons: [{ text: same.length ? '升级，同名效果也换成新的（旧的自动备份）' : '升级', value: 'overwrite', cls: 'pri' },
        ...(same.length ? [{ text: '升级，但保留我现在的同名效果', value: 'skip' }] : []), { text: '取消', value: null, cls: 'ghost' }] });
  } else if (same.length || chk.shared.length && same.length + fresh.length === 0) {
    const li = same.map(e => '<li>' + esc(e.name) + '<em>' + esc(e.id) + '</em></li>').join('');
    mode = await dialog({ title: same.length ? '有同名效果' : '更新共用文件',
      html: (same.length ? '<p>下面这些效果你已经有了：</p><ul>' + li + '</ul><p>覆盖的话，旧版本会自动备份到 <b>effects\\_backup</b>，装错了能找回来。</p>' : '')
        + (fresh.length ? '<p>另外还有 ' + fresh.length + ' 个新效果会直接装上。</p>' : '')
        + (chk.shared.length ? '<p>共用文件 ' + chk.shared.map(esc).join('、') + ' 也会更新（旧的同样会备份）。</p>' : ''),
      buttons: [{ text: same.length ? '覆盖（用新的）' : '更新', value: 'overwrite', cls: 'pri' },
        ...(same.length && fresh.length ? [{ text: '跳过同名，只装新的', value: 'skip' }] : []), { text: '取消', value: null, cls: 'ghost' }] });
  }
  if (!mode) { toast('已取消'); return; }
  const r = await api('/api/install?mode=' + mode, blob, name);
  if (r.error) { toast('安装失败：' + r.error, true); return; }
  const d = r.done, lines = [];
  if (d.studio) lines.push('工作台已更新');
  if (d.installed.length) lines.push('已安装：' + d.installed.join('、'));
  if (d.updated.length) lines.push('已更新：' + d.updated.join('、'));
  if (d.skipped.length) lines.push('已跳过（保留原来的）：' + d.skipped.join('、'));
  if (d.shared.length && !d.studio) lines.push('共用文件已更新');
  if (r.errors && r.errors.length) lines.push('⚠ ' + r.errors.join('；'));
  if (r.restart) { await waitRestart(); return; }
  if (r.manualRestart) {
    await dialog({ title: '工作台已更新', html: '<p>' + esc(lines.join('\n')).replace(/\n/g, '<br>') + '</p><p>请<b>关闭黑窗口</b>，再重新双击 <b>start.bat</b>，新版本就生效了。</p>', buttons: [{ text: '知道了', value: 1, cls: 'pri' }] });
    return;
  }
  toast(lines.join('\n') || '没有需要更新的内容', !!(r.errors && r.errors.length && !d.installed.length && !d.updated.length));
  const pick = (r.effects.find(e => d.installed.includes(e.name) || d.updated.includes(e.name)) || {}).id;
  await reloadEffects(pick);
}
const dropEl = $('#drop'), dropIn = $('#dropin');
let busy = false;
async function handleDrop(zips, folders, loose) {
  if (busy) { toast('上一个还在安装，请稍等', true); return; }
  if (!zips.length && !folders.length) {
    toast(loose ? '请把收到的 .zip 压缩包，或整个效果文件夹拖进来（不要只拖里面的单个文件）' : '没有可加载的内容', true); return;
  }
  busy = true; dropEl.classList.add('busy'); const lbl = dropEl.querySelector('b'); lbl.textContent = '正在加载…';
  try {
    for (const f of zips) await installZip(f, f.name);
    for (const en of folders) {
      const files = []; await readEntry(en, '', files);
      await installZip(makeZip(files), en.name + '.zip');
    }
  } catch (e) { toast('加载失败：' + e.message, true); }
  busy = false; dropEl.classList.remove('busy'); lbl.textContent = '加载效果';
}
dropEl.onclick = () => dropIn.click();
dropIn.onchange = () => { const fs = [...dropIn.files]; dropIn.value = ''; handleDrop(fs.filter(f => /\.zip$/i.test(f.name)), [], fs.length); };
// 拖文件进窗口时，「加载效果」区域亮起来；拖到页面任何空白地方松手都能加载（右侧上传图片的地方不受影响）
let dragN = 0;
const hasFiles = e => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
addEventListener('dragenter', e => { if (!hasFiles(e)) return; dragN++; dropEl.classList.add('over'); dropEl.querySelector('small').textContent = '松开鼠标就开始加载'; });
addEventListener('dragleave', e => { if (!hasFiles(e)) return; if (--dragN <= 0) { dragN = 0; dropEl.classList.remove('over'); dropEl.querySelector('small').textContent = '把效果压缩包或文件夹拖到这里，或点这里选择'; } });
addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); });
addEventListener('drop', e => {
  dragN = 0; dropEl.classList.remove('over'); dropEl.querySelector('small').textContent = '把效果压缩包或文件夹拖到这里，或点这里选择';
  if (!hasFiles(e) || e.defaultPrevented) return;          // 右侧图片上传框已经处理过的，不再管
  e.preventDefault();
  const zips = [], folders = []; let loose = 0;
  [...e.dataTransfer.items].forEach(it => {
    if (it.kind !== 'file') return;
    const en = it.webkitGetAsEntry && it.webkitGetAsEntry(), f = it.getAsFile();
    if (en && en.isDirectory) folders.push(en);
    else if (f && /\.zip$/i.test(f.name)) zips.push(f);
    else loose++;
  });
  handleDrop(zips, folders, loose);
});
// 点击右侧顶部的效果名：复制文件夹名
