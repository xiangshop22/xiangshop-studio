// 效果工坊 · 保存为预设 · 联系我 · 浅色 / 深色界面
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 保存为预设（v9.0） =================
// 把当前效果调好的样子（所有参数 + 关键帧 + 持续时间）存成左侧一张新卡片，下次只换素材。
// 素材不存：服务器会把参数里的 /uploads/… 和 data: 内嵌图都清掉（server.js【区域P】），预设只有几 KB。
async function reloadList(selId) {
  effects = await (await fetch('/api/effects')).json(); window.__fxList = effects;
  navBuilt = false; Object.keys(navCards).forEach(k => delete navCards[k]);
  renderList(); select(effects.some(e => e.id === selId) ? selId : effects[0].id);
}
$('#presetbtn').onclick = async () => {
  if (!cur) return;
  const name = prompt('给这个预设起个名字（左侧会多一张这个名字的卡片）：\n只保存动画（参数、关键帧、持续时间），上传的图片 / 视频不保存，下次换上自己的素材就行。', cur.name.replace(/ · 我的预设.*$/, '') + ' · 我的预设');
  if (name === null) return;
  try {
    const r = await (await fetch('/api/preset', { method: 'POST', headers: { 'X-FX': '1' }, body: JSON.stringify({ base: cur.id, name, params }) })).json();
    if (!r.ok) throw new Error(r.error || '保存失败');
    await reloadList(r.id);
    toast('已保存为预设「' + cur.name + '」：在左侧列表里，下次点它、换上素材就能用');
  } catch (e) { toast('保存预设失败：' + e.message, true); }
};
async function delPreset() {
  if (!cur || !cur.preset) return;
  const v = await dialog({ title: '删除预设', html: '删除「' + esc(cur.name) + '」？<br><small style="color:#888">只删这个预设，原效果不受影响；文件会先挪到 effects\\_backup，误删还能找回。</small>', buttons: [{ text: '取消', value: null }, { text: '删除', value: 1, cls: 'pri' }] });
  if (!v) return;
  const base = cur.preset;
  const r = await (await fetch('/api/preset-delete', { method: 'POST', headers: { 'X-FX': '1' }, body: JSON.stringify({ id: cur.id }) })).json();
  if (!r.ok) { toast(r.error || '删除失败', true); return; }
  await reloadList(base); toast('预设已删除');
}
// ================= 联系我（v7.8） =================
// 用户找不到想要的效果、或有意见建议时，从这里跳到作者的 X / YouTube 主页。改联系方式只改 CONTACTS
const CONTACTS = [
  { cls: 'x', name: 'X（推特）', sub: '@QiaoqiaoD85820 · 私信 / 留言', url: 'https://x.com/QiaoqiaoD85820',
    svg: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.9 2H22l-6.8 7.8L23 22h-6.2l-4.9-6.4L6.3 22H3.2l7.3-8.3L1 2h6.3l4.4 5.9L18.9 2Zm-1.1 18h1.7L6.3 3.9H4.5L17.8 20Z"/></svg>' },
  { cls: 'yt', name: 'YouTube 频道', sub: '@jdkt007 · 在视频下面留言', url: 'https://www.youtube.com/@jdkt007',
    svg: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l11-6.5z"/></svg>' }
];
function openContact() {
  const html = '<p>没有找到你想要的效果，或者有意见和建议？通过下面任意一个方式联系我。</p><div class="ctl">' +
    CONTACTS.map(c => '<a class="cti ' + c.cls + '" href="' + esc(c.url) + '" target="_blank" rel="noopener"><span class="ic">' + c.svg + '</span><span><b>' + esc(c.name) + '</b><small>' + esc(c.sub) + '</small></span><i>↗</i></a>').join('') + '</div>';
  dialog({ title: '联系我', html, buttons: [{ text: '关闭', value: null, cls: 'ghost' }] });
}
$('#contactbtn').onclick = () => openContact();
$('#packall').onclick = () => { toast('正在打包整个工作台，浏览器会自动下载…'); location.href = '/api/studio-zip'; };
// ================= 浅色 / 深色界面（v6.4） =================
// 做法：页面原本是深色。切到浅色时，把页面上所有样式表（包括效果编辑器自己加的样式）里的颜色自动「翻过来」：
//   灰色系：深 ↔ 浅对调（深底 → 浅底，浅字 → 深字）；带颜色的很深的底（如选中项的深橙底）→ 同色系的浅底；
//   主题橙色等鲜艳颜色、半透明的遮罩 / 阴影保持不变。生成一张覆盖用的样式表，切回深色就移除。
// 预览区里的效果画面不受影响（效果本身在 iframe 里）。
const Theme = (() => {
  const KEY = 'fxnav:theme';
  let mode = 'dark', sheet = null, mo = null, t = 0;
  const PROPS = ['color', 'background-color', 'background-image', 'border-top-color', 'border-right-color', 'border-bottom-color', 'border-left-color', 'outline-color', 'accent-color', 'caret-color', 'fill', 'stroke'];
  function parse(m) {
    if (m[0] === '#') {
      let h = m.slice(1); if (h.length === 3 || h.length === 4) h = [...h].map(c => c + c).join('');
      if (h.length !== 6 && h.length !== 8) return null;
      return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16), h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1];
    }
    const n = m.match(/[\d.]+%?/g); if (!n || n.length < 3) return null;
    const v = n.map(x => x.endsWith('%') ? parseFloat(x) * 2.55 : parseFloat(x));
    return [v[0], v[1], v[2], n.length > 3 ? (n[3].endsWith('%') ? parseFloat(n[3]) / 100 : parseFloat(n[3])) : 1];
  }
  function flip(m) {
    const c = parse(m); if (!c || c[3] < 0.98) return m;                 // 半透明（遮罩、阴影、覆盖在图上的标签）不动
    const [r, g, b] = c.map((x, i) => i < 3 ? x / 255 : x);
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
    let h = 0;
    if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h = Math.round(h * 60 + 360) % 360;
    let L;
    if (s < 0.2) L = Math.min(0.975, Math.max(0.1, 1 - l));               // 灰色：深浅对调
    else if (l < 0.3) L = Math.min(0.96, 1 - l * 0.55);                    // 很深的彩色底 → 同色系浅底
    else return m;                                                        // 主题色等鲜艳颜色：不变
    return `hsl(${h} ${Math.round(s * 100)}% ${Math.round(L * 100)}%)`;
  }
  const remap = v => v.replace(/#[0-9a-f]{3,8}\b|rgba?\([^)]*\)/gi, flip);
  function selectors(sel) {
    return sel.split(',').map(s => s.trim()).filter(Boolean).map(s =>
      /^(html|:root)(?![\w-])/.test(s) ? s.replace(/^(html|:root)/, 'html.light') : 'html.light ' + s).join(',');
  }
  function walk(rules, out) {
    for (const r of rules) {
      if (r.cssRules && r.media) { const sub = []; walk(r.cssRules, sub); if (sub.length) out.push(`@media ${r.media.mediaText}{${sub.join('')}}`); continue; }
      if (!r.selectorText || !r.style || /^html\.light/.test(r.selectorText)) continue;   // 已经专门写好的浅色样式，不再翻转
      const decl = [];
      const media = /#box\b|\.th\b/.test(r.selectorText);              // 预览区 / 缩略图的棋盘格底保持深色：白字效果才看得清
      for (const p of PROPS) {
        if (media && p.startsWith('background')) continue;
        const v = r.style.getPropertyValue(p); if (!v) continue;
        const nv = remap(v); if (nv !== v) decl.push(`${p}:${nv} !important`);
      }
      if (decl.length) out.push(`${selectors(r.selectorText)}{${decl.join(';')}}`);
    }
  }
  function build() {
    const out = ['html.light{color-scheme:light}'];
    for (const ss of document.styleSheets) {
      if (ss.ownerNode && ss.ownerNode.id === 'fx-light') continue;
      let rules; try { rules = ss.cssRules; } catch (e) { continue; }
      walk(rules, out);
    }
    if (!sheet) { sheet = document.createElement('style'); sheet.id = 'fx-light'; }
    sheet.textContent = out.join('\n');
    document.head.appendChild(sheet);                                    // 放在最后，保证覆盖得到
  }
  function set(m) {
    mode = m === 'light' ? 'light' : 'dark';
    try { localStorage.setItem(KEY, mode); } catch (e) {}
    document.documentElement.classList.toggle('light', mode === 'light');
    const b = document.getElementById('themebtn'); if (b) { b.textContent = mode === 'light' ? '☾' : '☀'; b.title = mode === 'light' ? '切换到深色界面' : '切换到浅色界面'; }
    if (mode === 'light') {
      build();
      // 效果编辑器切换效果时会往页面里加新样式 → 自动重新生成
      if (!mo) { mo = new MutationObserver(ms => { if (ms.some(x => [...x.addedNodes].some(n => n.nodeName === 'STYLE' && n.id !== 'fx-light'))) { clearTimeout(t); t = setTimeout(build, 30); } }); mo.observe(document.head, { childList: true }); }
    } else { if (mo) { mo.disconnect(); mo = null; } if (sheet) sheet.remove(); }
  }
  let saved = 'dark'; try { saved = localStorage.getItem(KEY) || 'dark'; } catch (e) {}
  return { set, toggle: () => set(mode === 'light' ? 'dark' : 'light'), init: () => set(saved) };
})();
$('#themebtn').onclick = () => Theme.toggle();
Theme.init();
