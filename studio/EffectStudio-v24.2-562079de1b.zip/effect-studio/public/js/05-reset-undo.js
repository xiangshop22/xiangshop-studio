// 效果工坊 · 恢复默认 · 撤销 / 重做（单个效果）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 恢复默认（v6.7） =================
// 用户改了一堆参数想回到初始状态，但不知道改过哪些、也不知道怎么回去。
// 这里先把「改过的项 + 原值 → 现在的值」列出来，再给三种恢复：单项 / 只恢复参数 / 连内容一起。
const isContentP = p => p.type === 'cards' || p.type === 'images' || p.key === 'cards' || p.key === 'images';
const defOf = p => (p.default && typeof p.default === 'object') ? JSON.parse(JSON.stringify(p.default)) : p.default;
const sameDef = p => JSON.stringify(params[p.key]) === JSON.stringify(defOf(p));
// 「持续时间」按比例伸缩时存在 params.__dur 里（不是 effect.json 里的参数），也要能在这里看到、恢复
const DURP = { key: '__dur', label: '持续时间（按比例放慢 / 加快）', type: 'number' };
const allPs = () => cur ? cur.params.concat([DURP]) : [];
const changedPs = () => allPs().filter(p => !sameDef(p));
function valText(p, v) {
  if (p.key === '__dur') return v ? v + ' 秒' : '原长';
  if (v === undefined || v === null || v === '') return '空';
  if (p.type === 'select' && Array.isArray(p.options)) { const o = p.options.find(x => String(x[0]) === String(v)); if (o) return o[1]; }
  if (typeof v === 'object') return '自己填的内容';
  const t = String(v).trim();
  if (/^[[{]/.test(t)) return '自己填的内容';
  return t.length > 16 ? t.slice(0, 16) + '…' : t;
}
function markDirty() { markDirtyPanel(); Hooks.run('markDirty'); }
function markDirtyPanel() {
  const b = $('#rstbtn'); if (!b) return;
  const n = cur ? changedPs().length : 0;
  b.classList.toggle('on', n > 0);
  b.querySelector('i').textContent = !cur ? '' : n ? n + ' 项已改' : '当前是默认';
}
function resetKeys(keys) {
  if (!cur || !keys.length) return;
  allPs().forEach(p => { if (keys.indexOf(p.key) >= 0) { if (p.key === '__dur') { if (DURP.default) params.__dur = DURP.default; else delete params.__dur; } else params[p.key] = defOf(p); } });
  buildParams(); reinit(true);
}
const closePop = () => { const p = $('#rstpop'); if (p) p.remove(); };
function openPop() {
  closePop(); if (!cur) return;
  const ch = changedPs();
  const pop = document.createElement('div'); pop.id = 'rstpop';
  const h = document.createElement('h4'); h.textContent = '恢复「' + cur.name + '」的默认设置'; pop.appendChild(h);
  if (!ch.length) {
    const d = document.createElement('div'); d.className = 'none';
    d.textContent = '当前所有参数都是默认值，没有需要恢复的。';
    pop.appendChild(d);
  } else ch.forEach(p => {
    const row = document.createElement('div'); row.className = 'it';
    const nm = document.createElement('b'); nm.textContent = p.label; nm.title = p.label;
    const vs = document.createElement('s');
    vs.textContent = isContentP(p) ? '已改动（照片 / 文字 / 视频）' : valText(p, defOf(p)) + ' → ' + valText(p, params[p.key]);
    vs.title = vs.textContent;
    const btn = document.createElement('button'); btn.type = 'button'; btn.textContent = '恢复';
    btn.onclick = () => { resetKeys([p.key]); toast('已恢复「' + p.label + '」'); openPop(); };
    row.append(nm, vs, btn); pop.appendChild(row);
  });
  const ft = document.createElement('div'); ft.className = 'ft';
  if (ch.length) {
    const hasContent = ch.some(isContentP);
    const a = document.createElement('button'); a.type = 'button'; a.className = 'pri';
    a.textContent = hasContent ? '只恢复参数（保留我填的内容）' : '恢复全部默认';
    a.onclick = () => { resetKeys(ch.filter(p => !isContentP(p)).map(p => p.key)); closePop(); toast(hasContent ? '参数已恢复默认，卡片内容保留' : '已恢复全部默认'); };
    ft.appendChild(a);
    if (hasContent) {
      const b2 = document.createElement('button'); b2.type = 'button'; b2.textContent = '全部恢复（内容也回到示例）';
      b2.onclick = () => { resetKeys(allPs().map(p => p.key)); closePop(); toast('已全部恢复默认'); };
      ft.appendChild(b2);
    }
  }
  const c = document.createElement('button'); c.type = 'button'; c.textContent = ch.length ? '取消' : '知道了';
  c.onclick = closePop; ft.appendChild(c);
  pop.appendChild(ft); $('#rst').appendChild(pop);
}
$('#rstbtn').onclick = e => { e.stopPropagation(); $('#rstpop') ? closePop() : openPop(); };
// 在预览区拖动位置是 iframe 里的 view-controls 在改参数，父页面收不到事件 →
// 鼠标回到右侧面板时顺手刷新一下徽标（弹层本身每次打开都会重算，始终是准的）
document.querySelector('aside.r').addEventListener('mouseenter', () => markDirty());
document.addEventListener('mousedown', e => { const p = $('#rstpop'); if (p && !p.contains(e.target) && e.target.id !== 'rstbtn') closePop(); });
$('#fxid').onclick = () => { if (!cur) return; const t = cur.id; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast('已复制文件夹名：' + t), () => toast('文件夹名：' + t)); };
// 打包整个工作台：程序 + 全部效果（不含 node_modules、导出的视频）
// ================= 撤销 / 重做（v8.1） =================
// Ctrl+Z 撤销上一步，Ctrl+Shift+Z 或 Ctrl+Y 重做。整个工作台通用：右侧参数、卡片内容、持续时间、
// 恢复默认、预览区里的拖动 / 滚轮 / 右键转角度、关键帧（打点、移动、删除、粘贴）都能撤。
// 做法：不去每个地方单独记，而是在每次操作结束后（松开鼠标 / 键盘、输入停下来）给整份参数拍一张快照，
// 和上一张不一样就记一步。效果在预览区里改的也是同一份 params（init 时按引用传进去的），所以都拍得到。
// 输入框里打字时 Ctrl+Z 交给浏览器撤销文字；每个效果单独一份历史，换效果就清空。
const HIST_MAX = 100;
let hUndo = [], hRedo = [], hLast = null, hT = 0, hDown = 0;
const hSnap = () => { try { return JSON.stringify(params); } catch (e) { return null; } };
function histReset() { hUndo = []; hRedo = []; hLast = hSnap(); }
function histBusy() {                       // 正在拖动时参数是临时值（关键帧层会先改、松手再还原），这时不拍
  if (hDown) return true;
  try { const K = frame.contentWindow.FXKeys; if (K && K.dragging) return true; } catch (e) { }
  return false;
}
function histCheck() { Hooks.run('histCheck:before'); histCheckRun(); Hooks.run('histCheck'); }
function histCheckRun() {
  if (!cur) return;
  if (histBusy()) { histSoon(300); return; }
  const s = hSnap(); if (s == null) return;
  if (hLast == null) { hLast = s; return; }
  if (s === hLast) return;
  hUndo.push(hLast); if (hUndo.length > HIST_MAX) hUndo.shift();
  hRedo = []; hLast = s;
}
function histSoon(ms) { clearTimeout(hT); hT = setTimeout(histCheck, ms || 450); }
addEventListener('mousedown', () => { hDown++; }, true);
addEventListener('mouseup', () => { hDown = 0; histSoon(); }, true);
addEventListener('blur', () => { hDown = 0; });
['input', 'change', 'keyup', 'drop', 'click'].forEach(ev => addEventListener(ev, () => histSoon(), true));
addEventListener('wheel', () => histSoon(650), { capture: true, passive: true });   // 滚轮缩放 220ms 后才打点，等它打完再拍
// 撤销提示里说清楚撤的是哪几项
function histDiff(a, b) {
  const ks = [...new Set(Object.keys(a).concat(Object.keys(b)))].filter(k => JSON.stringify(a[k]) !== JSON.stringify(b[k]));
  const name = k => k === '__dur' ? '持续时间' : k === 'keys' ? '关键帧' : k === 'scale' ? '大小' : (k === 'offsetX' || k === 'offsetY') ? '位置'
    : ['rotX', 'rotY', 'rotZ'].includes(k) ? '角度' : ((pOf(k) || {}).label || k).replace(/（.*$/, '');
  const ns = [...new Set(ks.map(name))];
  return ns.length ? ns.slice(0, 3).join('、') + (ns.length > 3 ? ' 等 ' + ns.length + ' 项' : '') : '参数';
}
function histGo(dir) {
  if (!cur) return;
  clearTimeout(hT); if (!histBusy()) histCheck();             // 先把还没记下的那一步记上
  const from = dir < 0 ? hUndo : hRedo, to = dir < 0 ? hRedo : hUndo;
  if (!from.length) { toast(dir < 0 ? '没有可以撤销的操作了' : '没有可以重做的操作了'); return; }
  const s = from.pop(); to.push(hLast);
  let before = {}, after;
  try { before = JSON.parse(hLast); after = JSON.parse(s); } catch (e) { return; }
  // 原地替换：效果手里拿着的就是这个 params 对象，不能换成新对象
  Object.keys(params).forEach(k => delete params[k]); Object.assign(params, after);
  hLast = s;
  const t = Math.min(+slider.value || 0, dur);
  stop(); closePop(); buildParams(); reinit(false); seek(Math.min(t, dur));
  toast((dir < 0 ? '↶ 已撤销：' : '↷ 已重做：') + histDiff(before, after) + '　（Ctrl+Z 撤销 · Ctrl+Shift+Z 重做）');
}
addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
  const k = e.key.toLowerCase();
  const undo = k === 'z' && !e.shiftKey, redo = (k === 'z' && e.shiftKey) || k === 'y';
  if (!undo && !redo) return;
  const a = document.activeElement;            // 在文字框里打字：交给浏览器撤销文字
  if (a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && /^(text|search|url|email)$/i.test(a.type)) || a.isContentEditable)) return;
  if (document.querySelector('.mask')) return;          // 弹窗开着时不撤
  e.preventDefault();
  if (a && a.tagName === 'INPUT') a.blur();
  histGo(undo ? -1 : 1);
});
