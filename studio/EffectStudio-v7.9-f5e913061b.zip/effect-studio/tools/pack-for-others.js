// ============================================================
// 打包给别人 —— 把整个工作台打成一个「干净」的 zip，放在工作台根目录里
// 由「打包给别人.bat」调用；也可以手动： node tools/pack-for-others.js
//
// 【区域地图】
//   【区域A 配置】   排除清单、顶层文件夹名
//   【区域B 扫描】   遍历工作台，按排除清单挑出要打包的文件
//   【区域C zip写入】不依赖任何第三方包，纯 Node 内置模块写 zip
//   【区域D 主流程】 检查 → 扫描 → 写 zip → 改名 → 打开所在文件夹
// ============================================================
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { spawn } = require('child_process');

// ---------- 【区域A 配置】 ----------
const ROOT = path.resolve(__dirname, '..');          // 工作台根目录（tools 的上一级）
const TOP = 'effect-studio';                         // 解压后最外层文件夹名

// 根目录下整个不要的文件夹
const SKIP_TOP_DIRS = new Set([
  'node_modules',   // 对方 start.bat 会自己装
  'output',         // 你导出的视频
  'uploads',        // 你上传的图片 / 视频（体积大，也可能是私人素材）
  'runtime',        // 绿色版 Node，对方会自己下载
  '_publish',       // 发布更新用的临时仓库
  '_backup',        // 升级时的备份
  '.git',
  'effect-studio',  // 误解压留下的嵌套旧副本
  '交付',           // 交接给同事的资料（规则、提示词），只给同事，不发给普通用户
  path.basename(ROOT)
]);
// 根目录下不要的文件（作者专用）
const SKIP_TOP_FILES = new Set([
  '发布更新.bat',
  '打包给别人.bat'
]);
// 指定相对路径不要（用 / 分隔）
const SKIP_PATHS = new Set([
  'effects/_backup',                 // 覆盖效果时的旧版备份
  'tools/pack-for-others.js'         // 打包脚本本身
]);
// 任何位置都不要的文件名
const SKIP_NAMES = new Set(['Thumbs.db', '.DS_Store', 'desktop.ini']);
// 打包后仍保留一个空文件夹（防止程序假设它存在）
const KEEP_EMPTY_DIRS = ['output', 'uploads'];
// 这些后缀本来就是压缩过的，直接存储，不再压缩
const STORE_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.mp4', '.mov', '.webm', '.mp3',
  '.aac', '.zip', '.7z', '.gz', '.woff', '.woff2', '.avif']);

// ---------- 小工具 ----------
const say = s => console.log(s);
const fmt = n => n >= 1073741824 ? (n / 1073741824).toFixed(2) + ' GB'
  : n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
const pad = n => String(n).padStart(2, '0');

function readVersion() {
  try {
    const s = fs.readFileSync(path.join(ROOT, 'server.js'), 'utf8');
    const m = s.match(/\bVERSION\s*=\s*['"`]([^'"`]+)['"`]/);
    if (m) return m[1].replace(/[^\w.\-]/g, '');
  } catch (e) { /* 读不到就用 unknown */ }
  return 'unknown';
}

// ---------- 【区域B 扫描】 ----------
function skipped(rel, isTop, name) {
  if (SKIP_NAMES.has(name)) return true;
  if (SKIP_PATHS.has(rel)) return true;
  if (isTop) {
    if (SKIP_TOP_DIRS.has(name) || SKIP_TOP_FILES.has(name)) return true;
    if (/\.(zip|part)$/i.test(name)) return true;      // 之前打出来的包不要再打进去
  }
  return false;
}

function scan(dir, rel, out, stat) {
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); }
  catch (e) { throw new Error('读不了文件夹：' + dir + '（' + e.message + '）'); }
  ents.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
  for (const ent of ents) {
    const r = rel ? rel + '/' + ent.name : ent.name;
    const isTop = rel === '';
    if (skipped(r, isTop, ent.name)) { stat.skipped.push(r + (ent.isDirectory() ? '/' : '')); continue; }
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) scan(full, r, out, stat);
    else if (ent.isFile()) out.push({ rel: r, full });
  }
}

// ---------- 【区域C zip写入】 ----------
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) { let c = i; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[i] = c >>> 0; }
  return t;
})();
function crc32(buf) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(buf) >>> 0;
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function dosTime(d) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  const date = (Math.max(0, d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time: time & 0xFFFF, date: date & 0xFFFF };
}

class ZipWriter {
  constructor(file) { this.fd = fs.openSync(file, 'w'); this.pos = 0; this.entries = []; }
  _write(buf) { fs.writeSync(this.fd, buf, 0, buf.length, this.pos); this.pos += buf.length; }
  add(name, data, mtime, forceStore) {
    if (data.length >= 0xFFFFFFFF) throw new Error('单个文件超过 4GB，没法放进普通 zip：' + name);
    const nameBuf = Buffer.from(name, 'utf8');
    const crc = data.length ? crc32(data) : 0;
    let method = 0, body = data;
    if (!forceStore && data.length > 64) {
      const z = zlib.deflateRawSync(data, { level: 6 });
      if (z.length < data.length) { method = 8; body = z; }
    }
    const { time, date } = dosTime(mtime || new Date());
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6);   // 0x0800 = 文件名是 UTF-8
    h.writeUInt16LE(method, 8); h.writeUInt16LE(time, 10); h.writeUInt16LE(date, 12);
    h.writeUInt32LE(crc, 14); h.writeUInt32LE(body.length, 18); h.writeUInt32LE(data.length, 22);
    h.writeUInt16LE(nameBuf.length, 26); h.writeUInt16LE(0, 28);
    const offset = this.pos;
    this._write(h); this._write(nameBuf); if (body.length) this._write(body);
    this.entries.push({ nameBuf, method, time, date, crc, csize: body.length, usize: data.length, offset, dir: name.endsWith('/') });
  }
  close() {
    if (this.entries.length > 65535) throw new Error('文件数量超过 65535，没法放进普通 zip');
    const cdStart = this.pos;
    for (const e of this.entries) {
      const c = Buffer.alloc(46);
      c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8);
      c.writeUInt16LE(e.method, 10); c.writeUInt16LE(e.time, 12); c.writeUInt16LE(e.date, 14);
      c.writeUInt32LE(e.crc, 16); c.writeUInt32LE(e.csize, 20); c.writeUInt32LE(e.usize, 24);
      c.writeUInt16LE(e.nameBuf.length, 28); c.writeUInt16LE(0, 30); c.writeUInt16LE(0, 32);
      c.writeUInt16LE(0, 34); c.writeUInt16LE(0, 36);
      c.writeUInt32LE(e.dir ? 0x10 : 0, 38);                 // 外部属性：0x10 = 文件夹
      c.writeUInt32LE(e.offset, 42);
      this._write(c); this._write(e.nameBuf);
    }
    const cdSize = this.pos - cdStart;
    const z = Buffer.alloc(22);
    z.writeUInt32LE(0x06054b50, 0); z.writeUInt16LE(this.entries.length, 8); z.writeUInt16LE(this.entries.length, 10);
    z.writeUInt32LE(cdSize, 12); z.writeUInt32LE(cdStart, 16);
    this._write(z);
    fs.closeSync(this.fd);
  }
  abort() { try { fs.closeSync(this.fd); } catch (e) { /* 已关闭 */ } }
}

// ---------- 【区域D 主流程】 ----------
function main() {
  say('');
  say('==== 打包给别人 ====');
  say('工作台目录：' + ROOT);

  // 1) 检查：核心文件在不在，避免打出一个跑不起来的包
  const must = ['start.bat', 'server.js', 'public/index.html', 'effects/_shared/view-controls.js'];
  const lack = must.filter(f => !fs.existsSync(path.join(ROOT, f)));
  if (lack.length) {
    say('');
    say('✗ 缺少这些关键文件，不打包：');
    lack.forEach(f => say('   ' + f));
    say('请确认这个脚本放在工作台里（tools 文件夹下）。');
    process.exitCode = 1; return;
  }

  // 2) 扫描
  const files = [], stat = { skipped: [] };
  scan(ROOT, '', files, stat);
  const effectDirs = new Set(files.filter(f => /^effects\/[^/_][^/]*\//.test(f.rel)).map(f => f.rel.split('/')[1]));
  say('版本：' + readVersion() + '    效果数：' + effectDirs.size + '    文件数：' + files.length);
  say('');
  say('已排除：');
  stat.skipped.forEach(s => say('   - ' + s));

  // 3) 写 zip（先写 .part，成功再改名，中途失败不会留下坏包）
  const d = new Date();
  const stamp = d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes());
  const finalName = 'effect-studio-' + readVersion() + '-给别人用-' + stamp + '.zip';
  const finalPath = path.join(ROOT, finalName);
  const partPath = finalPath + '.part';
  const zip = new ZipWriter(partPath);
  let raw = 0, n = 0;
  try {
    for (const dname of KEEP_EMPTY_DIRS) zip.add(TOP + '/' + dname + '/', Buffer.alloc(0), d, true);
    for (const f of files) {
      let buf, st;
      try { st = fs.statSync(f.full); buf = fs.readFileSync(f.full); }
      catch (e) { throw new Error('读不了文件：' + f.rel + '（' + e.message + '）。可能被别的程序占用，关掉后再试。'); }
      zip.add(TOP + '/' + f.rel, buf, st.mtime, STORE_EXT.has(path.extname(f.rel).toLowerCase()));
      raw += buf.length; n++;
      if (n % 100 === 0) process.stdout.write('\r打包中… ' + n + ' / ' + files.length);
    }
    zip.close();
    fs.renameSync(partPath, finalPath);
  } catch (e) {
    zip.abort();
    try { fs.unlinkSync(partPath); } catch (e2) { /* 没生成就算了 */ }
    say('');
    say('✗ 打包失败：' + e.message);
    process.exitCode = 1; return;
  }

  const size = fs.statSync(finalPath).size;
  process.stdout.write('\r' + ' '.repeat(40) + '\r');
  say('');
  say('✓ 打包完成');
  say('   文件：' + finalName);
  say('   位置：' + ROOT + '（就在工作台根目录里）');
  say('   大小：' + fmt(size) + '（原始 ' + fmt(raw) + '）');
  say('');
  say('对方使用：解压 → 双击里面的 start.bat。');
  say('提醒：根目录里旧的「给别人用」zip 不会自动删，用不着的可以手动删掉。');

  // 4) 打开所在文件夹并选中这个包
  if (process.platform === 'win32') {
    try {
      spawn('explorer.exe', ['/select,"' + finalPath + '"'], { detached: true, stdio: 'ignore', windowsVerbatimArguments: true }).unref();
    } catch (e) { /* 打不开就算了，路径上面已经打印了 */ }
  }
}

main();
