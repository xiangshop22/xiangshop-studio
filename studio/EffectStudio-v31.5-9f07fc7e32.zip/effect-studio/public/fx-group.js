/* ===========================================================================
   fx-group.js —— 组合（预合成）的变换算法（工作台 v12.1）
   ---------------------------------------------------------------------------
   工作台预览（index.html）和导出整条时间线（comp.html）共用这一份，保证预览和导出一模一样。

   组合 g = { tf: 不做动画时的整体变换, anim: 关键帧动画开没开, keys: [关键帧] }
   整体变换 = { x, y: 位置（px）, s: 大小（%）, rx, ry, rz: 三轴旋转（度）, o: 不透明度（%） }

   v12.1 起关键帧和效果里的一样按「行」分开（AE 的 P / S / R），再加一行 O（不透明度）：
     { t, k:'p', x, y }   { t, k:'s', s }   { t, k:'r', rx, ry, rz }   { t, k:'o', o }
   每一行各算各的：有点的行按自己的点插值（两头保持首尾），没有点的行用 tf。
   老工程里的关键帧是「一个点存全部数值」（没有 k），读的时候自动拆成四行，画面和以前一模一样。
   =========================================================================== */
(function () {
  const TF0 = { x: 0, y: 0, s: 100, rx: 0, ry: 0, rz: 0, o: 100 };
  const LANES = { p: ['x', 'y'], s: ['s'], r: ['rx', 'ry', 'rz'], o: ['o'] };
  const ORDER = 'psro';
  const laneOf = f => (f === 'x' || f === 'y') ? 'p' : f === 's' ? 's' : f === 'o' ? 'o' : 'r';
  const sortK = a => a.sort((p, q) => p.t - q.t || ORDER.indexOf(p.k) - ORDER.indexOf(q.k));
  // 整理数据：老格式拆行、补默认值、排序（原地改，返回 g）
  function norm(g) {
    if (!g) return g;
    if (!g.tf) g.tf = Object.assign({}, TF0);
    if (!Array.isArray(g.keys)) g.keys = [];
    if (g.keys.some(k => !k || !LANES[k.k])) {
      g.keys = g.keys.filter(Boolean).flatMap(k => LANES[k.k] ? [k] : Object.keys(LANES).map(l => {
        const o = { t: +k.t || 0, k: l };
        LANES[l].forEach(f => o[f] = Number.isFinite(+k[f]) ? +k[f] : TF0[f]);
        return o;
      }));
    }
    sortK(g.keys);
    return g;
  }
  const ease = u => u * u * (3 - 2 * u);
  // 组合里第 t 秒（从组合开头算）的整体变换
  function val(g, t) {
    norm(g);
    const out = Object.assign({}, TF0, g.tf);
    if (!g.anim || !g.keys.length) return out;
    for (const l in LANES) {
      const K = g.keys.filter(k => k.k === l); if (!K.length) continue;
      let v;
      if (t <= K[0].t) v = K[0];
      else if (t >= K[K.length - 1].t) v = K[K.length - 1];
      else {
        let i = 0; while (K[i + 1].t < t) i++;
        const a = K[i], b = K[i + 1], e = ease((t - a.t) / Math.max(0.001, b.t - a.t));
        v = {}; LANES[l].forEach(f => v[f] = a[f] + (b[f] - a[f]) * e);
      }
      LANES[l].forEach(f => out[f] = +v[f]);
    }
    return out;
  }
  window.FXGroup = { TF0, LANES, ORDER, laneOf, norm, val, sortK };
})();
