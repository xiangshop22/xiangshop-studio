// 效果工坊 · 启动：恢复上次的时间线
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ---------- 启动：等效果列表加载完，恢复上次的时间线 ----------
(function boot(n) {
  if (!effects.length || !cur) { if (n < 150) setTimeout(() => boot(n + 1), 200); else tlDraw(); return; }
  const s = store.get('timeline', null);
  if (s && Array.isArray(s.clips)) {
    TL.clips = s.clips.filter(c => c && effects.some(e => e.id === c.fx));
    TL.groups = Array.isArray(s.groups) ? s.groups : []; normLayers();
    tlT = +s.t || 0; TL.clips.forEach(ghost);
    if (TL.clips.length) { fit(); if (clip(s.sel)) tlSelect(s.sel); else { tlPreview = true; tlRender(); } }
  }
  tlDraw();
})(0);
