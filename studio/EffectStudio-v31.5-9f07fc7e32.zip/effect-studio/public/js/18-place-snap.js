// 效果工坊 · 摆位置模式 + 辅助对齐（v24.4）：「自动关键帧」在「关键帧之外」后面，「辅助对齐」在进度条上方右边
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// 【自动关键帧 开 / 关】
//   开 = 做动画：在预览里拖动 / 缩放 / 旋转，会在播放头这一刻自动打关键帧（和以前一样）
//   关 = 摆位置：不打关键帧，整段动画（原始值 + 这条轨道上所有关键帧）一起挪 / 缩放 / 转，动画样子不变
//   具体怎么挪在效果自己的 view-controls.js（placeShift）里；这里只把开关状态放到 window.__fxPlace 给它读。
// 【辅助对齐 开 / 关】
//   左键拖动素材时，它的左 / 中 / 右、上 / 中 / 下 靠近其他素材或画面的边、中线 6 像素以内，就吸过去并画一条对齐线。
//   按住 Alt 拖动临时不吸。效果拖动时调 window.__fxSnap(挪了多少 x, y, 画布像素/屏幕像素, 按着 Alt) 拿修正后的挪动量。

// ---------- 开关（v24.8 布局）----------
// 自动关键帧：和「关键帧之外」同一种样子（左边文字，右边「开 / 关」两个按钮），放在它后面；默认关（= 摆位置）
// 辅助对齐：小开关（一整个按钮，点一下换到另一边），放在进度条上方的右边，和提示文字同一行，不额外占地方
function pillToggle({ id, label, title, get, set }) {
  const b = document.createElement('button'); b.type = 'button'; b.id = id; b.className = 'gpill'; b.title = title;
  b.innerHTML = `<span class="gl">${label}</span><span class="gv" data-v="1">开</span><span class="gv" data-v="0">关</span>`;
  const sync = () => b.querySelectorAll('.gv').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === get()));
  b.onclick = () => { set(!get()); sync(); };
  sync(); return b;
}
let autoKey = store.get('autoKey', false), snapOn = store.get('snapOn', true);
window.__fxPlace = !autoKey;
const akEdge = document.createElement('div'); akEdge.id = 'akedge';
akEdge.title = '开 = 做动画：在预览里拖动 / 缩放 / 旋转，会在播放头这一刻自动打关键帧\n关 = 摆位置：不打关键帧，整段动画一起挪 / 缩放 / 转（先摆好位置，再打开做动画）';
akEdge.innerHTML = '<span>自动关键帧</span><button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>';
const akSync = () => akEdge.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === autoKey));
akEdge.querySelectorAll('button').forEach(x => x.onclick = () => {
  const v = x.dataset.v === '1'; if (v === autoKey) return;
  autoKey = v; window.__fxPlace = !v; store.set('autoKey', v); akSync();
  $('#hint').textContent = v ? '自动关键帧已打开：现在拖动会在这一刻打关键帧' : '摆位置模式：拖动 / 缩放 / 旋转不打关键帧，整段动画一起挪';
});
akSync(); $('#pbar').appendChild(akEdge);
const snapBtn = pillToggle({ id: 'snapbtn', label: '辅助对齐', get: () => snapOn,
  title: '拖动素材时，靠近其他素材或画面的边、中线会自动吸过去，并显示对齐线（按住 Alt 拖动临时不吸）',
  set: v => { snapOn = v; store.set('snapOn', v); } });
{ const h = $('#hint'), row = document.createElement('div'); row.id = 'hintrow'; h.before(row); row.append(h, snapBtn); }
const gst = document.createElement('style');
gst.textContent = `#akedge{display:flex;align-items:center;background:#1d1d1d;border:1px solid #333;border-radius:8px;overflow:hidden;font-size:12.5px}
#akedge span{padding:0 6px 0 11px;color:#888;white-space:nowrap}
#akedge button{border:0;padding:9px 12px;cursor:pointer;font-family:inherit;font-size:12.5px;white-space:nowrap}
#akedge button:not(.on){background:none;color:#bbb}
#akedge button:not(.on):hover{color:#fff}
#akedge button.on{background:#f28c0f;color:#111;font-weight:600}
#hintrow{position:relative}
#hintrow #snapbtn{position:absolute;right:0;top:50%;transform:translateY(-50%)}
.gpill{display:flex;align-items:center;padding:0;border:1px solid #2c2c2c;border-radius:6px;background:#1a1a1a;cursor:pointer;font-family:inherit;font-size:11px;overflow:hidden}
.gpill:hover{border-color:#555}
.gpill .gl{padding:3px 6px 3px 8px;color:#888;white-space:nowrap}
.gpill .gv{padding:3px 8px;color:#666}
.gpill .gv.on{background:#f28c0f;color:#000;font-weight:700}
html.light .gpill,html.light #akedge{background:#f4f4f4;border-color:#d0d0d0} html.light .gpill .gl{color:#666}`;
document.head.appendChild(gst);

// ---------- 辅助对齐 ----------
const snapSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
snapSvg.id = 'snapguide';
snapSvg.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;overflow:visible;pointer-events:none;z-index:99991';
box.appendChild(snapSvg);
const SNAP = 6;                                       // 屏幕上差几像素以内就吸
let snapS = null;                                     // 这一次拖动：开始时被拖素材的范围 + 可以对齐的线
function snapRectOf(el) {                             // 一个素材在预览框里（屏幕像素）看得见的范围，复用选中框的算法
  if (!el || el.style.visibility === 'hidden') return null;
  const r = sbContentRect(el); if (!r) return null;
  const pts = [[r.x0, r.y0], [r.x1, r.y0], [r.x1, r.y1], [r.x0, r.y1]].map(p => sbProject(el, p[0], p[1]));
  if (pts.some(p => !p)) return null;
  const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
  return { l: Math.min(...xs), r: Math.max(...xs), t: Math.min(...ys), b: Math.max(...ys) };
}
// 素材在画面上的缩放倍数（关键帧那一层的「大小」/ 参数里的大小）：参数里的位置挪 1，画面上挪「这个倍数」
// c 不传 = 选中的主素材（#frame）；t = 素材自己的时间
function visScale(c) {
  try {
    const cc = c || clip(tlSel); if (!cc) return 1;
    const w = c ? bcWin(c) : frame.contentWindow, ps = c ? c.params : params;
    if (!w || !w.FXKeys) return 1;
    const t = Math.max(0, tlT - cc.start), R = w.FXKeys.at(ps, t, +w.getDuration() || 0);
    const v = R.s / Math.max(0.01, +ps.scale || 1); return v > 0.01 ? v : 1;
  } catch (e) { return 1; }
}
let dragRho = 1;                                       // 这一次拖动：主素材在画面上的倍数
function snapStart() {
  const me = snapRectOf(frame); if (!me) return null;
  const W = box.clientWidth, H = box.clientHeight;
  const xs = [{ v: 0, a: 0, b: H }, { v: W / 2, a: 0, b: H }, { v: W, a: 0, b: H }];            // 画面左 / 中 / 右
  const ys = [{ v: 0, a: 0, b: W }, { v: H / 2, a: 0, b: W }, { v: H, a: 0, b: W }];            // 画面上 / 中 / 下
  const moving = new Set(tlMulti.size > 1 ? [...tlMulti] : []); if (tlSel) moving.add(tlSel);   // 一起动的素材不当目标
  TL.clips.forEach(c => {
    if (moving.has(c.id)) return;
    const r = snapRectOf(G[c.id]); if (!r) return;
    [r.l, (r.l + r.r) / 2, r.r].forEach(v => xs.push({ v, a: r.t, b: r.b }));
    [r.t, (r.t + r.b) / 2, r.b].forEach(v => ys.push({ v, a: r.l, b: r.r }));
  });
  return { me, xs, ys };
}
function snapPick(edges, lines) {                     // 被拖素材的三条线 vs 所有目标线：找最近的一对
  let best = null;
  for (const e of edges) for (const L of lines) { const d = L.v - e; if (Math.abs(d) <= SNAP && (!best || Math.abs(d) < Math.abs(best.d))) best = { d, L }; }
  return best;
}
window.__fxSnap = (dx, dy, k, alt) => {
  if (!k) return null;
  if (!snapS) { dragRho = visScale(); snapS = snapStart() || { none: true }; }
  const rho = dragRho, sx = dx / k * rho, sy = dy / k * rho;   // 参数里挪的 → 画面上实际挪的（屏幕像素）
  if (!snapOn || alt || snapS.none) { snapSvg.innerHTML = ''; liveMove(sx, sy); return null; }
  const m = snapS.me;
  const l = m.l + sx, r = m.r + sx, t = m.t + sy, b = m.b + sy;
  const bx = snapPick([l, (l + r) / 2, r], snapS.xs), by = snapPick([t, (t + b) / 2, b], snapS.ys);
  const fx = bx ? bx.d : 0, fy = by ? by.d : 0;
  let g = '';
  const line = (x1, y1, x2, y2) => `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#ff3ea5" stroke-width="1" stroke-dasharray="4 3"/>`;
  if (bx) { const x = bx.L.v; g += line(x, Math.min(bx.L.a, t + fy) - 8, x, Math.max(bx.L.b, b + fy) + 8); }
  if (by) { const y = by.L.v; g += line(Math.min(by.L.a, l + fx) - 8, y, Math.max(by.L.b, r + fx) + 8, y); }
  snapSvg.innerHTML = g;
  liveMove(sx + fx, sy + fy);
  return [(sx + fx) * k / rho, (sy + fy) * k / rho];
};
window.__fxSnapEnd = () => { snapS = null; snapSvg.innerHTML = ''; };
addEventListener('mouseup', () => { if (snapS) window.__fxSnapEnd(); });

// ---------- 多选时其他素材「实时跟着动」（v24.5） ----------
// 主素材拖动 / 滚轮缩放的过程中，其他选中的素材先在画面上临时挪 / 缩放同样多（只是 CSS，不改参数）；
// 松手后参数真正同步完（15-timeline-tools.js 的 bcCheck → ghostInit），再撤掉这层临时变换 —— 画面无缝衔接，不再「松手才跳过去」。
const live = new Map();                               // clip.id → { base: 原来的 transform, x, y, f, cx, cy }
function liveSet(c, fn) {
  const g = G[c.id]; if (!g || g.style.visibility === 'hidden') return;
  let L = live.get(c.id);
  if (!L) { const r = snapRectOf(g); L = { base: g.style.transform, x: 0, y: 0, f: 1, cx: r ? (r.l + r.r) / 2 : 0, cy: r ? (r.t + r.b) / 2 : 0 }; live.set(c.id, L); }
  fn(L);
  // 先按自己内容的中心缩放，再平移（transform-origin 是 0 0，所以手动绕中心）
  g.style.transform = `translate(${(L.x + L.cx).toFixed(2)}px,${(L.y + L.cy).toFixed(2)}px) scale(${L.f.toFixed(4)}) translate(${(-L.cx).toFixed(2)}px,${(-L.cy).toFixed(2)}px) ` + L.base;
  liveGuard();
}
function liveMove(sx, sy) { if (tlMulti.size > 1) bcOthers().forEach(c => liveSet(c, L => { L.x = sx; L.y = sy; })); }
window.__fxLive = (kind, a, b) => {                   // 效果滚轮缩放时调：('s', 改之前的大小, 改之后的大小)
  if (kind !== 's' || !(a > 0) || !(b > 0) || tlMulti.size < 2) return;
  bcOthers().forEach(c => liveSet(c, L => { L.f *= b / a; }));
};
function liveClear(id) {                              // 参数同步好了（或者放弃了）：撤掉临时变换
  const L = live.get(id); if (!L) return; live.delete(id);
  const g = G[id]; if (g) g.style.transform = L.base;
}
let liveT = 0;
function liveGuard() {                                // 保底：3 秒没同步（比如什么都没改成）就撤掉，免得画面一直歪着
  clearTimeout(liveT); liveT = setTimeout(() => [...live.keys()].forEach(liveClear), 3000);
}
// 松手后尽快同步（原来要等「撤销」那边 0.45 秒才检查一次）
Hooks.on('markDirty', () => { if (live.size) setTimeout(() => { if (live.size) histCheck(); }, 0); });
