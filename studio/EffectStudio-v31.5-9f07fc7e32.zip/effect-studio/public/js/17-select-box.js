// 效果工坊 · 选中框（v24.1）：时间线上选中的素材，在预览窗口里画一个实线框，框住它「看得见的部分」
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// · 不管是在时间线上点选，还是在预览里点选，都会显示；多选时每个素材各一个框；选中组合时框住整个组合。
// · 「看得见的部分」和预览里点选用的是同一套规则（见 12-timeline-input.js 的 hitClip）：
//   透明的、淡没了的、整屏的空容器都不算；所以框的就是素材真正画出来的东西。
// · 框跟着素材的变换走（组合的位置 / 大小 / 三轴旋转 / 透视），旋转过的素材框也是斜的。
// · 只在预览里显示，不会被导出。

const sbSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
sbSvg.id = 'selbox';
sbSvg.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;overflow:visible;pointer-events:none;z-index:99990';
box.appendChild(sbSvg);

// 素材页面里「画了东西」的范围（素材自己的像素坐标），没有就返回 null
function sbContentRect(el) {
  const d = pickDoc(el); if (!d || !d.body || !d.defaultView) return null;
  const w = d.defaultView, vw = w.innerWidth, vh = w.innerHeight;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, full = null;
  const add = r => {
    const a = Math.max(0, r.left), b = Math.max(0, r.top), c = Math.min(vw, r.right), e = Math.min(vh, r.bottom);
    if (c - a < 1 || e - b < 1) return;
    if (a < x0) x0 = a; if (b < y0) y0 = b; if (c > x1) x1 = c; if (e > y1) y1 = e;
  };
  const op = new Map(); op.set(d.body, 1);
  const range = d.createRange();
  for (const n of d.body.querySelectorAll('*')) {
    const p = op.get(n.parentElement); if (p === undefined || p === 0) { op.set(n, 0); continue; }   // 父级看不见 → 自己也看不见
    const cs = w.getComputedStyle(n);
    if (cs.display === 'none') { op.set(n, 0); continue; }
    const o = p * +cs.opacity; op.set(n, o < 0.04 ? 0 : o);
    if (o < 0.04 || cs.visibility === 'hidden') continue;
    const tag = n.tagName, svgKid = n instanceof w.SVGElement && tag.toLowerCase() !== 'svg';
    if (svgKid && /^(g|defs|clipPath|mask|linearGradient|radialGradient|stop|filter|symbol|pattern|title|desc)$/i.test(tag)) continue;
    const r = n.getBoundingClientRect(); if (r.width < 1 || r.height < 1) continue;
    const isMedia = /^(IMG|CANVAS|VIDEO|svg)$/i.test(tag) && !svgKid;
    const fullSize = r.width >= vw * 0.97 && r.height >= vh * 0.97;
    if (fullSize && !svgKid) { if (isMedia && !full) full = r; continue; }   // 整屏的容器不算；整屏的画布先记下，实在没别的再用
    if (isMedia || svgKid) { add(r); continue; }
    const paints = (cs.backgroundColor && !/^(transparent|rgba\(.*, 0\))$/.test(cs.backgroundColor)) || cs.backgroundImage !== 'none' ||
      (parseFloat(cs.borderTopWidth) + parseFloat(cs.borderLeftWidth) > 0 && cs.borderStyle !== 'none') || cs.boxShadow !== 'none';
    if (paints) add(r);
    for (const t of n.childNodes) {                   // 文字：用文字本身的范围（比整块 div 更贴）
      if (t.nodeType !== 3 || !t.nodeValue.trim()) continue;
      range.selectNodeContents(t); add(range.getBoundingClientRect());
    }
  }
  if (x1 < x0 && full) add(full);
  return x1 > x0 ? { x0, y0, x1, y1 } : null;
}
// 素材坐标里的一点 → 预览框里的位置（和 toLocal 正好反过来）
function sbProject(el, x, y) {
  const tf = getComputedStyle(el).transform;
  const m = !tf || tf === 'none' ? new DOMMatrix() : new DOMMatrix(tf);
  const q = m.m14 * x + m.m24 * y + m.m44; if (q <= 0) return null;
  return [(m.m11 * x + m.m21 * y + m.m41) / q, (m.m12 * x + m.m22 * y + m.m42) / q];
}
const sbEl = c => c.id === tlSel ? frame : G[c.id];
function sbDraw() {
  sbT = 0; let html = '';
  if (TL.clips.length && !tlLoading) {
    const g = grp(tlGrp);
    const sets = g ? [TL.clips.filter(c => c.group === g.id)]
      : (tlMulti.size > 1 ? [...tlMulti] : [tlSel]).map(clip).filter(Boolean).map(c => [c]);
    for (const set of sets) {
      let r = null, el = null;
      for (const c of set) {                          // 组合里的素材变换都一样：在素材坐标里合并，再一起投到预览上
        const e = sbEl(c); if (!e || e.style.visibility === 'hidden') continue;
        const cr = sbContentRect(e); if (!cr) continue;
        el = el || e; r = r ? { x0: Math.min(r.x0, cr.x0), y0: Math.min(r.y0, cr.y0), x1: Math.max(r.x1, cr.x1), y1: Math.max(r.y1, cr.y1) } : cr;
      }
      if (!r) continue;
      const a = sbProject(el, r.x0, r.y0), b = sbProject(el, r.x1, r.y0);   // 往外留 4 像素（按预览缩放换算），框不压在内容上
      const k = a && b ? Math.hypot(b[0] - a[0], b[1] - a[1]) / (r.x1 - r.x0) : 1, pad = 4 / (k || 1);
      r = { x0: r.x0 - pad, y0: r.y0 - pad, x1: r.x1 + pad, y1: r.y1 + pad };
      const pts = [[r.x0, r.y0], [r.x1, r.y0], [r.x1, r.y1], [r.x0, r.y1]].map(p => sbProject(el, p[0], p[1]));
      if (pts.some(p => !p)) continue;
      const s = pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
      html += `<polygon points="${s}" fill="none" stroke="rgba(0,0,0,.45)" stroke-width="3"/><polygon points="${s}" fill="none" stroke="#fff" stroke-width="1.5"/>`;
    }
  }
  if (html !== sbLast) { sbSvg.innerHTML = html; sbLast = html; }
}
let sbT = 0, sbLast = '', sbAt = 0;
function sbSoon() {                                   // 一帧里只算一次；播放时最多每 0.1 秒算一次
  if (sbT) return;
  const wait = (tlPlaying || playing) ? Math.max(0, 100 - (performance.now() - sbAt)) : 0;
  sbT = setTimeout(() => requestAnimationFrame(() => { sbAt = performance.now(); sbDraw(); }), wait);
}
['tlDraw', 'tlSeek', 'seek', 'fit', 'select', 'markDirty', 'reinit'].forEach(n => Hooks.on(n, () => sbSoon()));
// 在预览里拖动 / 滚轮缩放 / 右键旋转时，效果自己在改位置：鼠标动的时候也跟着刷新
['mousemove', 'wheel', 'mouseup'].forEach(t => addEventListener(t, () => { if (tlSel || tlGrp) sbSoon(); }, { passive: true }));
// 保底：素材入场动画、图片晚加载完等情况，每 0.4 秒看一眼（没选中东西时不算）
setInterval(() => { if (!document.hidden && (tlSel || tlGrp || sbLast)) sbSoon(); }, 400);
