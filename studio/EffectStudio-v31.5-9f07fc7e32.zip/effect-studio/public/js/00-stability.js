// 效果工坊 · 稳定性：出错记日志 · 工程自动存盘（必须最先加载）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 稳定性（v23.1）：出错自动记日志 + 工程自动存盘 =================
// 出错 → 写进 logs\错误日志.txt，左下角亮红点；时间线 / 原视频 / 分段修正 → 自动存到 projects\当前工程.json，并保留历史
(() => {
  const PK = ['timeline', 'refVideo', 'segFix'];
  const ls = { g(k) { try { return localStorage.getItem('fxnav:' + k); } catch (e) { return null; } }, s(k, v) { try { localStorage.setItem('fxnav:' + k, v); } catch (e) {} } };
  const post = (u, body, keep) => fetch(u, { method: 'POST', headers: { 'X-FX': '1', 'Content-Type': 'application/json' }, body: JSON.stringify(body), keepalive: !!keep }).then(r => r.json());
  const hhmm = () => new Date().toTimeString().slice(0, 5);
  let chip, errN = 0, state = '', bad = false;
  const mark = (txt, isBad) => { if (txt != null) { state = txt; bad = !!isBad; } if (!chip) return;
    chip.innerHTML = (errN ? `<b style="color:#ff5a5a">● ${errN} 个错误</b>　` : '') + `<span style="color:${bad ? '#ffb020' : '#7ad48a'}">●</span> 工程${state || '未改动'}`; };
  // ---- 1) 打开页面时：浏览器被清空了，或别处存的更新，就用硬盘上的工程 ----
  let disk = {};
  try { const x = new XMLHttpRequest(); x.open('GET', '/api/project/latest', false); x.send(); disk = JSON.parse(x.responseText || '{}') || {}; } catch (e) {}
  const localT = +ls.g('projT') || 0;
  if (disk.data && (+disk.t || 0) > localT) { PK.forEach(k => { if (disk.data[k] !== undefined) ls.s(k, JSON.stringify(disk.data[k])); }); ls.s('projT', String(disk.t)); }
  const snapshot = () => { const data = {}; PK.forEach(k => { const v = ls.g(k); if (v != null) try { data[k] = JSON.parse(v); } catch (e) {} }); return data; };
  let tm = 0;
  const push = (keep, force) => { tm = 0; return post('/api/project/save', { t: +ls.g('projT') || Date.now(), force: !!force, data: snapshot() }, keep)
    .then(r => { if (r.ok) mark('已存盘 ' + hhmm()); else throw 0; }).catch(() => mark('存盘失败（服务没开？）', true)); };
  window.__fxProj = k => { if (!PK.includes(k)) return; ls.s('projT', String(Date.now())); clearTimeout(tm); tm = setTimeout(push, 1500); };
  window.addEventListener('beforeunload', () => { if (tm) { clearTimeout(tm); push(true); } });
  if (localT > (+disk.t || 0) && Object.keys(snapshot()).length) setTimeout(push, 2000);   // 浏览器里的比硬盘新（比如上次存盘时服务没开）→ 补存
  // ---- 2) 出错记录 ----
  const sent = new Set();
  const report = (msg) => { msg = String(msg || '').slice(0, 4000); const key = msg.slice(0, 300);
    if (sent.has(key) || sent.size > 50) return; sent.add(key); errN++; mark();
    post('/api/log', { msg: msg + '\n页面：' + location.pathname }).catch(() => {}); };
  window.addEventListener('error', e => { if (!e.message) return;   // 图片 / 视频加载失败不算
    report(e.message + '\n位置：' + (e.filename || '').replace(location.origin, '') + ' 第 ' + e.lineno + ' 行 ' + e.colno + ' 列\n' + (e.error && e.error.stack || '')); });
  window.addEventListener('unhandledrejection', e => { const r = e.reason; report('异步出错：' + (r && (r.stack || r.message) || r)); });
  const ce = console.error.bind(console);
  console.error = (...a) => { ce(...a); try { report('console.error：' + a.map(x => x && x.stack || (typeof x === 'object' ? JSON.stringify(x) : String(x))).join(' ')); } catch (e) {} };
  // ---- 3) 左下角小标签：点开看工程历史、打开错误日志 ----
  const panel = async () => {
    let p = document.getElementById('fxStab'); if (p) return p.remove();
    p = document.createElement('div'); p.id = 'fxStab';
    p.style.cssText = 'position:fixed;left:8px;bottom:34px;z-index:99999;width:300px;max-height:60vh;overflow:auto;background:rgba(24,24,28,.97);color:#ddd;font:12px/1.6 sans-serif;border:1px solid #444;border-radius:8px;padding:10px;box-shadow:0 6px 24px rgba(0,0,0,.4)';
    const list = await (await fetch('/api/project/list')).json().catch(() => []);
    const fmt = n => n.replace(/^工程-(\d{4})(\d\d)(\d\d)-(\d\d)(\d\d)(\d\d)\.json$/, '$2-$3 $4:$5');
    p.innerHTML = `<div style="display:flex;gap:6px;margin-bottom:8px"><button data-a="log">打开错误日志</button>${errN ? '<button data-a="clr">清除红点</button>' : ''}</div>
      <div style="color:#999;margin-bottom:4px">工程历史（每 5 分钟一份，留最近 30 份）</div>` +
      (list.length ? list.map(f => `<div style="display:flex;justify-content:space-between;padding:2px 0">${fmt(f.name)}<button data-n="${f.name}">恢复到这里</button></div>`).join('') : '<div style="color:#777">还没有历史</div>');
    p.onclick = async e => { const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.a === 'log') return fetch('/api/open-logs');
      if (b.dataset.a === 'clr') { errN = 0; sent.clear(); mark(); return p.remove(); }
      if (b.dataset.n && confirm('恢复到 ' + fmt(b.dataset.n) + ' 的工程？\n（现在的工程会先另存一份历史，随时能再换回来）')) {
        await push(false, true);
        const d = await (await fetch('/api/project/get?name=' + encodeURIComponent(b.dataset.n))).json();
        if (!d.data) return alert('这份历史读不出来');
        PK.forEach(k => { try { localStorage.removeItem('fxnav:' + k); } catch (e) {} if (d.data[k] !== undefined) ls.s(k, JSON.stringify(d.data[k])); });
        ls.s('projT', String(Date.now())); await push(); location.reload();
      } };
    document.body.appendChild(p);
  };
  addEventListener('DOMContentLoaded', () => {
    chip = document.createElement('div'); chip.title = '点开：工程历史 / 错误日志';
    chip.style.cssText = 'position:fixed;left:8px;bottom:6px;z-index:99999;font:11px sans-serif;color:#bbb;background:rgba(24,24,28,.8);padding:3px 8px;border-radius:10px;cursor:pointer;user-select:none';
    chip.onclick = panel; document.body.appendChild(chip); mark();
  });
})();
