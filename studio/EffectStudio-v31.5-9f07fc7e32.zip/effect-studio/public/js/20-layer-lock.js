// 效果工坊 · 图层的「眼睛」和「锁」（v24.10）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// 素材时间线左边每一层前面两个小按钮：
//   眼睛：睁眼 = 显示；闭眼 = 这一层不显示，也不导出（预览里点不中它）
//   锁：  锁上 = 这一层不能选、不能拖、不能改（时间线和预览里都点不中，框选 / Ctrl+A 也跳过它），素材条变暗加斜线
// 状态记在这一层每个素材自己身上（c.hide / c.lock），所以撤销、存盘、复制都自动带上；挪到别的层也跟着素材走。
// 这里只管按钮和切换；「点不中 / 不显示 / 不导出」分别在 10-timeline（tlRender、点击、框选）、
// 12-timeline-input（hitsAt）、13-segment-export（compOf）、15-timeline-tools（Ctrl+A）里各加了一句判断。

const lyIn = L => TL.clips.filter(c => c.layer === L);
const lyAll = (L, k) => { const m = lyIn(L); return m.length > 0 && m.every(c => !!c[k]); };
const LY_EYE = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1.5 8s2.4-4.5 6.5-4.5S14.5 8 14.5 8 12.1 12.5 8 12.5 1.5 8 1.5 8z"/><circle cx="8" cy="8" r="2"/></svg>';
const LY_EYE_OFF = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M2 7.5c1.5 2 3.6 3.2 6 3.2s4.5-1.2 6-3.2"/><path d="M4.2 9.6 3 11.2M8 10.7v1.9M11.8 9.6l1.2 1.6"/></svg>';
const LY_LOCK = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="3.5" y="7" width="9" height="6.5" rx="1.2" fill="currentColor" fill-opacity=".25"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/></svg>';
const LY_UNLOCK = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="3.5" y="7" width="9" height="6.5" rx="1.2"/><path d="M5.5 7V5a2.5 2.5 0 0 1 4.9-.7"/></svg>';
function lyBtns(L) {                                  // 10-timeline.js 的 drawTrack 画层名时调
  const hid = lyAll(L, 'hide'), lk = lyAll(L, 'lock');
  return `<span class="lyb${hid ? ' on' : ''}" data-ly="${L}" data-a="hide" title="${hid ? '这一层现在不显示（也不导出）：点一下显示' : '显示中：点一下隐藏这一层'}">${hid ? LY_EYE_OFF : LY_EYE}</span>`
    + `<span class="lyb${lk ? ' on' : ''}" data-ly="${L}" data-a="lock" title="${lk ? '这一层锁住了（不能选、不能拖、不能改）：点一下解锁' : '点一下锁住这一层'}">${lk ? LY_LOCK : LY_UNLOCK}</span>`;
}
names.addEventListener('mousedown', e => {
  const b = e.target.closest('.lyb'); if (!b) return;
  e.preventDefault(); e.stopPropagation();
  const L = +b.dataset.ly, k = b.dataset.a, m = lyIn(L); if (!m.length) return;
  const on = !lyAll(L, k);
  m.forEach(c => { if (on) c[k] = true; else delete c[k]; });
  // 锁住 / 藏起来的素材如果正选着：取消选中（不然右侧面板和预览还能改它）
  const out = new Set(m.map(c => c.id));
  if (on && (out.has(tlSel) || [...tlMulti].some(id => out.has(id)))) {
    tlMulti = new Set([...tlMulti].filter(id => !out.has(id)));
    if (out.has(tlSel)) { commitSel(); tlSel = null; tlPreview = false; tlGrp = null; tlIn = null; gpBuild(); kfTrackDraw(); }
  }
  tlRender(); tlDraw(); tlSave();
  $('#hint').textContent = '层 ' + (L + 1) + (k === 'hide' ? (on ? ' 已隐藏（不显示、不导出）' : ' 已显示') : (on ? ' 已锁定（不能选、不能拖、不能改）' : ' 已解锁'));
});
const lst = document.createElement('style');
lst.textContent = `html #tlp{--tlnw:76px}
#tlp-names div{display:flex;align-items:center;justify-content:flex-end;gap:1px;white-space:nowrap}
#tlp-names .lyb{display:inline-flex;align-items:center;justify-content:center;width:17px;height:17px;border-radius:3px;color:#555;cursor:pointer;flex:none}
#tlp-names .lyb:hover{color:#ccc;background:#262626}
#tlp-names .lyb.on{color:#f28c0f}
#tlp-names .lyb svg{width:13px;height:13px;display:block}
#tlp-names .lyb + .lyb{margin-right:4px}
.tlc.lk{filter:brightness(.55) saturate(.35)!important;cursor:not-allowed!important;background-image:repeating-linear-gradient(-45deg,rgba(0,0,0,.45) 0 3px,transparent 3px 8px)!important}
.tlc.lk .tlr{display:none}
.tlc.hd{opacity:.35!important}
html.light #tlp-names .lyb{color:#aaa} html.light #tlp-names .lyb:hover{background:#e8e8e8;color:#333}`;
document.head.appendChild(lst);
tlDraw();
