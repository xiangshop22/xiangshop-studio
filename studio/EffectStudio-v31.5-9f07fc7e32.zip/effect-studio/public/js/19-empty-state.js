// 效果工坊 · 时间线为空时的预览窗口（v24.8）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）
//
// · 时间线上没有素材（刚打开 / 素材全删了）：预览窗口不显示任何效果，只在中间提示「从左侧拖一个效果过来」。
//   以前这时还会显示上一次的效果，容易误以为窗口里已经有素材了。
// · 在左侧点了某个效果卡片：照样可以预览它（挑效果用），但左上角标明「仅预览 · 还没加入时间线」。
// · 时间线上一有素材，这两样都不显示，一切照旧。
// 是否显示 #frame 由 10-timeline.js 的 tlRender 调 emptyShowFrame() 决定。
// · 关键帧区（v24.9）：空状态时整个不显示（以前会显示藏起来的那个效果的关键帧）；
//   选中的素材没有关键帧 → 折叠；打了第一个关键帧 / 选中的素材本来就有关键帧 → 自动展开；关键帧删光 → 又折叠。中间手动点开 / 收起照常有效。

let emptyPeek = false;                                // 时间线为空时，用户在左侧点过效果 → 允许预览
let emptyHad = false;                                 // 上一次检查时时间线上有没有素材（从有变没有 = 删光了，回到提示）
const emptyTip = document.createElement('div'); emptyTip.id = 'emptytip';
emptyTip.innerHTML = '<b>时间线上还没有素材</b><span>从左侧把效果拖到这里（或拖到下面的素材时间线），就可以开始制作</span>';
const emptyBadge = document.createElement('div'); emptyBadge.id = 'emptybadge';
emptyBadge.textContent = '仅预览 · 还没加入时间线（拖到这里或时间线上才开始制作）';
box.append(emptyTip, emptyBadge);
const est = document.createElement('style');
est.textContent = `#emptytip{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;justify-content:center;gap:8px;z-index:99980;pointer-events:none;text-align:center;padding:0 24px}
#emptytip b{font-size:17px;color:#ddd;font-weight:600}
#emptytip span{font-size:13px;color:#999}
#emptybadge{position:absolute;left:10px;top:10px;display:none;z-index:99980;pointer-events:none;font-size:12px;color:#111;background:#f2a33d;border-radius:5px;padding:4px 9px}
html.light #emptytip b{color:#333} html.light #emptytip span{color:#666}`;
document.head.appendChild(est);

function emptyShowFrame() { return !!emptyPeek; }   // tlRender：时间线为空时 #frame 要不要露出来
function emptySync() {
  const has = TL.clips.length > 0;
  if (has || (emptyHad && !has)) emptyPeek = false;   // 有素材了 / 刚删光：回到「提示」状态
  emptyHad = has;
  emptyTip.style.display = !has && !emptyPeek ? 'flex' : 'none';
  emptyBadge.style.display = !has && emptyPeek && cur ? 'block' : 'none';
  if (!has) { frame.style.visibility = emptyPeek ? '' : 'hidden'; if (!emptyPeek && playing) stopEffect(); }   // 藏起来时别在后台空播
  kfAuto();
}
let kfAutoKey = undefined, kfAutoN = -1;
function kfAuto() {
  const kft = $('#kft'); if (!kft) return;
  const blank = !TL.clips.length && !emptyPeek;
  if (blank) { kft.hidden = true; const a = $('#kfadd'), e = $('#kfedge'); if (a) a.hidden = true; if (e) e.hidden = true; kfAutoKey = null; kfAutoN = -1; return; }
  let n = 0; try { const api = kfApi(); n = api && (!api.enabled || api.enabled()) ? (api.get() || []).length : 0; } catch (e) { n = 0; }
  const key = (tlSel || '') + '|' + (cur ? cur.id : '');
  if (key !== kfAutoKey || (n > 0) !== (kfAutoN > 0)) {    // 换了素材，或者关键帧从无到有 / 从有到无：自动折叠或展开
    const want = n === 0, tg = kft.querySelector('.fdt');
    if (tg && kft.classList.contains('fold') !== want) {   // 直接切换（不模拟点击：点击会被当成一次操作去拍撤销快照）
      kft.classList.toggle('fold', want); tg.textContent = want ? '▸' : '▾'; tg.title = want ? '展开关键帧' : '收起关键帧'; fit();
    }
  }
  kfAutoKey = key; kfAutoN = n;
}
// 在左侧点效果卡片（不是拖）= 想看看这个效果
$('#list').addEventListener('click', e => { if (!TL.clips.length && e.target.closest('.item')) { emptyPeek = true; setTimeout(emptySync, 0); } });
['tlDraw', 'select', 'reinit', 'kfTrackDraw'].forEach(n => Hooks.on(n, () => emptySync()));
emptySync();
