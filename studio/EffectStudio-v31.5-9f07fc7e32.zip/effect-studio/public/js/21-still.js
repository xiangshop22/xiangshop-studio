// 效果工坊 · 抓取静帧（v28.0）
// 预览区下面「辅助对齐」左边一个「📷 抓取静帧」：把播放头这一刻的画面，按右侧「导出设置」的分辨率存成一张透明 PNG。
// 走和导出同一套渲染（server.js /api/export 带 still），所以和导出的视频是同一个画面；保存在 output\静帧\。
const stillBtn = document.createElement('button');
stillBtn.type = 'button'; stillBtn.id = 'stillbtn'; stillBtn.className = 'gpill';
stillBtn.title = '把播放头这一刻的画面存成一张 PNG（透明背景，尺寸 = 导出设置里的分辨率），保存在 output\\静帧';
stillBtn.innerHTML = '<span class="gl">📷 抓取静帧</span>';
{ const wrap = document.createElement('div'); wrap.id = 'hintr'; snapBtn.before(wrap); wrap.append(stillBtn, snapBtn); }
let stillBusy = false;
stillBtn.onclick = async () => {
  if (stillBusy) return;
  const real = TL.clips.filter(c => !c.ref);
  if (!real.length && !cur) return toast('先把效果放到时间线上，或在左边点一个效果', true);
  const { w, h } = res(), t = real.length ? tlT : (+slider.value || 0);
  const p2 = n => String(n).padStart(2, '0'), d = new Date();
  const name = '静帧_' + t.toFixed(2).replace('.', '_') + '秒_' + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds());
  const body = Object.assign(real.length ? { comp: compOf(real) } : { effect: cur.id, params },
    { still: t, name, dir: '静帧', width: w, height: h, fps: +$('#fps').value || 30, hold: 0 });
  stillBusy = true; const gl = stillBtn.querySelector('.gl'); gl.textContent = '📷 抓取中…';
  try {
    const file = await runJob(body, () => {});
    toast('静帧已保存：output\\' + file.replace('/', '\\') + '（' + w + '×' + h + '）', false, 6000);
  } catch (e) { toast('抓取失败：' + e.message, true); }
  stillBusy = false; gl.textContent = '📷 抓取静帧';
};
{ const st = document.createElement('style');
  st.textContent = '#hintrow #hintr{position:absolute;right:0;top:50%;transform:translateY(-50%);display:flex;gap:6px;align-items:center}'
    + '#hintrow #hintr #snapbtn{position:static;transform:none}#stillbtn .gl{color:#ccc;padding:3px 9px}#stillbtn:hover .gl{color:#f28c0f}';
  document.head.appendChild(st); }
