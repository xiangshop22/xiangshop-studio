// 效果工坊 · 组合（预合成）· 组合参数面板 · 关键帧行
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 组合（预合成，v10.4） =================
// 把几个素材合成一个组合：组合有自己的 位置 / 大小 / XYZ 旋转 / 透明度（可打关键帧），
// 套在每个成员的 iframe 上（同一个中心点、同一个透视），看起来就是整组一起动。成员各自的参数和关键帧照旧。
const TF0 = { x: 0, y: 0, s: 100, rx: 0, ry: 0, rz: 0, o: 100 };
function gRange(g) { const m = TL.clips.filter(c => c.group === g.id); return m.length ? [Math.min(...m.map(c => c.start)), Math.max(...m.map(c => c.start + c.len)), m] : [0, 0, m]; }
// 算法在 /fx-group.js（导出用的 comp.html 也用它）。v12.1 起关键帧按 P / S / R / O 分行，老工程自动兼容
function gVal(g, T) { return FXGroup.val(g, T - gRange(g)[0]); }
function tfStr(v) {
  const { w, h } = res();
  return baseTf + ' translate(' + (w / 2 + v.x) + 'px,' + (h / 2 + v.y) + 'px) perspective(' + Math.max(w, h) * 1.5 + 'px) rotateX(' + v.rx + 'deg) rotateY(' + v.ry + 'deg) rotateZ(' + v.rz + 'deg) scale(' + v.s / 100 + ') translate(' + (-w / 2) + 'px,' + (-h / 2) + 'px)';
}
function applyTf(el, c) {
  const g = c && c.group && grp(c.group);
  if (!g) { if (el._tf) { el.style.transform = baseTf; el.style.opacity = ''; el._tf = 0; } return; }
  const v = gVal(g, tlT); el.style.transform = tfStr(v); el.style.opacity = Math.max(0, Math.min(1, v.o / 100)); el._tf = 1;
}
function selGroup(id) { tlGrp = id; tlIn = null; tlMulti = new Set(); gpBuild(); tlDraw(); kfSel = new Set(); kfTrackDraw(); }
// 进到组合里面改单个素材（双击组合条 / 双击画面里组合的素材）：选中那个素材，关键帧轨道换回它自己的
function enterGroup(g, cid) {
  const m = TL.clips.filter(c => c.group === g.id); if (!m.length) return;
  const c = clip(cid) && clip(cid).group === g.id ? clip(cid) : m.slice().sort((a, b) => b.layer - a.layer)[0];
  g.col = false; tlIn = g.id; tlGrp = null; gpBuild();
  if (tlSel === c.id) { tlDraw(); kfSel = new Set(); kfTrackDraw(); } else tlSelect(c.id);
  tlIn = g.id; tlDraw();
  const f = fxOf(c); toast('已进到「' + g.name + '」里面：现在改的是「' + (f ? f.name : c.fx) + '」自己。按 Esc（或点一下组合条）回到整个组合');
}
function makeGroup() {
  const ids = tlMulti.size ? [...tlMulti] : tlSel ? [tlSel] : [];
  const cs = ids.map(clip).filter(Boolean);
  if (!cs.length) return toast('先选中要组合的素材（Ctrl / Shift + 点击可以多选），再按 Ctrl+G');
  cs.forEach(c => delete c.group);                  // 不做组合套组合：已经在别的组合里的，先拿出来
  // v13.1：创建的那一刻就在当前这一秒打一个「组合关键帧」（P / S / R / O 四行，值 = 刚合成时的样子），
  // 之后拖 / 转都自动打点；「还原」= 回到这个起点（g.base）
  const g = { id: nid('g'), name: '组合 ' + (TL.groups.length + 1), tf: Object.assign({}, TF0), base: Object.assign({}, TF0), keys: [], anim: true, col: true };
  TL.groups.push(g); cs.forEach(c => c.group = g.id);
  gKeyAll(g, gTime(g), g.base);
  normLayers(); selGroup(g.id); tlRender(); tlSave();
  toast('已把 ' + cs.length + ' 个素材合成「' + g.name + '」，并在 ' + gTime(g).toFixed(2) + ' 秒打了起始关键帧：拖 / 滚轮 / 右键转都是整组一起，双击画面空白处还原');
}
function unGroup() {
  const c = clip(tlSel), g = grp(tlGrp) || (c && grp(c.group)); if (!g) return toast('先选中一个组合');
  TL.clips.forEach(o => { if (o.group === g.id) delete o.group; });
  TL.groups = TL.groups.filter(x => x !== g); tlGrp = null; tlIn = null;
  normLayers(); gpBuild(); tlRender(); tlDraw(); tlSave();
  toast('已解散「' + g.name + '」：素材还在，组合的整体变换去掉了');
}
// ---- 右侧：组合的参数面板（选中组合时替换「效果参数」那一块） ----
const GF = [['x', '位置 X', 'px', -2000, 2000, 1], ['y', '位置 Y', 'px', -2000, 2000, 1], ['s', '大小', '%', 1, 400, 1], ['rx', '旋转 X', '°', -180, 180, 1], ['ry', '旋转 Y', '°', -180, 180, 1], ['rz', '旋转 Z', '°', -180, 180, 1], ['o', '不透明度', '%', 0, 100, 1]];
const gp = document.createElement('div'); gp.id = 'gpanel'; $('aside.r').prepend(gp);
function gpBuild() {
  const g = grp(tlGrp); $('aside.r').classList.toggle('grpmode', !!g);
  if (!g) { gp.innerHTML = ''; return; }
  const [gs, ge, m] = gRange(g);
  gp.innerHTML = '<div class="gph"><b>▣</b><input id="gpn" title="改名"><span>' + m.length + ' 个素材 · ' + gs.toFixed(2) + ' → ' + ge.toFixed(2) + ' 秒</span></div>' +
    '<div class="gpt">组合（预合成）的整体变换，所有成员一起变。预览区：左键拖 = 位置 · 滚轮 = 大小 · 右键拖 = 旋转 X / Y · Shift+右键拖 = 旋转 Z。<br>关键帧在播放器下面那条轨道上（P / S / R / O）。<b>双击画面里的素材</b>（或双击时间线上的组合条）进到里面改单个素材，Esc 退出来；<b>双击画面空白处</b> = 还原到刚合成时的样子。</div>' +
    '<div class="gpa"><span>关键帧动画</span><span class="gsw"><button type="button" data-a="1">开</button><button type="button" data-a="0">关</button></span></div>' +
    GF.map(f => '<div class="gpr"><span>' + f[1] + '</span><input type="range" data-k="' + f[0] + '" min="' + f[3] + '" max="' + f[4] + '" step="' + f[5] + '"><input type="number" data-k="' + f[0] + '" step="' + f[5] + '"><i>' + f[2] + '</i></div>').join('') +
    '<div class="gpk" id="gpk"></div>' +
    '<div class="gpb"><button type="button" id="gpkey"></button><button type="button" id="gpreset">↺ 还原到刚合成时的样子</button><button type="button" id="gpun">解散组合（Ctrl+Shift+G）</button></div>';
  const n = gp.querySelector('#gpn'); n.value = g.name;
  n.onchange = () => { g.name = n.value.trim() || g.name; tlDraw(); tlSave(); };
  n.addEventListener('keydown', e => { if (e.key === 'Enter') n.blur(); });
  gp.querySelectorAll('.gsw button').forEach(b => b.onclick = () => {
    const on = b.dataset.a === '1'; if (on === !!g.anim) return;
    if (on) { g.anim = true; FXGroup.norm(g); if (!g.keys.length) gKeyAll(g, Math.max(0, r2(tlT - gRange(g)[0])), Object.assign({}, TF0, g.tf)); toast('关键帧动画已打开：把播放头拖到别的时间再改数值，就会自动打一个关键帧'); }
    else { g.tf = Object.assign({}, TF0, pick(gVal(g, tlT))); g.anim = false; g.keys = []; toast('关键帧动画已关闭：停在现在这一帧的样子'); }
    tlRender(); gpSync(); tlDraw(); tlSave();
  });
  gp.querySelectorAll('.gpr input').forEach(inp => inp.addEventListener('input', () => { const v = +inp.value; if (Number.isFinite(v)) gSet({ [inp.dataset.k]: v }); }));
  gp.querySelector('#gpkey').onclick = () => { if (!g.anim) { g.anim = true; g.keys = []; } gSet({}, true); toast('已在 ' + (tlT - gRange(g)[0]).toFixed(2) + ' 秒打关键帧'); };
  gp.querySelector('#gpreset').onclick = () => gReset();
  gp.querySelector('#gpun').onclick = unGroup;
  gpSync();
}
const pick = v => { const o = {}; for (const k in TF0) o[k] = +(+v[k]).toFixed(2); return o; };
function gpSync() {
  const g = grp(tlGrp); if (!g || !gp.firstChild) return;
  const v = gVal(g, tlT), gs = gRange(g)[0], t = r2(tlT - gs);
  gp.querySelectorAll('.gpr input').forEach(inp => { if (document.activeElement !== inp) inp.value = Math.round(v[inp.dataset.k] * 10) / 10; });
  gp.querySelectorAll('.gsw button').forEach(b => b.classList.toggle('on', (b.dataset.a === '1') === !!g.anim));
  const kb = gp.querySelector('#gpkey'); kb.textContent = '◆ 在 ' + Math.max(0, t).toFixed(2) + ' 秒打关键帧';
  const box2 = gp.querySelector('#gpk');
  FXGroup.norm(g);
  const ts = [...new Set(g.keys.map(k => k.t))].sort((a, b) => a - b);     // 同一秒的几行算一个（v12.1 关键帧按行分开）
  box2.innerHTML = g.anim ? (ts.length ? '<span>关键帧：</span>' + ts.map((kt, i) => '<em class="' + (Math.abs(kt - t) < 0.011 ? 'on' : '') + '" data-i="' + i + '" title="跳到这一秒（' + g.keys.filter(k => k.t === kt).map(k => k.k.toUpperCase()).join(' ') + '）">' + kt.toFixed(2) + 's<u data-i="' + i + '" title="删掉这一秒的关键帧">×</u></em>').join('') : '<span>还没有关键帧</span>') : '';
  box2.querySelectorAll('em').forEach(el => el.onclick = e => {
    const kt = ts[+el.dataset.i];
    if (e.target.tagName === 'U') { g.keys = g.keys.filter(k => k.t !== kt); if (!g.keys.length) { g.anim = false; } tlRender(); gpSync(); tlDraw(); tlSave(); }
    else { tlStop(); tlSeek(gRange(g)[0] + kt); }
  });
  try { kfTrackDraw(); } catch (e) { }
}
// 还原：回到创建组合那一刻的样子（g.base；老工程没有就是不做变换）。动画开着时在当前这一秒打一个「还原」的点（四行都打），
// 和单个素材「双击还原」一样，不会删掉别的关键帧
// 播放头在组合里的第几秒（夹在组合的头尾之间：播放头停在组合外面时，点打在最近的一头）
function gTime(g) { const [a, b] = gRange(g); return Math.max(0, Math.min(r2(b - a), r2(tlT - a))); }
function gReset() {
  const g = grp(tlGrp); if (!g) return;
  gSet(Object.assign({}, TF0, g.base || {}));
  toast(g.anim ? '已在组合的 ' + gTime(g).toFixed(2) + ' 秒打了一个「还原」关键帧（回到刚合成时的样子）' : '已还原到刚合成时的样子');
}
// 改数值：动画开着 → 写到当前时间的关键帧（没有就新建一个）；关着 → 直接改整体变换
// v12.1：关键帧按行（P 位置 / S 大小 / R 旋转 / O 不透明度）记，改哪一项就只在那一行打点，和效果里的关键帧一样
function gKeyAll(g, t, v, lanes) {                   // 在 t 秒给这几行打点（已有的就改它），值取 v
  FXGroup.norm(g);
  (lanes || Object.keys(FXGroup.LANES)).forEach(l => {
    let k = g.keys.find(x => x.k === l && Math.abs(x.t - t) < 0.011);
    if (!k) { k = { t, k: l }; g.keys.push(k); }
    FXGroup.LANES[l].forEach(f => k[f] = +(+v[f]).toFixed(2));
  });
  FXGroup.sortK(g.keys);
}
function gSet(o, forceKey, gg) {
  const g = gg || grp(tlGrp); if (!g) return;
  FXGroup.norm(g);
  if (forceKey) g.anim = true;
  if (g.anim) {
    const t = gTime(g);
    const v = Object.assign(pick(gVal(g, tlT)), o);
    gKeyAll(g, t, v, forceKey ? null : [...new Set(Object.keys(o).map(FXGroup.laneOf))]);
  } else Object.assign(g.tf, o);
  tlRender(); gpSync(); drawSoon(); tlSave();
}
// 预览区直接拖：选中组合时接管预览区的鼠标（不再改选中素材自己的参数）
// v12.1：这几个监听挂在 window 的捕获阶段 —— 比效果里 view-controls.js 挂在 document 上的拖动 / 右键旋转监听先执行，
// 选中组合时整组一起动，不会再漏给「当前选中的那个素材」（以前右键旋转就是这样漏过去的）
const sw = $('#stagewrap'); let gd = null;
const inSw = e => e.target instanceof Node && sw.contains(e.target);
const eat = e => { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };
function grpDown(e) {                                // 由下面「在预览窗口里点素材」那段统一调用
  const g = grp(tlGrp); if (!g) return false;
  eat(e);
  gd = { b: e.button, x: e.clientX, y: e.clientY, v: pick(gVal(g, tlT)), sh: e.shiftKey, sc: res().w / Math.max(1, box.clientWidth), moved: false };
  return true;
}
addEventListener('mousemove', e => {
  if (!gd) return;
  const dx = e.clientX - gd.x, dy = e.clientY - gd.y, v = gd.v;
  if (!gd.moved && Math.abs(dx) < 2 && Math.abs(dy) < 2) return;
  gd.moved = true;
  if (gd.b === 0) gSet({ x: Math.round(v.x + dx * gd.sc), y: Math.round(v.y + dy * gd.sc) });
  else if (gd.b === 2) gSet(gd.sh ? { rz: r2(v.rz + dx * 0.4) } : { ry: r2(v.ry + dx * 0.4), rx: r2(v.rx - dy * 0.4) });
});
addEventListener('mouseup', e => {
  if (!gd) return;
  const d = gd; gd = null; if (!d.moved) return;
  const g = grp(tlGrp); if (g && g.anim) toast('已在组合的 ' + Math.max(0, tlT - gRange(g)[0]).toFixed(2) + ' 秒记下【' + (d.b === 2 ? '旋转 R' : '位置 P') + '】关键帧');
}, true);
addEventListener('wheel', e => {
  const g = grp(tlGrp); if (!g || !inSw(e)) return;
  eat(e);
  const s = gVal(g, tlT).s; gSet({ s: Math.round(Math.max(1, Math.min(400, s * (e.deltaY < 0 ? 1.06 : 1 / 1.06))) * 10) / 10 });
}, { capture: true, passive: false });
addEventListener('contextmenu', e => { if (grp(tlGrp) && inSw(e)) eat(e); }, true);
addEventListener('mouseup', e => { if (grp(tlGrp) && inSw(e) && e.button === 2) eat(e); }, true);
