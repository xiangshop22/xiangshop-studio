// 效果工坊 · 在线更新 · 存储占用 / 清理
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 在线更新（v6.5） =================
// 打开工作台时自动去 Gitee / GitHub 看一眼有没有新版本、新效果；左上角 ⟳ 可以随时手动检查
// 有更新 → 「加载效果」下面出现提示条 → 点开勾选要装的 → 自动下载、安装（旧的自动备份），装了工作台程序会自动重启
// ================= 存储占用 / 清理（v7.7） =================
// 文件夹变大几乎都不是效果代码（全部效果加起来 1~2MB），而是素材和成品。
// 这里把占用按类别摊开，让用户自己勾着删；真正在用的素材和程序本体不给勾。
const spWrap = $('#spwrap'), spList = $('#splist'), spGo = $('#spgo'), spSel = $('#spsel'), spTot = $('#sptot');
const mb = n => n >= 1048576 ? (n / 1048576).toFixed(n >= 104857600 ? 0 : 1) + ' MB' : n >= 1024 ? Math.round(n / 1024) + ' KB' : n + ' B';
let spData = [];
function spSync() {
  const on = [...spList.querySelectorAll('input:checked')];
  const n = on.reduce((a, x) => a + (+x.dataset.bytes || 0), 0);
  spGo.disabled = !on.length;
  spSel.textContent = on.length ? '勾了 ' + on.length + ' 项，可腾出 ' + mb(n) : '没有勾选';
}
async function spOpen() {
  spWrap.hidden = false;
  spList.innerHTML = '<div style="padding:22px 0;color:#777;font-size:12px">正在统计…</div>';
  spTot.textContent = ''; spGo.disabled = true; spSel.textContent = '没有勾选';
  let r; try { r = await (await fetch('/api/space')).json(); } catch (e) { spList.innerHTML = '<div style="padding:22px 0;color:#e5484d;font-size:12px">读不到占用信息，重新双击 start.bat 再试。</div>'; return; }
  spData = r.groups || [];
  spTot.textContent = '整个文件夹约 ' + mb(spData.reduce((a, g) => a + g.bytes, 0));
  spList.innerHTML = '';
  spData.filter(g => g.bytes > 0 || g.safe).forEach(g => {
    const d = document.createElement('div');
    d.className = 'spit' + (g.safe ? '' : ' keep');
    d.innerHTML = (g.safe && g.bytes > 0
        ? '<input type="checkbox" data-k="' + g.key + '" data-bytes="' + g.bytes + '">'
        : '<span style="width:15px;flex:none"></span>')
      + '<div class="b"><div class="n">' + g.name + '<b>' + mb(g.bytes) + '</b></div>'
      + '<div class="d"><code>' + g.dir + '</code> ' + g.note + '</div></div>';
    spList.appendChild(d);
  });
  spList.querySelectorAll('input').forEach(i => i.onchange = spSync);
}
$('#spacebtn').onclick = spOpen;
$('#spx').onclick = () => { spWrap.hidden = true; };
spWrap.onclick = e => { if (e.target === spWrap) spWrap.hidden = true; };
spGo.onclick = async () => {
  const keys = [...spList.querySelectorAll('input:checked')].map(x => x.dataset.k);
  if (!keys.length) return;
  spGo.disabled = true; spGo.textContent = '清理中…';
  try {
    const r = await (await fetch('/api/space/clean', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-FX': '1' }, body: JSON.stringify({ keys }) })).json();
    toast('已腾出 ' + mb(r.freed || 0));
  } catch (e) { toast('清理失败：' + e.message); }
  spGo.textContent = '清理勾选的';
  spOpen();
};

const updBar = $('#updbar'), updBtn = $('#updbtn');
let updInfo = null;
const updSig = i => JSON.stringify([i.studio && i.studio.newer ? i.studio.latest : '', i.effects.map(e => e.id + e.status)]);
const hasUpd = i => i && i.ok && ((i.studio && i.studio.newer) || i.effects.length);
function showUpdBar(i) {
  updInfo = i;
  updBtn.classList.toggle('dot', !!hasUpd(i));
  let ign = ''; try { ign = localStorage.getItem('fxnav:updIgnore') || ''; } catch (e) {}
  if (!hasUpd(i) || ign === updSig(i)) { updBar.hidden = true; return; }
  const parts = [];
  if (i.studio && i.studio.newer) parts.push('工作台新版 ' + i.studio.latest);
  const nn = i.effects.filter(e => e.status === 'new').length, nu = i.effects.length - nn;
  if (nn) parts.push(nn + ' 个新效果'); if (nu) parts.push(nu + ' 个效果有更新');
  updBar.querySelector('span').textContent = '有更新：' + parts.join(' · ');
  updBar.hidden = false;
}
async function checkUpdate(manual) {
  if (manual) { updBtn.classList.add('spin'); toast('正在检查更新…', false, 20000); }
  let i; try { i = await (await fetch('/api/update/check' + (manual ? '?force=1' : ''))).json(); } catch (e) { i = { ok: false, error: e.message }; }
  updBtn.classList.remove('spin');
  if (!i.ok) { if (manual) toast('检查更新失败：' + i.error, true, 9000); return; }
  showUpdBar(i);
  if (manual) { if (hasUpd(i)) { toastEl.className = ''; openUpdate(); } else toast('已经是最新版（' + i.studio.current + '，来源：' + i.source + '）'); }
}
async function openUpdate() {
  const i = updInfo; if (!hasUpd(i)) return;
  const pick = { studio: !!(i.studio && i.studio.newer), effects: new Set(i.effects.map(e => e.id)) };
  const row = (k, title, sub, tag) => `<label class="upd-i"><input type="checkbox" checked data-k="${esc(k)}"><span><b>${esc(title)}</b>${tag ? '<em>' + tag + '</em>' : ''}${sub ? '<small>' + esc(sub) + '</small>' : ''}</span></label>`;
  let html = '<p>来源：' + esc(i.source) + (i.published ? ' · 发布于 ' + esc(i.published.slice(0, 10)) : '') + '</p>'
    + (i.notes ? '<p class="upd-n">' + esc(i.notes) + '</p>' : '') + '<div class="upd-l">';
  if (pick.studio) html += row('__studio', '工作台程序 ' + i.studio.latest, '你现在是 ' + i.studio.current + '；装完会自动重启', '升级');
  i.effects.forEach(e => { html += row(e.id, e.name, e.description, e.status === 'new' ? '新效果' : '有更新'); });
  html += '</div><p class="upd-f">被替换的旧文件会自动备份到 _backup 文件夹。不想装的取消勾选即可。</p>';
  const pr = dialog({ title: '发现更新', html, buttons: [{ text: '更新选中的', value: 'go', cls: 'pri' }, { text: '这次先不更新（不再提示这一批）', value: 'ignore' }, { text: '取消', value: null, cls: 'ghost' }] });
  document.querySelectorAll('.dlg input[data-k]').forEach(c => c.onchange = () => {
    const k = c.dataset.k; if (k === '__studio') pick.studio = c.checked; else c.checked ? pick.effects.add(k) : pick.effects.delete(k);
  });
  const v = await pr;
  if (v === 'ignore') { try { localStorage.setItem('fxnav:updIgnore', updSig(i)); } catch (e) {} updBar.hidden = true; return; }
  if (v !== 'go' || (!pick.studio && !pick.effects.size)) return;
  updBar.hidden = true; toast('正在下载并安装更新…', false, 120000);
  let r; try { r = await (await fetch('/api/update/apply', { method: 'POST', headers: { 'X-FX': '1' }, body: JSON.stringify({ studio: pick.studio, effects: [...pick.effects] }) })).json(); } catch (e) { r = { error: e.message }; }
  if (r.error) { toast('更新失败：' + r.error, true, 10000); showUpdBar(i); return; }
  const d = r.done, lines = [];
  if (d.studio) lines.push('工作台已更新');
  if (d.installed.length) lines.push('已添加：' + d.installed.join('、'));
  if (d.updated.length) lines.push('已更新：' + d.updated.join('、'));
  if (d.errors && d.errors.length) lines.push('⚠ ' + d.errors.join('；'));
  if (r.restart) { await waitRestart(); return; }
  if (r.manualRestart) { await dialog({ title: '工作台已更新', html: '<p>请<b>关闭黑窗口</b>，再重新双击 <b>start.bat</b>，新版本就生效了。</p>', buttons: [{ text: '知道了', value: 1, cls: 'pri' }] }); return; }
  toast(lines.join('\n') || '更新完成');
  const first = i.effects.find(e => pick.effects.has(e.id));
  await reloadEffects(first && first.id);
  updBtn.classList.remove('dot');
}
updBtn.onclick = () => checkUpdate(true);
updBar.querySelector('button').onclick = () => openUpdate();
setTimeout(() => fetch('/api/update/check').then(r => r.json()).then(i => { if (i.ok) showUpdBar(i); }).catch(() => {}), 1500);

// 启动时检查环境：缺 FFmpeg / 浏览器时在右侧提示
fetch('/api/info').then(r => r.json()).then(i => {
  const w = [];
  if (!i.ffmpeg) w.push('没找到 FFmpeg');
  if (!i.browser) w.push('没找到导出用的浏览器');
  if (w.length) $('#msg').textContent = '⚠ ' + w.join('、') + '，导出 MOV 会失败。关闭黑窗口，重新双击 start.bat 会自动安装。';
}).catch(() => {});
load();
