// 效果工坊 · 持续时间 · 预览缩放 / 播放 / 进度（fit / reinit / seek）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 持续时间（v8.1） =================
// 用户最常想做的事：让这个效果正好占满剪辑里的 N 秒。以前要在一堆「入场 / 停留 / 退场」里自己算，
// 现在右侧最上面一个「持续时间」直接填总秒数，工作台按效果的情况自己决定改哪里：
//   native  效果本身有「总时长」参数（dur / total）     → 直接改它
//   minsec  效果用「分钟 + 秒」两个参数（章节进度条）    → 拆成分和秒
//   hold    有「停留」类参数                            → 多出来 / 少掉的时间加减在停留上，动作速度不变
//   ui      卡片类效果（卡片内容里的「停留时长」）        → 同上，加减在卡片停留上
//   stretch 都没有                                      → 整段按比例放慢 / 加快（params.__dur，见 view-controls.js 顶部）
// 停留减到 0 还不够短时，剩下的部分自动按比例加快。效果也可以在 effect.json 里写 "duration" 指定：
//   "duration": "dur"（直接改这个参数） / {"hold": "hold2"}（加减在这个参数上） / "stretch"（按比例）
const TIME_RE = /（秒|（ms）|\(ms\)|时长|停留|间隔|周期|圈数|等待/;
const r2 = x => Math.round(x * 100) / 100;
const pOf = k => cur && cur.params.find(p => p.key === k);
const isNum = p => p && p.type === 'number' && !p.hidden;
function durPlan() {
  const o = cur.duration, ps = cur.params;
  if (o === 'stretch' || cur.__durFell) return { mode: 'stretch', own: [] };
  if (typeof o === 'string' && pOf(o)) return { mode: 'native', key: o, own: [o] };
  if (o && typeof o === 'object' && o.hold && pOf(o.hold)) return { mode: 'hold', key: o.hold, own: [] };
  if (pOf('durMin') && pOf('durSec')) return { mode: 'minsec', own: ['durMin', 'durSec'] };
  const nat = ps.find(p => isNum(p) && ['dur', 'total', 'duration'].includes(p.key) && /时长|时间/.test(p.label || ''));
  if (nat) return { mode: 'native', key: nat.key, own: [nat.key] };
  const holds = ps.filter(p => isNum(p) && /停留|持续时长/.test(p.label || ''));
  if (holds.length) return { mode: 'hold', key: holds[holds.length - 1].key, own: [] };
  if (ps.some(p => p.key === 'cards')) return { mode: 'ui', own: [] };
  return { mode: 'stretch', own: [] };
}
// 「分段时间」：所有能影响时长的数字参数（入场 / 停留 / 间隔 / 周期……），从「数值调节」里搬到这一块
const durSegKeys = DP => cur.params.filter(p => isNum(p) && !DP.own.includes(p.key) && TIME_RE.test(p.label || '') && !/px|%|度）/.test(p.label || '')).map(p => p.key);
const fw = () => frame.contentWindow;
const nativeDur = () => { const w = fw(); try { return +(w.__fxNativeDur ? w.__fxNativeDur() : w.getDuration()) || 0; } catch (e) { return 0; } };
const cardsObj = () => { const v = params.cards; if (!v) return null; try { return typeof v === 'string' ? JSON.parse(v) : JSON.parse(JSON.stringify(v)); } catch (e) { return null; } };
const cardsPut = o => { params.cards = typeof params.cards === 'string' ? JSON.stringify(o) : o; if (inputs.cards) inputs.cards.value = typeof params.cards === 'string' ? params.cards : JSON.stringify(o); };
const uiHold = () => { const o = cardsObj(); const h = o && o.ui ? +o.ui.hold : NaN; return Number.isFinite(h) ? h : 2; };
function durBuild(DP, nSeg) {
  const d = document.createElement('div'); d.className = 'fxdur';
  const k = 'fxdur:' + cur.id; let off = false; try { off = localStorage.getItem(k) === '0'; } catch (e) { }
  if (off) d.classList.add('off');
  d.innerHTML = '<div class="fxdur-h">⏱ 持续时间<small>整个效果有多长</small></div>'
    + '<div class="fxdur-row"><input type="number" min="0.5" step="0.1"><em>秒</em><button type="button" hidden title="回到这个效果原来的时长">↺ 原长</button></div>'
    + '<input type="range" class="fxdur-rng" min="0.5" step="0.1">'
    + '<div class="fxdur-note"></div>'
    + '<button type="button" class="fxdur-tg"><i>▾</i>分段时间（' + nSeg + ' 项）<small style="margin-left:auto;color:#777">入场 / 停留 / 退场各多长</small></button>'
    + '<div class="fxdur-list"></div>';
  const inp = d.querySelector('input[type=number]'), rng = d.querySelector('.fxdur-rng');
  d.querySelector('.fxdur-tg').onclick = () => { d.classList.toggle('off'); try { localStorage.setItem(k, d.classList.contains('off') ? '0' : '1'); } catch (e) { } };
  d.querySelector('.fxdur-row button').onclick = () => { durReset(); };
  const go = v => { const n = parseFloat(v); if (Number.isFinite(n) && n > 0) setDuration(n); };
  inp.addEventListener('change', () => go(inp.value));
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') { go(inp.value); inp.select(); } });
  let rt = 0;
  rng.addEventListener('input', () => { inp.value = rng.value; clearTimeout(rt); rt = setTimeout(() => go(rng.value), 120); });
  return d;
}
// 把整个效果的时长设成 T 秒
function setDuration(T) {
  if (!cur) return;
  const w = fw(); if (!w || !w.init) return;
  const DP = durPlan(), t0 = +slider.value || 0;
  T = Math.max(0.5, Math.min(7200, r2(T)));
  delete params.__dur;
  if (DP.mode === 'native') {
    const p = pOf(DP.key);
    params[DP.key] = Math.max(p.min != null ? +p.min : 0.5, p.max != null ? Math.min(+p.max, T) : T);
    if (params[DP.key] !== T) toast('「' + p.label + '」的范围是 ' + (p.min != null ? p.min : 0.5) + ' ~ ' + (p.max != null ? p.max : '∞') + ' 秒');
  } else if (DP.mode === 'minsec') {
    const s = Math.max(1, Math.round(T));
    params.durMin = Math.floor(s / 60); params.durSec = s % 60;
  } else if (DP.mode === 'hold' || DP.mode === 'ui') {
    try { w.init(params); } catch (e) { }
    const D0 = nativeDur();
    const h0 = DP.mode === 'hold' ? (Number.isFinite(+params[DP.key]) ? +params[DP.key] : +pOf(DP.key).default || 0) : uiHold();
    const put = h => {
      if (DP.mode === 'hold') { params[DP.key] = h; if (inputs[DP.key]) { inputs[DP.key].value = h; if (inputs[DP.key].__fxRange) inputs[DP.key].__fxRange.value = h; } }
      else { const o = cardsObj() || {}; o.ui = Object.assign({}, o.ui || {}, { hold: h }); cardsPut(o); }
    };
    let h = r2(h0 + (T - D0));
    const hp = DP.mode === 'hold' ? pOf(DP.key) : null;
    const hMax = hp && hp.max != null ? +hp.max : 1e9;
    if (h < 0) { put(0); params.__dur = T; }                  // 停留减到 0 还不够短：剩下的按比例加快
    else if (h > hMax) { put(hMax); params.__dur = T; }       // 停留到上限还不够长：剩下的按比例放慢
    else put(h);
    // 检查一下真的变成了 T 秒；没变（比如这个卡片效果不看「停留」）就退回按比例伸缩
    try { w.init(params); } catch (e) { }
    const D1 = params.__dur ? T : nativeDur();
    if (Math.abs(D1 - T) > 0.06) {
      put(h0);
      if (DP.mode === 'ui') cur.__durFell = true;
      params.__dur = T;
    }
  } else params.__dur = T;
  const s = Math.max(0, Math.min(t0, T));
  // 卡片内容是效果自己的编辑器在管（它挂载时读一次），改了停留要重建面板，让编辑器重新读到新的停留时长
  if (DP.mode === 'ui') buildParams();
  reinit(false); seek(Math.min(s, dur)); durSync();
}
// 回到原长
function durReset() {
  if (!cur) return;
  const DP = durPlan();
  delete params.__dur;
  if (DP.mode === 'native') params[DP.key] = defOf(pOf(DP.key));
  else if (DP.mode === 'minsec') { params.durMin = defOf(pOf('durMin')); params.durSec = defOf(pOf('durSec')); }
  else if (DP.mode === 'hold') { params[DP.key] = defOf(pOf(DP.key)); if (inputs[DP.key]) inputs[DP.key].value = params[DP.key]; }
  else if (DP.mode === 'ui') {
    const p = pOf('cards'), o = cardsObj();
    let dh; try { const d0 = typeof p.default === 'string' ? JSON.parse(p.default) : p.default; dh = d0 && d0.ui ? d0.ui.hold : undefined; } catch (e) { }
    if (o) { o.ui = Object.assign({}, o.ui || {}); if (dh === undefined) delete o.ui.hold; else o.ui.hold = dh; cardsPut(o); }
  }
  buildParams(); reinit(false); toast('已回到原来的时长：' + dur.toFixed(1) + ' 秒');
}
// 刷新「持续时间」那一块：数字、滑杆范围、说明文字、「原长」按钮
function durSync() {
  const d = document.querySelector('#params .fxdur'); if (!d || !cur) return;
  const DP = durPlan(), inp = d.querySelector('input[type=number]'), rng = d.querySelector('.fxdur-rng');
  const T = r2(dur || 0), D = r2(nativeDur());
  if (document.activeElement !== inp) inp.value = T;
  rng.max = Math.max(30, Math.ceil(Math.max(T, D) * 3 / 10) * 10, DP.mode === 'minsec' ? 7200 : 0);
  if (document.activeElement !== rng) rng.value = T;
  let changed = !!params.__dur;
  const lab = k => { const p = pOf(k); return p ? p.label.replace(/（.*$/, '') : k; };
  let note;
  if (DP.mode === 'native') { changed = changed || !sameDef(pOf(DP.key)); note = '就是这个效果的「' + lab(DP.key) + '」。'; }
  else if (DP.mode === 'minsec') { changed = changed || !sameDef(pOf('durMin')) || !sameDef(pOf('durSec')); note = '= <b>' + Math.floor(T / 60) + ' 分 ' + Math.round(T % 60) + ' 秒</b>（最长 120 分钟）。'; }
  else if (DP.mode === 'hold') { changed = changed || !sameDef(pOf(DP.key)); note = '加长 / 缩短的时间放在<b>「' + lab(DP.key) + '」</b>上，动作速度不变。'; }
  else if (DP.mode === 'ui') { changed = changed || Math.abs(uiHold() - (() => { const p = pOf('cards'); try { const o = typeof p.default === 'string' ? JSON.parse(p.default) : p.default; return o && o.ui && Number.isFinite(+o.ui.hold) ? +o.ui.hold : 2; } catch (e) { return 2; } })()) > 1e-6; note = '加长 / 缩短的时间放在卡片的<b>「停留时长」</b>上，动作速度不变。'; }
  else note = '这个效果没有单独的停留时间，改了以后<b>整段动画按比例放慢 / 加快</b>（原长 ' + D + ' 秒）。';
  if (params.__dur && DP.mode !== 'stretch') note += '停留已经到头，<b>剩下的部分按比例' + (T < D ? '加快' : '放慢') + '</b>（原长 ' + D + ' 秒）。';
  d.querySelector('.fxdur-note').innerHTML = note;
  d.querySelector('.fxdur-row button').hidden = !changed;
}


function applyLive() {
  const w = frame.contentWindow; if (!w || !w.init) return;
  w.init(params); dur = w.getDuration(); slider.max = dur || 0.01; seek(Math.min(+slider.value, dur));
  markDirty();
}
box.addEventListener('wheel', e => {
  const sp = cur && cur.params.find(p => p.key === 'scale'); if (!sp) return;
  e.preventDefault();
  let v = Math.round((+params.scale || 1) * (e.deltaY < 0 ? 1.06 : 1 / 1.06) * 100) / 100;
  v = Math.min(sp.max != null ? sp.max : 5, Math.max(sp.min != null ? sp.min : 0.2, v));
  params.scale = v; if (inputs.scale) inputs.scale.value = v;
  $('#hint').textContent = '卡片大小 ' + Math.round(v * 100) + '%（双击预览区还原）'; applyLive();
}, { passive: false });
box.addEventListener('dblclick', () => {
  const sp = cur && cur.params.find(p => p.key === 'scale'); if (!sp) return;
  params.scale = sp.default != null ? sp.default : 1; if (inputs.scale) inputs.scale.value = params.scale;
  $('#hint').textContent = '卡片大小已还原 100%'; applyLive();
});
function fit() { fitStage(); Hooks.run('fit'); }
function fitStage() {
  const { w, h } = res();
  const s = Math.min($('#stagewrap').clientWidth / w, (window.__stageH || Math.max(200, innerHeight - 130 - (typeof tlFitH === 'function' ? tlFitH() : 0))) / h);
  box.style.width = w * s + 'px'; box.style.height = h * s + 'px';
  frame.style.width = w + 'px'; frame.style.height = h + 'px'; frame.style.transform = 'scale(' + s + ')';
}
frame.onload = () => { fit(); reinit(true); setTimeout(() => { if (!hUndo.length) hLast = hSnap(); }, 600); };   // 效果初始化时自己补的默认值不算一步
function reinit(play) { const ctx = { play }; Hooks.run('reinit:before', ctx); reinitEffect(ctx.play); Hooks.run('reinit', ctx); }
function reinitEffect(play) {
  const w = frame.contentWindow; if (!w || !w.init) return;
  try { w.init(params); dur = w.getDuration(); } catch (e) { console.error(e); return; }
  slider.max = dur || 0.01;
  play ? start() : seek(Math.min(+slider.value, dur));
  markDirty(); kfSel = new Set(); kfTrackDraw(); durSync();
}
let kfHeadT = 0;
function seek(t) { seekEffect(t); Hooks.run('seek', t); }
function seekEffect(t) {
  frame.contentWindow.renderAt(Math.min(t, dur)); slider.value = t; $('#tl').textContent = t.toFixed(1) + ' / ' + dur.toFixed(1) + ' s';
  const n = Date.now(); if (n - kfHeadT > 60) { kfHeadT = n; const h = kfTrack && kfTrack.querySelector('.kfhead'); if (h) h.style.left = kfHeadPct(t) + '%';  const kb = $('#kfadd'); if (kb && !kb.hidden) kb.textContent = '◆ 在 ' + t.toFixed(2) + ' 秒打关键帧'; }
}
// 播放状态：原来只有「从头播」，现在支持暂停 / 从当前位置续播
let playing = false;
function ppSync() {
  const b = $('#pp'); if (!b) return;
  const on = playing || (typeof tlPlaying !== 'undefined' && tlPlaying);   // 时间线在播也算
  b.classList.toggle('on', on);
  b.querySelector('i').textContent = on ? '❚❚' : '▶';
  b.querySelector('span').textContent = on ? '暂停' : '播放';
}
function stop() { stopEffect(); Hooks.run('stop'); }
function stopEffect() { cancelAnimationFrame(raf); if (playing) { playing = false; ppSync(); } }
function start(from) {
  stop();
  const begin = Math.max(0, Math.min(from == null ? 0 : +from || 0, dur));
  const t0 = performance.now() - begin * 1000;
  playing = true; ppSync();
  const tick = n => {
    const t = (n - t0) / 1000;
    seek(Math.min(t, dur));
    if (t < dur) raf = requestAnimationFrame(tick);
    else { playing = false; ppSync(); }      // 播到头自动停，按钮变回「播放」
  };
  raf = requestAnimationFrame(tick);
}
// 时间线上有素材时（v24.11）：播放 / 暂停 / 重播 / 进度条都管整条时间线，不再只播「当前这一个效果」
// （以前没选中素材时点播放，播的是藏在后面的那个效果：进度条在走、时间线播放头不动、画面也看不到）
const tlMode = () => TL.clips.some(c => !c.ref);
$('#play').onclick = () => { if (tlMode()) { tlStop(); stop(); tlSeek(0); tlPlay(); return; } reinit(true); };   // 重播 = 从第 0 秒重新来一遍
$('#pp').onclick = () => {
  if (tlMode()) { tlPlay(); return; }                       // tlPlay 自己会在「播放中」时停下
  if (playing) { stop(); return; }
  const t = +slider.value || 0;
  start(t >= dur - 0.02 ? 0 : t);                             // 已经播到头就从头播，否则从当前位置续播
};
ppSync();
slider.oninput = () => {
  if (tlMode() && !tlSel) { tlStop(); stop(); tlSeek(+slider.value); return; }   // 没选中素材：进度条就是整条时间线
  stop(); seek(+slider.value);
};
$('#res').onchange = () => { fit(); reinit(true); };
addEventListener('resize', fit);

// ================= 导出编码 + 文件大小预估（v27.0） =================
// mbps = 1920×1080 / 30 帧时每秒多少 MB（按画面铺满的组合卡片实测；小标题这类画面更空的会更小）。和 server.js 的 CODECS 对应
const CODECS = {
  pq: { ext: '.mov', mbps: 14, name: 'ProRes 4444 标准' }, prores: { ext: '.mov', mbps: 32, name: 'ProRes 4444 最高画质' },
  png: { ext: '.mov', mbps: 17, name: 'PNG 编码 MOV（无损）' }, qtrle: { ext: '.mov', mbps: 20, name: '动画编码 MOV（无损）' },
  mp4: { ext: '.mp4', mbps: 0.3, name: 'MP4 不透明' },
};
const codecId = () => CODECS[$('#codec').value] ? $('#codec').value : 'pq';
const codecExt = () => CODECS[codecId()].ext;
function estMB(secs) { const { w, h } = res(), fps = +$('#fps').value || 30; return CODECS[codecId()].mbps * (w * h / 2073600) * (fps / 30) * Math.max(0, secs); }
const fmtMB = mb => mb >= 1024 ? (mb / 1024).toFixed(1) + ' GB' : mb >= 10 ? Math.round(mb) + ' MB' : Math.max(0.1, mb).toFixed(1) + ' MB';
function sizeEst() {
  const el = $('#sizeest'); if (!el) return;
  const tl = typeof TL !== 'undefined' && TL.clips.length, secs = (tl ? tlEnd() : dur) + (+$('#hold').value || 0);
  const pr = CODECS.prores.mbps / CODECS[codecId()].mbps;
  el.innerHTML = '预计' + (tl ? '整条时间线' : '') + ' ' + secs.toFixed(1) + ' 秒约 <b>' + fmtMB(estMB(secs)) + '</b>' + (codecId() !== 'prores' ? '（最高画质要 ' + fmtMB(estMB(secs) * pr) + '）' : '') + '<br>按画面铺满估算，画面越空文件越小';
}
try { const v = store.get('codec', 'pq'); if (CODECS[v]) $('#codec').value = v; } catch (e) {}
$('#codec').addEventListener('change', () => { store.set('codec', codecId()); sizeEst(); });
['#res', '#fps', '#hold'].forEach(q => $(q).addEventListener('change', sizeEst));
setInterval(sizeEst, 1500);
$('#export').onclick = async () => {
  // 很长的效果（比如 2 小时的章节进度条）：先提醒大概要多久、多大
  { const { w, h } = res(), fps = +$('#fps').value, secs = dur + (+$('#hold').value || 0), frames = Math.round(secs * fps);
    if (frames > 9000) {
      const mpx = w * h / 1e6;                                    // 实测：每帧约 (40 + 55×百万像素) 毫秒、(90 + 12×百万像素) KB
      const mins = Math.max(1, Math.round(frames * (0.04 + 0.055 * mpx) / 60));
      const gb = (estMB(secs) / 1024).toFixed(1);
      const tip = (fps > 10 ? '\n· 进度条这类变化很慢的效果，帧率选 5 或 10，看起来一样，快好几倍' : '') + (h >= 720 ? '\n· 分辨率选「1920×160 横条」，只导出进度条那一条，文件小很多，放进剪辑软件再摆到顶部/底部' : '');
      if (!confirm(`这个效果有 ${Math.floor(secs / 60)} 分 ${Math.round(secs % 60)} 秒，要导出 ${frames} 帧。\n预计需要约 ${mins} 分钟，文件约 ${gb} GB（粗略估算）。${tip}\n\n继续导出吗？`)) return;
    } }
  const name = prompt('请输入文件名（不用写 ' + codecExt() + '）：\n编码：' + CODECS[codecId()].name + '，预计约 ' + fmtMB(estMB(dur + (+$('#hold').value || 0))), cur.id);
  if (name === null) return;
  const b = $('#export'), msg = $('#msg'), prog = $('#prog');
  const { w, h } = res(); b.disabled = true; prog.style.display = 'block'; prog.firstChild.style.width = '0'; msg.textContent = '正在导出…';
  try {
    const r = await (await fetch('/api/export', { method: 'POST', body: JSON.stringify({ effect: cur.id, name, params, width: w, height: h, fps: +$('#fps').value, hold: +$('#hold').value || 0, codec: codecId() }) })).json();
    if (r.error) throw new Error(r.error);
    while (true) {
      await new Promise(r => setTimeout(r, 500));
      const j = await (await fetch('/api/job?id=' + r.id)).json();
      prog.firstChild.style.width = (j.progress * 100 || 0) + '%'; msg.textContent = j.stage || ('正在导出… ' + Math.round((j.progress || 0) * 100) + '%');
      if (j.status === 'done') { msg.textContent = '完成：output/' + j.file; break; }
      if (j.status === 'error') throw new Error(j.message);
    }
  } catch (e) { msg.textContent = '出错：' + e.message; }
  b.disabled = false;
};
$('#open').onclick = () => fetch('/api/open-output', { method: 'POST' });
