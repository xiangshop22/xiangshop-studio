// 效果工坊 · 保存为预设 · 联系我 · 浅色 / 深色界面
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 保存为预设（v9.0，v25.0 改成整体打包） =================
// 把调好的样子整体存成左侧一张新卡片：参数、关键帧、持续时间、上传的图片都存（图片复制进预设自己的 media 文件夹）。
// 选中的是组合（或组合里的素材）→ 整个组合连同组合关键帧一起存；多选 → 这几个一起存；否则存当前这一个。
async function reloadList(selId) {
  effects = await (await fetch('/api/effects')).json(); window.__fxList = effects;
  navBuilt = false; Object.keys(navCards).forEach(k => delete navCards[k]);
  renderList(); select(effects.some(e => e.id === selId) ? selId : effects[0].id);
}
async function refreshNav() {                        // 只刷新左侧列表，不打断正在做的时间线
  effects = await (await fetch('/api/effects')).json(); window.__fxList = effects;
  if (cur) cur = effects.find(e => e.id === cur.id) || cur;
  navBuilt = false; Object.keys(navCards).forEach(k => delete navCards[k]); renderList();
}
function presetScope() {
  try { syncSel(); } catch (e) {}                    // 正在改的参数先存回素材
  const sc = clip(tlSel), g = grp(tlGrp) || grp(tlIn) || (sc && sc.group && grp(sc.group));
  const cs = g ? TL.clips.filter(c => c.group === g.id) : tlMulti.size > 1 ? [...tlMulti].map(clip).filter(Boolean) : sc ? [sc] : [];
  return { g, cs, sc };
}
$('#presetbtn').onclick = async () => {
  if (!cur) return;
  const { g, cs, sc } = presetScope();
  const multi = cs.length > 1 || !!g;
  const fx0 = sc ? fxOf(sc) : cur, nm0 = (g ? g.name : (fx0 || cur).name).replace(/ · 我的预设.*$/, '') + ' · 我的预设';
  const name = prompt('给这个预设起个名字（左侧会多一张这个名字的卡片）：\n' + (multi ? '整个组合（' + cs.length + ' 个素材）连同组合关键帧' : '这个素材的') + '参数、关键帧、持续时间、上传的图片都会保存。下次从左侧拖进时间线，换素材就能用。', nm0);
  if (name === null) return;
  let body;
  if (multi) {
    const s0 = Math.min(...cs.map(c => c.start)), l0 = Math.min(...cs.map(c => c.layer)), srt = cs.slice().sort((a, b) => a.layer - b.layer || a.start - b.start);
    const grpOut = g ? (() => { const o = clone(g); delete o.id; o.col = true; return o; })() : null;
    const clips = srt.map(c => ({ fx: c.fx, params: clone(c.params), start: r2(c.start - s0), len: c.len, layer: c.layer - l0 }));
    body = { name, base: clips[0].fx, params: clips[0].params, combo: { clips, group: grpOut, len: r2(Math.max(...cs.map(c => c.start + c.len)) - s0) } };
  } else body = { name, base: sc ? sc.fx : cur.id, params: sc ? clone(sc.params) : params };
  try {
    const r = await (await fetch('/api/preset', { method: 'POST', headers: { 'X-FX': '1' }, body: JSON.stringify(body) })).json();
    if (!r.ok) throw new Error(r.error || '保存失败');
    await refreshNav();
    toast('已保存为预设「' + name + '」' + (multi ? '（' + cs.length + ' 个素材）' : '') + (r.media ? '，' + r.media + ' 张图片 / 视频一起存好了' : '') + '：在左侧列表里，下次拖进时间线就能用');
  } catch (e) { toast('保存预设失败：' + e.message, true); }
};
async function delPreset() { if (cur) delCard(cur.id); }      // 右侧顶部「删除这个预设」也走同一套
// ================= 删除卡片（v26.0） =================
// 左侧卡片右下角 🗑：彻底删掉这张卡片的文件夹（effects\<文件夹名>，预设里复制进去的图片 / 视频都在里面），不能恢复。
// 只删这一张：uploads 里的原始素材、别的卡片都不动；别的预设卡片基于它、或时间线上正在用它时，不让删。
async function delCard(id) {
  const e = effects.find(x => x.id === id); if (!e) return;
  const inTl = (typeof TL !== 'undefined' ? TL.clips : []).filter(c => c.fx === id).length;
  let info = {}; try { info = await (await fetch('/api/card-info?id=' + encodeURIComponent(id))).json(); } catch (er) {}
  if (info.error) return toast(info.error, true);
  const block = info.usedBy && info.usedBy.length ? '有 ' + info.usedBy.length + ' 张别的卡片是基于它做的（' + info.usedBy.slice(0, 3).map(esc).join('、') + (info.usedBy.length > 3 ? ' 等' : '') + '），删掉会让它们坏掉。请先删掉那几张。'
    : inTl ? '时间线上有 ' + inTl + ' 个素材正在用这张卡片。请先把它们从时间线删掉，再删卡片。' : '';
  if (block) return dialog({ title: '不能删除「' + e.name + '」', html: esc(block), buttons: [{ text: '知道了', value: null, cls: 'pri' }], mcls: 'blur' });
  const mb = ((info.bytes || 0) / 1048576).toFixed(info.bytes > 1048576 ? 1 : 2);
  const v = await dialog({
    title: '真的要删除「' + e.name + '」吗？', mcls: 'blur',
    html: '会删掉这张卡片和它文件夹里的全部内容：<b>effects\\' + esc(id) + '</b>（' + (info.files || 0) + ' 个文件，' + mb + ' MB）' + (info.media ? '，其中包括保存预设时复制进去的 <b>' + info.media + ' 个素材</b>' : '') + '。'
      + '<div class="warn">删除后不能恢复。只删这一张卡片；其他卡片、上传文件夹里的原始素材都不受影响。' + (e.preset ? '' : '<br>这是工作台自带的效果，删掉以后可以通过左上角 ⟳「检查更新」重新下载。') + '</div>',
    buttons: [{ text: '取消', value: null, cls: 'ghost' }, { text: '确认删除', value: 1, cls: 'pri' }]
  });
  if (!v) return;
  const r = await (await fetch('/api/card-delete', { method: 'POST', headers: { 'X-FX': '1' }, body: JSON.stringify({ id }) })).json().catch(() => ({ error: '服务没开？' }));
  if (!r.ok) return toast('删除失败：' + (r.error || ''), true);
  if (favs.has(id)) { favs.delete(id); store.set('favs', [...favs]); }
  if (cur && cur.id === id) await reloadList(e.preset || (effects.find(x => x.id !== id) || {}).id); else await refreshNav();
  toast('已删除「' + e.name + '」和它的 ' + (r.files || 0) + ' 个文件');
}
// ================= 联系我（v7.8） =================
// 用户找不到想要的效果、或有意见建议时，从这里跳到作者的 X / YouTube 主页。改联系方式只改 CONTACTS
const CONTACTS = [
  { cls: 'x', name: 'X（推特）', sub: '@QiaoqiaoD85820 · 私信 / 留言', url: 'https://x.com/QiaoqiaoD85820',
    svg: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.9 2H22l-6.8 7.8L23 22h-6.2l-4.9-6.4L6.3 22H3.2l7.3-8.3L1 2h6.3l4.4 5.9L18.9 2Zm-1.1 18h1.7L6.3 3.9H4.5L17.8 20Z"/></svg>' },
  { cls: 'yt', name: 'YouTube 频道', sub: '@jdkt007 · 在视频下面留言', url: 'https://www.youtube.com/@jdkt007',
    svg: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l11-6.5z"/></svg>' }
];
function openContact() {
  const html = '<p>没有找到你想要的效果，或者有意见和建议？通过下面任意一个方式联系我。</p><div class="ctl">' +
    CONTACTS.map(c => '<a class="cti ' + c.cls + '" href="' + esc(c.url) + '" target="_blank" rel="noopener"><span class="ic">' + c.svg + '</span><span><b>' + esc(c.name) + '</b><small>' + esc(c.sub) + '</small></span><i>↗</i></a>').join('') + '</div>';
  dialog({ title: '联系我', html, buttons: [{ text: '关闭', value: null, cls: 'ghost' }] });
}
$('#contactbtn').onclick = () => openContact();
$('#packall').onclick = () => { toast('正在打包整个工作台，浏览器会自动下载…'); location.href = '/api/studio-zip'; };
// ================= 浅色 / 深色界面（v6.4） =================
// 做法：页面原本是深色。切到浅色时，把页面上所有样式表（包括效果编辑器自己加的样式）里的颜色自动「翻过来」：
//   灰色系：深 ↔ 浅对调（深底 → 浅底，浅字 → 深字）；带颜色的很深的底（如选中项的深橙底）→ 同色系的浅底；
//   主题橙色等鲜艳颜色、半透明的遮罩 / 阴影保持不变。生成一张覆盖用的样式表，切回深色就移除。
// 预览区里的效果画面不受影响（效果本身在 iframe 里）。
const Theme = (() => {
  const KEY = 'fxnav:theme';
  let mode = 'dark', sheet = null, mo = null, t = 0;
  const PROPS = ['color', 'background-color', 'background-image', 'border-top-color', 'border-right-color', 'border-bottom-color', 'border-left-color', 'outline-color', 'accent-color', 'caret-color', 'fill', 'stroke'];
  function parse(m) {
    if (m[0] === '#') {
      let h = m.slice(1); if (h.length === 3 || h.length === 4) h = [...h].map(c => c + c).join('');
      if (h.length !== 6 && h.length !== 8) return null;
      return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16), h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1];
    }
    const n = m.match(/[\d.]+%?/g); if (!n || n.length < 3) return null;
    const v = n.map(x => x.endsWith('%') ? parseFloat(x) * 2.55 : parseFloat(x));
    return [v[0], v[1], v[2], n.length > 3 ? (n[3].endsWith('%') ? parseFloat(n[3]) / 100 : parseFloat(n[3])) : 1];
  }
  function flip(m) {
    const c = parse(m); if (!c || c[3] < 0.98) return m;                 // 半透明（遮罩、阴影、覆盖在图上的标签）不动
    const [r, g, b] = c.map((x, i) => i < 3 ? x / 255 : x);
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
    let h = 0;
    if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h = Math.round(h * 60 + 360) % 360;
    let L;
    if (s < 0.2) L = Math.min(0.975, Math.max(0.1, 1 - l));               // 灰色：深浅对调
    else if (l < 0.3) L = Math.min(0.96, 1 - l * 0.55);                    // 很深的彩色底 → 同色系浅底
    else return m;                                                        // 主题色等鲜艳颜色：不变
    return `hsl(${h} ${Math.round(s * 100)}% ${Math.round(L * 100)}%)`;
  }
  const remap = v => v.replace(/#[0-9a-f]{3,8}\b|rgba?\([^)]*\)/gi, flip);
  function selectors(sel) {
    return sel.split(',').map(s => s.trim()).filter(Boolean).map(s =>
      /^(html|:root)(?![\w-])/.test(s) ? s.replace(/^(html|:root)/, 'html.light') : 'html.light ' + s).join(',');
  }
  function walk(rules, out) {
    for (const r of rules) {
      if (r.cssRules && r.media) { const sub = []; walk(r.cssRules, sub); if (sub.length) out.push(`@media ${r.media.mediaText}{${sub.join('')}}`); continue; }
      if (!r.selectorText || !r.style || /^html\.light/.test(r.selectorText)) continue;   // 已经专门写好的浅色样式，不再翻转
      const decl = [];
      const media = /#box\b|\.th\b/.test(r.selectorText);              // 预览区 / 缩略图的棋盘格底保持深色：白字效果才看得清
      for (const p of PROPS) {
        if (media && p.startsWith('background')) continue;
        const v = r.style.getPropertyValue(p); if (!v) continue;
        const nv = remap(v); if (nv !== v) decl.push(`${p}:${nv} !important`);
      }
      if (decl.length) out.push(`${selectors(r.selectorText)}{${decl.join(';')}}`);
    }
  }
  function build() {
    const out = ['html.light{color-scheme:light}'];
    for (const ss of document.styleSheets) {
      if (ss.ownerNode && ss.ownerNode.id === 'fx-light') continue;
      let rules; try { rules = ss.cssRules; } catch (e) { continue; }
      walk(rules, out);
    }
    if (!sheet) { sheet = document.createElement('style'); sheet.id = 'fx-light'; }
    sheet.textContent = out.join('\n');
    document.head.appendChild(sheet);                                    // 放在最后，保证覆盖得到
  }
  function set(m) {
    mode = m === 'light' ? 'light' : 'dark';
    try { localStorage.setItem(KEY, mode); } catch (e) {}
    document.documentElement.classList.toggle('light', mode === 'light');
    const b = document.getElementById('themebtn'); if (b) { b.textContent = mode === 'light' ? '☾' : '☀'; b.title = mode === 'light' ? '切换到深色界面' : '切换到浅色界面'; }
    if (mode === 'light') {
      build();
      // 效果编辑器切换效果时会往页面里加新样式 → 自动重新生成
      if (!mo) { mo = new MutationObserver(ms => { if (ms.some(x => [...x.addedNodes].some(n => n.nodeName === 'STYLE' && n.id !== 'fx-light'))) { clearTimeout(t); t = setTimeout(build, 30); } }); mo.observe(document.head, { childList: true }); }
    } else { if (mo) { mo.disconnect(); mo = null; } if (sheet) sheet.remove(); }
  }
  let saved = 'dark'; try { saved = localStorage.getItem(KEY) || 'dark'; } catch (e) {}
  return { set, toggle: () => set(mode === 'light' ? 'dark' : 'light'), init: () => set(saved) };
})();
$('#themebtn').onclick = () => Theme.toggle();
Theme.init();
