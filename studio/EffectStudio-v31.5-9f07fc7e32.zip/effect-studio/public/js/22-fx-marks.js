// 效果工坊 · 素材条上的时间小旗子（v30.0）
// ---------------------------------------------------------------------------
// 做什么：效果在 effect.json 顶层写了 "marks"，时间线上这个效果的素材条里就画一面白色小旗子，
//         标出「某件事从第几秒开始」（例：圆形闪光换色卡的「闪」= 闪烁开始）。按住小旗子左右拖 = 改这个秒数。
// effect.json 写法：
//   "marks": [{ "key": "flashAt",          // 对应哪个秒数参数（从素材开头算）
//               "label": "闪",             // 旗子上的字（一两个字）
//               "tip": "闪烁开始",          // 鼠标提示
//               "keep": "hold",           // 可选：拖的时候把差值从这个参数里扣回来，素材总长不变
//               "min": 0,                 // 可选：最早能拖到第几秒（from 时 = 参数本身最小多少）
//               "from": ["soloIn"],       // 可选：参数是「从这几个参数加起来那一秒往后多久」（例：出场 = 入场时长 + 停留），旗子画在加起来的位置
//               "hideWhen": { "key": "layout", "in": ["soloP"] } }]   // 可选：某个参数是这些值时不画（notIn = 不是这些值时不画；也可以写成数组，任一条成立就不画）
// 点一下小旗子（不拖）= 右侧跳到管这件事的那一块、闪两下：效果在那一块上写 data-fx-mark="参数key"；
//   效果的 window.__fxMarkFocus(key) 有的话先调它（比如把折叠块打开）。没选中的素材先选中再跳。
// 不改任何老文件的逻辑：只挂在 Hooks.on('tlDraw') 后面补画，鼠标用 window 捕获阶段、只在按中小旗子时拦下（规则 29）。
(function () {
  const st = document.createElement('style');
  st.textContent = `
#tlp-t .tlc .tlmk{position:absolute;top:0;bottom:0;width:2px;margin-left:-1px;background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.45);cursor:ew-resize;z-index:3}
#tlp-t .tlc .tlmk::before{content:"";position:absolute;left:-6px;right:-6px;top:0;bottom:0}
#tlp-t .tlc .tlmk span{position:absolute;left:2px;top:1px;font:700 9px/12px system-ui,sans-serif;color:#111;background:#fff;border-radius:0 3px 3px 0;padding:0 3px;white-space:nowrap;pointer-events:none}
#tlp-t .tlc .tlmk.drag,#tlp-t .tlc .tlmk:hover{background:#f28c0f}
#tlp-t .tlc .tlmk.drag span,#tlp-t .tlc .tlmk:hover span{background:#f28c0f}
#tlp-t.mkdrag,#tlp-t.mkdrag .tlc{cursor:ew-resize}`;
  document.head.appendChild(st);

  const marksOf = c => { const f = fxOf(c); return f && Array.isArray(f.marks) ? f.marks : []; };
  const defOf = (c, key) => { const f = fxOf(c), p = f && (f.params || []).find(x => x.key === key); return p ? p.default : undefined; };
  const pv = (c, key) => (c.params && c.params[key] != null ? c.params[key] : defOf(c, key));
  const baseOf = (c, m) => [].concat(m.from || []).reduce((a, k) => a + (Number(pv(c, k)) || 0), 0);
  const valOf = (c, m) => { const v = Number(pv(c, m.key)); return Number.isFinite(v) ? baseOf(c, m) + v : NaN; };   // 旗子在第几秒
  // hideWhen 每一条：{ key, in: [...] } = 是这些值时不画；{ key, notIn: [...] } = 不是这些值时不画
  const hidden = (c, m) => [].concat(m.hideWhen || []).some(h => h && ((Array.isArray(h.in) && h.in.includes(pv(c, h.key))) || (Array.isArray(h.notIn) && !h.notIn.includes(pv(c, h.key)))));
  const lenOf = c => (c._len != null ? c._len : c.len);

  function draw() {
    trk.querySelectorAll('.tlc[data-id]').forEach(el => {
      const c = clip(el.dataset.id); if (!c) return;
      marksOf(c).forEach((m, i) => {
        if (hidden(c, m)) return;
        const t = valOf(c, m), len = lenOf(c); if (!(t >= 0) || t > len) return;
        const b = document.createElement('b'); b.className = 'tlmk'; b.dataset.i = i;
        b.style.left = (t / len * 100) + '%';
        b.title = (m.tip || m.label || m.key) + '：第 ' + t.toFixed(2) + ' 秒　按住左右拖动改时间';
        b.innerHTML = '<span>' + esc(m.label || '') + '</span>';
        el.appendChild(b);
      });
    });
  }
  Hooks.on('tlDraw', draw);
  draw();

  // ---------- 拖动 ----------
  let D = null;
  addEventListener('mousedown', e => {
    const b = e.button === 0 && e.target.closest && e.target.closest('#tlp-t .tlmk'); if (!b) return;
    const el = b.closest('.tlc'), c = el && clip(el.dataset.id); if (!c || c.lock) return;
    e.preventDefault(); e.stopPropagation();
    if (c.id === tlSel) { try { syncSel(); } catch (er) {} }
    const m = marksOf(c)[+b.dataset.i]; if (!m) return;
    const t0 = valOf(c, m), k0 = m.keep ? Number(pv(c, m.keep)) || 0 : 0;
    D = { c, m, b, t0, k0, base: baseOf(c, m), x0: e.clientX, w: el.getBoundingClientRect().width / lenOf(c), v: t0, last: 0 };
    b.classList.add('drag'); trk.classList.add('mkdrag');
  }, true);
  addEventListener('mousemove', e => {
    if (!D) return;
    const { c, m, b, t0, k0, base } = D, len = lenOf(c);
    const hi = m.keep ? t0 + k0 : len - 0.05, lo = Math.max(0, base + (Number(m.min) || 0));
    let v = Math.round((t0 + (e.clientX - D.x0) / D.w) * 20) / 20;           // 0.05 秒一格
    v = Math.min(hi, Math.max(lo, v)); if (v === D.v) return; D.v = v;
    c.params = c.params || {}; c.params[m.key] = Math.round((v - base) * 100) / 100;
    if (m.keep) c.params[m.keep] = Math.round((k0 - (v - t0)) * 100) / 100;
    b.style.left = (v / len * 100) + '%';
    b.title = (m.tip || m.label || m.key) + '：第 ' + v.toFixed(2) + ' 秒';
    if (typeof toast === 'function') toast((m.tip || m.label) + '：第 ' + v.toFixed(2) + ' 秒');
    // 选中的素材：边拖边让预览停在这一秒（限流，最多 12 次 / 秒）
    const now = performance.now();
    if (c.id === tlSel && now - D.last > 80) { D.last = now; live(c, m, v); }
  }, true);
  addEventListener('mouseup', () => {
    if (!D) return;
    const { c, m, b, v, t0 } = D; D = null;
    b.classList.remove('drag'); trk.classList.remove('mkdrag');
    if (v === t0) {                                                           // 没拖动 = 点了一下：右侧跳到对应的参数
      if (c.id === tlSel && !tlLoading) focus(m.key);
      else { tlSelect(c.id); whenReady(() => setTimeout(() => focus(m.key), 200)); }
      return;
    }
    if (c.id === tlSel) {
      params[m.key] = c.params[m.key]; if (m.keep) params[m.keep] = c.params[m.keep];
      // 右侧面板里的数字跟着变：和撤销一样走 buildParams + reinit（效果自己的编辑器会重新挂上），再停到这一秒
      try { buildParams(); reinit(false); } catch (er) {}
      setTimeout(() => { try { seek(Math.max(0, v + 0.05)); } catch (er) {} }, 60);
      try { markDirty(); histSoon(); } catch (er) {}
    } else { try { const g = ghost(c); if (g._ok) ghostInit(c); } catch (er) {} }
    try { tlSave(); tlDraw(); } catch (er) {}
  }, true);
  function focus(key) {
    let el = null;
    try { const w = frame.contentWindow; if (w && w.__fxMarkFocus) el = w.__fxMarkFocus(key); } catch (er) {}
    el = document.querySelector('#params [data-fx-mark="' + key + '"]') || el; if (!el) return;
    el.classList.remove('off');
    const g = el.closest('.fxg'); if (g) g.classList.remove('off');
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    el.classList.remove('kf-flash'); void el.offsetWidth; el.classList.add('kf-flash');   // 和关键帧面板同一个「闪两下」（timeline.css）
    clearTimeout(el.__mkft); el.__mkft = setTimeout(() => el.classList.remove('kf-flash'), 1300);
  }
  function live(c, m, v) {
    params[m.key] = c.params[m.key]; if (m.keep) params[m.keep] = c.params[m.keep];
    try {
      const w = frame.contentWindow;
      if (w && w.init) { w.init(params); const t = Math.max(0, v + 0.05); w.renderAt(t); tlT = Math.round((c.start + t) * 100) / 100; headPos(); }
    } catch (er) {}
  }
})();
