/* 效果工坊 · 配置 GitHub（作者用：双击「配置GitHub.bat」）
 *
 * 浏览器能打开 GitHub、发布更新时 git 却推不上去 —— 一般是 git 没走代理。这个工具：
 * 【区域A 检查 Git】     电脑上有没有 Git、update.json 里的 GitHub 仓库
 * 【区域B 找代理】       update.json 里写的、git 自己配的、环境变量、Windows 系统代理、
 *                        正在运行的代理软件（Clash / v2rayN 等）实际监听的端口、常见端口
 * 【区域C 逐个测】       每个候选用 http 和 socks5h 两种写法真的连一次 GitHub（git ls-remote），最后再试直连
 * 【区域D 写配置】       把能用的那个写进 update.json 的 "proxy"（发布更新.bat 会用它）
 * 【区域E 登录检查】     可选：检查当前登录的 GitHub 账号有没有推送权限，或清掉旧登录、重新登录
 *
 * 不会改 git 的全局设置；只改 update.json 的 "proxy" 一项。
 * 用法：node tools/github-setup.js [--yes]   （--yes：不提问，只做 A~D）
 */
const fs = require('fs'), path = require('path'), net = require('net'), { spawnSync } = require('child_process'), readline = require('readline');
const ROOT = path.join(__dirname, '..');
const UJ = path.join(ROOT, 'update.json');
const REPO_DIR = path.join(ROOT, '_publish', 'repo');
const YES = process.argv.includes('--yes');
const log = (...a) => console.log('  ' + a.join(' '));
const ask = q => new Promise(ok => {
  if (YES || !process.stdin.isTTY) return ok('');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); rl.question('  ' + q, a => { rl.close(); ok(a.trim()); });
});

// ---------- 【区域A 检查 Git】 ----------
function findGit() {
  const cands = ['git', 'C:\\Program Files\\Git\\cmd\\git.exe', 'C:\\Program Files (x86)\\Git\\cmd\\git.exe', 'D:\\git\\cmd\\git.exe', 'D:\\Git\\cmd\\git.exe', 'D:\\Program Files\\Git\\cmd\\git.exe'];
  for (const g of cands) { try { const r = spawnSync(g, ['--version'], { encoding: 'utf8', windowsHide: true }); if (r.status === 0) return { g, ver: String(r.stdout).trim() }; } catch (e) {} }
  return null;
}
function readCfg() {
  const txt = fs.readFileSync(UJ, 'utf8').replace(/^\uFEFF/, '');
  return JSON.parse(txt);
}

// ---------- 【区域B 找代理】 ----------
// 统一成 { host, port, scheme('' = 不知道是 http 还是 socks), from }
function splitUrl(u, from) {
  const m = /^(?:(\w+):\/\/)?(?:[^@/]*@)?([^:/]+):(\d+)/.exec(String(u).trim());
  if (!m) return null;
  let sc = (m[1] || '').toLowerCase(); if (/^socks/.test(sc)) sc = 'socks5h'; else if (/^https?$/.test(sc)) sc = 'http';
  return { host: m[2], port: +m[3], scheme: sc, from };
}
function gitProxies(g) {
  const out = [];
  for (const k of ['http.https://github.com.proxy', 'http.https://github.com/.proxy', 'https.proxy', 'http.proxy']) {
    const r = spawnSync(g, ['config', '--get', k], { encoding: 'utf8', windowsHide: true });
    if (r.status === 0 && String(r.stdout).trim()) out.push(splitUrl(String(r.stdout).trim(), 'git 配置 ' + k));
  }
  return out;
}
function envProxies() {
  return ['HTTPS_PROXY', 'https_proxy', 'ALL_PROXY', 'all_proxy', 'HTTP_PROXY', 'http_proxy'].filter(k => process.env[k]).map(k => splitUrl(process.env[k], '环境变量 ' + k));
}
// Windows 系统代理（注册表）。返回可能多项：http=…;https=…;socks=…
function parseRegProxy(out) {
  const en = /ProxyEnable\s+REG_DWORD\s+0x([0-9a-f]+)/i.exec(out);
  if (!en || parseInt(en[1], 16) === 0) return [];
  const sv = /ProxyServer\s+REG_SZ\s+(\S+)/i.exec(out);
  if (!sv) return [];
  const s = sv[1], res = [];
  if (s.includes('=')) {
    s.split(';').forEach(p => {
      const i = p.indexOf('='); if (i < 0) return;
      const k = p.slice(0, i).trim().toLowerCase(), v = p.slice(i + 1).trim();
      const x = splitUrl(v, 'Windows 系统代理（' + k + '）'); if (!x) return;
      if (k === 'socks') x.scheme = 'socks5h'; else if (k === 'http' || k === 'https') x.scheme = x.scheme || 'http'; else return;
      res.push(x);
    });
  } else { const x = splitUrl(s, 'Windows 系统代理'); if (x) { x.scheme = x.scheme || 'http'; res.push(x); } }
  return res;
}
function regProxies() {
  if (process.platform !== 'win32') return [];
  const r = spawnSync('reg', ['query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings'], { encoding: 'utf8', windowsHide: true });
  return r.status === 0 ? parseRegProxy(String(r.stdout || '')) : [];
}
// 正在运行的代理软件在监听哪些端口（netstat + tasklist）
const PROXY_APP = /clash|mihomo|verge|v2ray|xray|sing-?box|nekoray|nekobox|hiddify|shadowsocks|ss-local|sslocal|trojan|qv2ray|flclash|karing|naive|privoxy|throne|furious|v2rayn|gui\.for|shadowrocket|surge|stash|lantern|psiphon|ghelper|astrill|letsvpn|快连|outline/i;
function parseNetstat(txt) {
  const out = [];
  for (const line of String(txt).split(/\r?\n/)) {
    const m = /^\s*TCP\s+(\S+):(\d+)\s+\S+\s+LISTENING\s+(\d+)/i.exec(line);
    if (m) out.push({ addr: m[1].replace(/^\[|\]$/g, ''), port: +m[2], pid: +m[3] });
  }
  return out;
}
function parseTasklist(txt) {
  const map = {};
  for (const line of String(txt).split(/\r?\n/)) { const m = /^"([^"]+)","(\d+)"/.exec(line); if (m) map[+m[2]] = m[1]; }
  return map;
}
function appProxies() {
  if (process.platform !== 'win32') return [];
  const ns = spawnSync('netstat', ['-ano', '-p', 'TCP'], { encoding: 'utf8', windowsHide: true });
  const tl = spawnSync('tasklist', ['/FO', 'CSV', '/NH'], { encoding: 'utf8', windowsHide: true });
  if (ns.status !== 0 || tl.status !== 0) return [];
  const names = parseTasklist(tl.stdout), seen = new Set(), out = [];
  for (const l of parseNetstat(ns.stdout)) {
    const name = names[l.pid] || '';
    if (!PROXY_APP.test(name)) continue;
    if (!/^(127\.0\.0\.1|0\.0\.0\.0|::|::1)$/.test(l.addr)) continue;
    if (seen.has(l.port)) continue; seen.add(l.port);
    out.push({ host: '127.0.0.1', port: l.port, scheme: '', from: '正在运行的 ' + name });
  }
  return out;
}
const COMMON = [[7890, ''], [7897, ''], [7891, 'socks5h'], [10809, 'http'], [10808, 'socks5h'], [10811, ''], [2080, ''], [2081, ''], [33210, 'http'], [33211, 'socks5h'], [8889, 'http'], [1087, 'http'], [1086, 'socks5h'], [1080, ''], [20171, 'http'], [20170, 'socks5h']];
const portOpen = (port, host = '127.0.0.1') => new Promise(ok => {
  const s = net.connect({ port, host }); const done = v => { s.destroy(); ok(v); };
  s.setTimeout(400, () => done(false)); s.on('connect', () => done(true)); s.on('error', () => done(false));
});
async function commonProxies() {
  const out = [];
  for (const [p, sc] of COMMON) if (await portOpen(p)) out.push({ host: '127.0.0.1', port: p, scheme: sc, from: '本机常见端口' });
  return out;
}
// 候选 → 要测的地址列表（不确定类型的端口，http 和 socks5h 都测；http 排前面，因为登录窗口只认 http 代理）
function toTries(cands) {
  const tries = [], seen = new Set();
  const add = (sc, c) => { const url = `${sc}://${c.host}:${c.port}`; if (!seen.has(url)) { seen.add(url); tries.push({ url, from: c.from }); } };
  for (const c of cands.filter(Boolean)) {
    if (c.scheme === 'http') add('http', c);
    else if (c.scheme === 'socks5h') add('socks5h', c);
    else { add('http', c); add('socks5h', c); }
  }
  return tries;
}

// ---------- 【区域C 逐个测】 ----------
function classify(err) {
  const e = String(err || '');
  if (/timed out|Timeout|timeout/i.test(e)) return '超时（这个代理没把请求转出去，或者节点不通）';
  if (/Could not resolve host|resolve/i.test(e)) return '解析不了 github.com';
  if (/Failed to connect|Connection refused|couldn't connect/i.test(e)) return '连不上（端口没开，或者不是代理端口）';
  if (/CONNECT tunnel failed|Proxy CONNECT aborted|Received HTTP code \d+ from proxy|proxy/i.test(e)) return '代理拒绝了（可能是 socks 端口却按 http 用了，或反过来）';
  if (/SOCKS|socks/i.test(e)) return 'socks 握手失败（可能是 http 端口却按 socks 用了）';
  if (/SSL|TLS|certificate/i.test(e)) return '加密连接出错（代理在中间改了证书？）';
  if (/not found|Repository not found/i.test(e)) return '连上了，但找不到仓库（检查 update.json 里的 github 仓库名）';
  const last = e.trim().split(/\r?\n/).pop() || '';
  return last.slice(0, 120) || '失败';
}
function tryGithub(g, repo, proxyUrl) {
  const a = proxyUrl ? ['-c', 'http.https://github.com.proxy=' + proxyUrl] : ['-c', 'http.https://github.com.proxy='];
  const env = { ...process.env, GIT_TERMINAL_PROMPT: '0', GCM_INTERACTIVE: 'never' };
  for (const k of ['HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy', 'ALL_PROXY', 'all_proxy']) delete env[k];
  const t0 = Date.now();
  const r = spawnSync(g, [...a, '-c', 'http.lowSpeedLimit=1', '-c', 'http.lowSpeedTime=12', 'ls-remote', '--heads', `https://github.com/${repo}.git`],
    { encoding: 'utf8', windowsHide: true, env, timeout: 20000 });
  const ms = Date.now() - t0;
  if (r.error && r.error.code === 'ETIMEDOUT') return { ok: false, ms, why: '超时（20 秒没反应）' };
  if (r.status === 0) return { ok: true, ms };
  // GitHub 回了「要登录 / 没权限 / 找不到仓库」= 网络已经通了（私有仓库没登录时就是这样），代理算能用
  if (/could not read Username|terminal prompts disabled|Authentication failed|Repository not found|returned error: (401|403|404)/i.test(String(r.stderr))) return { ok: true, ms, note: '网络通了；GitHub 要求登录或找不到仓库，登录问题在最后一步检查' };
  return { ok: false, ms, why: classify(r.stderr) };
}

// ---------- 【区域D 写配置】 ----------
function writeProxy(value) {
  const c = readCfg();
  c.proxy = value;
  fs.writeFileSync(UJ, JSON.stringify(c, null, 2) + '\n', 'utf8');
}

// ---------- 【区域E 登录检查】 ----------
function eraseLogin(g) {
  // 让 Git（和 Git Credential Manager）忘掉保存的 GitHub 账号
  spawnSync(g, ['credential', 'reject'], { input: 'protocol=https\nhost=github.com\n\n', encoding: 'utf8', windowsHide: true });
  spawnSync(g, ['credential-manager', 'erase'], { input: 'protocol=https\nhost=github.com\n\n', encoding: 'utf8', windowsHide: true });
}
function checkPush(g, branch, proxyUrl) {
  // 在发布用的仓库里「假装推一次」（--dry-run，不会真的改 GitHub 上的东西）；没登录会弹出登录窗口
  const a = proxyUrl ? ['-c', 'http.https://github.com.proxy=' + proxyUrl] : [];
  const env = { ...process.env };
  if (proxyUrl && /^http:/.test(proxyUrl)) Object.assign(env, { HTTPS_PROXY: proxyUrl, HTTP_PROXY: proxyUrl });
  const r = spawnSync(g, [...a, 'push', '--dry-run', 'origin', 'HEAD:' + branch], { cwd: REPO_DIR, encoding: 'utf8', windowsHide: false, env, stdio: ['inherit', 'pipe', 'pipe'], timeout: 180000 });
  const err = String(r.stderr || '') + String(r.stdout || '');
  if (r.status === 0) return { ok: true };
  if (/403|Permission .* denied|denied to/i.test(err)) return { ok: false, why: '登录的这个 GitHub 账号没有这个仓库的推送权限（登错账号了？选 2 重新登录）' };
  if (/Authentication failed|could not read Username|terminal prompts disabled|401/i.test(err)) return { ok: false, why: '没有登录，或者登录过期了（选 2 重新登录）' };
  return { ok: false, why: classify(err) };
}

// ---------- 主流程 ----------
async function main() {
  console.log('\n  ─────────────── 效果工坊 · 配置 GitHub ───────────────\n');
  // A
  const G = findGit();
  if (!G) { log('✘ 没找到 Git。先安装 Git：https://git-scm.com/download/win，装好再双击「配置GitHub.bat」。'); return; }
  log('Git：' + G.ver);
  let cfg;
  try { cfg = readCfg(); } catch (e) { log('✘ update.json 读不了：' + e.message); log('  常见原因：少了逗号，或最后一行后面多了逗号。改好再运行。'); return; }
  if (!cfg.github) { log('✘ update.json 里没填 "github"（格式「账号/仓库名」）。'); return; }
  const branch = cfg.branch || 'main';
  log('GitHub 仓库：' + cfg.github + '　分支：' + branch);
  log('update.json 现在的 proxy：' + (cfg.proxy || '（没填）'));
  console.log('');

  // B
  log('正在找代理…');
  const own = cfg.proxy && !/^(off|none|no|false|direct)$/i.test(cfg.proxy) ? [splitUrl(cfg.proxy, 'update.json 现在填的')] : [];
  const cands = [...own, ...gitProxies(G.g), ...envProxies(), ...regProxies(), ...appProxies(), ...(await commonProxies())].filter(Boolean);
  const tries = toTries(cands);
  if (!tries.length) log('没找到任何代理。代理软件开着吗？');
  else { log('找到 ' + tries.length + ' 个要试的地址：'); tries.forEach(t => log('   · ' + t.url + '　（' + t.from + '）')); }
  console.log('');

  // C
  log('逐个连 GitHub 试一下（每个最多 20 秒）…');
  let win = null;
  for (const t of tries) {
    process.stdout.write('  ' + t.url.padEnd(30) + ' ');
    const r = tryGithub(G.g, cfg.github, t.url);
    console.log(r.ok ? '✔ 能连上（' + (r.ms / 1000).toFixed(1) + ' 秒）' + (r.note ? '　' + r.note : '') : '✘ ' + r.why);
    if (r.ok) { win = t; break; }
  }
  let direct = null;
  if (!win) {
    process.stdout.write('  ' + '直连（不走代理）'.padEnd(26) + ' ');
    direct = tryGithub(G.g, cfg.github, '');
    console.log(direct.ok ? '✔ 能连上（' + (direct.ms / 1000).toFixed(1) + ' 秒）' + (direct.note ? '　' + direct.note : '') : '✘ ' + direct.why);
  }
  console.log('');

  // D
  let useProxy = '';
  if (win) {
    useProxy = win.url;
    if (cfg.proxy === win.url) log('✔ update.json 里的 proxy 已经是能用的：' + win.url);
    else { writeProxy(win.url); log('✔ 已把 update.json 的 proxy 改成：' + win.url + '　（原来是：' + (cfg.proxy || '没填') + '）'); }
  } else if (direct && direct.ok) {
    writeProxy('off'); log('✔ 不走代理也能连上 GitHub，已把 update.json 的 proxy 改成 "off"（直连）。');
  } else {
    log('✘ 所有方式都连不上 GitHub，update.json 没有改动。可以这样排查：');
    log('   1. 代理软件（Clash / v2rayN 等）开着，并且选了能用的节点；浏览器打开 https://github.com 试试；');
    log('   2. 在代理软件里找「本地端口 / 混合端口 / HTTP 端口 / SOCKS 端口」，记下数字；');
    log('   3. 把代理软件切到「规则」或「全局」模式（不要「直连」模式）；');
    log('   4. 或者打开代理软件的 TUN /「虚拟网卡」模式，这样所有程序都走代理，再运行一次这个工具。');
    log('   把这个窗口截图发给 Claude，可以帮你看。');
    return;
  }
  console.log('');

  // E
  if (!fs.existsSync(path.join(REPO_DIR, '.git'))) {
    log('还没发布过（没有 _publish\\repo），登录检查跳过。直接双击「发布更新.bat」就行，第一次会弹出 GitHub 登录窗口。');
    return;
  }
  log('接下来可以检查 GitHub 登录：');
  log('   1 = 检查当前登录的账号能不能推送（不会改 GitHub 上的东西）');
  log('   2 = 清掉保存的 GitHub 登录，重新登录（换账号 / 登录过期时用）');
  log('   直接回车 = 跳过');
  const pick = await ask('请选择：');
  if (pick !== '1' && pick !== '2') { log('跳过登录检查。现在可以双击「发布更新.bat」了。'); return; }
  if (pick === '2') { eraseLogin(G.g); log('已清掉保存的 GitHub 登录。接下来会弹出登录窗口，请用仓库 ' + cfg.github.split('/')[0] + ' 的账号登录。'); }
  log('正在检查…（如果弹出 GitHub 登录窗口，在里面登录即可）');
  const p = checkPush(G.g, branch, useProxy);
  if (p.ok) log('✔ 登录正常，有推送权限。现在可以双击「发布更新.bat」了。');
  else log('✘ ' + p.why);
}

if (require.main === module) main().catch(e => { console.error('  出错了：' + e.message); process.exit(1); });
module.exports = { checkPush, splitUrl, parseRegProxy, parseNetstat, parseTasklist, toTries, classify, tryGithub, writeProxy, readCfg };
