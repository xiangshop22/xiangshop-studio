/* 效果工坊 · 在线更新（server.js 用；不需要安装任何东西，Node 自带联网下载）
 *
 * 【区域U1 更新地址】update.json 里写仓库：先试 Gitee（国内快），再试 GitHub，最后试 jsDelivr 加速镜像
 * 【区域U2 版本清单】仓库里的 manifest.json：工作台程序的版本、每个文件的指纹；每个效果的名字、每个文件的指纹
 *      对比本地文件的指纹：有文件不一样或缺了 → 「有更新」；本地没有这个效果 → 「新效果」
 * 【区域U3 下载】按清单里的文件名下载 zip，核对指纹（下载不完整 / 被篡改就不装），再交给原来的「加载效果」流程安装
 * 【区域U4 发布】tools/publish.js：把工作台和每个效果打包、生成 manifest.json（作者用，见「发布更新.bat」）
 */
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const ROOT = path.join(__dirname, '..');
const EFFECTS = path.join(ROOT, 'effects');

// ---------- 【区域U2】哪些文件算「工作台程序」 ----------
const PROGRAM_FILES = ['server.js', 'start.bat', 'package.json', 'package-lock.json', 'README.txt', 'update.json', '发布更新.bat'];
const PROGRAM_DIRS = ['public', 'tools'];
const JUNK = /(^|\/)(Thumbs\.db|desktop\.ini|\.DS_Store)$/i;
const sha = buf => crypto.createHash('sha256').update(buf).digest('hex');

function listFiles(dir, prefix = '') {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const n of fs.readdirSync(dir).sort()) {
    const p = path.join(dir, n), rel = prefix + n;
    if (JUNK.test(rel)) continue;
    const st = fs.statSync(p);
    if (st.isDirectory()) out.push(...listFiles(p, rel + '/')); else out.push(rel);
  }
  return out;
}
function programFiles() {
  return [...PROGRAM_FILES.filter(f => fs.existsSync(path.join(ROOT, f))), ...PROGRAM_DIRS.flatMap(d => listFiles(path.join(ROOT, d), d + '/'))];
}
function effectIds() {
  if (!fs.existsSync(EFFECTS)) return [];
  return fs.readdirSync(EFFECTS).filter(id => /^[\w-]+$/.test(id) && !id.startsWith('_') && fs.existsSync(path.join(EFFECTS, id, 'effect.json'))).sort();
}
const fileSha = rel => { try { return sha(fs.readFileSync(path.join(ROOT, ...rel.split('/')))); } catch (e) { return null; } };
// 和清单比：清单里有、本地没有或内容不同的文件（本地多出来的文件不管）
const changed = files => files.filter(f => fileSha(f.path) !== f.sha).map(f => f.path);

// ---------- 【区域U1 更新地址】 ----------
function config() {
  let c = {};
  try { c = JSON.parse(fs.readFileSync(path.join(ROOT, 'update.json'), 'utf8')); } catch (e) {}
  return { github: c.github || '', gitee: c.gitee || '', branch: c.branch || 'main', autoCheck: c.autoCheck !== false, base: process.env.FX_UPDATE_BASE || c.base || '' };
}
function sources() {
  const c = config(), out = [];
  if (c.base) out.push({ name: '测试地址', url: f => c.base.replace(/\/$/, '') + '/' + f });
  if (c.gitee) out.push({ name: 'Gitee', url: f => `https://gitee.com/${c.gitee}/raw/${c.branch}/${f}` });
  if (c.github) out.push({ name: 'GitHub', url: f => `https://raw.githubusercontent.com/${c.github}/${c.branch}/${f}` });
  if (c.github) out.push({ name: 'jsDelivr 镜像', url: f => `https://cdn.jsdelivr.net/gh/${c.github}@${c.branch}/${f}` });
  return out;
}
async function get(url, ms) {
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, { signal: ac.signal, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'EffectStudio' } });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return Buffer.from(await r.arrayBuffer());
  } finally { clearTimeout(t); }
}
// 按顺序试每个地址，第一个成功的就用
async function fetchAny(file, ms, check) {
  const errs = [];
  for (const s of sources()) {
    try {
      const buf = await get(s.url(file) + (file.endsWith('.json') ? '?t=' + Date.now() : ''), ms);
      if (check) check(buf);
      return { buf, source: s.name };
    } catch (e) { errs.push(s.name + '：' + (e.name === 'AbortError' ? '超时' : e.message)); }
  }
  throw new Error(errs.length ? '连不上更新服务器（' + errs.join('；') + '）' : '还没有设置更新地址（update.json）');
}

// ---------- 【区域U2 版本清单】检查更新 ----------
let cache = null;
async function check(currentVersion, force) {
  if (!force && cache && Date.now() - cache.at < 10 * 60 * 1000) return cache.res;
  const { buf, source } = await fetchAny('manifest.json', 10000);
  let m; try { m = JSON.parse(buf.toString('utf8')); } catch (e) { throw new Error('更新清单格式有误'); }
  const res = { source, published: m.published || '', studio: null, effects: [], notes: m.notes || '' };
  if (m.studio) {
    const diff = changed(m.studio.files || []);
    res.studio = { current: currentVersion, latest: m.studio.version, newer: diff.length > 0, files: diff.length };
  }
  const local = new Set(effectIds());
  for (const e of m.effects || []) {
    const exists = local.has(e.id);
    const diff = changed((e.files || []).map(f => ({ path: 'effects/' + f.path, sha: f.sha })));
    if (!exists) res.effects.push({ id: e.id, name: e.name, description: e.description || '', status: 'new' });
    else if (diff.length) res.effects.push({ id: e.id, name: e.name, description: e.description || '', status: 'update', files: diff.length });
  }
  cache = { at: Date.now(), res, manifest: m };
  return res;
}

// ---------- 【区域U3 下载】 ----------
async function download(entry) {
  const { buf } = await fetchAny(entry.file, 120000, b => { if (entry.zipSha && sha(b) !== entry.zipSha) throw new Error('下载的文件不完整'); });
  return buf;
}
async function fetchPackages(wantStudio, ids) {
  if (!cache) throw new Error('请先检查更新');
  const m = cache.manifest, out = [];
  if (wantStudio && m.studio) out.push({ name: path.basename(m.studio.file), buf: await download(m.studio) });
  for (const id of ids || []) {
    const e = (m.effects || []).find(x => x.id === id);
    if (e) out.push({ name: path.basename(e.file), buf: await download(e) });
  }
  return out;
}
const clearCache = () => { cache = null; };

module.exports = { ROOT, sha, listFiles, programFiles, effectIds, config, check, fetchPackages, clearCache, PROGRAM_FILES, PROGRAM_DIRS };
