/* 效果工坊 v6 · 本地服务（双击 start.bat 会自动启动它，不用手动运行）
 *
 * 【区域A 基础】端口、文件夹位置
 * 【区域B 效果列表】读取 effects 里每个文件夹的 effect.json
 * 【区域C 导出 MOV】用浏览器一帧一帧截图，交给 FFmpeg 合成透明 ProRes 4444
 * 【区域D 图片 / 视频上传】卡片里上传的照片、视频存到 uploads 文件夹；视频会转一份预览用的小视频
 * 【区域C2 视频卡导出提速】导出前用 FFmpeg 把卡片里的视频一次拆成图片，逐帧直接换图（比浏览器跳帧快很多）
 * 【区域E 加载效果】把拖进网页的 zip / 文件夹解压，放进 effects（同名会先备份到 effects\_backup）
 *                   拖进来的是「整个工作台」的升级包时，更新工作台文件并自动重启
 * 【区域F 导出效果 / 打包工作台】下载单个效果的 zip，或整个工作台的 zip（发给别人用）
 * 【区域H 在线更新】点「检查更新」→ 去 Gitee / GitHub 看清单 → 勾选后自动下载安装（见 tools/update.js）
 * 【区域G 网址路由】网页请求哪个地址，交给上面哪一段处理
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { spawn, exec } = require('child_process');
const { readZip, writeZip } = require('./tools/zip');
const { findFfmpeg, findBrowser, systemBrowsers } = require('./tools/env');
const updater = require('./tools/update');

// ================= 【区域A 基础】 =================
const VERSION = 'v8.0';
const PORT = 3210, HOST = '127.0.0.1', ROOT = __dirname;   // 只允许本机访问（局域网里的其他电脑打不开）
const EFFECTS = path.join(ROOT, 'effects'), PUBLIC = path.join(ROOT, 'public'), OUT = path.join(ROOT, 'output');
const UPLOADS = path.join(ROOT, 'uploads'), BACKUP = path.join(EFFECTS, '_backup'), STUDIO_BACKUP = path.join(ROOT, '_backup');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.otf': 'font/otf', '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.mp3': 'audio/mpeg', '.wav': 'audio/wav' };
const jobs = {};
const ID_OK = /^[\w-]+$/;
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); };
const readRaw = (req, max) => new Promise((ok, no) => {
  const bufs = []; let n = 0;
  req.on('data', c => { n += c.length; if (n > max) { no(new Error('文件太大（超过 ' + Math.round(max / 1048576) + 'MB）')); req.destroy(); } else bufs.push(c); });
  req.on('end', () => ok(Buffer.concat(bufs))); req.on('error', no);
});
const readBody = async (req) => { try { return JSON.parse((await readRaw(req, 5e6)).toString('utf8') || '{}'); } catch { return {}; } };
const stamp = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().replace(/[-:T]/g, '').slice(0, 14).replace(/^(\d{8})/, '$1-');

// ================= 【区域B 效果列表】 =================
function listEffects() {
  if (!fs.existsSync(EFFECTS)) return [];
  const out = [];
  for (const id of fs.readdirSync(EFFECTS)) {
    const jf = path.join(EFFECTS, id, 'effect.json');
    if (!ID_OK.test(id) || id.startsWith('_') || !fs.existsSync(jf)) continue;
    try { out.push({ id, ...JSON.parse(fs.readFileSync(jf, 'utf8')) }); } catch (e) { console.log('effect.json 格式有误：', id); }
  }
  return out;
}

// ================= 【区域C 导出 MOV】 =================
async function launchBrowser() {
  const puppeteer = require('puppeteer');
  const args = ['--no-sandbox'];
  try { return await puppeteer.launch({ args }); } catch (e1) {
    // Puppeteer 自带的 Chrome 没下载成功时，用电脑里已有的 Chrome / Edge
    for (const p of systemBrowsers()) if (fs.existsSync(p)) { try { return await puppeteer.launch({ args, executablePath: p }); } catch (e) {} }
    throw new Error('找不到可用的浏览器（Chrome / Edge）。请关闭黑窗口，重新双击 start.bat 让它自动安装。' + e1.message);
  }
}
async function runExport(job, o) {
  const ffmpeg = findFfmpeg();
  if (!ffmpeg) throw new Error('没有找到 FFmpeg，无法导出。请关闭黑窗口，重新双击 start.bat，它会自动安装。');
  fs.mkdirSync(OUT, { recursive: true });
  const safe = (o.name || '').replace(/[\\/:*?"<>|]/g, '').trim();
  let file = (safe || `${o.effect}_${stamp()}`) + '.mov';
  for (let n = 1; fs.existsSync(path.join(OUT, file)); n++) file = `${safe || o.effect}_${n}.mov`;
  const outPath = path.join(OUT, file);
  const browser = await launchBrowser();
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: o.width, height: o.height, deviceScaleFactor: 1 });
    await page.goto(`http://${HOST}:${PORT}/effects/${o.effect}/effect.html`);
    let dur = await page.evaluate((p) => { window.init(p); return window.getDuration(); }, o.params);
    // 【区域C2】卡片里有视频：先拆成图片，再重新初始化（这时效果会改用图片逐帧显示）
    const vids = findVideos(o.params);
    if (vids.length) {
      job.stage = '正在准备视频画面…';
      const map = {};
      for (const v of vids) map[v] = await extractFrames(v, o.fps, dur + o.hold + 0.5, o.width);
      o.params.__media = { fps: o.fps, map };
      job.stage = '';
    }
    dur = await page.evaluate(async (p) => { window.init(p); if (window.whenReady) await window.whenReady(); return window.getDuration(); }, o.params);
    const total = Math.max(1, Math.round((dur + o.hold) * o.fps));
    const ff = spawn(ffmpeg, ['-y', '-f', 'image2pipe', '-framerate', String(o.fps), '-c:v', 'png', '-i', '-',
      '-c:v', 'prores_ks', '-profile:v', '4444', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0', outPath], { stdio: ['pipe', 'ignore', 'pipe'], windowsHide: true });
    let ffErr = '', dead = false;
    ff.stderr.on('data', (d) => (ffErr = (ffErr + d).slice(-800)));
    ff.stdin.on('error', () => {});
    const closed = new Promise((r) => { ff.on('error', (e) => { dead = true; ffErr = String(e.message); r(-1); }); ff.on('close', (c) => { dead = true; r(c); }); });
    for (let i = 0; i < total && !dead; i++) {
      await page.evaluate((t) => { window.renderAt(t); return window.__fxFrameWait ? window.__fxFrameWait() : null; }, i / o.fps);
      const buf = await page.screenshot({ type: 'png', omitBackground: true, optimizeForSpeed: true });
      if (!ff.stdin.write(buf)) await Promise.race([new Promise((r) => ff.stdin.once('drain', r)), closed]);
      job.progress = (i + 1) / total;
    }
    ff.stdin.end();
    const code = await closed;
    if (code !== 0) throw new Error('FFmpeg 出错：' + ffErr);
    job.status = 'done'; job.file = file; job.progress = 1;
  } finally { await browser.close(); }
}

// ================= 【区域C2 视频卡导出提速】 =================
// 参数里所有 { video: '/uploads/...' } 的地址
function findVideos(o, out = new Set()) {
  if (Array.isArray(o)) o.forEach(x => findVideos(x, out));
  else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) {
    if (k === 'video' && typeof v === 'string' && v.startsWith('/uploads/')) out.add(v); else if (typeof v === 'object' || (typeof v === 'string' && v.startsWith('{'))) {
      if (typeof v === 'string') { try { findVideos(JSON.parse(v), out); } catch (e) {} } else findVideos(v, out);
    }
  }
  return [...out];
}
const runFF = (args) => new Promise((ok, no) => {
  const ff = spawn(findFfmpeg(), args, { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
  let err = ''; ff.stderr.on('data', d => (err = (err + d).slice(-1500)));
  ff.on('error', no); ff.on('close', c => (c === 0 ? ok(err) : no(new Error('FFmpeg 出错：' + err.slice(-300)))));
});
// 预览小视频 xxx.fx.mp4 → 原视频 xxx.orig.*（画质更好）
function originalOf(url) {
  const fp = path.join(ROOT, ...decodeURIComponent(url).split('/').filter(Boolean));
  const base = fp.replace(/\.fx\.(mp4|webm)$/, '');
  const dir = path.dirname(base), name = path.basename(base) + '.orig.';
  try { const f = fs.readdirSync(dir).find(n => n.startsWith(name)); if (f) return path.join(dir, f); } catch (e) {}
  return fp;
}
// 按导出帧率拆成 JPG（只拆需要的长度），拆过的直接复用
async function extractFrames(url, fps, maxSec, outW) {
  const src = originalOf(url);
  const side = Math.min(2560, Math.max(1280, Math.round(1280 * outW / 1920)));
  const key = path.basename(src).replace(/[^\w.-]/g, '_') + `_${fps}fps_${side}_${Math.ceil(maxSec)}s`;
  const dir = path.join(UPLOADS, '.frames', key), done = path.join(dir, 'done.json');
  if (!fs.existsSync(done)) {
    fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
    await runFF(['-v', 'error', '-y', '-i', src, '-t', String(maxSec), '-an',
      '-vf', `fps=${fps},scale=w='if(gt(iw,ih),min(${side},iw),-2)':h='if(gt(iw,ih),-2,min(${side},ih))'`,
      '-q:v', '3', path.join(dir, '%06d.jpg')]);
    const count = fs.readdirSync(dir).filter(n => n.endsWith('.jpg')).length;
    fs.writeFileSync(done, JSON.stringify({ count }));
  }
  const { count } = JSON.parse(fs.readFileSync(done, 'utf8'));
  return { dir: `/uploads/.frames/${encodeURIComponent(key)}/`, count: Math.max(1, count) };
}

// ================= 【区域D 图片上传】 =================
const IMG_EXT = { 'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp', 'image/gif': '.gif' };
async function handleUpload(req, res) {
  const ext = IMG_EXT[(req.headers['content-type'] || '').split(';')[0].trim()];
  if (!ext) return send(res, 400, { error: '只支持 PNG / JPG / WEBP / GIF 图片' });
  const buf = await readRaw(req, 60 * 1048576);
  fs.mkdirSync(UPLOADS, { recursive: true });
  const name = stamp() + '-' + Math.random().toString(36).slice(2, 8) + ext;
  fs.writeFileSync(path.join(UPLOADS, name), buf);
  send(res, 200, { url: '/uploads/' + name });
}

// ---------- 视频上传：存原视频 + 转一份预览小视频（最长边 960、全是关键帧附近，拖动进度条跳得快）+ 封面 ----------
async function handleVideoUpload(req, res) {
  if (!findFfmpeg()) return send(res, 400, { error: '没有找到 FFmpeg，无法处理视频' });
  const dir = path.join(UPLOADS, 'videos'); fs.mkdirSync(dir, { recursive: true });
  const ext = (path.extname(decodeURIComponent(req.headers['x-file-name'] || '')).toLowerCase().match(/^\.(mp4|mov|webm|m4v|mkv|avi)$/) || ['.mp4'])[0];
  const base = stamp() + '-' + Math.random().toString(36).slice(2, 8);
  const orig = path.join(dir, base + '.orig' + ext);
  await new Promise((ok, no) => { const w = fs.createWriteStream(orig); req.pipe(w); w.on('finish', ok); w.on('error', no); req.on('error', no); });
  // 读时长和尺寸（ffmpeg -i 的输出里有）
  const info = await new Promise(ok => {
    let err = ''; const ff = spawn(findFfmpeg(), ['-hide_banner', '-i', orig], { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
    ff.stderr.on('data', d => (err += d)); ff.on('close', () => ok(err)); ff.on('error', () => ok(err));
  });
  const dm = info.match(/Duration:\s*(\d+):(\d+):([\d.]+)/), sm = info.match(/Video:.*?(\d{2,5})x(\d{2,5})/);
  if (!dm || !sm) { fs.rmSync(orig, { force: true }); return send(res, 400, { error: '无法识别这个视频文件' }); }
  const vdur = +dm[1] * 3600 + +dm[2] * 60 + +dm[3];
  const vf = "scale=w='if(gt(iw,ih),min(960,iw),-2)':h='if(gt(iw,ih),-2,min(960,ih))'";
  let out = path.join(dir, base + '.fx.mp4');
  try {
    await runFF(['-v', 'error', '-y', '-i', orig, '-an', '-vf', vf, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', '-g', '12', '-movflags', '+faststart', out]);
  } catch (e) {                                                    // 没有 x264 时用 WebM
    out = path.join(dir, base + '.fx.webm');
    await runFF(['-v', 'error', '-y', '-i', orig, '-an', '-vf', vf, '-c:v', 'libvpx', '-b:v', '2M', '-deadline', 'realtime', '-cpu-used', '8', '-g', '12', out]);
  }
  const poster = path.join(dir, base + '.poster.jpg');
  try { await runFF(['-v', 'error', '-y', '-i', orig, '-frames:v', '1', '-vf', vf, '-q:v', '4', poster]); } catch (e) {}
  const rel = f => '/uploads/videos/' + path.basename(f);
  send(res, 200, { video: rel(out), poster: fs.existsSync(poster) ? rel(poster) : '', vdur: Math.round(vdur * 1000) / 1000, w: +sm[1], h: +sm[2] });
}

// ================= 【区域E 加载效果】 =================
// 把压缩包里的路径统一成 a/b/c 的样子；有 .. 或盘符的直接丢掉（防止写到别的地方）
function cleanEntries(entries) {
  const out = [];
  for (const e of entries) {
    const p = e.path.replace(/\\/g, '/').replace(/^(\.\/|\/)+/, '');
    const segs = p.split('/');
    if (!p || segs.some(s => s === '..' || s.includes(':')) || segs.includes('__MACOSX') || /^(\.DS_Store|Thumbs\.db|desktop\.ini)$/i.test(segs[segs.length - 1])) continue;
    out.push({ path: p, data: e.data });
  }
  return out;
}
const STUDIO_FILES = ['server.js', 'start.bat', 'package.json', 'package-lock.json', 'README.txt', '使用说明.txt', 'update.json', '发布更新.bat'];
const STUDIO_DIRS = ['public/', 'tools/'];
// 看清压缩包里有什么：几个效果、共用文件、是不是整个工作台
function analyze(entries, zipName) {
  const plan = { effects: [], shared: [], studio: null, errors: [], unchanged: [] };
  // 1) 整个工作台的升级包：有 server.js，旁边还有 public/index.html
  const srv = entries.find(e => /(^|\/)server\.js$/.test(e.path) && entries.some(x => x.path === e.path.replace(/server\.js$/, 'public/index.html')));
  let effEntries = entries;
  if (srv) {
    const pre = srv.path.slice(0, -'server.js'.length);
    const files = entries.filter(e => e.path.startsWith(pre)).map(e => ({ rel: e.path.slice(pre.length), data: e.data }))
      .filter(e => STUDIO_FILES.includes(e.rel) || STUDIO_DIRS.some(d => e.rel.startsWith(d)));
    let ver = '';
    const ix = files.find(f => f.rel === 'public/index.html');
    if (ix) { const m = ix.data.toString('utf8').match(/<small[^>]*>\s*(v[\d.]+)\s*<\/small>/); if (m) ver = m[1]; }
    plan.studio = { files, version: ver };
    effEntries = entries.filter(e => e.path.startsWith(pre + 'effects/')).map(e => ({ path: e.path.slice(pre.length), data: e.data }));
  }
  // 2) 共用文件：路径里有 _shared 的
  for (const e of effEntries) {
    const segs = e.path.split('/'), i = segs.indexOf('_shared');
    if (i < 0 || segs.includes('_backup')) continue;
    const rel = segs.slice(i + 1).join('/'); if (!rel) continue;
    const dest = path.join(EFFECTS, '_shared', ...rel.split('/'));
    let same = false; try { same = fs.readFileSync(dest).equals(e.data); } catch (er) {}
    if (!same) plan.shared.push({ rel, data: e.data, exists: fs.existsSync(dest) });
  }
  // 3) 效果：每个 effect.json 所在的文件夹就是一个效果，文件夹名就是效果名
  const jsons = effEntries.filter(e => /(^|\/)effect\.json$/.test(e.path) && !e.path.split('/').some(s => s === '_backup' || s === '_shared'));
  const roots = jsons.map(j => j.path.slice(0, -'effect.json'.length));
  for (const j of jsons) {
    const dir = j.path.slice(0, -'effect.json'.length);                     // 例如 "effects/card-deal/"，或 ""（effect.json 就在最外层）
    if (roots.some(r => r !== dir && r.length < dir.length && dir.startsWith(r))) continue;   // 效果里面又套了效果，不算
    let id = dir ? dir.replace(/\/$/, '').split('/').pop() : String(zipName || '').replace(/\.zip$/i, '').replace(/[\s（(]\d+[)）]$/, '').trim();
    let meta; try { meta = JSON.parse(j.data.toString('utf8').replace(/^﻿/, '')); } catch (e) { plan.errors.push(`「${id}」的 effect.json 格式有误，没法安装`); continue; }
    if (!ID_OK.test(id) || id.startsWith('_')) { plan.errors.push(`效果文件夹名「${id}」只能用英文字母、数字、- 和 _`); continue; }
    const files = effEntries.filter(e => e.path.startsWith(dir) && !e.path.slice(dir.length).split('/').includes('_shared')).map(e => ({ rel: e.path.slice(dir.length), data: e.data }));
    if (!files.some(f => f.rel === 'effect.html')) { plan.errors.push(`「${meta.name || id}」缺少 effect.html`); continue; }
    if (plan.effects.some(x => x.id === id) || plan.unchanged.includes(meta.name || id)) continue;
    const exists = fs.existsSync(path.join(EFFECTS, id, 'effect.json'));
    // 已经有、而且每个文件都一模一样 → 不用再装（也不会产生多余的备份）
    if (exists && files.every(f => { try { return fs.readFileSync(path.join(EFFECTS, id, ...f.rel.split('/'))).equals(f.data); } catch (e) { return false; } })) { plan.unchanged.push(meta.name || id); continue; }
    plan.effects.push({ id, name: meta.name || id, files, exists });
  }
  return plan;
}
const writeFile = (dest, data) => { fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, data); };
const inside = (base, p) => { const r = path.relative(base, p); return r && !r.startsWith('..') && !path.isAbsolute(r); };
function moveAside(src, dest) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  try { fs.renameSync(src, dest); } catch (e) { fs.cpSync(src, dest, { recursive: true }); fs.rmSync(src, { recursive: true, force: true }); }
}
function applyPlan(plan, mode) {          // mode: overwrite（同名覆盖，旧的备份） / skip（同名跳过，只装新的）
  const st = stamp(), done = { installed: [], updated: [], skipped: [], shared: [], studio: false, backup: false };
  for (const fx of plan.effects) {
    const dir = path.join(EFFECTS, fx.id);
    if (fx.exists && mode !== 'overwrite') { done.skipped.push(fx.name); continue; }
    if (fs.existsSync(dir)) { moveAside(dir, path.join(BACKUP, fx.id + '_' + st)); done.backup = true; }
    for (const f of fx.files) { const d = path.join(dir, ...f.rel.split('/')); if (inside(dir, d)) writeFile(d, f.data); }
    (fx.exists ? done.updated : done.installed).push(fx.name);
  }
  const sh = path.join(EFFECTS, '_shared');
  for (const f of plan.shared) {
    const d = path.join(sh, ...f.rel.split('/')); if (!inside(sh, d)) continue;
    if (f.exists) { writeFile(path.join(BACKUP, '_shared_' + st, ...f.rel.split('/')), fs.readFileSync(d)); done.backup = true; }
    writeFile(d, f.data); done.shared.push(f.rel);
  }
  if (plan.studio) {
    for (const f of plan.studio.files) {
      const d = path.join(ROOT, ...f.rel.split('/')); if (!inside(ROOT, d)) continue;
      let same = false; try { same = fs.readFileSync(d).equals(f.data); } catch (e) {}
      if (same) continue;
      if (fs.existsSync(d)) writeFile(path.join(STUDIO_BACKUP, 'studio_' + st, ...f.rel.split('/')), fs.readFileSync(d));
      writeFile(d, f.data); done.studio = true;
    }
  }
  trimBackups();                    // 每次安装 / 升级后，旧备份只留最近几份，不让文件夹一直长
  return done;
}

// ================= 【区域I 占用统计 / 清理】 =================
// 文件夹越来越大，99% 不是效果代码（全部效果加起来才 1~2MB），而是素材和成品：
// 上传视频的原片、导出的 MOV、逐帧缓存。这里统计出来，让用户自己点着删。
const KEEP_BACKUPS = 3;             // 每个效果 / 工作台各保留最近 3 份旧版本
function dirSize(p) {
  let n = 0, c = 0;
  const walk = d => {
    let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of es) {
      const f = path.join(d, e.name);
      if (e.isDirectory()) walk(f);
      else { try { n += fs.statSync(f).size; c++; } catch (e2) { } }
    }
  };
  if (fs.existsSync(p)) walk(p);
  return { bytes: n, files: c };
}
function filesIn(dir, test) {       // 平铺一层，挑出符合条件的文件
  const out = [];
  let es; try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return out; }
  for (const e of es) {
    const f = path.join(dir, e.name);
    if (e.isFile() && test(e.name)) { try { out.push({ p: f, size: fs.statSync(f).size }); } catch (e2) { } }
  }
  return out;
}
const sumOf = list => ({ bytes: list.reduce((a, x) => a + x.size, 0), files: list.length });
// 旧备份文件夹：名字都是 xxx_20261102-101422，按时间戳排序，只留最近 KEEP_BACKUPS 份
function oldBackupDirs() {
  const groups = {}, out = [];
  for (const [root, tag] of [[BACKUP, 'effects'], [STUDIO_BACKUP, 'studio']]) {
    if (!fs.existsSync(root)) continue;
    for (const n of fs.readdirSync(root)) {
      const m = n.match(/^(.+)_(\d{8}-\d{6})$/); if (!m) continue;
      (groups[tag + ':' + m[1]] = groups[tag + ':' + m[1]] || []).push({ p: path.join(root, n), t: m[2] });
    }
  }
  for (const k in groups) {
    groups[k].sort((a, b) => b.t.localeCompare(a.t));
    out.push(...groups[k].slice(KEEP_BACKUPS));
  }
  return out;
}
function trimBackups() { for (const d of oldBackupDirs()) { try { fs.rmSync(d.p, { recursive: true, force: true }); } catch (e) { } } }

const VID = path.join(UPLOADS, 'videos'), FRAMES = path.join(UPLOADS, '.frames');
function spaceGroups() {
  const origs = filesIn(VID, n => /\.orig\.[^.]+$/i.test(n));
  const prev = filesIn(VID, n => !/\.orig\.[^.]+$/i.test(n));
  const imgs = filesIn(UPLOADS, n => !n.startsWith('.') && /\.(png|jpe?g|webp|gif|avif|bmp)$/i.test(n));
  const outs = filesIn(OUT, n => /\.(mov|mp4|webm|png|zip)$/i.test(n));
  const oldbk = oldBackupDirs().map(d => ({ p: d.p, size: dirSize(d.p).bytes }));
  return [
    { key: 'output', name: '导出的成品视频', dir: 'output', safe: true, ...sumOf(outs),
      note: '已经导出的 MOV。拖进剪辑软件用过就可以删，要用再导一次。' },
    { key: 'origvideo', name: '上传视频的原片', dir: 'uploads\\videos', safe: true, ...sumOf(origs),
      note: '原画质备份，导出时用它出片。删了效果照常预览和导出，只是导出画质按预览那份来。' },
    { key: 'frames', name: '视频逐帧缓存', dir: 'uploads\\.frames', safe: true, ...dirSize(FRAMES),
      note: '导出视频卡时自动拆出来的图片，纯缓存，删了下次导出会自动重建。' },
    { key: 'oldbackup', name: '旧版本备份（超出最近 3 份的）', dir: '_backup', safe: true, ...sumOf(oldbk),
      note: '升级时自动留的旧版本。现在每个效果只保留最近 ' + KEEP_BACKUPS + ' 份，多出来的在这里。' },
    { key: 'publish', name: '发布仓库缓存', dir: '_publish', safe: true, ...dirSize(path.join(ROOT, '_publish')),
      note: '只有发布更新给别人时才用得上；删了下次发布会重新拉一份。' },
    { key: 'preview', name: '正在用的素材（图片 + 预览视频）', dir: 'uploads', safe: false,
      bytes: sumOf(imgs).bytes + sumOf(prev).bytes, files: imgs.length + prev.length,
      note: '卡片里正在显示的照片和预览视频。删了画面会变空，所以不提供一键清理。' },
    { key: 'program', name: '程序本体（含 FFmpeg、效果代码）', dir: 'node_modules + effects + public', safe: false,
      bytes: dirSize(path.join(ROOT, 'node_modules')).bytes + dirSize(EFFECTS).bytes + dirSize(PUBLIC).bytes + dirSize(path.join(ROOT, 'tools')).bytes,
      files: 0, note: '工具本身，其中 FFmpeg 一个就 64MB，不能删。' }
  ];
}
function cleanSpace(keys) {
  const kill = [];
  if (keys.includes('output')) kill.push(...filesIn(OUT, n => /\.(mov|mp4|webm|png|zip)$/i.test(n)).map(f => f.p));
  if (keys.includes('origvideo')) kill.push(...filesIn(VID, n => /\.orig\.[^.]+$/i.test(n)).map(f => f.p));
  if (keys.includes('frames')) kill.push(FRAMES);
  if (keys.includes('oldbackup')) kill.push(...oldBackupDirs().map(d => d.p));
  if (keys.includes('publish')) kill.push(path.join(ROOT, '_publish'));
  let freed = 0;
  for (const p of kill) {
    if (!inside(ROOT, p)) continue;                       // 只在工作台目录里删，绝不碰外面
    try { freed += fs.statSync(p).isDirectory() ? dirSize(p).bytes : fs.statSync(p).size; } catch (e) { continue; }
    try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) { }
  }
  return { freed };
}
// 【区域H 在线更新】下载好的 zip 直接走同一套安装流程（同名覆盖，旧的自动备份）
function installBuffer(buf, name) {
  const plan = analyze(cleanEntries(readZip(buf)), name);
  if (!plan.effects.length && !plan.shared.length && !plan.studio) return { done: null, errors: plan.errors };
  return { done: applyPlan(plan, 'overwrite'), errors: plan.errors };
}
async function handleUpdateApply(req, res) {
  const b = await readBody(req);
  const pk = await updater.fetchPackages(!!b.studio, Array.isArray(b.effects) ? b.effects : []);
  const all = { installed: [], updated: [], shared: [], studio: false, errors: [] };
  // 先装效果，最后装工作台程序（装完程序要重启）
  pk.sort((a, b2) => (/^studio|^EffectStudio/i.test(a.name) ? 1 : 0) - (/^studio|^EffectStudio/i.test(b2.name) ? 1 : 0));
  for (const p of pk) {
    const r = installBuffer(p.buf, p.name);
    all.errors.push(...r.errors);
    if (!r.done) continue;
    all.installed.push(...r.done.installed); all.updated.push(...r.done.updated); all.shared.push(...r.done.shared);
    if (r.done.studio) all.studio = true;
  }
  updater.clearCache();
  const restart = all.studio && !!process.env.FX_LAUNCHER;
  send(res, 200, { ok: true, done: all, restart, manualRestart: all.studio && !restart });
  if (restart) setTimeout(() => { console.log('工作台已在线更新，正在重启…'); process.exit(99); }, 400);
}

async function handleInstall(req, res, url) {
  const buf = await readRaw(req, 500 * 1048576);
  const zipName = decodeURIComponent(req.headers['x-file-name'] || '');
  let entries;
  try { entries = cleanEntries(readZip(buf)); } catch (e) { return send(res, 400, { error: e.message }); }
  const plan = analyze(entries, zipName);
  const nothing = !plan.effects.length && !plan.shared.length && !plan.studio;
  if (nothing && plan.unchanged.length) return send(res, 200, { same: true, unchanged: plan.unchanged, errors: plan.errors });
  if (nothing) return send(res, 400, { error: plan.errors[0] || '压缩包里没有找到 effect.json，这不像是效果包' });
  const mode = url.searchParams.get('mode') || 'check';
  const summary = {
    effects: plan.effects.map(e => ({ id: e.id, name: e.name, exists: e.exists })),
    shared: plan.shared.map(s => s.rel), unchanged: plan.unchanged, studio: plan.studio ? { version: plan.studio.version, current: VERSION } : null, errors: plan.errors,
  };
  if (mode === 'check') return send(res, 200, { check: true, ...summary });
  const done = applyPlan(plan, mode);
  const restart = done.studio && !!process.env.FX_LAUNCHER;
  send(res, 200, { ok: true, ...summary, done, restart, manualRestart: done.studio && !restart });
  if (restart) setTimeout(() => { console.log('工作台已更新，正在重启…'); process.exit(99); }, 400);
}

// ================= 【区域F 导出效果 / 打包工作台】 =================
function collect(dir, prefix, skip) {           // 把一个文件夹里的所有文件读出来（skip 里的文件夹不要）
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const n of fs.readdirSync(dir)) {
    const p = path.join(dir, n), rel = prefix + n;
    if (skip && skip(rel)) continue;
    const s = fs.statSync(p);
    if (s.isDirectory()) out.push(...collect(p, rel + '/', skip)); else out.push({ path: rel, data: fs.readFileSync(p) });
  }
  return out;
}
function sendZip(res, name, files) {
  const buf = writeZip(files);
  res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Length': buf.length, 'Cache-Control': 'no-store',
    'Content-Disposition': `attachment; filename="${name}"` });      // 文件名用英文：所有浏览器、所有电脑都不会乱码
  res.end(buf);
}
const junk = rel => /(^|\/)(Thumbs\.db|desktop\.ini|\.DS_Store)$/i.test(rel);
function handleEffectZip(res, id) {
  const fx = listEffects().find(e => e.id === id);
  if (!fx) return send(res, 404, { error: '没有这个效果' });
  // 和以前发的包一样：最外层是 effects 文件夹，里面是这个效果 + _shared 共用文件
  const files = [...collect(path.join(EFFECTS, id), `effects/${id}/`, junk), ...collect(path.join(EFFECTS, '_shared'), 'effects/_shared/', junk)];
  sendZip(res, `effect-${id}.zip`, files);
}
function handleStudioZip(res) {
  const top = 'effect-studio/';
  const skipTop = rel => junk(rel) || /^(node_modules|output|uploads|runtime|_backup|_publish|\.git)(\/|$)/.test(rel) || /^effects\/_backup(\/|$)/.test(rel) || /\.(log|zip)$/.test(rel);
  const files = collect(ROOT, '', skipTop).map(f => ({ path: top + f.path, data: f.data }));
  ['output', 'uploads'].forEach(d => files.push({ path: top + d + '/.keep', data: Buffer.alloc(0) }));
  sendZip(res, `EffectStudio-${VERSION}-${stamp().slice(0, 8)}.zip`, files);
}

// ================= 【区域G 网址路由】 =================
http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const ra = req.socket.remoteAddress || '';
  if (!/^(127\.|::1$|::ffff:127\.)/.test(ra)) { res.writeHead(403); return res.end('forbidden'); }
  try {
    // 会写文件的操作，要求网页带上 X-FX 标记（别的网站没法偷偷往你电脑里写东西）
    const guard = () => req.method === 'POST' && req.headers['x-fx'] === '1';
    if (url.pathname === '/api/effects') return send(res, 200, listEffects());
    if (url.pathname === '/api/info') {
      const b = findBrowser();
      return send(res, 200, { version: VERSION, ffmpeg: !!findFfmpeg(), browser: b ? b.kind : null, launcher: !!process.env.FX_LAUNCHER });
    }
    if (url.pathname === '/api/export' && req.method === 'POST') {
      const b = await readBody(req);
      if (!listEffects().some((e) => e.id === b.effect)) return send(res, 400, { error: 'unknown effect' });
      const o = { effect: b.effect, name: String(b.name || ''), params: b.params || {}, width: Math.min(7680, Math.max(16, b.width | 0 || 1920)), height: Math.min(7680, Math.max(16, b.height | 0 || 1080)),
        fps: Math.min(120, Math.max(1, +b.fps || 30)), hold: Math.max(0, +b.hold || 0) };
      const id = String(Date.now()); jobs[id] = { status: 'running', progress: 0 };
      runExport(jobs[id], o).catch((e) => { jobs[id].status = 'error'; jobs[id].message = e.message; console.error(e); });
      return send(res, 200, { id });
    }
    if (url.pathname === '/api/job') return send(res, 200, jobs[url.searchParams.get('id')] || { status: 'error', message: 'job not found' });
    if (url.pathname === '/api/open-output') {
      fs.mkdirSync(OUT, { recursive: true });
      const cmd = process.platform === 'win32' ? 'explorer' : process.platform === 'darwin' ? 'open' : 'xdg-open';
      exec(`${cmd} "${OUT}"`); return send(res, 200, { ok: true });
    }
    if (url.pathname === '/api/upload-video') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return await handleVideoUpload(req, res); }
    if (url.pathname === '/api/upload') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return await handleUpload(req, res); }
    if (url.pathname === '/api/install') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return await handleInstall(req, res, url); }
    if (url.pathname === '/api/update/check') {
      try { return send(res, 200, { ok: true, autoCheck: updater.config().autoCheck, ...(await updater.check(VERSION, url.searchParams.get('force') === '1')) }); }
      catch (e) { return send(res, 200, { ok: false, autoCheck: updater.config().autoCheck, error: e.message }); }
    }
    if (url.pathname === '/api/update/apply') {
      if (!guard()) return send(res, 403, { error: 'forbidden' });
      try { return await handleUpdateApply(req, res); } catch (e) { return send(res, 200, { error: e.message }); }
    }
    if (url.pathname === '/api/space') return send(res, 200, { groups: spaceGroups(), keep: KEEP_BACKUPS });
    if (url.pathname === '/api/space/clean' && req.method === 'POST') {
      if (!guard()) return send(res, 403, { error: 'forbidden' });
      const b = await readBody(req);
      return send(res, 200, cleanSpace(Array.isArray(b.keys) ? b.keys : []));
    }
    if (url.pathname === '/api/effect-zip') return handleEffectZip(res, url.searchParams.get('id') || '');
    if (url.pathname === '/api/studio-zip') return handleStudioZip(res);
    // 静态文件：/effects/... 和 /uploads/... 从对应文件夹读，其余从 public 读
    let p = decodeURIComponent(url.pathname); if (p === '/') p = '/index.html';
    const base = p.startsWith('/effects/') || p.startsWith('/uploads/') ? ROOT : PUBLIC;
    const fp = path.normalize(path.join(base, p));
    if (!fp.startsWith(base) || !fs.existsSync(fp) || fs.statSync(fp).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
    const type = MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream', size = fs.statSync(fp).size;
    const cache = p.startsWith('/uploads/') ? 'max-age=3600' : 'no-store';          // 上传的图片 / 视频帧不会变，可以缓存
    const rg = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (rg && size) {                                              // 视频拖动进度条要用「只读一段」
      let a = rg[1] === '' ? Math.max(0, size - +rg[2]) : +rg[1], b = rg[1] !== '' && rg[2] !== '' ? Math.min(+rg[2], size - 1) : size - 1;
      if (a > b || a >= size) { res.writeHead(416, { 'Content-Range': `bytes */${size}` }); return res.end(); }
      res.writeHead(206, { 'Content-Type': type, 'Content-Range': `bytes ${a}-${b}/${size}`, 'Accept-Ranges': 'bytes', 'Content-Length': b - a + 1, 'Cache-Control': cache });
      return fs.createReadStream(fp, { start: a, end: b }).pipe(res);
    }
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': size, 'Accept-Ranges': 'bytes', 'Cache-Control': cache });
    fs.createReadStream(fp).pipe(res);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: e.message }); else res.end();
  }
}).on('error', (e) => {
  const u = `http://localhost:${PORT}`;
  if (e.code === 'EADDRINUSE') {
    // 已经开着一个工作台了：直接打开网页就行
    console.log('效果工坊已经在运行，直接打开网页：' + u);
    if (process.platform === 'win32') exec(`start "" ${u}`); else if (process.platform === 'darwin') exec(`open ${u}`);
    setTimeout(() => process.exit(0), 500); return;
  }
  console.error(e); process.exit(1);
}).listen(PORT, () => {
  const u = `http://localhost:${PORT}`;
  console.log(`\n  效果工坊 ${VERSION} 已启动：${u}\n  （用的时候不要关这个黑窗口；关掉窗口 = 关掉工作台）\n`);
  if (process.env.FX_NO_OPEN) return;
  if (process.platform === 'win32') exec(`start "" ${u}`); else if (process.platform === 'darwin') exec(`open ${u}`);
});
