// 效果工坊 · 关键帧轨道
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 关键帧轨道（v6.8） =================
// 播放器下面那条长条。关键帧数据在效果里（params.keys），这里通过效果暴露的
// window.__fxKeysApi 读写；改完让效果重画一帧，不走 reinit（不然会跳回 0 秒重播）。
const kfT = $('#kft'), kfTrack = $('#kft-t');
const KF_LANES = [['P', '位置（左键拖）', 'p'], ['S', '大小（滚轮）', 's'], ['R', '旋转（右键拖）', 'r']];
let kfSel = new Set(), kfDrag = null;
// v12.1：选中的是组合（预合成）时，这条轨道显示 / 编辑的是组合自己的关键帧（window.__kfGroupApi 由素材时间线提供），
// 时间也换成组合里的时间（从组合开头算）。没选组合时和以前完全一样。
const kfGrp = () => { try { return window.__kfGroupApi ? window.__kfGroupApi() : null; } catch (e) { return null; } };
const kfApi = () => { const g = kfGrp(); if (g) return g; try { return frame.contentWindow.__fxKeysApi || null; } catch (e) { return null; } };
const kfHas = () => !!kfGrp() || !!(cur && cur.params.some(p => p.key === 'keys'));
const kfD = () => { const g = kfGrp(); return g ? g.dur() : dur; };                 // 轨道代表的总时长
const kfNow = () => { const g = kfGrp(); return g ? g.now() : (+slider.value || 0); };  // 播放头在第几秒
const kfGo = t => { const g = kfGrp(); if (g) g.seek(t); else { stop(); seek(t); } };   // 跳到第几秒
const kfLanes = () => { const g = kfGrp(); return g && g.lanes ? g.lanes() : KF_LANES; };
// 只移动选中的点：base 是快照，sel 是快照里的序号；排序规则和效果里一致（按时间，同一时间按 P/R/S）
function kfMoveSel(api, base, sel, dt) {
  const L = base.map((k, i) => Object.assign({}, k, { _s: sel.has(i) }));
  L.forEach(k => { if (k._s) k.t = kfClamp(k.t + dt); });
  L.sort((a, b) => a.t - b.t || 'prs'.indexOf(a.k) - 'prs'.indexOf(b.k));
  kfSel = new Set(L.map((k, i) => (k._s ? i : -1)).filter(i => i >= 0));
  api.set(L.map(k => { const c = Object.assign({}, k); delete c._s; return c; }));
}
const kfClamp = t => Math.max(0, Math.min(kfD() || 0.01, Math.round(t * 100) / 100));
function kfTrackDraw() { kfTrackDrawRun(); Hooks.run('kfTrackDraw'); }   // 挂钩：19-empty-state.js（空状态隐藏、自动折叠 / 展开）
function kfTrackDrawRun() {
  if (!kfT) return;
  const api = kfApi();
  const kfAddB = $('#kfadd');
  const kfE = $('#kfedge');
  if (!kfHas() || !api) { kfT.hidden = true; if (kfAddB) kfAddB.hidden = true; if (kfE) kfE.hidden = true; return; }
  kfT.hidden = false;
  if (kfE) {                                     // 关键帧之外：回到默认 / 保持首尾（v8.1）
    const op = api.opt ? api.opt() : null;
    kfE.hidden = !op;
    if (op) kfE.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === op.edge));
  }
  if (kfAddB) { kfAddB.hidden = false; kfAddB.textContent = '◆ 在 ' + kfNow().toFixed(2) + ' 秒打关键帧'; }
  const list = api.get(), D = kfD() || 0.01, LN = kfLanes();
  kfTrack.style.height = LN.length * 24 + 'px';
  const gH = $('#kft-h b'); if (gH) gH.textContent = kfGrp() ? '组合的关键帧' : '关键帧';
  const pos = t => Math.max(0, Math.min(100, t / D * 100));
  // AE 式三行：P 位置 / S 大小 / R 旋转，每个点画在自己那一行
  let html = LN.map((l, r) => '<div class="kfln" style="top:' + r * 24 + 'px" title="' + l[1] + '"><b>' + l[0] + '</b></div>').join('');
  let inner = '';
  LN.forEach((l, r) => {
    const L = list.filter(k => k.k === l[2]);
    if (L.length > 1) inner += '<div class="kfspan" style="top:' + r * 24 + 'px;left:' + pos(L[0].t) + '%;width:' + (pos(L[L.length - 1].t) - pos(L[0].t)) + '%"></div>';
  });
  list.forEach((k, i) => {
    const r = Math.max(0, LN.findIndex(l => l[2] === k.k));
    const v = k.k === 'o' ? '不透明度 ' + Math.round(k.o) + '%' : k.k === 'p' ? '位置 X ' + k.ox + '  Y ' + k.oy : k.k === 's' ? '大小 ' + Math.round(k.s * 100) + '%' : '旋转 X ' + k.x + '°  Y ' + k.y + '°  Z ' + k.z + '°';
    inner += '<div class="kfp' + (kfSel.has(i) ? ' on' : '') + '" data-i="' + i + '" style="top:' + (r * 24 + 6) + 'px;left:' + pos(k.t) + '%" title="' + k.t.toFixed(2) + 's　' + v + '"></div>';
  });
  inner += '<div class="kfhead" style="left:' + pos(kfNow()) + '%"></div>';
  if (kfDrag && kfDrag.band) inner += '<div class="kfband" style="left:' + Math.min(kfDrag.band[0], kfDrag.band[1]) + '%;width:' + Math.abs(kfDrag.band[1] - kfDrag.band[0]) + '%;top:' + kfDrag.rows[0] * 24 + 'px;height:' + (kfDrag.rows[1] - kfDrag.rows[0] + 1) * 24 + 'px;bottom:auto"></div>';
  kfTrack.innerHTML = html + '<div class="kfin">' + inner + '</div>';
  $('#kft-n').textContent = list.length ? '（' + list.length + ' 个' + (kfSel.size ? '，选中 ' + kfSel.size + ' 个' : '') + '）' : '（还没有）';
  $('#kft-e').textContent = kfGrp() ? (!list.length ? '这是整个组合的关键帧：把进度条拖到某一秒，在预览区左键拖 → P、滚轮 → S、右键拖 → R（右侧不透明度 → O），就在那一秒打一个点。要改组合里的单个素材，在预览区双击它（或双击时间线上的组合条）进去改，Esc 退出来。'
      : '组合整体的动画：P 位置 / S 大小 / R 旋转 / O 不透明度，每一行各管各的。第一个点之前、最后一个点之后保持首尾。双击画面里的素材进去改单个素材，Esc 退出来。')
    : !api.enabled() ? '关键帧动画已关闭（右侧面板里可以打开）'
    : !list.length ? '和 AE 一样分三行：左键拖位置 → P，滚轮缩放 → S，右键转角度 → R。把进度条拖到某一秒再操作，松手就在对应那一行打一个点。'
      : '三行各管各的：P 只管位置、S 只管大小、R 只管旋转。每一行第一个点之前、最后一个点之后回到默认值，效果自带的开场和结尾原样保留。';
}
const kfIn = () => { const r = kfTrack.getBoundingClientRect(); return { left: r.left + 24, width: Math.max(1, r.width - 30), top: r.top }; };
const kfRow = e => Math.max(0, Math.min(kfLanes().length - 1, Math.floor((e.clientY - kfIn().top) / 24)));
const kfXToT = e => { const r = kfIn(); return kfClamp((e.clientX - r.left) / r.width * (kfD() || 0.01)); };
// 拖播放头：画面跟着走；直接改播放头位置，不等 seek 里 60ms 的节流
function kfScrub(e) {
  const t = kfXToT(e); if (kfGrp()) kfGo(t); else seek(t);
  const h = kfTrack.querySelector('.kfhead'); if (h) h.style.left = Math.max(0, Math.min(100, t / (kfD() || 0.01) * 100)) + '%';
  const kb = $('#kfadd'); if (kb && !kb.hidden) kb.textContent = '◆ 在 ' + t.toFixed(2) + ' 秒打关键帧';
}
const kfPct = e => { const r = kfIn(); return Math.max(0, Math.min(100, (e.clientX - r.left) / r.width * 100)); };
kfTrack.addEventListener('mousedown', e => {
  const api = kfApi(); if (!api || e.button !== 0) return;
  kfTrack.focus();
  if (e.target.classList && e.target.classList.contains('kfhead')) {   // 拖播放头 = 拖时间（v8.2）
    if (!kfGrp()) stop(); kfDrag = { scrub: true }; kfTrack.classList.add('scrub'); kfScrub(e); e.preventDefault(); return;
  }
  const hit = e.target.classList && e.target.classList.contains('kfp') ? +e.target.dataset.i : -1;
  if (hit >= 0) {
    if (e.shiftKey || e.ctrlKey) { kfSel.has(hit) ? kfSel.delete(hit) : kfSel.add(hit); }
    else if (!kfSel.has(hit)) { kfSel = new Set([hit]); }
    kfDrag = { move: true, x: e.clientX, base: api.get(), sel: new Set(kfSel) };
    kfTrack.classList.add('drag');
  } else {
    if (!e.shiftKey && !e.ctrlKey) kfSel = new Set();
    kfDrag = { band: [kfPct(e), kfPct(e)], r0: kfRow(e), rows: [kfRow(e), kfRow(e)], add: new Set(kfSel), x0: e.clientX, t0: kfXToT(e) };
  }
  kfTrackDraw(); e.preventDefault();
});
addEventListener('mousemove', e => {
  if (!kfDrag) return;
  if (kfDrag.scrub) { kfScrub(e); return; }
  const api = kfApi(); if (!api) return;
  if (kfDrag.move) {
    const dt = (e.clientX - kfDrag.x) / kfIn().width * (kfD() || 0.01);
    kfMoveSel(api, kfDrag.base, kfDrag.sel, dt);
    kfTrackDraw();
    $('#hint').textContent = '移动 ' + kfSel.size + ' 个关键帧：' + (dt >= 0 ? '+' : '') + dt.toFixed(2) + ' 秒';
  } else if (kfDrag.band) {
    kfDrag.band[1] = kfPct(e);
    const rr = kfRow(e); kfDrag.rows = [Math.min(kfDrag.r0, rr), Math.max(kfDrag.r0, rr)];
    const D = kfD() || 0.01, a = Math.min(kfDrag.band[0], kfDrag.band[1]) / 100 * D, b = Math.max(kfDrag.band[0], kfDrag.band[1]) / 100 * D;
    const ks = kfLanes().slice(kfDrag.rows[0], kfDrag.rows[1] + 1).map(l => l[2]);   // 框到哪几行就只选那几行
    kfSel = new Set(kfDrag.add);
    api.get().forEach((k, i) => { if (ks.includes(k.k) && k.t >= a - 0.02 && k.t <= b + 0.02) kfSel.add(i); });
    kfTrackDraw();
  }
});
addEventListener('mouseup', e => {
  if (!kfDrag) return;
  const wasMove = kfDrag.move, d = kfDrag;
  kfDrag = null; kfTrack.classList.remove('drag', 'scrub');
  if (d.band && Math.abs(e.clientX - d.x0) < 4) kfGo(d.t0);   // 空白处单击（没拖开）= 跳到那一秒（v8.2）
  kfTrackDraw();
  if (wasMove) toast('关键帧已移动');
});
$('#kfadd').addEventListener('click', () => {
  const api = kfApi(); if (!api) return;
  const t = kfClamp(kfNow());
  api.addAt(t); kfTrackDraw(); toast('已在 ' + t.toFixed(2) + ' 秒给 ' + kfLanes().map(l => l[0]).join(' / ') + ' 几行都打上关键帧');
});
$('#kfedge').querySelectorAll('button').forEach(b => b.addEventListener('click', () => {
  const api = kfApi(); if (!api || !api.setOpt) return;
  api.setOpt({ edge: b.dataset.v }); kfTrackDraw();
  toast(b.dataset.v === 'hold' ? '关键帧之外：保持首尾 —— 开头停在第一个关键帧、结尾停在最后一个关键帧的样子'
    : '关键帧之外：回到默认 —— 第一个关键帧之前、最后一个之后回到默认值，效果自带的开场和结尾原样保留');
}));
kfTrack.addEventListener('dblclick', e => {
  const api = kfApi(); if (!api) return;
  if (e.target.classList && e.target.classList.contains('kfp')) return;
  const t = kfXToT(e), l = kfLanes()[kfRow(e)]; if (kfGrp()) kfGo(t); else { seek(t); slider.value = t; }
  api.addAt(t, l[2]); kfTrackDraw(); toast('已在 ' + t.toFixed(2) + ' 秒给【' + l[0] + ' ' + l[1].replace(/（.*/, '') + '】打一个关键帧');
});
// ---- Ctrl+C / Ctrl+V 复制粘贴关键帧（和 AE 一样：粘贴到当前播放头那一秒，保持各点之间的间隔和所在的行） ----
let kfClip = null;
addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
  const key = e.key.toLowerCase(); if (key !== 'c' && key !== 'v') return;
  const a = document.activeElement;                       // 在输入框里打字时不抢 Ctrl+C / V
  if (a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && a.type !== 'range') || a.isContentEditable)) return;
  if (getSelection && String(getSelection()).trim()) return;   // 选中了页面文字就照常复制文字
  const api = kfApi(); if (!api || kfT.hidden) return;
  if (key === 'c') {
    if (!kfSel.size) return;
    const list = api.get(), picked = [...kfSel].sort((x, y) => x - y).map(i => list[i]).filter(Boolean);
    const t0 = Math.min(...picked.map(k => k.t));
    kfClip = picked.map(k => Object.assign({}, k, { t: k.t - t0 }));     // 存相对时间
    toast('已复制 ' + kfClip.length + ' 个关键帧 · 把进度条拖到别的位置，按 Ctrl+V 粘贴');
  } else {
    if (!kfClip || !kfClip.length) { toast('还没有复制关键帧（先选中点，按 Ctrl+C）'); return; }
    const at = kfClamp(kfNow());
    const add = kfClip.map(k => Object.assign({}, k, { t: kfClamp(at + k.t), _s: true }));
    // 同一行 0.04 秒内已有的点会被粘贴的点替换
    const L = api.get().filter(o => !add.some(n => n.k === o.k && Math.abs(n.t - o.t) < 0.04)).concat(add);
    L.sort((x, y) => x.t - y.t || 'prs'.indexOf(x.k) - 'prs'.indexOf(y.k));
    kfSel = new Set(L.map((k, i) => (k._s ? i : -1)).filter(i => i >= 0));   // 粘贴后选中刚贴的点，可以直接拖
    api.set(L.map(k => { const c = Object.assign({}, k); delete c._s; return c; }));
    kfTrackDraw(); toast('已在 ' + at.toFixed(2) + ' 秒粘贴 ' + add.length + ' 个关键帧');
  }
  e.preventDefault();
});
kfTrack.addEventListener('keydown', e => {
  const api = kfApi(); if (!api || !kfSel.size) return;
  if (e.key === 'Delete' || e.key === 'Backspace') {
    const list = api.get().filter((k, i) => !kfSel.has(i));
    kfSel = new Set(); api.set(list); kfTrackDraw(); toast('已删除关键帧'); e.preventDefault();
  } else if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
    const d = (e.key === 'ArrowLeft' ? -1 : 1) * (e.shiftKey ? 0.5 : 0.05);
    kfMoveSel(api, api.get(), new Set(kfSel), d); kfTrackDraw(); e.preventDefault();
  }
});
