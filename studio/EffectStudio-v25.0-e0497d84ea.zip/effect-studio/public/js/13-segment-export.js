// 效果工坊 · 分段导出 · 导出弹窗 / 导出窗口
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ---------- 分段导出（v15.0）：按空白自动分段 → 段色带上拖入点 / 出点微调 → 勾选逐段导出 ----------
// 有素材的地方连成一段，中间完全空白的地方断开；标成「参照」的素材（比如垫在底下的原视频）不参与分段、也不导出。
// 手动调过的入点 / 出点存成「相对自动结果的偏移」，素材挪一点也跟着走；双击色带还原成自动结果。
const lenOf = c => c._len != null ? c._len : c.len;
let segFix = store.get('segFix', []);                // [{ a0, b0, da, db, name, off }]
const segSave = () => store.set('segFix', segFix);
function segAuto() {
  const iv = TL.clips.filter(c => !c.ref).map(c => [c.start, c.start + lenOf(c)]).sort((a, b) => a[0] - b[0]), out = [];
  iv.forEach(([a, b]) => { const L = out[out.length - 1]; if (L && a <= L[1] + 0.0001) L[1] = Math.max(L[1], b); else out.push([a, b]); });
  return out.map(([a, b]) => [r2(a), r2(b)]);
}
function segs() {
  const used = new Set();
  const out = segAuto().map(([a0, b0]) => {
    let bi = -1, bo = -1;
    segFix.forEach((f, i) => { if (used.has(i)) return; const o = Math.min(b0, f.b0) - Math.max(a0, f.a0); if (o > bo && o > -0.0001) { bo = o; bi = i; } });
    const f = bi >= 0 ? segFix[bi] : null; if (f) { used.add(bi); f.a0 = a0; f.b0 = b0; }
    return { a0, b0, f };
  });
  segFix = out.filter(s => s.f).map(s => s.f);
  let prev = 0;
  out.forEach((s, i) => {
    const f = s.f || {};
    s.i = i; s.a = r2(Math.max(prev, s.a0 + (f.da || 0))); s.b = r2(Math.max(s.a + 0.1, s.b0 + (f.db || 0))); prev = s.b;
    s.name = f.name || ''; s.on = !f.off; s.edited = !!(f.da || f.db);
    const hit = TL.clips.filter(c => !c.ref && c.start < s.b - 0.0001 && s.a < c.start + lenOf(c) - 0.0001);
    const gs = new Set(hit.map(c => c.group).filter(Boolean));
    s.clips = TL.clips.filter(c => hit.includes(c) || (c.group && gs.has(c.group)));
    s.n = hit.length;
  });
  return out;
}
const fixOf = s => { if (!s.f) { s.f = { a0: s.a0, b0: s.b0, da: 0, db: 0 }; segFix.push(s.f); } return s.f; };
const fmtT = t => Math.floor(t / 60) + ':' + (t % 60).toFixed(1).padStart(4, '0');

const sgRow = document.createElement('div'); sgRow.id = 'tlp-sg';
sgRow.innerHTML = '<div class="sgn">分段</div><div id="tlp-st"></div>';
$('#tlp-b').after(sgRow);
const sgT = $('#tlp-st');
const sgBar = document.createElement('div'); sgBar.id = 'tlp-sgh';
sgBar.hidden = true;   // v21.0：说明挪进第 1 段色带里，「设为参照」挪到标题栏，这一行不再占地方
sgBar.innerHTML = '<button type="button" id="sg-ref" title="把选中的素材标成「参照」：只在预览里垫着对照时间，不参与分段、不会被导出（再点一次取消）">把选中的素材设为参照</button>';
sgRow.after(sgBar);
function segDraw() {
  const has = TL.clips.length > 0; sgRow.style.display = sgBar.style.display = has ? '' : 'none';
  TL.clips.forEach(c => { if (c.ref) { const el = trk.querySelector('.tlc[data-id="' + c.id + '"]'); if (el) { el.classList.add('ref'); el.title = '【参照：不参与分段、不导出】' + el.title; } } });
  if (!has) { sgT.innerHTML = ''; return; }
  const V = tlV; let h = '';
  segs().forEach(s => {
    h += '<div class="sgb' + (s.on ? '' : ' off') + (s.edited ? ' ed' : '') + '" data-i="' + s.i + '" style="left:' + s.a / V * 100 + '%;width:' + Math.max(0.3, (s.b - s.a) / V * 100) + '%" title="第 ' + (s.i + 1) + ' 段　' + fmtT(s.a) + ' → ' + fmtT(s.b) + '（' + (s.b - s.a).toFixed(2) + ' 秒 · ' + s.n + ' 个素材）' + (s.edited ? '\n手动调过（双击还原成自动判断）' : '') + '\n拖左右两头的竖条：改入点 / 出点；点一下：跳到这一段开头">' +
      '<i class="sgh l"></i><b>' + (s.i + 1) + '</b>' + (s.edited ? '✎' : '') + ' ' + esc(s.name || '') + (s.i === 0 ? '<span class="sgtip">分段导出：空白处自动断开 · 拖两头竖条改入点 / 出点 · 双击还原</span>' : '') + '<i class="sgh r"></i></div>';
  });
  sgT.innerHTML = h;
}
Hooks.on('tlDraw', () => segDraw());
let sgDrag = null;
sgT.addEventListener('mousedown', e => {
  const b = e.target.closest('.sgb'); if (!b || e.button) return;
  const s = segs()[+b.dataset.i]; if (!s) return;
  if (e.target.classList.contains('sgh')) { sgDrag = { i: s.i, side: e.target.classList.contains('l') ? 'a' : 'b' }; document.body.style.cursor = 'ew-resize'; e.preventDefault(); }
  else { tlStop(); tlSeek(s.a); }
});
sgT.addEventListener('dblclick', e => {
  const b = e.target.closest('.sgb'); if (!b) return;
  const s = segs()[+b.dataset.i]; if (s && s.f) { s.f.da = s.f.db = 0; segSave(); segDraw(); toast('第 ' + (s.i + 1) + ' 段已还原成自动判断的范围'); }
});
addEventListener('mousemove', e => {
  if (!sgDrag) return;
  const r = sgT.getBoundingClientRect(), tol = 6 / r.width * tlV;
  let t = Math.max(0, (e.clientX - r.left) / r.width * tlV);
  const pts = [tlT]; TL.clips.forEach(c => { if (!c.ref) pts.push(c.start, c.start + lenOf(c)); });   // 吸附：播放头、素材头尾
  pts.forEach(p => { if (Math.abs(p - t) < tol) t = p; });
  const s = segs()[sgDrag.i]; if (!s) return; const f = fixOf(s);
  if (sgDrag.side === 'a') f.da = r2(Math.min(t, s.b - 0.1) - s.a0); else f.db = r2(Math.max(t, s.a + 0.1) - s.b0);
  segDraw();
});
addEventListener('mouseup', () => { if (!sgDrag) return; sgDrag = null; document.body.style.cursor = ''; segSave(); });
const sgRefToggle = $('#sg-ref').onclick = () => {
  const cs = (tlGrp ? TL.clips.filter(o => o.group === tlGrp) : tlMulti.size > 1 ? [...tlMulti].map(clip) : [clip(tlSel)]).filter(Boolean);
  if (!cs.length) return toast('先在时间线上点选一个素材（比如垫在底下的原视频）', true);
  const on = !cs.every(c => c.ref); cs.forEach(c => { if (on) c.ref = true; else delete c.ref; });
  tlSave(); tlDraw();
  toast(on ? '已设为参照：只在预览里垫着对照，不参与分段、不导出' : '已取消参照，它又会参与分段和导出');
};

// ---------- 导出：时间线上有素材时，弹窗选「勾选的段逐段导出」或「整条时间线」（v15.0） ----------
async function runJob(body, onP) {
  const r = await (await fetch('/api/export', { method: 'POST', body: JSON.stringify(body) })).json();
  if (r.error) throw new Error(r.error === 'unknown effect' ? '时间线里有效果找不到了' : r.error);
  while (true) {
    await new Promise(r => setTimeout(r, 500));
    const j = await (await fetch('/api/job?id=' + r.id)).json();
    onP(j);
    if (j.status === 'done') return j.file;
    if (j.status === 'error') throw new Error(j.message);
  }
}
const compOf = (cs, range) => {
  cs = cs.filter(c => !c.hide);                       // 眼睛关掉的层不导出（v24.10）
  const gs = new Set(cs.map(c => c.group).filter(Boolean));
  const o = { clips: cs.map(c => ({ id: c.id, fx: c.fx, params: c.params, start: c.start, len: c.len, group: c.group || null, z: zOf(c) })), groups: TL.groups.filter(g => gs.has(g.id)) };
  if (range) o.range = range; return o;
};
// ---------- 导出窗口（v18.0）：居中、背景模糊变暗；左边预览、右边每段的名字、底部进度条 ----------
// 每段一个 MOV（文件名写「放在原视频 X分X秒X帧」+ 里面写时间码），再加一个 XML（PR 导入 → 另存 prproj → 剪映导入）和使用说明，都放在同一个子文件夹里。
const p2 = n => String(n).padStart(2, '0');
const srcT = s => s.a + (REF ? REF.in : 0);                       // 这一段在原视频里的时间
const posName = (t, fps) => { const f = Math.round(t * fps), r = Math.round(fps); return p2(Math.floor(f / r / 60)) + '分' + p2(Math.floor(f / r) % 60) + '秒' + p2(f % r) + '帧'; };
const cleanNm = v => String(v || '').replace(/[\\/:*?"<>|]/g, '').trim();
const fileOf = (s, label, fps) => '②段' + p2(s.i + 1) + '_' + (cleanNm(label) ? cleanNm(label) + '_' : '') + '放在原视频' + posName(srcT(s), fps);
const _exp = $('#export').onclick;
$('#export').onclick = () => {
  if (!TL.clips.length) return _exp();
  tlStop(); stop(); syncSel();
  const S = segs(), refs = TL.clips.filter(c => c.ref), real = TL.clips.filter(c => !c.ref);
  if (!real.length) return toast('时间线上的素材全都标成了「参照」，没有可导出的效果', true);
  const { w, h } = res(), fps = +$('#fps').value || 30, base = { width: w, height: h, fps, hold: +$('#hold').value || 0 };
  const d = new Date(), dir = cleanNm('分段导出_' + (REF ? REF.name : '时间线') + '_' + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes()));
  const m = document.createElement('div'); m.className = 'xpm';
  m.innerHTML = '<div class="xpd"><div class="xph"><b>导出</b><span>共 ' + S.length + ' 段 · 存到 output\\' + esc(dir) + '</span><button type="button" class="xpx" title="关闭">✕</button></div>' +
    '<div class="xpb"><div class="xpv"><div class="xpst"><div class="xpsc"></div></div><div class="xpcap"></div></div><div class="xpl">' +
    S.map(s => '<div class="xpr" data-i="' + s.i + '"><input type="checkbox"' + (s.on ? ' checked' : '') + ' title="导出这一段"><div class="xprm"><div class="xpr1"><b>段 ' + p2(s.i + 1) + '</b><span>原视频 ' + fmtT(srcT(s)) + ' → ' + fmtT(srcT(s) + s.b - s.a) + ' · ' + (s.b - s.a).toFixed(1) + ' 秒 · ' + s.n + ' 个效果</span><em class="xpst1"></em></div>' +
      '<input class="xpn" placeholder="备注（可不填，例如：开场标题）" value="' + esc(s.name) + '"><div class="xpf"></div><i class="xpbar"><i></i></i></div></div>').join('') +
    '</div></div><div class="xpft"><div class="xppg"><i></i></div><div class="xpmsg">' + (refs.length ? '参照素材不导出：' + refs.map(c => esc((fxOf(c) || {}).name || c.fx)).join('、') + '。' : '') + '每段一个透明 MOV，另附一个 XML（Premiere 导入 → 另存 prproj → 剪映导入，自动摆好位置）。</div>' +
    '<div class="xpbt"><button type="button" class="xpall">导出整条时间线（一个文件）</button><button type="button" class="xpgo pri"></button></div></div></div>';
  document.body.appendChild(m);
  const $$ = q => m.querySelector(q), rows = [...m.querySelectorAll('.xpr')], go = $$('.xpgo'), msg = $$('.xpmsg'), pg = $$('.xppg i');
  let busy = false, cur = -1;
  const sync = () => {
    rows.forEach((r, k) => { r.querySelector('.xpf').textContent = fileOf(S[k], r.querySelector('.xpn').value, fps) + '.mov'; r.classList.toggle('off', !r.querySelector('input[type=checkbox]').checked); });
    const n = rows.filter(r => r.querySelector('input[type=checkbox]').checked).length; go.textContent = '开始导出 ' + n + ' 段'; go.disabled = busy || !n;
  };
  // 左边预览：真正导出用的合成页（comp.html），停在这一段中间；下面垫着原视频同一时刻的画面
  const st = $$('.xpsc'), vw = 420, k = vw / w;
  st.style.cssText = 'width:' + w + 'px;height:' + h + 'px;transform:scale(' + k + ')';
  $$('.xpst').style.height = h * k + 'px';
  let fr = null, vid = null;
  if (REF) { vid = document.createElement('video'); vid.muted = true; vid.src = REF.url; vid.preload = 'auto'; st.appendChild(vid); }
  function show(i) {
    if (i === cur || !S[i]) return; cur = i; const s = S[i], mid = (s.b - s.a) / 2;
    rows.forEach((r, j) => r.classList.toggle('sel', j === i));
    $$('.xpcap').textContent = '段 ' + p2(i + 1) + ' · 预览这一段中间（原视频 ' + fmtT(srcT(s) + mid) + '）';
    if (vid) vid.currentTime = srcT(s) + mid;
    if (fr) fr.remove(); fr = document.createElement('iframe'); fr.src = '/comp.html'; st.appendChild(fr);
    fr.onload = async () => { try { const W = fr.contentWindow; W.init(compOf(s.clips, [s.a, s.b])); await W.whenReady(); if (cur === i) W.renderAt(mid); } catch (e) { } };
  }
  rows.forEach((r, i) => { r.addEventListener('mouseenter', () => !busy && show(i)); r.addEventListener('focusin', () => !busy && show(i)); r.addEventListener('input', sync); r.addEventListener('change', sync); });
  const close = () => { if (busy) return toast('正在导出，等它跑完再关', true); m.remove(); };
  $$('.xpx').onclick = close; m.addEventListener('mousedown', e => { if (e.target === m) close(); });
  const save = () => S.forEach((s, i) => { const on = rows[i].querySelector('input[type=checkbox]').checked, nm = rows[i].querySelector('.xpn').value.trim(); if (on !== s.on || nm !== s.name) { const f = fixOf(s); f.off = !on; f.name = nm; } s.on = on; s.name = nm; });
  const lock = on => { busy = on; m.classList.toggle('busy', on); m.querySelectorAll('input,.xpall').forEach(x => x.disabled = on); sync(); };
  const done = (html) => { lock(false); msg.innerHTML = html; go.textContent = '完成'; go.disabled = false; go.onclick = () => m.remove(); };
  const openBtn = () => '<a href="#" class="xpopen">打开文件夹</a>';
  m.addEventListener('click', e => { if (e.target.classList.contains('xpopen')) { e.preventDefault(); fetch('/api/open-output?dir=' + encodeURIComponent(dir)); } });
  $$('.xpall').onclick = async () => {
    save(); segSave(); segDraw(); lock(true); show(0);
    try {
      const file = await runJob(Object.assign({ comp: compOf(real), name: 'timeline', dir, tc: REF ? REF.in : 0 }, base), j => { pg.style.width = (j.progress * 100 || 0) + '%'; msg.textContent = j.stage || ('正在导出整条时间线… ' + Math.round((j.progress || 0) * 100) + '%'); });
      done('✓ 完成：output\\' + esc(file.replace('/', '\\')) + '　' + openBtn());
    } catch (e) { done('出错：' + esc(e.message)); }
  };
  go.onclick = async () => {
    save(); segSave(); segDraw();
    const todo = S.filter((s, i) => rows[i].querySelector('input[type=checkbox]').checked); if (!todo.length) return;
    lock(true); rows.forEach(r => { r.querySelector('.xpst1').textContent = ''; r.classList.remove('ok', 'bad', 'run'); });
    const ok = [], bad = [];
    for (let n = 0; n < todo.length; n++) {
      const s = todo[n], r = rows[s.i], bar = r.querySelector('.xpbar i'), name = fileOf(s, s.name, fps);
      show(s.i); r.classList.add('run'); r.querySelector('.xpst1').textContent = '导出中…'; r.scrollIntoView({ block: 'nearest' });
      try {
        await runJob(Object.assign({ comp: compOf(s.clips, [s.a, s.b]), name, dir, tc: srcT(s) }, base), j => {
          const p = j.progress || 0; bar.style.width = p * 100 + '%'; pg.style.width = (n + p) / todo.length * 100 + '%';
          msg.textContent = '第 ' + (n + 1) + ' / ' + todo.length + ' 个 · ' + name + '.mov · ' + (j.stage || Math.round(p * 100) + '%');
        });
        ok.push({ file: name + '.mov', start: srcT(s), dur: s.b - s.a }); r.classList.add('ok'); r.querySelector('.xpst1').textContent = '✓ 完成'; bar.style.width = '100%';
      } catch (e) { bad.push('段 ' + p2(s.i + 1) + '：' + e.message); r.classList.add('bad'); r.querySelector('.xpst1').textContent = '✕ 失败'; }
      r.classList.remove('run');
    }
    pg.style.width = '100%';
    let pk = {}; if (ok.length) try { pk = await (await fetch('/api/export-pack', { method: 'POST', body: JSON.stringify(Object.assign({ dir, items: ok, ref: REF }, base)) })).json(); } catch (e) { pk = { error: e.message }; }
    done((ok.length ? '✓ 已导出 ' + ok.length + ' 段' + (pk.ok ? ' + XML + 使用说明' : '（XML 没写成：' + esc(pk.error || '') + '）') + (pk.ok && !pk.ref ? '（没找到原视频原片，XML 里只有效果）' : '') + ' → output\\' + esc(dir) + '　' + openBtn() : '') + (bad.length ? '<br>失败：' + esc(bad.join('；')) : ''));
  };
  sync(); show(Math.max(0, S.findIndex(s => s.on)));
  const fi = m.querySelector('.xpn'); if (fi) setTimeout(() => fi.focus(), 50);
};
const expLbl = () => { const b = $('#export'); if (!b.disabled) b.textContent = TL.clips.length ? '导出时间线（可分段，透明 MOV）' : '导出透明 MOV'; };
setInterval(expLbl, 700);
