/* 效果工坊 · 启动器（start.bat 会自动运行它）
 *
 * 【第1步 检查环境】每次启动都很快地检查一遍：
 *     - 依赖（Puppeteer）装了没有
 *     - 导出用的浏览器（Puppeteer 自带的 Chrome；没有就用电脑里的 Chrome / Edge）
 *     - FFmpeg（系统里的、runtime\ffmpeg 里的，或者 npm 自动装的那份）
 * 【第2步 缺什么装什么】第一次运行时自动安装，走国内镜像（npmmirror），失败再换官方源
 * 【第3步 启动工作台】运行 server.js 并打开网页
 *     在网页里拖入「整个工作台」的升级包后，server.js 会退出并返回 99，这里自动重新启动它
 */
const fs = require('fs'), path = require('path'), { spawn, spawnSync } = require('child_process');
const ROOT = path.join(__dirname, '..');
const MARK = path.join(ROOT, 'runtime', '.installed');
const MIRROR = {
  npm_config_registry: 'https://registry.npmmirror.com',
  PUPPETEER_CHROME_DOWNLOAD_BASE_URL: 'https://cdn.npmmirror.com/binaries/chrome-for-testing',
  PUPPETEER_CHROME_HEADLESS_SHELL_DOWNLOAD_BASE_URL: 'https://cdn.npmmirror.com/binaries/chrome-for-testing',
};
const log = (...a) => console.log('  ' + a.join(' '));
const line = () => console.log('  ' + '─'.repeat(46));

function pkg() { try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')); } catch (e) { return {}; } }
const has = name => fs.existsSync(path.join(ROOT, 'node_modules', ...name.split('/'), 'package.json'));
const freshEnv = () => require.cache && Object.keys(require.cache).forEach(k => { if (k.includes('node_modules')) delete require.cache[k]; });
function env() { delete require.cache[require.resolve('./env')]; freshEnv(); return require('./env'); }

// 找 npm：优先用 Node 自带的 npm-cli.js（不用依赖系统 PATH）
function npmCmd() {
  const d = path.dirname(process.execPath);
  for (const p of [path.join(d, 'node_modules', 'npm', 'bin', 'npm-cli.js'), path.join(d, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js')])
    if (fs.existsSync(p)) return { cmd: process.execPath, pre: [p], shell: false };
  return { cmd: process.platform === 'win32' ? 'npm.cmd' : 'npm', pre: [], shell: process.platform === 'win32' };
}
function run(cmd, args, extraEnv, shell) {
  const r = spawnSync(cmd, args, { cwd: ROOT, stdio: 'inherit', shell: !!shell, env: { ...process.env, ...extraEnv } });
  return r.status === 0;
}
function npmInstall() {
  const n = npmCmd(), args = [...n.pre, 'install', '--no-audit', '--no-fund', '--loglevel=error'];
  log('正在安装依赖（国内镜像）… 第一次大约需要 1~5 分钟，请不要关闭窗口');
  if (run(n.cmd, args, MIRROR, n.shell)) return true;
  log('国内镜像没装成功，换官方源再试一次…');
  return run(n.cmd, [...args, '--registry=https://registry.npmjs.org', '--replace-registry-host=always'], {}, n.shell);
}
function chromeInstall() {
  const inst = path.join(ROOT, 'node_modules', 'puppeteer', 'install.mjs');
  if (!fs.existsSync(inst)) return false;
  log('正在下载导出用的 Chrome（国内镜像）…');
  if (run(process.execPath, [inst], MIRROR)) return true;
  log('国内镜像没下载成功，换官方地址再试一次…');
  return run(process.execPath, [inst], {});
}

function check() {
  const p = pkg(), deps = Object.keys(p.dependencies || {});
  const missing = deps.filter(d => !has(d));
  const e = env();
  return { missing, ffmpeg: e.findFfmpeg(), browser: e.findBrowser(), optionalMissing: Object.keys(p.optionalDependencies || {}).filter(d => !has(d)) };
}

function prepare() {
  const first = !fs.existsSync(MARK);
  if (first) { console.log(''); line(); log('效果工坊 · 第一次运行，正在检查电脑环境…'); line(); }
  let c = check();
  // 缺依赖，或者找不到 FFmpeg（npm 能顺便装一份）→ npm install
  if (c.missing.length || (!c.ffmpeg && c.optionalMissing.length)) {
    if (!first) log('发现缺少依赖，正在补装…');
    if (!npmInstall()) log('⚠ 依赖没有装成功：请检查网络后，关闭窗口重新双击 start.bat');
    c = check();
  }
  // 导出用的浏览器：Puppeteer 自带的 Chrome 没下载好，就再下载一次（只在第一次安装时自动尝试；电脑里有 Chrome / Edge 也能用）
  if (!c.missing.length && (!c.browser || (first && c.browser.kind !== 'puppeteer'))) {
    chromeInstall(); c = check();
  }
  if (first || c.missing.length || !c.ffmpeg || !c.browser) {
    log('Node.js ' + process.version + '   ✔');
    log('依赖 Puppeteer      ' + (c.missing.length ? '✘ 没装好' : '✔'));
    log('导出用的浏览器      ' + (c.browser ? '✔ ' + (c.browser.kind === 'puppeteer' ? 'Chrome（自带）' : path.basename(c.browser.path)) : '✘ 没找到（导出 MOV 会失败）'));
    log('FFmpeg              ' + (c.ffmpeg ? '✔' : '✘ 没找到（导出 MOV 会失败）'));
    line();
  }
  if (!c.missing.length) {
    fs.mkdirSync(path.dirname(MARK), { recursive: true });
    fs.writeFileSync(MARK, JSON.stringify({ at: new Date().toISOString(), node: process.version, ffmpeg: c.ffmpeg, browser: c.browser }, null, 2));
  }
  return c;
}

function startServer(noOpen) {
  const child = spawn(process.execPath, [path.join(ROOT, 'server.js')], { cwd: ROOT, stdio: 'inherit', env: { ...process.env, FX_LAUNCHER: '1', ...(noOpen ? { FX_NO_OPEN: '1' } : {}) } });
  child.on('exit', code => {
    if (code === 99) { console.log('\n  工作台已升级，正在重新启动…\n'); prepare(); startServer(true); return; }
    process.exit(code || 0);
  });
  // 关窗口 / Ctrl+C 时一起关掉
  ['SIGINT', 'SIGTERM', 'SIGHUP'].forEach(s => process.on(s, () => { try { child.kill(); } catch (e) {} process.exit(0); }));
}

const c = prepare();
if (c.missing.length) { log('依赖没装好，工作台暂时打不开。请检查网络后，关闭窗口重新双击 start.bat。'); process.exit(1); }
startServer(false);
