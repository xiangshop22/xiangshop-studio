/* 效果工坊 · 找工具（启动器 launcher.js 和 server.js 共用）
 *   findFfmpeg()  导出 MOV 用的 FFmpeg：先找 runtime\ffmpeg，再找系统里装的，最后用 npm 自动装的那份
 *   findBrowser() 导出用的浏览器：先用 Puppeteer 自己下载的 Chrome；下载不了就用电脑里的 Chrome / Edge
 */
const fs = require('fs'), path = require('path'), { spawnSync } = require('child_process');
const ROOT = path.join(__dirname, '..');
const WIN = process.platform === 'win32';

function works(bin) {
  try { const r = spawnSync(bin, ['-hide_banner', '-encoders'], { encoding: 'utf8', windowsHide: true, timeout: 15000 }); return r.status === 0 && /prores_ks/.test(r.stdout || ''); } catch (e) { return false; }
}
let ffCache;
function findFfmpeg() {
  if (ffCache !== undefined) return ffCache;
  const exe = WIN ? 'ffmpeg.exe' : 'ffmpeg';
  const list = [path.join(ROOT, 'runtime', 'ffmpeg', 'bin', exe), path.join(ROOT, 'runtime', 'ffmpeg', exe), 'ffmpeg'];
  try { list.push(require(require.resolve('@ffmpeg-installer/ffmpeg', { paths: [ROOT] })).path); } catch (e) {}
  for (const b of list) if ((b === 'ffmpeg' || fs.existsSync(b)) && works(b)) return (ffCache = b);
  return (ffCache = null);
}

function systemBrowsers() {
  if (WIN) {
    const pf = [process.env['ProgramFiles'], process.env['ProgramFiles(x86)'], process.env['LOCALAPPDATA']].filter(Boolean);
    const rel = ['Google\\Chrome\\Application\\chrome.exe', 'Microsoft\\Edge\\Application\\msedge.exe'];
    return pf.flatMap(b => rel.map(r => path.join(b, r)));
  }
  if (process.platform === 'darwin') return ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'];
  return ['/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge'];
}
// 返回 { kind: 'puppeteer' | 'system', path }；都没有返回 null
function findBrowser() {
  try {
    const pp = require(require.resolve('puppeteer', { paths: [ROOT] }));
    const p = pp.executablePath();
    if (p && fs.existsSync(p)) return { kind: 'puppeteer', path: p };
  } catch (e) {}
  const s = systemBrowsers().find(p => { try { return fs.existsSync(p); } catch (e) { return false; } });
  return s ? { kind: 'system', path: s } : null;
}

module.exports = { ROOT, findFfmpeg, findBrowser, systemBrowsers };
