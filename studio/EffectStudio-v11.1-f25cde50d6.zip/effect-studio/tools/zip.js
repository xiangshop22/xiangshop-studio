/* 效果工坊 · zip 压缩包读写（只用 Node 自带功能，不用装任何插件）
 *   readZip(buffer)            → [{ path, data }]   解压：支持「不压缩」和「普通压缩」两种 zip（Windows 右键压缩、7-Zip、WinRAR 的 zip 都可以）
 *   writeZip([{ path, data }]) → Buffer             打包：给「导出效果」「打包整个工作台」用
 * 文件名：带 UTF-8 标记的按 UTF-8 读；没有标记的（Windows 自带压缩常见）按 GBK 读，中文名不会乱码。
 */
const zlib = require('zlib');

// ---------- CRC32 校验（Node 新版本自带；旧版本用下面的表算） ----------
let TABLE = null;
function crc32(buf) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(buf) >>> 0;
  if (!TABLE) { TABLE = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; TABLE[n] = c >>> 0; } }
  let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

// ---------- 解压 ----------
function decodeName(bytes, utf8) {
  if (utf8 || bytes.every(b => b < 0x80)) return bytes.toString('utf8');
  try { return new TextDecoder('gbk', { fatal: true }).decode(bytes); } catch (e) { return bytes.toString('utf8'); }
}
function readZip(buf) {
  // 找到「中央目录结束标记」（在文件末尾）
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('这不是 zip 压缩包（或者文件不完整）。请用 zip 格式压缩，不支持 rar / 7z');
  const count = buf.readUInt16LE(eocd + 10), cdOff = buf.readUInt32LE(eocd + 16);
  if (count === 0xffff || cdOff === 0xffffffff) throw new Error('压缩包太大（ZIP64 格式），请分开压缩');
  const out = [];
  let p = cdOff;
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('压缩包已损坏');
    const flag = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10);
    const csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32);
    const lho = buf.readUInt32LE(p + 42);
    const name = decodeName(buf.subarray(p + 46, p + 46 + nl), flag & 0x800);
    p += 46 + nl + xl + cl;
    if (name.endsWith('/') || name.endsWith('\\')) continue;            // 文件夹本身不用管
    if (flag & 1) throw new Error('压缩包设置了密码，请去掉密码后再压缩');
    const lnl = buf.readUInt16LE(lho + 26), lxl = buf.readUInt16LE(lho + 28);
    const raw = buf.subarray(lho + 30 + lnl + lxl, lho + 30 + lnl + lxl + csize);
    let data;
    if (method === 0) data = Buffer.from(raw);
    else if (method === 8) data = zlib.inflateRawSync(raw);
    else throw new Error('压缩包里的「' + name + '」用了不支持的压缩方式，请用普通 zip（Deflate）重新压缩');
    if (data.length !== usize) throw new Error('压缩包已损坏：' + name);
    out.push({ path: name, data });
  }
  return out;
}

// ---------- 打包 ----------
function dosTime(d) {
  return { time: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1),
           date: ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate() };
}
function writeZip(files, opts) {                 // opts.date：固定时间（发布用，内容不变时 zip 也一模一样）
  const parts = [], cd = []; let off = 0;
  const { time, date } = dosTime((opts && opts.date) || new Date());
  for (const f of files) {
    const name = Buffer.from(f.path.replace(/\\/g, '/'), 'utf8');
    const data = Buffer.isBuffer(f.data) ? f.data : Buffer.from(f.data);
    const crc = crc32(data);
    let comp = zlib.deflateRawSync(data, { level: 6 }), method = 8;
    if (comp.length >= data.length) { comp = data; method = 0; }
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(time, 10); lh.writeUInt16LE(date, 12); lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    parts.push(lh, name, comp);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x800, 8); ch.writeUInt16LE(method, 10);
    ch.writeUInt16LE(time, 12); ch.writeUInt16LE(date, 14); ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(comp.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(name.length, 28);
    ch.writeUInt32LE(off, 42);
    cd.push(ch, name);
    off += 30 + name.length + comp.length;
  }
  const cdBuf = Buffer.concat(cd), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(cdBuf.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cdBuf, end]);
}

module.exports = { readZip, writeZip, crc32 };
