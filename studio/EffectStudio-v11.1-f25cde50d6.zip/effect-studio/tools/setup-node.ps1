﻿# 效果工坊 · 自动下载 Node.js（绿色版，放在 runtime\node 里，不用管理员权限，不改系统设置）
# start.bat 发现电脑没有 Node.js，或版本太旧（低于 22.12）时，会自动运行这个脚本。
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}

$root = Split-Path -Parent $PSScriptRoot
$rt = Join-Path $root 'runtime'
$dest = Join-Path $rt 'node'
New-Item -ItemType Directory -Force -Path $rt | Out-Null
$arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }

# 下载源：先国内镜像，再官方
$bases = @('https://registry.npmmirror.com/-/binary/node/', 'https://cdn.npmmirror.com/binaries/node/', 'https://nodejs.org/dist/')

# 选版本：最新的 LTS（22 或更新）；查不到就用固定版本
$ver = 'v22.20.0'
foreach ($b in $bases) {
  try {
    $list = Invoke-RestMethod -Uri ($b + 'index.json') -TimeoutSec 20
    $pick = $list | Where-Object { $_.lts -and ([int]($_.version.TrimStart('v').Split('.')[0]) -ge 22) -and ($_.files -contains "win-$arch-zip") } | Select-Object -First 1
    if ($pick) { $ver = $pick.version; break }
  } catch {}
}
Write-Host "  正在下载 Node.js $ver（约 30MB）…"

$zip = Join-Path $rt 'node.zip'
$ok = $false
foreach ($b in $bases) {
  $url = "$b$ver/node-$ver-win-$arch.zip"
  try {
    Write-Host "  下载地址：$url"
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing -TimeoutSec 600
    if ((Get-Item $zip).Length -gt 10MB) { $ok = $true; break }
  } catch { Write-Host "  这个地址下载失败，换下一个…" }
}
if (-not $ok) { Write-Host "  ✘ Node.js 下载失败，请检查网络。"; exit 1 }

Write-Host "  正在解压…"
$tmp = Join-Path $rt 'node-tmp'
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
Expand-Archive -Path $zip -DestinationPath $tmp -Force
$inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
Move-Item $inner.FullName $dest
Remove-Item $tmp -Recurse -Force
Remove-Item $zip -Force
if (Test-Path (Join-Path $dest 'node.exe')) { Write-Host "  ✔ Node.js $ver 已就绪"; exit 0 }
Write-Host "  ✘ Node.js 解压失败"; exit 1
