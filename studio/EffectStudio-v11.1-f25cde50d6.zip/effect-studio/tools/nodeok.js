// start.bat 用来判断 Node.js 版本够不够（Puppeteer 需要 22.12 以上）：够返回 0，不够返回 1
const [a, b] = process.versions.node.split('.').map(Number);
process.exit(a > 22 || (a === 22 && b >= 12) ? 0 : 1);
