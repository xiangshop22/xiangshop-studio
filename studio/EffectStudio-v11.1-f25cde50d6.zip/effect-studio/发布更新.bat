@echo off
rem Effect Studio - publish an update to GitHub / Gitee (author only)
rem Packs the studio and every effect, writes manifest.json, then pushes with Git.
setlocal
cd /d "%~dp0"
chcp 65001 >nul 2>nul
set "NODE="
if exist "%~dp0runtime\node\node.exe" set "NODE=%~dp0runtime\node\node.exe"
if not defined NODE for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
if not defined NODE (
  echo Node.js not found. Double-click start.bat once first.
  pause
  exit /b 1
)
"%NODE%" "%~dp0tools\publish.js" & echo. & pause & exit /b
