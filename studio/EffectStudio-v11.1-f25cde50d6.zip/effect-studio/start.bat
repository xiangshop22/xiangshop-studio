@echo off
rem ============================================================
rem  Effect Studio  -  double-click this file to start
rem  1. Look for Node.js 22.12+ : runtime\node first, then system
rem  2. Not found / too old  -> download a portable Node.js into runtime\node
rem  3. tools\launcher.js checks the rest - Puppeteer, Chrome, FFmpeg -
rem     installs anything missing on first run, then opens the web page
rem  Keep this file ASCII only.
rem ============================================================
setlocal
cd /d "%~dp0"
title Effect Studio
chcp 65001 >nul 2>nul

set "NODE="
if exist "%~dp0runtime\node\node.exe" set "NODE=%~dp0runtime\node\node.exe"
if not defined NODE for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"

if defined NODE (
  "%NODE%" "%~dp0tools\nodeok.js"
  if errorlevel 1 set "NODE="
)

if not defined NODE (
  echo.
  echo   [Effect Studio] Node.js 22.12+ not found. Downloading a portable copy, please wait...
  echo.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\setup-node.ps1"
  if exist "%~dp0runtime\node\node.exe" set "NODE=%~dp0runtime\node\node.exe"
)

if not defined NODE (
  echo.
  echo   Could not install Node.js automatically.
  echo   Please install Node.js 22 LTS from https://nodejs.org/zh-cn then double-click start.bat again.
  echo.
  pause
  exit /b 1
)

set "PATH=%~dp0runtime\node;%~dp0runtime\ffmpeg\bin;%PATH%"
"%NODE%" "%~dp0tools\launcher.js" & echo. & pause & exit /b
