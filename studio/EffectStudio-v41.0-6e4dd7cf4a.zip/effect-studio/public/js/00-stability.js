// 效果工坊 · 稳定性：出错记日志 · 工程自动存盘（必须最先加载）
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 稳定性（v23.1）：出错自动记日志 + 工程自动存盘 =================
// 出错 → 写进 logs\错误日志.txt，左下角亮红点；时间线 / 原视频 / 分段修正 → 自动存到 projects\当前工程.json，并保留历史
(() => {
  const PK = ['timeline', 'refVideo', 'segFix'];
  const ls = { g(k) { try { return localStorage.getItem('fxnav:' + k); } catch (e) { return null; } }, s(k, v) { try { localStorage.setItem('fxnav:' + k, v); } catch (e) {} } };
  const post = (u, body, keep) => fetch(u, { method: 'POST', headers: { 'X-FX': '1', 'Content-Type': 'application/json' }, body: JSON.stringify(body), keepalive: !!keep }).then(r => r.json());
  const hhmm = () => new Date().toTimeString().slice(0, 5);
  let chip, errN = 0, state = '', bad = false;
  const mark = (txt, isBad) => { if (txt != null) { state = txt; bad = !!isBad; } if (!chip) return;
    chip.innerHTML = (errN ? `<b style="color:#ff5a5a">● ${errN} 个错误</b>　` : '') + `📁 ${(ls.g('projName') || '未命名工程').replace(/[<>&]/g, '')}　<span style="color:${bad ? '#ffb020' : '#7ad48a'}">●</span> ${state || '未改动'}`; };
  // ---- 1) 打开页面时：浏览器被清空了，或别处存的更新，就用硬盘上的工程 ----
  let disk = {};
  try { const x = new XMLHttpRequest(); x.open('GET', '/api/project/latest', false); x.send(); disk = JSON.parse(x.responseText || '{}') || {}; } catch (e) {}
  const localT = +ls.g('projT') || 0;
  if (disk.data && (+disk.t || 0) > localT) { PK.forEach(k => { if (disk.data[k] !== undefined) ls.s(k, JSON.stringify(disk.data[k])); }); ls.s('projT', String(disk.t)); ls.s('projName', disk.name || ''); }
  const snapshot = () => { const data = {}; PK.forEach(k => { const v = ls.g(k); if (v != null) try { data[k] = JSON.parse(v); } catch (e) {} }); return data; };
  let tm = 0;
  const pname = () => ls.g('projName') || '';
  const push = (keep, force) => { tm = 0; return post('/api/project/save', { t: +ls.g('projT') || Date.now(), name: pname(), force: !!force, data: snapshot() }, keep)
    .then(r => { if (r.ok) mark('已存盘 ' + hhmm()); else throw 0; }).catch(() => mark('存盘失败（服务没开？）', true)); };
  window.__fxProj = k => { if (!PK.includes(k)) return; ls.s('projT', String(Date.now())); clearTimeout(tm); tm = setTimeout(push, 1500); };
  window.addEventListener('beforeunload', () => { if (tm) { clearTimeout(tm); push(true); } });
  if (localT > (+disk.t || 0) && Object.keys(snapshot()).length) setTimeout(push, 2000);   // 浏览器里的比硬盘新（比如上次存盘时服务没开）→ 补存
  // ---- 2) 出错记录 ----
  const sent = new Set();
  const report = (msg) => { msg = String(msg || '').slice(0, 4000); const key = msg.slice(0, 300);
    if (sent.has(key) || sent.size > 50) return; sent.add(key); errN++; mark();
    post('/api/log', { msg: msg + '\n页面：' + location.pathname }).catch(() => {}); };
  window.addEventListener('error', e => { if (!e.message) return;   // 图片 / 视频加载失败不算
    report(e.message + '\n位置：' + (e.filename || '').replace(location.origin, '') + ' 第 ' + e.lineno + ' 行 ' + e.colno + ' 列\n' + (e.error && e.error.stack || '')); });
  window.addEventListener('unhandledrejection', e => { const r = e.reason; report('异步出错：' + (r && (r.stack || r.message) || r)); });
  const ce = console.error.bind(console);
  console.error = (...a) => { ce(...a); try { report('console.error：' + a.map(x => x && x.stack || (typeof x === 'object' ? JSON.stringify(x) : String(x))).join(' ')); } catch (e) {} };
  // ---- 2.5) 工程：新建 / 另存为 / 打开 / 导出 / 导入（v35.x）----
  // 工程 = 时间线 + 原视频 + 分段修正（PK 三项，几十 KB 的 JSON）；起过名字的工程自动同时存进 projects\工程库\。
  // 图片、视频这些素材不在工程文件里（还在 uploads 里、原视频还是引用电脑上的原片）：同一台电脑上打开没问题，导出给别的电脑要连 uploads 一起给。
  const askName = (def) => { const n = (prompt('工程名字：', def || '') || '').replace(/[\\/:*?"<>|]/g, '_').trim().slice(0, 60); return n; };
  const load = async (data, name) => {
    PK.forEach(k => { try { localStorage.removeItem('fxnav:' + k); } catch (e) {} if (data && data[k] !== undefined) ls.s(k, JSON.stringify(data[k])); });
    ls.s('projName', name || ''); ls.s('projT', String(Date.now())); await push(false, true); location.reload();
  };
  const saveFirst = async () => {   // 换工程之前：当前这个先存好；没名字又有内容 → 问要不要起个名字存进工程库
    const has = Object.values(snapshot()).some(v => v && (Array.isArray(v.clips) ? v.clips.length : Object.keys(v).length));
    if (!pname() && has) { const n = askName('工程 ' + new Date().toLocaleDateString()); if (n) ls.s('projName', n); }
    await push(false, true);
  };
  async function projAct(b, p) {
    const a = b.dataset.a;
    if (a === 'saveas') { const n = askName(pname()); if (!n) return; ls.s('projName', n); ls.s('projT', String(Date.now())); await push(false, true); mark(); p.remove(); return toastMsg('已存为「' + n + '」'); }
    if (a === 'new') { if (!confirm('新建一个空工程？\n（现在的工程会先存好，在工程库里随时能打开回来）')) return; await saveFirst(); const n = askName('新工程'); return load({}, n || ''); }
    if (b.dataset.o) { await saveFirst(); const d = await (await fetch('/api/project/lib-get?name=' + encodeURIComponent(b.dataset.o))).json(); if (!d.data) return alert('这个工程读不出来'); return load(d.data, b.dataset.o); }
    if (b.dataset.d) { if (!confirm('从工程库删掉「' + b.dataset.d + '」？（删了找不回来）')) return; await fetch('/api/project/lib-del?name=' + encodeURIComponent(b.dataset.d), { headers: { 'X-FX': '1' } }); p.remove(); return panel(); }
    if (a === 'exp') {
      const blob = new Blob([JSON.stringify({ app: 'effect-studio', name: pname(), t: Date.now(), data: snapshot() })], { type: 'application/json' });
      const u = URL.createObjectURL(blob), x = document.createElement('a'); x.href = u; x.download = (pname() || '未命名工程') + '.fxproj.json'; document.body.appendChild(x); x.click(); x.remove(); setTimeout(() => URL.revokeObjectURL(u), 3000);
      return toastMsg('工程文件已下载（只有时间线和设置，不含图片视频素材）');
    }
    if (a === 'imp') {
      const f = document.createElement('input'); f.type = 'file'; f.accept = '.json,application/json';
      f.onchange = async () => { const file = f.files[0]; if (!file) return; let d; try { d = JSON.parse(await file.text()); } catch (e) { return alert('这个文件不是工程文件'); }
        const data = d && (d.data || d); if (!data || !PK.some(k => data[k] !== undefined)) return alert('这个文件里没有工程内容');
        if (!confirm('打开工程文件「' + file.name + '」？\n（现在的工程会先存好）')) return;
        await saveFirst(); load(data, (d.name || file.name.replace(/(\.fxproj)?\.json$/i, '')).slice(0, 60)); };
      f.click();
    }
  }
  const toastMsg = m => { try { window.toast ? toast(m) : alert(m); } catch (e) {} };
  // ---- 3) 左下角小标签：点开看工程历史、打开错误日志 ----
  const panel = async () => {
    let p = document.getElementById('fxStab'); if (p) return p.remove();
    p = document.createElement('div'); p.id = 'fxStab';
    p.style.cssText = 'position:fixed;left:8px;bottom:34px;z-index:99999;width:300px;max-height:60vh;overflow:auto;background:rgba(24,24,28,.97);color:#ddd;font:12px/1.6 sans-serif;border:1px solid #444;border-radius:8px;padding:10px;box-shadow:0 6px 24px rgba(0,0,0,.4)';
    const list = await (await fetch('/api/project/list')).json().catch(() => []);
    const fmt = n => n.replace(/^工程-(\d{4})(\d\d)(\d\d)-(\d\d)(\d\d)(\d\d)\.json$/, '$2-$3 $4:$5');
    const lib = await (await fetch('/api/project/lib')).json().catch(() => []);
    const esc = s => String(s).replace(/[<>&"]/g, '');
    p.innerHTML = `<div style="color:#999;margin-bottom:4px">工程：<b style="color:#eee">${esc(pname() || '未命名工程')}</b></div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px"><button data-a="new">＋ 新建工程</button><button data-a="saveas">另存为…</button><button data-a="exp">导出工程文件</button><button data-a="imp">导入工程文件</button></div>
      <div style="color:#999;margin-bottom:4px">工程库（点「打开」切换）</div>` +
      (lib.length ? lib.map(f => `<div style="display:flex;justify-content:space-between;gap:6px;padding:2px 0"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(f.name)}${f.name === pname() ? ' <i style="color:#f2a33d;font-style:normal">（当前）</i>' : ''}</span><span style="white-space:nowrap">${f.name === pname() ? '' : `<button data-o="${esc(f.name)}">打开</button> <button data-d="${esc(f.name)}" title="从工程库删掉">✕</button>`}</span></div>`).join('') : '<div style="color:#777">还没有存过的工程：点「另存为…」起个名字</div>') +
      `<hr style="border:0;border-top:1px solid #333;margin:8px 0"><div style="display:flex;gap:6px;margin-bottom:8px"><button data-a="log">打开错误日志</button>${errN ? '<button data-a="clr">清除红点</button>' : ''}</div>`;
    p.innerHTML += `
      <div style="color:#999;margin-bottom:4px">工程历史（每 5 分钟一份，留最近 30 份）</div>` +
      (list.length ? list.map(f => `<div style="display:flex;justify-content:space-between;padding:2px 0">${fmt(f.name)}<button data-n="${f.name}">恢复到这里</button></div>`).join('') : '<div style="color:#777">还没有历史</div>');
    p.onclick = async e => { const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.a === 'log') return fetch('/api/open-logs');
      if (b.dataset.a === 'new' || b.dataset.a === 'saveas' || b.dataset.a === 'exp' || b.dataset.a === 'imp' || b.dataset.o || b.dataset.d) return projAct(b, p);
      if (b.dataset.a === 'clr') { errN = 0; sent.clear(); mark(); return p.remove(); }
      if (b.dataset.n && confirm('恢复到 ' + fmt(b.dataset.n) + ' 的工程？\n（现在的工程会先另存一份历史，随时能再换回来）')) {
        await push(false, true);
        const d = await (await fetch('/api/project/get?name=' + encodeURIComponent(b.dataset.n))).json();
        if (!d.data) return alert('这份历史读不出来');
        PK.forEach(k => { try { localStorage.removeItem('fxnav:' + k); } catch (e) {} if (d.data[k] !== undefined) ls.s(k, JSON.stringify(d.data[k])); });
        ls.s('projT', String(Date.now())); await push(); location.reload();
      } };
    document.body.appendChild(p);
  };
  addEventListener('DOMContentLoaded', () => {
    chip = document.createElement('div'); chip.title = '点开：工程历史 / 错误日志';
    chip.style.cssText = 'position:fixed;left:8px;bottom:6px;z-index:99999;font:11px sans-serif;color:#bbb;background:rgba(24,24,28,.8);padding:3px 8px;border-radius:10px;cursor:pointer;user-select:none';
    chip.onclick = panel; document.body.appendChild(chip); mark();
  });
})();
