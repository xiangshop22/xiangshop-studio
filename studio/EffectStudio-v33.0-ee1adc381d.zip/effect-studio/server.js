/* 效果工坊 v6 · 本地服务（双击 start.bat 会自动启动它，不用手动运行）
 *
 * 【区域A 基础】端口、文件夹位置
 * 【区域B 效果列表】读取 effects 里每个文件夹的 effect.json
 * 【区域C 导出 MOV】用浏览器一帧一帧截图，交给 FFmpeg 合成透明 ProRes 4444
 * 【区域D 图片 / 视频上传】卡片里上传的照片、视频存到 uploads 文件夹；视频会转一份预览用的小视频
 * 【区域C2 视频卡导出提速】导出前用 FFmpeg 把卡片里的视频一次拆成图片，逐帧直接换图（比浏览器跳帧快很多）
 * 【区域E 加载效果】把拖进网页的 zip / 文件夹解压，放进 effects（同名会先备份到 effects\_backup）
 *                   拖进来的是「整个工作台」的升级包时，更新工作台文件并自动重启
 * 【区域F 导出效果 / 打包工作台】下载单个效果的 zip，或整个工作台的 zip（发给别人用）
 * 【区域H 在线更新】点「检查更新」→ 去 Gitee / GitHub 看清单 → 勾选后自动下载安装（见 tools/update.js）
 * 【区域I 稳定性】页面出错自动记进 logs\错误日志.txt；时间线、原视频设置自动存成 projects\当前工程.json，并保留历史
 * 【区域G 网址路由】网页请求哪个地址，交给上面哪一段处理
 */
const http = require('http'), fs = require('fs'), path = require('path');
const { spawn, exec } = require('child_process');
const crypto = require('crypto');
const { readZip, writeZip } = require('./tools/zip');
const { findFfmpeg, findBrowser, systemBrowsers } = require('./tools/env');
const updater = require('./tools/update');

// ================= 【区域A 基础】 =================
const VERSION = 'v33.0';
const PORT = 3210, HOST = '127.0.0.1', ROOT = __dirname;   // 只允许本机访问（局域网里的其他电脑打不开）
const EFFECTS = path.join(ROOT, 'effects'), PUBLIC = path.join(ROOT, 'public'), OUT = path.join(ROOT, 'output');
const UPLOADS = path.join(ROOT, 'uploads'), BACKUP = path.join(EFFECTS, '_backup'), STUDIO_BACKUP = path.join(ROOT, '_backup');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.otf': 'font/otf', '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.mp3': 'audio/mpeg', '.wav': 'audio/wav' };
const jobs = {};
const ID_OK = /^[\w-]+$/;
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); };
const readRaw = (req, max) => new Promise((ok, no) => {
  const bufs = []; let n = 0;
  req.on('data', c => { n += c.length; if (n > max) { no(new Error('文件太大（超过 ' + Math.round(max / 1048576) + 'MB）')); req.destroy(); } else bufs.push(c); });
  req.on('end', () => ok(Buffer.concat(bufs))); req.on('error', no);
});
const readBody = async (req) => { try { return JSON.parse((await readRaw(req, 5e6)).toString('utf8') || '{}'); } catch { return {}; } };
const stamp = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().replace(/[-:T]/g, '').slice(0, 14).replace(/^(\d{8})/, '$1-');

// ================= 【区域B 效果列表】 =================
// 【区域T 缩略图缓存（v31.6）】每个效果一个 rev = 它的文件（预设连同原效果）和 _shared 里最新的修改时间。
// 左侧缩略图用 /api/thumb?id=…&r=rev 取一张静态 PNG：浏览器按「一年不变」缓存，下次打开直接从浏览器缓存里拿，
// 不再一张张跑效果。效果一改 rev 就变，自动重新截。图片只存在浏览器缓存里，工作台里不多出任何文件。
function dirRev(d) { let m = 0; try { for (const n of fs.readdirSync(d)) { const st = fs.statSync(path.join(d, n)); if (st.isFile()) m = Math.max(m, st.mtimeMs); } } catch (e) { } return m; }
function listEffects() {
  if (!fs.existsSync(EFFECTS)) return [];
  const out = [], shared = dirRev(path.join(EFFECTS, '_shared'));
  for (const id of fs.readdirSync(EFFECTS)) {
    const jf = path.join(EFFECTS, id, 'effect.json');
    if (!ID_OK.test(id) || id.startsWith('_') || !fs.existsSync(jf)) continue;
    try {
      const j = JSON.parse(fs.readFileSync(jf, 'utf8'));
      const rev = Math.max(shared, dirRev(path.join(EFFECTS, id)), j.preset && ID_OK.test(j.preset) ? dirRev(path.join(EFFECTS, j.preset)) : 0);
      out.push({ id, ...j, rev: Math.round(rev).toString(36) });
    } catch (e) { console.log('effect.json 格式有误：', id); }
  }
  return out;
}

// 缩略图截图：一个后台浏览器排队截（一次只截一张，不抢电脑），闲 60 秒自动关掉
let thBrowser = null, thIdle = 0, thQ = Promise.resolve();
function thumbPng(id) {
  const run = async () => {
    clearTimeout(thIdle);
    if (!thBrowser) thBrowser = await launchBrowser();
    const page = await thBrowser.newPage();
    try {
      await page.setViewport({ width: 640, height: 360, deviceScaleFactor: 1 });
      await page.goto(`http://${HOST}:${PORT}/thumb.html?fx=${encodeURIComponent(id)}`);
      await page.waitForFunction(() => document.documentElement.dataset.ready === '1', { timeout: 20000 });
      await new Promise(r => setTimeout(r, 150));
      return await page.screenshot({ type: 'png', omitBackground: true });
    } finally {
      await page.close().catch(() => { });
      thIdle = setTimeout(() => { const b = thBrowser; thBrowser = null; if (b) b.close().catch(() => { }); }, 60000);
    }
  };
  const p = thQ.then(run, run); thQ = p.catch(() => { }); return p;
}

// ================= 【区域C 导出 MOV】 =================
async function launchBrowser() {
  const puppeteer = require('puppeteer');
  const args = ['--no-sandbox'];
  try { return await puppeteer.launch({ args }); } catch (e1) {
    // Puppeteer 自带的 Chrome 没下载成功时，用电脑里已有的 Chrome / Edge
    for (const p of systemBrowsers()) if (fs.existsSync(p)) { try { return await puppeteer.launch({ args, executablePath: p }); } catch (e) {} }
    throw new Error('找不到可用的浏览器（Chrome / Edge）。请关闭黑窗口，重新双击 start.bat 让它自动安装。' + e1.message);
  }
}
// ---------- 分段导出的「摆放文件」（v18.0）：XML（Premiere 导入 → 另存 prproj → 剪映导入）+ 使用说明 ----------
const safeDir = (d) => String(d || '').replace(/[\\/:*?"<>|]/g, '').replace(/^\.+/, '').trim().slice(0, 120);
function tcOf(sec, fps) {   // 秒 → 时:分:秒:帧（不丢帧）
  const f = Math.round(sec * fps), r = Math.round(fps), p = (n) => String(n).padStart(2, '0');
  return p(Math.floor(f / (r * 3600))) + ':' + p(Math.floor(f / (r * 60)) % 60) + ':' + p(Math.floor(f / r) % 60) + ':' + p(f % r);
}
function writePack(b) {
  const dir = safeDir(b.dir); if (!dir) return { error: 'no dir' };
  const OD = path.join(OUT, dir); fs.mkdirSync(OD, { recursive: true });
  const fps = Math.round(+b.fps || 30), W = b.width | 0 || 1920, H = b.height | 0 || 1080;
  const fu = (p) => 'file://localhost/' + p.replace(/\\/g, '/').split('/').map(encodeURIComponent).join('/').replace(/^([A-Za-z])%3A/, '$1:');
  const x = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const rate = `<rate><timebase>${fps}</timebase><ntsc>FALSE</ntsc></rate>`;
  const sc = `<samplecharacteristics>${rate}<width>${W}</width><height>${H}</height><pixelaspectratio>square</pixelaspectratio></samplecharacteristics>`;
  let n = 0; const item = (name, file, st, d, inF, srcD) => { n++; return `<clipitem id="clip${n}"><name>${x(name)}</name><enabled>TRUE</enabled><duration>${srcD}</duration>${rate}<start>${st}</start><end>${st + d}</end><in>${inF}</in><out>${inF + d}</out><file id="file${n}"><name>${x(path.basename(file))}</name><pathurl>${fu(file)}</pathurl>${rate}<duration>${srcD}</duration><media><video>${sc}</video></media></file></clipitem>`; };
  // 原视频：用上传到工作台的原片（uploads\videos\xxx.orig.*），被清理掉了就不放
  let v1 = '', end = 0;
  if (b.ref && b.ref.src && fs.existsSync(String(b.ref.src))) { const D = Math.round((+b.ref.vdur || 0) * fps); if (D > 0) { v1 = item(b.ref.name || '原视频', String(b.ref.src), 0, D, 0, D); end = D; } }   // v19.0：引用的本机原视频
  const m = b.ref && String(b.ref.url || '').match(/^\/uploads\/videos\/(.+?)\.fx\.(mp4|webm)$/);
  if (m && !v1) {
    const vd = path.join(UPLOADS, 'videos'), o = fs.existsSync(vd) && fs.readdirSync(vd).find((f) => f.startsWith(m[1] + '.orig.'));
    if (o) { const D = Math.round((+b.ref.vdur || 0) * fps); if (D > 0) { v1 = item(b.ref.name || '原视频', path.join(vd, o), 0, D, 0, D); end = D; } }
  }
  const v2 = (b.items || []).map((it) => { const st = Math.round(+it.start * fps), d = Math.max(1, Math.round(+it.dur * fps)); end = Math.max(end, st + d); return item(it.file.replace(/\.mov$/, ''), path.join(OD, it.file), st, d, 0, d); }).join('');
  const tr = (c) => `<track>${c}<enabled>TRUE</enabled><locked>FALSE</locked></track>`;
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4"><sequence id="seq1"><name>${x(dir)}</name><duration>${end}</duration>${rate}<timecode>${rate}<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode><media><video><format>${sc}</format>${tr(v1)}${tr(v2)}</video></media></sequence></xmeml>\n`;
  const xf = '①用PR导入XML-另存prproj-再导入剪映_全自动摆好.xml';
  fs.writeFileSync(path.join(OD, xf), xml);
  fs.writeFileSync(path.join(OD, '使用说明.txt'), [
    '【效果工坊 · 分段导出】时间都按原视频算，' + fps + ' 帧。',
    '',
    '① 全自动（推荐）',
    '  Premiere / 达芬奇：直接导入 ① 开头的 XML，效果自动摆到原视频上面一轨。',
    '  剪映：先用 Premiere 导入这个 XML → 另存为 .prproj → 剪映里「导入工程」选它。',
    '',
    '② 手动放',
    '  文件名写着「放在原视频 X分X秒X帧」：在剪辑软件里输入这个时间，播放头跳过去，把文件拖上去吸附即可。',
    '  Premiere / 达芬奇也可以：原视频和效果一起选中 →「按时间码同步 / 自动对齐」（每个 MOV 里都写了时间码）。',
    '',
    v1 ? '原视频用的是工作台里上传的原片。' : '注意：工作台里没找到原视频的原片，XML 里只有效果，原视频请自己放在第 0 秒。',
    '这个文件夹不要挪位置、文件不要改名，否则 XML 会找不到素材。',
  ].join('\r\n'));
  return { ok: true, xml: xf, ref: !!v1 };
}

// 导出编码（v27.0）：实测 1920×1080 / 30 帧、画面铺满的组合卡片 10 秒 ——
//   prores 原来的 ProRes 4444：317 MB；pq ProRes 4444 + qscale 8：约 140 MB（PSNR 53 dB，肉眼看不出差别，编码还快 4 倍）；
//   webm VP9 透明：约 2 MB（Premiere 不认）；mp4 H.264 不透明：约 2 MB。改这里要同步改 02-preview.js 的 CODECS（估算用）。
const CODECS = {
  pq: { ext: '.mov', tc: true, args: ['-c:v', 'prores_ks', '-profile:v', '4444', '-qscale:v', '8', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0'] },
  prores: { ext: '.mov', tc: true, args: ['-c:v', 'prores_ks', '-profile:v', '4444', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0'] },
  // v27.1：11-08 在「output\剪映透明测试」里用户实测过剪映都认透明的另外两种：PNG 编码 MOV、动画编码（QuickTime Animation）MOV。
  // 两种都是无损；画面空（小标题、字幕条）时比 ProRes 小得多，画面铺满时反而比「ProRes 标准」大。
  png: { ext: '.mov', tc: true, args: ['-c:v', 'png', '-pred', 'mixed', '-pix_fmt', 'rgba'] },
  qtrle: { ext: '.mov', tc: true, args: ['-c:v', 'qtrle', '-pix_fmt', 'argb'] },
  mp4: { ext: '.mp4', tc: true, args: ['-c:v', 'libx264', '-preset', 'medium', '-crf', '16', '-pix_fmt', 'yuv420p', '-movflags', '+faststart'] },
};
async function runExport(job, o) {
  const C = o.still != null ? { ext: '.png' } : (CODECS[o.codec] || CODECS.pq);   // 抓取静帧（v28.0）：只出一张 PNG
  const ffmpeg = findFfmpeg();
  if (!ffmpeg) throw new Error('没有找到 FFmpeg，无法导出。请关闭黑窗口，重新双击 start.bat，它会自动安装。');
  const OD = o.dir ? path.join(OUT, o.dir) : OUT;   // 分段导出（v18.0）：每次导出一个子文件夹
  fs.mkdirSync(OD, { recursive: true });
  const safe = (o.name || '').replace(/[\\/:*?"<>|]/g, '').trim();
  let file = (safe || `${o.effect}_${stamp()}`) + C.ext;
  for (let n = 1; fs.existsSync(path.join(OD, file)); n++) file = `${safe || o.effect}_${n}${C.ext}`;
  const outPath = path.join(OD, file);
  const browser = await launchBrowser();
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: o.width, height: o.height, deviceScaleFactor: 1 });
    await page.goto(o.comp ? `http://${HOST}:${PORT}/comp.html` : `http://${HOST}:${PORT}/effects/${o.effect}/effect.html`);   // comp = 素材时间线整条导出（v10.4）
    let dur = await page.evaluate((p) => { window.init(p); return window.getDuration(); }, o.params);
    // 【区域C2】卡片里有视频：先拆成图片，再重新初始化（这时效果会改用图片逐帧显示）
    const vids = findVideos(o.params);
    if (vids.length) {
      job.stage = '正在准备视频画面…';
      const map = {};
      const need = o.comp ? Math.max(dur, ...(o.params.clips || []).map((c) => +c.len || 0)) : dur;   // 分段导出（v15.0）：素材自己的时间可能比这一段长
      for (const v of vids) map[v] = await extractFrames(v, o.fps, need + o.hold + 0.5, o.width);
      o.params.__media = { fps: o.fps, map };
      job.stage = '';
    }
    dur = await page.evaluate(async (p) => { window.init(p); if (window.whenReady) await window.whenReady(); return window.getDuration(); }, o.params);
    if (o.still != null) {                           // 【抓取静帧 v28.0】渲染这一秒，按导出分辨率截一张透明 PNG
      await page.evaluate((t) => { window.renderAt(t); return window.__fxFrameWait ? window.__fxFrameWait() : null; }, o.still);
      fs.writeFileSync(outPath, await page.screenshot({ type: 'png', omitBackground: true }));
      job.status = 'done'; job.file = o.dir ? o.dir + '/' + file : file; job.progress = 1; return;
    }
    const total = Math.max(1, Math.round((dur + o.hold) * o.fps));
    const ff = spawn(ffmpeg, ['-y', '-f', 'image2pipe', '-framerate', String(o.fps), '-c:v', 'png', '-i', '-',
      ...C.args, ...(o.tc != null && C.tc ? ['-timecode', tcOf(o.tc, o.fps)] : []), outPath], { stdio: ['pipe', 'ignore', 'pipe'], windowsHide: true });
    let ffErr = '', dead = false;
    ff.stderr.on('data', (d) => (ffErr = (ffErr + d).slice(-800)));
    ff.stdin.on('error', () => {});
    const closed = new Promise((r) => { ff.on('error', (e) => { dead = true; ffErr = String(e.message); r(-1); }); ff.on('close', (c) => { dead = true; r(c); }); });
    for (let i = 0; i < total && !dead; i++) {
      await page.evaluate((t) => { window.renderAt(t); return window.__fxFrameWait ? window.__fxFrameWait() : null; }, i / o.fps);
      const buf = await page.screenshot({ type: 'png', omitBackground: true, optimizeForSpeed: true });
      if (!ff.stdin.write(buf)) await Promise.race([new Promise((r) => ff.stdin.once('drain', r)), closed]);
      job.progress = (i + 1) / total;
    }
    ff.stdin.end();
    const code = await closed;
    if (code !== 0) throw new Error('FFmpeg 出错：' + ffErr);
    job.status = 'done'; job.file = o.dir ? o.dir + '/' + file : file; job.progress = 1;
  } finally { await browser.close(); }
}

// ================= 【区域C2 视频卡导出提速】 =================
// 参数里所有 { video: '/uploads/...' } 的地址
function findVideos(o, out = new Set()) {
  if (Array.isArray(o)) o.forEach(x => findVideos(x, out));
  else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) {
    if (k === 'video' && typeof v === 'string' && v.startsWith('/uploads/')) out.add(v); else if (typeof v === 'object' || (typeof v === 'string' && v.startsWith('{'))) {
      if (typeof v === 'string') { try { findVideos(JSON.parse(v), out); } catch (e) {} } else findVideos(v, out);
    }
  }
  return [...out];
}
const runFF = (args) => new Promise((ok, no) => {
  const ff = spawn(findFfmpeg(), args, { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
  let err = ''; ff.stderr.on('data', d => (err = (err + d).slice(-1500)));
  ff.on('error', no); ff.on('close', c => (c === 0 ? ok(err) : no(new Error('FFmpeg 出错：' + err.slice(-300)))));
});
// 预览小视频 xxx.fx.mp4 → 原视频 xxx.orig.*（画质更好）
function originalOf(url) {
  const fp = path.join(ROOT, ...decodeURIComponent(url).split('/').filter(Boolean));
  const base = fp.replace(/\.fx\.(mp4|webm)$/, '');
  const dir = path.dirname(base), name = path.basename(base) + '.orig.';
  try { const f = fs.readdirSync(dir).find(n => n.startsWith(name)); if (f) return path.join(dir, f); } catch (e) {}
  return fp;
}
// 按导出帧率拆成 JPG（只拆需要的长度），拆过的直接复用
async function extractFrames(url, fps, maxSec, outW) {
  const src = originalOf(url);
  const side = Math.min(2560, Math.max(1280, Math.round(1280 * outW / 1920)));
  const key = path.basename(src).replace(/[^\w.-]/g, '_') + `_${fps}fps_${side}_${Math.ceil(maxSec)}s`;
  const dir = path.join(UPLOADS, '.frames', key), done = path.join(dir, 'done.json');
  if (!fs.existsSync(done)) {
    fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
    await runFF(['-v', 'error', '-y', '-i', src, '-t', String(maxSec), '-an',
      '-vf', `fps=${fps},scale=w='if(gt(iw,ih),min(${side},iw),-2)':h='if(gt(iw,ih),-2,min(${side},ih))'`,
      '-q:v', '3', path.join(dir, '%06d.jpg')]);
    const count = fs.readdirSync(dir).filter(n => n.endsWith('.jpg')).length;
    fs.writeFileSync(done, JSON.stringify({ count }));
  }
  const { count } = JSON.parse(fs.readFileSync(done, 'utf8'));
  return { dir: `/uploads/.frames/${encodeURIComponent(key)}/`, count: Math.max(1, count) };
}

// ================= 【区域D 图片上传】 =================
const IMG_EXT = { 'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp', 'image/gif': '.gif' };
async function handleUpload(req, res) {
  const ext = IMG_EXT[(req.headers['content-type'] || '').split(';')[0].trim()];
  if (!ext) return send(res, 400, { error: '只支持 PNG / JPG / WEBP / GIF 图片' });
  const buf = await readRaw(req, 60 * 1048576);
  fs.mkdirSync(UPLOADS, { recursive: true });
  const name = stamp() + '-' + Math.random().toString(36).slice(2, 8) + ext;
  fs.writeFileSync(path.join(UPLOADS, name), buf);
  send(res, 200, { url: '/uploads/' + name });
}

// 读时长 / 尺寸 + 转一份预览小视频（最长边 960、关键帧间隔 12）+ 封面；上传和「引用本机原视频」（v19.0）共用
async function makePreview(src, dir, base) {
  // 读时长和尺寸（ffmpeg -i 的输出里有）
  const info = await new Promise(ok => {
    let err = ''; const ff = spawn(findFfmpeg(), ['-hide_banner', '-i', src], { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
    ff.stderr.on('data', d => (err += d)); ff.on('close', () => ok(err)); ff.on('error', () => ok(err));
  });
  const dm = info.match(/Duration:\s*(\d+):(\d+):([\d.]+)/), sm = info.match(/Video:.*?(\d{2,5})x(\d{2,5})/);
  if (!dm || !sm) { return { error: '无法识别这个视频文件' }; }
  const vdur = +dm[1] * 3600 + +dm[2] * 60 + +dm[3];
  const vf = "scale=w='if(gt(iw,ih),min(960,iw),-2)':h='if(gt(iw,ih),-2,min(960,ih))'";
  let out = path.join(dir, base + '.fx.mp4');
  try {
    await runFF(['-v', 'error', '-y', '-i', src, '-an', '-vf', vf, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', '-g', '12', '-movflags', '+faststart', out]);
  } catch (e) {                                                    // 没有 x264 时用 WebM
    out = path.join(dir, base + '.fx.webm');
    await runFF(['-v', 'error', '-y', '-i', src, '-an', '-vf', vf, '-c:v', 'libvpx', '-b:v', '2M', '-deadline', 'realtime', '-cpu-used', '8', '-g', '12', out]);
  }
  const poster = path.join(dir, base + '.poster.jpg');
  try { await runFF(['-v', 'error', '-y', '-i', src, '-frames:v', '1', '-vf', vf, '-q:v', '4', poster]); } catch (e) {}
  const rel = f => '/uploads/videos/' + path.basename(f);
  return { video: rel(out), poster: fs.existsSync(poster) ? rel(poster) : '', vdur: Math.round(vdur * 1000) / 1000, w: +sm[1], h: +sm[2] };
}

// ---------- 引用本机原视频（v19.0）：在电脑上弹出选文件窗口，只记下原视频的路径，不拷贝原片；只生成一份预览小视频（按路径 + 大小 + 修改时间缓存） ----------
function pickFile() {
  if (process.platform !== 'win32') return Promise.resolve({ error: 'only-windows' });
  // 选文件窗口一定要在最上面（v19.0 补丁）：先显示一个看不见的「置顶」小窗口并激活它，再把选文件窗口挂在它下面 —— 挂在置顶窗口下的窗口也是置顶的，不会被浏览器挡住
  const ps = "[Console]::OutputEncoding=[Text.Encoding]::UTF8;Add-Type -AssemblyName System.Windows.Forms;" +
    "$f=New-Object System.Windows.Forms.Form -Property @{TopMost=$true;ShowInTaskbar=$false;StartPosition='CenterScreen';Width=1;Height=1;Opacity=0;FormBorderStyle='None'};" +
    "$f.Show();$f.Activate();$f.BringToFront();" +
    "$d=New-Object System.Windows.Forms.OpenFileDialog;$d.Title='选择原视频（只引用，不拷贝原片）';$d.Filter='视频|*.mp4;*.mov;*.m4v;*.mkv;*.webm;*.avi|所有文件|*.*';" +
    "$r=$d.ShowDialog($f);$f.Close();if($r -eq 'OK'){$d.FileName}";
  return new Promise((ok) => { let o = ''; const p = spawn('powershell', ['-NoProfile', '-STA', '-Command', ps], { windowsHide: true }); p.stdout.on('data', (d) => (o += d)); p.on('close', () => ok({ path: o.trim() })); p.on('error', (e) => ok({ error: e.message })); });
}
async function handlePickVideo(res) {
  if (!findFfmpeg()) return send(res, 400, { error: '没有找到 FFmpeg，无法处理视频' });
  const r = await pickFile(); if (r.error) return send(res, 200, r);
  if (!r.path) return send(res, 200, { cancel: true });
  if (!fs.existsSync(r.path)) return send(res, 400, { error: '找不到这个文件：' + r.path });
  const st = fs.statSync(r.path), dir = path.join(UPLOADS, 'videos'); fs.mkdirSync(dir, { recursive: true });
  const base = 'ref-' + crypto.createHash('md5').update(r.path + '|' + st.size + '|' + st.mtimeMs).digest('hex').slice(0, 12);
  const ex = ['.fx.mp4', '.fx.webm'].map((e) => path.join(dir, base + e)).find((f) => fs.existsSync(f));
  const meta = path.join(dir, base + '.json');
  if (ex && fs.existsSync(meta)) return send(res, 200, Object.assign(JSON.parse(fs.readFileSync(meta, 'utf8')), { src: r.path, cached: true }));
  const p = await makePreview(r.path, dir, base); if (p.error) return send(res, 400, p);
  fs.writeFileSync(meta, JSON.stringify(p)); send(res, 200, Object.assign(p, { src: r.path }));
}

// ---------- 视频上传：存原视频 + 转一份预览小视频（最长边 960、全是关键帧附近，拖动进度条跳得快）+ 封面 ----------
async function handleVideoUpload(req, res) {
  if (!findFfmpeg()) return send(res, 400, { error: '没有找到 FFmpeg，无法处理视频' });
  const dir = path.join(UPLOADS, 'videos'); fs.mkdirSync(dir, { recursive: true });
  const ext = (path.extname(decodeURIComponent(req.headers['x-file-name'] || '')).toLowerCase().match(/^\.(mp4|mov|webm|m4v|mkv|avi)$/) || ['.mp4'])[0];
  const base = stamp() + '-' + Math.random().toString(36).slice(2, 8);
  const orig = path.join(dir, base + '.orig' + ext);
  await new Promise((ok, no) => { const w = fs.createWriteStream(orig); req.pipe(w); w.on('finish', ok); w.on('error', no); req.on('error', no); });
  const r = await makePreview(orig, dir, base);
  if (r.error) fs.rmSync(orig, { force: true });
  send(res, r.error ? 400 : 200, r);
}

// ================= 【区域E 加载效果】 =================
// 把压缩包里的路径统一成 a/b/c 的样子；有 .. 或盘符的直接丢掉（防止写到别的地方）
function cleanEntries(entries) {
  const out = [];
  for (const e of entries) {
    const p = e.path.replace(/\\/g, '/').replace(/^(\.\/|\/)+/, '');
    const segs = p.split('/');
    if (!p || segs.some(s => s === '..' || s.includes(':')) || segs.includes('__MACOSX') || /^(\.DS_Store|Thumbs\.db|desktop\.ini)$/i.test(segs[segs.length - 1])) continue;
    out.push({ path: p, data: e.data });
  }
  return out;
}
const STUDIO_FILES = ['server.js', 'start.bat', 'package.json', 'package-lock.json', 'README.txt', '使用说明.txt', 'update.json', '发布更新.bat'];
const STUDIO_DIRS = ['public/', 'tools/'];
// 看清压缩包里有什么：几个效果、共用文件、是不是整个工作台
function analyze(entries, zipName) {
  const plan = { effects: [], shared: [], studio: null, errors: [], unchanged: [] };
  // 1) 整个工作台的升级包：有 server.js，旁边还有 public/index.html
  const srv = entries.find(e => /(^|\/)server\.js$/.test(e.path) && entries.some(x => x.path === e.path.replace(/server\.js$/, 'public/index.html')));
  let effEntries = entries;
  if (srv) {
    const pre = srv.path.slice(0, -'server.js'.length);
    const files = entries.filter(e => e.path.startsWith(pre)).map(e => ({ rel: e.path.slice(pre.length), data: e.data }))
      .filter(e => STUDIO_FILES.includes(e.rel) || STUDIO_DIRS.some(d => e.rel.startsWith(d)));
    let ver = '';
    const ix = files.find(f => f.rel === 'public/index.html');
    if (ix) { const m = ix.data.toString('utf8').match(/<small[^>]*>\s*(v[\d.]+)\s*<\/small>/); if (m) ver = m[1]; }
    plan.studio = { files, version: ver };
    effEntries = entries.filter(e => e.path.startsWith(pre + 'effects/')).map(e => ({ path: e.path.slice(pre.length), data: e.data }));
  }
  // 2) 共用文件：路径里有 _shared 的
  for (const e of effEntries) {
    const segs = e.path.split('/'), i = segs.indexOf('_shared');
    if (i < 0 || segs.includes('_backup')) continue;
    const rel = segs.slice(i + 1).join('/'); if (!rel) continue;
    const dest = path.join(EFFECTS, '_shared', ...rel.split('/'));
    let same = false; try { same = fs.readFileSync(dest).equals(e.data); } catch (er) {}
    if (!same) plan.shared.push({ rel, data: e.data, exists: fs.existsSync(dest) });
  }
  // 3) 效果：每个 effect.json 所在的文件夹就是一个效果，文件夹名就是效果名
  const jsons = effEntries.filter(e => /(^|\/)effect\.json$/.test(e.path) && !e.path.split('/').some(s => s === '_backup' || s === '_shared'));
  const roots = jsons.map(j => j.path.slice(0, -'effect.json'.length));
  for (const j of jsons) {
    const dir = j.path.slice(0, -'effect.json'.length);                     // 例如 "effects/card-deal/"，或 ""（effect.json 就在最外层）
    if (roots.some(r => r !== dir && r.length < dir.length && dir.startsWith(r))) continue;   // 效果里面又套了效果，不算
    let id = dir ? dir.replace(/\/$/, '').split('/').pop() : String(zipName || '').replace(/\.zip$/i, '').replace(/[\s（(]\d+[)）]$/, '').trim();
    let meta; try { meta = JSON.parse(j.data.toString('utf8').replace(/^﻿/, '')); } catch (e) { plan.errors.push(`「${id}」的 effect.json 格式有误，没法安装`); continue; }
    if (!ID_OK.test(id) || id.startsWith('_')) { plan.errors.push(`效果文件夹名「${id}」只能用英文字母、数字、- 和 _`); continue; }
    const files = effEntries.filter(e => e.path.startsWith(dir) && !e.path.slice(dir.length).split('/').includes('_shared')).map(e => ({ rel: e.path.slice(dir.length), data: e.data }));
    if (!files.some(f => f.rel === 'effect.html')) { plan.errors.push(`「${meta.name || id}」缺少 effect.html`); continue; }
    if (plan.effects.some(x => x.id === id) || plan.unchanged.includes(meta.name || id)) continue;
    const exists = fs.existsSync(path.join(EFFECTS, id, 'effect.json'));
    // 已经有、而且每个文件都一模一样 → 不用再装（也不会产生多余的备份）
    if (exists && files.every(f => { try { return fs.readFileSync(path.join(EFFECTS, id, ...f.rel.split('/'))).equals(f.data); } catch (e) { return false; } })) { plan.unchanged.push(meta.name || id); continue; }
    plan.effects.push({ id, name: meta.name || id, files, exists });
  }
  return plan;
}
const writeFile = (dest, data) => { fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, data); };
const inside = (base, p) => { const r = path.relative(base, p); return r && !r.startsWith('..') && !path.isAbsolute(r); };
function moveAside(src, dest) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  try { fs.renameSync(src, dest); } catch (e) { fs.cpSync(src, dest, { recursive: true }); fs.rmSync(src, { recursive: true, force: true }); }
}
function applyPlan(plan, mode) {          // mode: overwrite（同名覆盖，旧的备份） / skip（同名跳过，只装新的）
  const st = stamp(), done = { installed: [], updated: [], skipped: [], shared: [], studio: false, backup: false };
  for (const fx of plan.effects) {
    const dir = path.join(EFFECTS, fx.id);
    if (fx.exists && mode !== 'overwrite') { done.skipped.push(fx.name); continue; }
    if (fs.existsSync(dir)) { moveAside(dir, path.join(BACKUP, fx.id + '_' + st)); done.backup = true; }
    for (const f of fx.files) { const d = path.join(dir, ...f.rel.split('/')); if (inside(dir, d)) writeFile(d, f.data); }
    (fx.exists ? done.updated : done.installed).push(fx.name);
  }
  const sh = path.join(EFFECTS, '_shared');
  for (const f of plan.shared) {
    const d = path.join(sh, ...f.rel.split('/')); if (!inside(sh, d)) continue;
    if (f.exists) { writeFile(path.join(BACKUP, '_shared_' + st, ...f.rel.split('/')), fs.readFileSync(d)); done.backup = true; }
    writeFile(d, f.data); done.shared.push(f.rel);
  }
  if (plan.studio) {
    for (const f of plan.studio.files) {
      const d = path.join(ROOT, ...f.rel.split('/')); if (!inside(ROOT, d)) continue;
      let same = false; try { same = fs.readFileSync(d).equals(f.data); } catch (e) {}
      if (same) continue;
      if (fs.existsSync(d)) writeFile(path.join(STUDIO_BACKUP, 'studio_' + st, ...f.rel.split('/')), fs.readFileSync(d));
      writeFile(d, f.data); done.studio = true;
    }
  }
  trimBackups();                    // 每次安装 / 升级后，旧备份只留最近几份，不让文件夹一直长
  return done;
}

// ================= 【区域I 占用统计 / 清理】 =================
// 文件夹越来越大，99% 不是效果代码（全部效果加起来才 1~2MB），而是素材和成品：
// 上传视频的原片、导出的 MOV、逐帧缓存。这里统计出来，让用户自己点着删。
const KEEP_BACKUPS = 3;             // 每个效果 / 工作台各保留最近 3 份旧版本
function dirSize(p) {
  let n = 0, c = 0;
  const walk = d => {
    let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of es) {
      const f = path.join(d, e.name);
      if (e.isDirectory()) walk(f);
      else { try { n += fs.statSync(f).size; c++; } catch (e2) { } }
    }
  };
  if (fs.existsSync(p)) walk(p);
  return { bytes: n, files: c };
}
function filesIn(dir, test) {       // 平铺一层，挑出符合条件的文件
  const out = [];
  let es; try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return out; }
  for (const e of es) {
    const f = path.join(dir, e.name);
    if (e.isFile() && test(e.name)) { try { out.push({ p: f, size: fs.statSync(f).size }); } catch (e2) { } }
  }
  return out;
}
const sumOf = list => ({ bytes: list.reduce((a, x) => a + x.size, 0), files: list.length });
// 旧备份文件夹：名字都是 xxx_20261102-101422，按时间戳排序，只留最近 KEEP_BACKUPS 份
function oldBackupDirs() {
  const groups = {}, out = [];
  for (const [root, tag] of [[BACKUP, 'effects'], [STUDIO_BACKUP, 'studio']]) {
    if (!fs.existsSync(root)) continue;
    for (const n of fs.readdirSync(root)) {
      const m = n.match(/^(.+)_(\d{8}-\d{6})$/); if (!m) continue;
      (groups[tag + ':' + m[1]] = groups[tag + ':' + m[1]] || []).push({ p: path.join(root, n), t: m[2] });
    }
  }
  for (const k in groups) {
    groups[k].sort((a, b) => b.t.localeCompare(a.t));
    out.push(...groups[k].slice(KEEP_BACKUPS));
  }
  return out;
}
function trimBackups() { for (const d of oldBackupDirs()) { try { fs.rmSync(d.p, { recursive: true, force: true }); } catch (e) { } } }

const VID = path.join(UPLOADS, 'videos'), FRAMES = path.join(UPLOADS, '.frames');
function spaceGroups() {
  const origs = filesIn(VID, n => /\.orig\.[^.]+$/i.test(n));
  const prev = filesIn(VID, n => !/\.orig\.[^.]+$/i.test(n));
  const imgs = filesIn(UPLOADS, n => !n.startsWith('.') && /\.(png|jpe?g|webp|gif|avif|bmp)$/i.test(n));
  const outs = filesIn(OUT, n => /\.(mov|mp4|webm|png|zip)$/i.test(n));
  const oldbk = oldBackupDirs().map(d => ({ p: d.p, size: dirSize(d.p).bytes }));
  return [
    { key: 'output', name: '导出的成品视频', dir: 'output', safe: true, ...sumOf(outs),
      note: '已经导出的 MOV。拖进剪辑软件用过就可以删，要用再导一次。' },
    { key: 'origvideo', name: '上传视频的原片', dir: 'uploads\\videos', safe: true, ...sumOf(origs),
      note: '原画质备份，导出时用它出片。删了效果照常预览和导出，只是导出画质按预览那份来。' },
    { key: 'frames', name: '视频逐帧缓存', dir: 'uploads\\.frames', safe: true, ...dirSize(FRAMES),
      note: '导出视频卡时自动拆出来的图片，纯缓存，删了下次导出会自动重建。' },
    { key: 'oldbackup', name: '旧版本备份（超出最近 3 份的）', dir: '_backup', safe: true, ...sumOf(oldbk),
      note: '升级时自动留的旧版本。现在每个效果只保留最近 ' + KEEP_BACKUPS + ' 份，多出来的在这里。' },
    { key: 'publish', name: '发布仓库缓存', dir: '_publish', safe: true, ...dirSize(path.join(ROOT, '_publish')),
      note: '只有发布更新给别人时才用得上；删了下次发布会重新拉一份。' },
    { key: 'preview', name: '正在用的素材（图片 + 预览视频）', dir: 'uploads', safe: false,
      bytes: sumOf(imgs).bytes + sumOf(prev).bytes, files: imgs.length + prev.length,
      note: '卡片里正在显示的照片和预览视频。删了画面会变空，所以不提供一键清理。' },
    { key: 'program', name: '程序本体（含 FFmpeg、效果代码）', dir: 'node_modules + effects + public', safe: false,
      bytes: dirSize(path.join(ROOT, 'node_modules')).bytes + dirSize(EFFECTS).bytes + dirSize(PUBLIC).bytes + dirSize(path.join(ROOT, 'tools')).bytes,
      files: 0, note: '工具本身，其中 FFmpeg 一个就 64MB，不能删。' }
  ];
}
function cleanSpace(keys) {
  const kill = [];
  if (keys.includes('output')) kill.push(...filesIn(OUT, n => /\.(mov|mp4|webm|png|zip)$/i.test(n)).map(f => f.p));
  if (keys.includes('origvideo')) kill.push(...filesIn(VID, n => /\.orig\.[^.]+$/i.test(n)).map(f => f.p));
  if (keys.includes('frames')) kill.push(FRAMES);
  if (keys.includes('oldbackup')) kill.push(...oldBackupDirs().map(d => d.p));
  if (keys.includes('publish')) kill.push(path.join(ROOT, '_publish'));
  let freed = 0;
  for (const p of kill) {
    if (!inside(ROOT, p)) continue;                       // 只在工作台目录里删，绝不碰外面
    try { freed += fs.statSync(p).isDirectory() ? dirSize(p).bytes : fs.statSync(p).size; } catch (e) { continue; }
    try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) { }
  }
  return { freed };
}
// 【区域H 在线更新】下载好的 zip 直接走同一套安装流程（同名覆盖，旧的自动备份）
function installBuffer(buf, name) {
  const plan = analyze(cleanEntries(readZip(buf)), name);
  if (!plan.effects.length && !plan.shared.length && !plan.studio) return { done: null, errors: plan.errors };
  return { done: applyPlan(plan, 'overwrite'), errors: plan.errors };
}
async function handleUpdateApply(req, res) {
  const b = await readBody(req);
  const pk = await updater.fetchPackages(!!b.studio, Array.isArray(b.effects) ? b.effects : []);
  const all = { installed: [], updated: [], shared: [], studio: false, errors: [] };
  // 先装效果，最后装工作台程序（装完程序要重启）
  pk.sort((a, b2) => (/^studio|^EffectStudio/i.test(a.name) ? 1 : 0) - (/^studio|^EffectStudio/i.test(b2.name) ? 1 : 0));
  for (const p of pk) {
    const r = installBuffer(p.buf, p.name);
    all.errors.push(...r.errors);
    if (!r.done) continue;
    all.installed.push(...r.done.installed); all.updated.push(...r.done.updated); all.shared.push(...r.done.shared);
    if (r.done.studio) all.studio = true;
  }
  updater.clearCache();
  const restart = all.studio && !!process.env.FX_LAUNCHER;
  send(res, 200, { ok: true, done: all, restart, manualRestart: all.studio && !restart });
  if (restart) setTimeout(() => { console.log('工作台已在线更新，正在重启…'); process.exit(99); }, 400);
}

async function handleInstall(req, res, url) {
  const buf = await readRaw(req, 500 * 1048576);
  const zipName = decodeURIComponent(req.headers['x-file-name'] || '');
  let entries;
  try { entries = cleanEntries(readZip(buf)); } catch (e) { return send(res, 400, { error: e.message }); }
  const plan = analyze(entries, zipName);
  const nothing = !plan.effects.length && !plan.shared.length && !plan.studio;
  if (nothing && plan.unchanged.length) return send(res, 200, { same: true, unchanged: plan.unchanged, errors: plan.errors });
  if (nothing) return send(res, 400, { error: plan.errors[0] || '压缩包里没有找到 effect.json，这不像是效果包' });
  const mode = url.searchParams.get('mode') || 'check';
  const summary = {
    effects: plan.effects.map(e => ({ id: e.id, name: e.name, exists: e.exists })),
    shared: plan.shared.map(s => s.rel), unchanged: plan.unchanged, studio: plan.studio ? { version: plan.studio.version, current: VERSION } : null, errors: plan.errors,
  };
  if (mode === 'check') return send(res, 200, { check: true, ...summary });
  const done = applyPlan(plan, mode);
  const restart = done.studio && !!process.env.FX_LAUNCHER;
  send(res, 200, { ok: true, ...summary, done, restart, manualRestart: done.studio && !restart });
  if (restart) setTimeout(() => { console.log('工作台已更新，正在重启…'); process.exit(99); }, 400);
}

// ================= 【区域F 导出效果 / 打包工作台】 =================
function collect(dir, prefix, skip) {           // 把一个文件夹里的所有文件读出来（skip 里的文件夹不要）
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const n of fs.readdirSync(dir)) {
    const p = path.join(dir, n), rel = prefix + n;
    if (skip && skip(rel)) continue;
    const s = fs.statSync(p);
    if (s.isDirectory()) out.push(...collect(p, rel + '/', skip)); else out.push({ path: rel, data: fs.readFileSync(p) });
  }
  return out;
}
function sendZip(res, name, files) {
  const buf = writeZip(files);
  res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Length': buf.length, 'Cache-Control': 'no-store',
    'Content-Disposition': `attachment; filename="${name}"` });      // 文件名用英文：所有浏览器、所有电脑都不会乱码
  res.end(buf);
}
const junk = rel => /(^|\/)(Thumbs\.db|desktop\.ini|\.DS_Store)$/i.test(rel);
function handleEffectZip(res, id) {
  const fx = listEffects().find(e => e.id === id);
  if (!fx) return send(res, 404, { error: '没有这个效果' });
  // 和以前发的包一样：最外层是 effects 文件夹，里面是这个效果 + _shared 共用文件
  // 预设：把原效果（组合预设 = 里面用到的所有效果）一起打进去，对方才能用
  const j = readFx(id) || {}, bases = [...new Set([presetOf(id), ...((j.combo && j.combo.clips) || []).map(c => c.fx)].filter(x => x && x !== id && ID_OK.test(x)))];
  const files = [...collect(path.join(EFFECTS, id), `effects/${id}/`, junk), ...bases.flatMap(b => collect(path.join(EFFECTS, b), `effects/${b}/`, junk)), ...collect(path.join(EFFECTS, '_shared'), 'effects/_shared/', junk)];
  sendZip(res, `effect-${id}.zip`, files);
}
// ================= 【区域P 我的预设（v9.0）】 =================
// 用户把某个效果调好（参数 + 关键帧 + 持续时间）后「保存为预设」，左侧就多一张自己的卡片。
// 预设文件夹里只有一个 effect.json：基于原效果的 effect.json，把每个参数的默认值换成保存时的值，
// 再加 "preset": 原效果文件夹名。effect.html / bundle.js 等不复制，访问时直接用原效果的（见静态文件那段）。
// 上传的素材不保存：参数里所有 /uploads/… 路径和 data: 内嵌图都清掉，换成效果默认的占位内容，预设文件只有几 KB。
const presetOf = id => { try { const j = JSON.parse(fs.readFileSync(path.join(EFFECTS, id, 'effect.json'), 'utf8').replace(/^\uFEFF/, '')); return j.preset || ''; } catch (e) { return ''; } };
// v25.0：预设连素材一起保存（用户要求「整体全部打包一份」）。参数里引用到的 /uploads/… 文件复制到预设自己的
// media 文件夹，路径改成 /effects/<预设>/media/…；这样以后清理 uploads 也不会把预设里的图片删掉。
// 组合（多个素材 + 组合关键帧）存在 effect.json 的 "combo" 里，从左侧加到时间线时整组放进去（10-timeline.js addFx）。
function keepMedia(v, id, done) {
  if (typeof v === 'string') {
    const m = /^\/uploads\/([^?#]+)$/.exec(v);
    if (m) {
      const src = path.normalize(path.join(UPLOADS, decodeURIComponent(m[1])));
      if (src.startsWith(UPLOADS) && fs.existsSync(src) && fs.statSync(src).isFile()) {
        const name = m[1].replace(/[\\/]/g, '_');
        if (!done.has(name)) { writeFile(path.join(EFFECTS, id, 'media', name), fs.readFileSync(src)); done.add(name); }
        return '/effects/' + id + '/media/' + name;
      }
      return v;
    }
    const t = v.trim();
    if (/^[[{]/.test(t)) { try { return JSON.stringify(keepMedia(JSON.parse(t), id, done)); } catch (e) { } }
    return v;
  }
  if (Array.isArray(v)) return v.map(x => keepMedia(x, id, done));
  if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v)) o[k] = keepMedia(v[k], id, done); return o; }
  return v;
}
const readFx = id => { try { return JSON.parse(fs.readFileSync(path.join(EFFECTS, id, 'effect.json'), 'utf8').replace(/^﻿/, '')); } catch (e) { return null; } };
function savePreset(b) {
  const realOf = x => { x = String(x || ''); return ID_OK.test(x) && !x.startsWith('_') ? (presetOf(x) || x) : ''; };
  const combo = b.combo && Array.isArray(b.combo.clips) && b.combo.clips.length ? b.combo : null;
  const base = realOf(combo ? combo.clips[0].fx : b.base);          // 在预设上再存预设：仍然指向最初的效果
  const src = base && readFx(base); if (!src) return { error: '读不到原效果的 effect.json' };
  const id = base + '-my-' + stamp().replace('-', ''), done = new Set();
  const vals = keepMedia(b.params && typeof b.params === 'object' ? b.params : {}, id, done);
  const keys = new Set((src.params || []).map(p => p.key));
  const extra = {}; Object.keys(vals).forEach(k => { if (!keys.has(k) && /^__/.test(k)) extra[k] = vals[k]; });   // 例如 __dur（持续时间按比例伸缩）
  const name = String(b.name || '').trim().slice(0, 40) || (src.name + ' · 我的预设');
  let cb = null;
  if (combo) {
    const clips = [];
    for (const c of combo.clips) {
      const fx = realOf(c.fx); if (!fx || !readFx(fx)) return { error: '组合里的效果「' + c.fx + '」找不到了' };
      clips.push({ fx, params: keepMedia(c.params || {}, id, done), start: +c.start || 0, len: +c.len || 5, layer: +c.layer || 0 });
    }
    cb = { clips, group: combo.group || null, len: +combo.len || 0 };
  }
  const out = Object.assign({}, src, {
    name, description: (cb ? '我的组合预设 · ' + cb.clips.length + ' 个素材' : '我的预设 · 基于「' + src.name + '」') + '，图片 / 关键帧都已保存',
    preset: base, presetExtra: extra,
    params: (src.params || []).map(p => (p.key in vals && vals[p.key] !== undefined) ? Object.assign({}, p, { default: vals[p.key] }) : p),
  });
  if (cb) out.combo = cb; else delete out.combo;
  writeFile(path.join(EFFECTS, id, 'effect.json'), JSON.stringify(out, null, 1));
  return { ok: true, id, media: done.size };
}
function deletePreset(id) {
  if (!ID_OK.test(id) || id.startsWith('_') || !presetOf(id)) return { error: '只能删除自己保存的预设' };
  moveAside(path.join(EFFECTS, id), path.join(BACKUP, id + '_' + stamp()));   // 先挪到 effects\_backup，误删还能找回
  return { ok: true };
}
// ================= 删除卡片（v26.0） =================
// 彻底删掉 effects\<id> 整个文件夹（预设复制进去的 media 也在里面），不进 _backup。只动这一个文件夹。
// 别的卡片基于它（"preset" 或组合里的 fx 指向它）时不让删，免得把别的卡片弄坏。
function cardInfo(id) {
  if (!ID_OK.test(id) || id.startsWith('_')) return { error: '卡片不存在' };
  const dir = path.join(EFFECTS, id); if (!fs.existsSync(path.join(dir, 'effect.json'))) return { error: '卡片不存在' };
  let files = 0, bytes = 0, media = 0;
  const walk = (d, inMedia) => { for (const n of fs.readdirSync(d)) { const f = path.join(d, n), st = fs.statSync(f); if (st.isDirectory()) walk(f, inMedia || n === 'media'); else { files++; bytes += st.size; if (inMedia) media++; } } };
  walk(dir, false);
  const usedBy = [];
  for (const o of fs.readdirSync(EFFECTS)) {
    if (o === id || o.startsWith('_')) continue;
    const j = readFx(o); if (!j) continue;
    if (j.preset === id || ((j.combo && j.combo.clips) || []).some(c => c.fx === id)) usedBy.push(j.name || o);
  }
  return { ok: true, files, bytes, media, usedBy };
}
function deleteCard(id) {
  const info = cardInfo(id); if (info.error) return info;
  if (info.usedBy.length) return { error: '有 ' + info.usedBy.length + ' 张别的卡片基于它，先删那几张' };
  try { fs.rmSync(path.join(EFFECTS, id), { recursive: true, force: true }); } catch (e) { return { error: e.message }; }
  return { ok: true, files: info.files, bytes: info.bytes };
}
function handleStudioZip(res) {
  const top = 'effect-studio/';
  const skipTop = rel => junk(rel) || /^(node_modules|output|uploads|runtime|_backup|_publish|logs|projects|\.git)(\/|$)/.test(rel) || /^effects\/_backup(\/|$)/.test(rel) || /\.(log|zip)$/.test(rel);
  const files = collect(ROOT, '', skipTop).map(f => ({ path: top + f.path, data: f.data }));
  ['output', 'uploads'].forEach(d => files.push({ path: top + d + '/.keep', data: Buffer.alloc(0) }));
  sendZip(res, `EffectStudio-${VERSION}-${stamp().slice(0, 8)}.zip`, files);
}

// ================= 【区域I 稳定性】 =================
// 1) 错误日志：网页里出的错、服务这边出的错，都追加到 logs\错误日志.txt（超过 2MB 自动换一个新文件，旧的留一份）
const LOGS = path.join(ROOT, 'logs'), ERRLOG = path.join(LOGS, '错误日志.txt');
function logError(from, msg) {
  try {
    fs.mkdirSync(LOGS, { recursive: true });
    if (fs.existsSync(ERRLOG) && fs.statSync(ERRLOG).size > 2e6) fs.renameSync(ERRLOG, path.join(LOGS, '错误日志-旧.txt'));
    const t = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().replace('T', ' ').slice(0, 19);
    fs.appendFileSync(ERRLOG, `[${t}] [${from}] ${VERSION}\n${String(msg).slice(0, 4000)}\n\n`);
  } catch (e) { }
}
process.on('uncaughtException', (e) => { logError('服务', e && e.stack || e); console.error(e); });
process.on('unhandledRejection', (e) => { logError('服务', e && e.stack || e); console.error(e); });
// 2) 工程存盘：projects\当前工程.json 是最新的一份；每隔 5 分钟（且内容有变化）另存一份到 projects\历史\，只留最近 30 份
const PROJ = path.join(ROOT, 'projects'), PROJ_CUR = path.join(PROJ, '当前工程.json'), PROJ_HIST = path.join(PROJ, '历史'), PROJ_KEEP = 30;
const histFiles = () => { try { return fs.readdirSync(PROJ_HIST).filter(f => /^工程-[\d-]+\.json$/.test(f)).sort().reverse(); } catch (e) { return []; } };
function saveProject(raw) {
  const d = JSON.parse(raw.toString('utf8'));
  if (!d || typeof d !== 'object' || !d.data) throw new Error('工程数据不对');
  const txt = JSON.stringify(d);
  fs.mkdirSync(PROJ_HIST, { recursive: true });
  const tmp = PROJ_CUR + '.tmp'; fs.writeFileSync(tmp, txt); fs.renameSync(tmp, PROJ_CUR);   // 先写临时文件再换名：写到一半断电也不会把旧工程弄坏
  const h = histFiles(), lastH = h[0] && path.join(PROJ_HIST, h[0]);
  const core = (x) => { const c = JSON.parse(JSON.stringify(x || {})); if (c.timeline) { delete c.timeline.t; delete c.timeline.sel; } return JSON.stringify(c); };   // 只是挪了播放头 / 换了选中，不算改动
  const same = lastH && (() => { try { return core(JSON.parse(fs.readFileSync(lastH, 'utf8')).data) === core(d.data); } catch (e) { return false; } })();
  if (!same && (!lastH || d.force || Date.now() - fs.statSync(lastH).mtimeMs > 5 * 60e3)) {
    fs.copyFileSync(PROJ_CUR, path.join(PROJ_HIST, '工程-' + stamp() + '.json'));
    for (const f of histFiles().slice(PROJ_KEEP)) { try { fs.unlinkSync(path.join(PROJ_HIST, f)); } catch (e) { } }
  }
  return { ok: true };
}
function readProject(name) {
  const f = name ? path.join(PROJ_HIST, name) : PROJ_CUR;
  if (name && !/^工程-[\d-]+\.json$/.test(name)) return {};
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return {}; }
}

// ================= 【区域G 网址路由】 =================
http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const ra = req.socket.remoteAddress || '';
  if (!/^(127\.|::1$|::ffff:127\.)/.test(ra)) { res.writeHead(403); return res.end('forbidden'); }
  try {
    // 会写文件的操作，要求网页带上 X-FX 标记（别的网站没法偷偷往你电脑里写东西）
    const guard = () => req.method === 'POST' && req.headers['x-fx'] === '1';
    if (url.pathname === '/api/log') { if (!guard()) return send(res, 403, { error: 'forbidden' }); const b = await readBody(req); logError('网页', b.msg || ''); return send(res, 200, { ok: true }); }
    if (url.pathname === '/api/project/save') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return send(res, 200, saveProject(await readRaw(req, 50e6))); }
    if (url.pathname === '/api/project/latest') return send(res, 200, readProject(''));
    if (url.pathname === '/api/project/list') return send(res, 200, histFiles().map(n => ({ name: n, size: fs.statSync(path.join(PROJ_HIST, n)).size })));
    if (url.pathname === '/api/project/get') return send(res, 200, readProject(url.searchParams.get('name') || 'x'));
    if (url.pathname === '/api/open-logs') {
      fs.mkdirSync(LOGS, { recursive: true }); if (!fs.existsSync(ERRLOG)) fs.writeFileSync(ERRLOG, '');
      exec(process.platform === 'win32' ? `explorer /select,"${ERRLOG}"` : `open "${LOGS}"`); return send(res, 200, { ok: true });
    }
    if (url.pathname === '/api/effects') return send(res, 200, listEffects());
    if (url.pathname === '/api/thumb') {           // 左侧缩略图（区域T）：r 变了 URL 就变，浏览器缓存自动失效
      const id = url.searchParams.get('id') || '';
      if (!ID_OK.test(id) || id.startsWith('_') || !fs.existsSync(path.join(EFFECTS, id, 'effect.json'))) return send(res, 404, { error: 'not found' });
      try { const png = await thumbPng(id); res.writeHead(200, { 'Content-Type': 'image/png', 'Content-Length': png.length, 'Cache-Control': 'public, max-age=31536000, immutable' }); return res.end(png); }
      catch (e) { return send(res, 503, { error: e.message }); }
    }
    if (url.pathname === '/api/info') {
      const b = findBrowser();
      return send(res, 200, { version: VERSION, ffmpeg: !!findFfmpeg(), browser: b ? b.kind : null, launcher: !!process.env.FX_LAUNCHER });
    }
    if (url.pathname === '/api/export' && req.method === 'POST') {
      const b = await readBody(req);
      const comp = b.comp && Array.isArray(b.comp.clips) && b.comp.clips.length ? b.comp : null;   // 素材时间线：多个效果叠在一起导出
      const fxs = listEffects();
      if (comp ? !comp.clips.every((c) => fxs.some((e) => e.id === c.fx)) : !fxs.some((e) => e.id === b.effect)) return send(res, 400, { error: 'unknown effect' });
      const o = { effect: comp ? 'timeline' : b.effect, comp: !!comp, name: String(b.name || ''), params: comp || b.params || {}, width: Math.min(7680, Math.max(16, b.width | 0 || 1920)), height: Math.min(7680, Math.max(16, b.height | 0 || 1080)),
        fps: Math.min(120, Math.max(1, +b.fps || 30)), hold: Math.max(0, +b.hold || 0), dir: safeDir(b.dir), tc: b.tc != null && isFinite(+b.tc) ? Math.max(0, +b.tc) : null, codec: CODECS[b.codec] ? b.codec : 'pq', still: b.still != null && isFinite(+b.still) ? Math.max(0, +b.still) : null };
      const id = String(Date.now()); jobs[id] = { status: 'running', progress: 0 };
      runExport(jobs[id], o).catch((e) => { jobs[id].status = 'error'; jobs[id].message = e.message; console.error(e); logError('导出 ' + o.effect, e && e.stack || e); });
      return send(res, 200, { id });
    }
    if (url.pathname === '/api/job') return send(res, 200, jobs[url.searchParams.get('id')] || { status: 'error', message: 'job not found' });
    if (url.pathname === '/api/open-output') {
      fs.mkdirSync(OUT, { recursive: true });
      const cmd = process.platform === 'win32' ? 'explorer' : process.platform === 'darwin' ? 'open' : 'xdg-open';
      const d = safeDir(url.searchParams.get('dir')), od = d && fs.existsSync(path.join(OUT, d)) ? path.join(OUT, d) : OUT;
      exec(`${cmd} "${od}"`); return send(res, 200, { ok: true });
    }
    if (url.pathname === '/api/export-pack' && req.method === 'POST') { const b = await readBody(req); return send(res, 200, writePack(b)); }
    if (url.pathname === '/api/pick-video' && req.method === 'POST') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return await handlePickVideo(res); }
    if (url.pathname === '/api/upload-video') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return await handleVideoUpload(req, res); }
    if (url.pathname === '/api/upload') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return await handleUpload(req, res); }
    if (url.pathname === '/api/install') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return await handleInstall(req, res, url); }
    if (url.pathname === '/api/update/check') {
      try { return send(res, 200, { ok: true, autoCheck: updater.config().autoCheck, ...(await updater.check(VERSION, url.searchParams.get('force') === '1')) }); }
      catch (e) { return send(res, 200, { ok: false, autoCheck: updater.config().autoCheck, error: e.message }); }
    }
    if (url.pathname === '/api/update/apply') {
      if (!guard()) return send(res, 403, { error: 'forbidden' });
      try { return await handleUpdateApply(req, res); } catch (e) { return send(res, 200, { error: e.message }); }
    }
    if (url.pathname === '/api/space') return send(res, 200, { groups: spaceGroups(), keep: KEEP_BACKUPS });
    if (url.pathname === '/api/space/clean' && req.method === 'POST') {
      if (!guard()) return send(res, 403, { error: 'forbidden' });
      const b = await readBody(req);
      return send(res, 200, cleanSpace(Array.isArray(b.keys) ? b.keys : []));
    }
    if (url.pathname === '/api/preset') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return send(res, 200, savePreset(await readBody(req))); }
    if (url.pathname === '/api/card-info') return send(res, 200, cardInfo(url.searchParams.get('id') || ''));
    if (url.pathname === '/api/card-delete') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return send(res, 200, deleteCard(String((await readBody(req)).id || ''))); }
    if (url.pathname === '/api/preset-delete') { if (!guard()) return send(res, 403, { error: 'forbidden' }); return send(res, 200, deletePreset(String((await readBody(req)).id || ''))); }
    if (url.pathname === '/api/effect-zip') return handleEffectZip(res, url.searchParams.get('id') || '');
    if (url.pathname === '/api/studio-zip') return handleStudioZip(res);
    // 静态文件：/effects/... 和 /uploads/... 从对应文件夹读，其余从 public 读
    let p = decodeURIComponent(url.pathname); if (p === '/') p = '/index.html';
    const base = p.startsWith('/effects/') || p.startsWith('/uploads/') ? ROOT : PUBLIC;
    // 预设文件夹里只有 effect.json，其余文件（effect.html、bundle.js…）用原效果的（v9.0）
    { const m = /^\/effects\/([\w-]+)\/(.+)$/.exec(p);
      if (m && m[2] !== 'effect.json' && !fs.existsSync(path.join(EFFECTS, m[1], m[2]))) { const pb = presetOf(m[1]); if (pb) p = '/effects/' + pb + '/' + m[2]; } }
    const fp = path.normalize(path.join(base, p));
    if (!fp.startsWith(base) || !fs.existsSync(fp) || fs.statSync(fp).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
    const type = MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream', size = fs.statSync(fp).size;
    const cache = p.startsWith('/uploads/') ? 'max-age=3600' : 'no-store';          // 上传的图片 / 视频帧不会变，可以缓存
    const rg = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (rg && size) {                                              // 视频拖动进度条要用「只读一段」
      let a = rg[1] === '' ? Math.max(0, size - +rg[2]) : +rg[1], b = rg[1] !== '' && rg[2] !== '' ? Math.min(+rg[2], size - 1) : size - 1;
      if (a > b || a >= size) { res.writeHead(416, { 'Content-Range': `bytes */${size}` }); return res.end(); }
      res.writeHead(206, { 'Content-Type': type, 'Content-Range': `bytes ${a}-${b}/${size}`, 'Accept-Ranges': 'bytes', 'Content-Length': b - a + 1, 'Cache-Control': cache });
      return fs.createReadStream(fp, { start: a, end: b }).pipe(res);
    }
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': size, 'Accept-Ranges': 'bytes', 'Cache-Control': cache });
    fs.createReadStream(fp).pipe(res);
  } catch (e) {
    console.error(e); logError('服务 ' + url.pathname, e && e.stack || e);
    if (!res.headersSent) send(res, 500, { error: e.message }); else res.end();
  }
}).on('error', (e) => {
  const u = `http://localhost:${PORT}`;
  if (e.code === 'EADDRINUSE') {
    // 已经开着一个工作台了：直接打开网页就行
    console.log('效果工坊已经在运行，直接打开网页：' + u);
    if (process.platform === 'win32') exec(`start "" ${u}`); else if (process.platform === 'darwin') exec(`open ${u}`);
    setTimeout(() => process.exit(0), 500); return;
  }
  console.error(e); process.exit(1);
}).listen(PORT, () => {
  const u = `http://localhost:${PORT}`;
  console.log(`\n  效果工坊 ${VERSION} 已启动：${u}\n  （用的时候不要关这个黑窗口；关掉窗口 = 关掉工作台）\n`);
  if (process.env.FX_NO_OPEN) return;
  if (process.platform === 'win32') exec(`start "" ${u}`); else if (process.platform === 'darwin') exec(`open ${u}`);
});
