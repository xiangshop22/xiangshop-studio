// 效果工坊 · 素材时间线层高可调（v33.0）
// 鼠标放到左边层名（层 1、层 2…）的下沿附近，光标变成上下箭头，按住上下拖就能把每一层调高 / 调矮（所有层一起变）。
// 双击这条边回到默认高度。高度记在浏览器里（fxnav:tlRowH），下次打开还是这个高度。
// 改的是 10-timeline.js 的 TR（每层多高）和 CSS 变量 --tlr（timeline.css 里层名、轨道、素材条都用它）。
const TR_MIN = 22, TR_MAX = 96, TR_DEF = 30, TR_EDGE = 5;   // 下沿上下各 5 像素算「抓得到」
function tlSetRowH(h, save) {
  TR = Math.max(TR_MIN, Math.min(TR_MAX, Math.round(h)));
  $('#tlp').style.setProperty('--tlr', TR + 'px');
  if (save) store.set('tlRowH', TR);
}
tlSetRowH(TR, false);
// 指针在不在某一层的下沿：返回这是第几条边（从 1 开始），不在返回 0
function rowEdgeAt(e) {
  const r = names.getBoundingClientRect(), y = e.clientY - r.top - RUL;
  const n = names.children.length; if (y < TR / 2) return 0;
  const k = Math.round(y / TR);
  return k >= 1 && k <= n && Math.abs(y - k * TR) <= TR_EDGE ? k : 0;
}
let rhDrag = null;
names.addEventListener('mousemove', e => { if (!rhDrag) names.style.cursor = rowEdgeAt(e) ? 'row-resize' : ''; });
names.addEventListener('mouseleave', () => { if (!rhDrag) names.style.cursor = ''; });
names.addEventListener('mousedown', e => {
  const k = rowEdgeAt(e); if (!k || e.button !== 0) return;
  e.preventDefault(); e.stopPropagation();
  rhDrag = { k, y0: e.clientY, h0: TR };
  document.documentElement.style.cursor = 'row-resize';
}, true);
addEventListener('mousemove', e => {
  if (!rhDrag) return;
  const h = rhDrag.h0 + (e.clientY - rhDrag.y0) / rhDrag.k;   // 第 k 条边跟着鼠标走：上面 k 层一起变高
  if (Math.round(h) === TR) return;
  tlSetRowH(h, false); tlDraw();
});
addEventListener('mouseup', () => {
  if (!rhDrag) return;
  rhDrag = null; document.documentElement.style.cursor = ''; names.style.cursor = '';
  tlSetRowH(TR, true); $('#hint').textContent = '素材时间线每层高度：' + TR + ' 像素（双击层名下沿回到默认）';
});
names.addEventListener('dblclick', e => {
  if (!rowEdgeAt(e)) return;
  e.preventDefault(); e.stopPropagation();
  tlSetRowH(TR_DEF, true); tlDraw(); $('#hint').textContent = '素材时间线每层高度回到默认（' + TR_DEF + ' 像素）';
}, true);
