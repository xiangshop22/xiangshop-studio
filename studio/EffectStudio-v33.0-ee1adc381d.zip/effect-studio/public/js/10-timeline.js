// 效果工坊 · 素材时间线：数据 · 叠加 iframe · 画面 · 选中 · 播放 · 画时间线 · 鼠标 · 按钮
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

// ================= 素材时间线（v10.2，组合 v10.4） =================
// 时间线上没有素材时，工作台和以前一模一样（下面所有挂钩都先判断 TL.clips.length）。
// 每个素材 = 一个效果 + 它自己的一份参数 + 开始时间 + 层。
// 选中的素材用原来的 #frame（右侧参数面板、关键帧、持续时间都照旧管它）；其余素材各开一个透明 iframe 叠在 #box 里。
let TR = Math.max(22, Math.min(96, +store.get('tlRowH', 30) || 30)); const RUL = 18;   // TR = 每一层的高度，在层名下沿上下拖可以改（v33.0，23-row-height.js）
const COLORS = ['#c9cfd8', '#5fb3b3', '#6d9cf0', '#7dc58c', '#d4a24c', '#d9806e', '#c7b07a', '#a98be0'];
const TL = { clips: [], groups: [] };
let tlKeepT = false, tlSel = null, tlT = 0, tlV = 10, tlLoading = false, tlPreview = true, tlInSel = false, tlInside = false, tlRaf = 0, tlQ = [], tlDragS = null, tlMulti = new Set(), tlGrp = null, tlIn = null, baseTf = '';   // tlIn = 双击「进到里面」正在改的组合（v12.1）
const grp = id => TL.groups.find(g => g.id === id);
const G = {};                                       // clip.id → 叠加用的 iframe
const clone = o => JSON.parse(JSON.stringify(o == null ? {} : o));
const clip = id => TL.clips.find(c => c.id === id);
const fxOf = c => effects.find(e => e.id === c.fx);
const colorOf = fx => { let h = 0; for (const ch of fx) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; };
var REF = null, tlZ = 1, rvSpan = 0;               // rvSpan：拖原视频结尾时临时把时间线拉到原视频剩下的全长（v19.0）                            // tlZ = 素材时间线放大倍数（v17.0）                                     // 原视频（v16.0）：{ url, name, vdur, in, out }，见下面【原视频】
function refLen() { return REF ? Math.max(0, REF.out - REF.in) : 0; }
const tlEnd = () => TL.clips.reduce((m, c) => Math.max(m, c.start + (c._len != null ? c._len : c.len)), refLen());
const panel = document.createElement('div'); panel.id = 'tlp';
panel.innerHTML = '<div id="tlp-h"><b>素材时间线</b><span id="tlp-time"></span><i id="tlp-k" title="点一下看完整的快捷键说明\n\n空格　播放 / 暂停\nDelete　删除选中的素材\nCtrl+A　全选素材\nCtrl+C / Ctrl+V　复制选中的素材 / 组合，粘贴到播放头那一秒（独立的一份）\nCtrl+D　原地复制一份\nCtrl / Shift + 点击　多选素材\nCtrl+G（或 Ctrl+Shift+C）　把选中的素材合成一个组合（预合成）\nCtrl+Shift+G　解散组合\nEsc　取消选中组合 / 多选\nCtrl+]　/　Alt+↑　上移一层\nCtrl+[　/　Alt+↓　下移一层\n← →　选中的素材前后挪 0.1 秒（加 Shift 是 1 秒）\nHome / End　跳到开头 / 结尾\n\n鼠标：把左边的效果拖到预览窗口或这里 = 加素材；拖素材条换时间 / 换层；拖右边缘改时长；点空白处跳时间">⌨ 快捷键</i></div>' +
  '<div id="tlp-e"></div><div id="tlp-b"><div id="tlp-names"></div><div id="tlp-t" tabindex="0"></div></div>';
$('main').insertBefore(panel, $('#kft'));
const trk = $('#tlp-t'), names = $('#tlp-names');
window.tlFitH = () => TL.clips.length || REF ? panel.offsetHeight + 12 : 0;

// ---------- 保存 / 恢复（存在这台电脑的浏览器里） ----------
let saveT = 0;
const tlSave = () => { clearTimeout(saveT); saveT = setTimeout(() => store.set('timeline', { clips: TL.clips.map(c => { const o = Object.assign({}, c); delete o._len; return o; }), groups: TL.groups, sel: tlSel, t: tlT }), 400); };

// ---------- 叠加 iframe ----------
function ghost(c) {
  let g = G[c.id];
  if (!g) {
    g = document.createElement('iframe'); g.className = 'tlg'; g.tabIndex = -1; G[c.id] = g;
    g.style.width = frame.style.width; g.style.height = frame.style.height; g.style.transform = baseTf || frame.style.transform;
    // v11.2：套一层 ghost.html —— 效果直接挂在工作台下面的话，它的拖动 / 缩放监听会把「选中素材」的抢走（见 ghost.html 开头）
    g.src = '/ghost.html?fx=' + encodeURIComponent(c.fx);
    g.onload = () => { try { if (!g.contentWindow.init) return; } catch (e) { return; } g._ok = true; ghostInit(c); };
    box.insertBefore(g, frame);
  }
  return g;
}
function ghostInit(c) {
  const g = G[c.id]; if (!g || !g._ok) return;
  try { const w = g.contentWindow; w.init(clone(c.params)); const d = +w.getDuration(); if (d > 0 && c.id !== tlSel) c.len = r2(d); } catch (e) { console.error(e); }
  tlRender(); tlDraw();
}
function dropGhost(id) { const g = G[id]; if (g) { g.remove(); delete G[id]; } }

// ---------- 画面：把全局时间 tlT 分给每个素材 ----------
function zOf(c) { const same = TL.clips.filter(o => o.layer === c.layer).sort((a, b) => a.start - b.start); return 10 + c.layer * 100 + same.indexOf(c); }
function tlRender() {
  if (!TL.clips.length) { frame.style.visibility = typeof emptyShowFrame !== 'function' || emptyShowFrame() ? '' : 'hidden'; frame.style.zIndex = ''; return; }   // 时间线为空：只有在左侧点过效果才露出来（19-empty-state.js）
  const T = tlT;
  TL.clips.forEach(c => {
    const loc = T - c.start, vis = loc >= -0.0001 && loc <= c.len + 0.0001, z = zOf(c);
    if (c.id === tlSel) {
      const g = G[c.id]; if (g) g.style.visibility = 'hidden';
      frame.style.zIndex = z; frame.style.visibility = vis && !tlLoading && !c.hide ? '' : 'hidden';
      applyTf(frame, c);
      if (vis && !tlLoading) { tlInside = true; try { seek(Math.max(0, Math.min(loc, dur))); } catch (e) { } tlInside = false; }
    } else {
      const g = ghost(c); g.style.zIndex = z; g.style.visibility = vis && !c.hide ? '' : 'hidden'; applyTf(g, c);   // 眼睛关了 = 不显示
      if (vis && g._ok) { try { g.contentWindow.renderAt(Math.max(0, Math.min(loc, c.len))); } catch (e) { } }
    }
  });
  if (!tlSel) { frame.style.zIndex = 9000; frame.style.visibility = tlPreview ? '' : 'hidden'; if (frame._tf) { frame.style.transform = baseTf; frame.style.opacity = ''; frame._tf = 0; } }
}
function tlSeek(T) { tlSeekTo(T); Hooks.run('tlSeek'); }
// 没选中素材时，上面的进度条显示整条时间线的时间（选中了素材时进度条是它自己的时间，由 seek 负责）
const tlBarSync = () => {
  if (tlSel || !TL.clips.some(c => !c.ref)) return;
  const E = Math.max(0.01, tlEnd()); slider.max = E; slider.value = tlT; $('#tl').textContent = tlT.toFixed(1) + ' / ' + E.toFixed(1) + ' s';
};
Hooks.on('tlSeek', tlBarSync); Hooks.on('tlDraw', tlBarSync); Hooks.on('seek', tlBarSync);   // 后台那个效果自己播的时候也别把进度条抢走
function tlSeekTo(T) { tlT = Math.max(0, r2(T)); tlRender(); headPos(); if (tlGrp) gpSync(); tlSave(); }
function headPos() { headPosTrack(); Hooks.run('headPos'); }
function headPosTrack() {
  const h = trk.querySelector('.tlhd'); if (h) h.style.left = Math.min(100, tlT / tlV * 100) + '%';
  $('#tlp-time').textContent = tlT.toFixed(2) + ' / ' + tlEnd().toFixed(2) + ' s';
}

// ---------- 选中素材 = 把它装进原来的 #frame，右侧面板就是它的参数 ----------
function syncSel() {
  const c = clip(tlSel); if (!c || tlLoading || !cur || cur.id !== c.fx) return;
  c.params = clone(params); if (dur > 0) c.len = r2(dur); tlSave();
}
function commitSel() {                               // 离开当前选中的素材：参数存回去，交给它自己的叠加 iframe
  const c = clip(tlSel); if (!c) return;
  syncSel(); const g = ghost(c); if (g._ok) ghostInit(c);
}
function tlSelect(id, keepMulti) {
  const c = clip(id); if (!c) return;
  if (!keepMulti) tlMulti = new Set([id]);
  tlIn = c.group || null;                            // 选中组合里的素材 = 在组合里面改它
  if (tlGrp) { tlGrp = null; gpBuild(); }
  if (tlSel === id) { tlDraw(); return; }
  tlStop(); commitSel();
  tlSel = id; tlPreview = false;
  if (!tlKeepT && (tlT < c.start || tlT > c.start + c.len)) tlT = c.start;
  tlLoading = true; tlRender();
  if (cur && cur.id === c.fx && frame.contentWindow && frame.contentWindow.init) {
    params = clone(c.params); buildParams(); histReset(); reinit(false);
  } else {
    tlInSel = true; select(c.fx); tlInSel = false;
    params = clone(c.params); buildParams(); histReset();   // 页面加载完 frame.onload → reinit 用的就是这份参数
  }
  tlDraw();
}
const frameIs = fx => { try { return frame.contentWindow.location.pathname.indexOf('/effects/' + fx + '/') >= 0; } catch (e) { return false; } };
function whenReady(fn) { tlLoading ? tlQ.push(fn) : fn(); }

// ---------- 接到工作台原来的流程上（没有素材时原样放行） ----------
Hooks.on('reinit:before', ctx => { ctx.clip = tlLoading && clip(tlSel); if (ctx.clip) ctx.play = false; });   // 素材正在装进 #frame：先别自动播放
Hooks.on('reinit', ctx => {
  const c = ctx.clip;
  if (c && frameIs(c.fx) && cur && cur.id === c.fx) {
    tlLoading = false; if (dur > 0) c.len = r2(dur);
    tlRender(); tlDraw();
    const q = tlQ; tlQ = []; q.forEach(f => f());
  }
});
Hooks.on('seek', t => {
  if (tlInside || !tlSel || tlLoading || !TL.clips.length) return;
  const c = clip(tlSel); if (!c) return;
  tlT = r2(c.start + t);                             // 用原来的播放 / 进度条时，别的素材跟着走
  TL.clips.forEach(o => {
    if (o.id === tlSel) return;
    const g = G[o.id]; if (!g) return; const loc = tlT - o.start, vis = loc >= 0 && loc <= o.len;
    g.style.visibility = vis ? '' : 'hidden'; applyTf(g, o); if (vis && g._ok) { try { g.contentWindow.renderAt(loc); } catch (e) { } }
  });
  applyTf(frame, c); headPos(); if (tlGrp) gpSync();
});
Hooks.on('markDirty', () => { if (tlSel && !tlLoading) { syncSel(); drawSoon(); } });
Hooks.on('select:before', () => { if (!tlInSel && TL.clips.length) { tlStop(); commitSel(); tlSel = null; tlPreview = true; } });
Hooks.on('select', () => { tlRender(); tlDraw(); });
Hooks.on('stop', () => { if (!tlPlaying) tlStop(); });
let lastSz = '';
Hooks.on('fit', () => {          // 其余素材的叠加 iframe 跟着 #frame 一起缩放（窗口大小变了也会走这里）
  const sz = frame.style.width + 'x' + frame.style.height;
  baseTf = frame.style.transform; frame._tf = 0;
  Object.keys(G).forEach(id => { const g = G[id]; g.style.width = frame.style.width; g.style.height = frame.style.height; g.style.transform = baseTf; g._tf = 0; });
  if (sz !== lastSz) { const first = !lastSz; lastSz = sz; if (!first) TL.clips.forEach(c => { if (c.id !== tlSel) ghostInit(c); }); }
  if (TL.groups.length) tlRender();
});

// ---------- 播放整条时间线 ----------
let tlPlaying = false;
function tlStop() { tlStopPlay(); Hooks.run('tlStop'); }
function tlStopPlay() { cancelAnimationFrame(tlRaf); tlRaf = 0; if (tlPlaying) { tlPlaying = false; ppTxt(); } }
function tlPlay() {
  if (tlPlaying) { tlStop(); return; }
  const end = tlEnd(); if (!end) return;
  stop(); tlPlaying = true; ppTxt();
  const from = tlT >= end - 0.02 ? 0 : tlT, t0 = performance.now() - from * 1000;
  const tick = n => { const T = (n - t0) / 1000; tlSeek(Math.min(T, end)); if (T < end && tlPlaying) tlRaf = requestAnimationFrame(tick); else tlStop(); };
  tlRaf = requestAnimationFrame(tick);
}
const ppTxt = () => ppSync();                        // 播放按钮显示「播放 / 暂停」也跟着时间线（v24.11）

// ---------- 画时间线 ----------
// 行：最上面一条「新层」，然后从最上层往下；组合在它最上面一层的上方多一条「组合条」，折叠时成员行不显示
function buildRows() {
  const top = TL.clips.length ? Math.max(...TL.clips.map(c => c.layer)) : -1;
  const R = [{ t: 'new', L: top + 1 }]; let pg = null;
  for (let L = top; L >= 0; L--) {
    const cs = TL.clips.filter(c => c.layer === L), g = (cs.length && cs[0].group) || null;
    if (g && g !== pg) R.push({ t: 'grp', g, L });
    pg = g;
    if (g && grp(g) && grp(g).col) continue;
    R.push({ t: 'layer', L, g });
  }
  return R;
}
const rowIdx = (R, L) => { const i = R.findIndex(r => r.t === 'layer' && r.L === L); return i >= 0 ? i : 0; };
const rowAt = (R, y) => R[Math.max(0, Math.min(R.length - 1, Math.floor((y - W().top - RUL) / TR)))];
const rowLayer = r => r.t === 'layer' ? r.L : r.L + 1;
let drawT = 0; const drawSoon = () => { clearTimeout(drawT); drawT = setTimeout(tlDraw, 80); };
function tlDraw() { drawTrack(); Hooks.run('tlDraw'); }
function drawTrack() {
  const has = TL.clips.length > 0 || !!REF;
  $('#tlp-e').hidden = has; $('#tlp-b').style.display = has ? '' : 'none';
  $('#tlp-e').textContent = '还没有素材：把左边的效果直接拖到上面的预览窗口（或拖到这里），它就出现在时间线上；再拖别的效果进来，就一层一层叠上去。';
  if (!has) { trk.innerHTML = ''; names.innerHTML = ''; headPos(); if (lastPH) { lastPH = 0; fit(); } return; }
  if (!tlDragS) {                                     // 时间线刻度（v24.6）：变长时一次多留些余量，变短时不急着缩 —— 拉长 / 拉短素材时整条时间线不再跟着跳
    const need = Math.max(10, Math.ceil(Math.max(tlEnd(), rvSpan) * 1.12));
    if (need > tlV) tlV = Math.max(need, Math.ceil(Math.max(tlEnd(), rvSpan) * 1.3));
    else if (need < tlV * 0.5) tlV = need;             // 内容短到不到一半（比如删了素材）才缩回来
  }
  const R = tlDragS && tlDragS.R ? tlDragS.R : buildRows(), V = tlV;
  trk.style.height = RUL + R.length * TR + 'px';
  let h = '<div class="tlrul notranslate" translate="no">';   // 不让翻译插件（沉浸式翻译等）翻刻度：每次重画都会在「0s / 1s…」后面挂一个转圈图标
  const step = [0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300].find(s => V / s <= 14 * tlZ) || 600;
  for (let t = 0; t <= V + 0.001; t += step) h += '<div class="tltk" style="left:' + t / V * 100 + '%">' + (t >= 60 ? Math.floor(t / 60) + ':' + String(Math.round(t % 60)).padStart(2, '0') : +t.toFixed(1) + 's') + '</div>';
  h += '</div>';
  let nm = '';
  R.forEach((r, i) => {
    h += '<div class="tlrow' + (r.t === 'new' ? ' nw' : r.g ? ' ing' : '') + '" style="top:' + (RUL + i * TR) + 'px"></div>';
    nm += r.t === 'new' ? '<div class="nw">新层</div>' : r.t === 'grp' ? '<div class="gq">组合</div>' : '<div' + (r.g ? ' class="gm"' : '') + '>' + (typeof lyBtns === 'function' ? lyBtns(r.L) : '') + (r.g ? '└ ' : '层 ') + (r.L + 1) + '</div>';   // 眼睛 / 锁：20-layer-lock.js
    if (r.t === 'grp') {
      const g = grp(r.g); if (!g) return;
      const [gs, ge, m] = gRange(g);
      let dm = ''; if (g.anim) g.keys.forEach(k => dm += '<b class="tlgk" style="left:' + (k.t / Math.max(0.01, ge - gs) * 100) + '%"></b>');
      h += '<div class="tlgb' + (g.id === tlGrp ? ' on' : '') + (g.id === tlIn ? ' in' : '') + '" data-g="' + g.id + '" style="top:' + (RUL + i * TR + 3) + 'px;left:' + gs / V * 100 + '%;width:' + Math.max(0.4, (ge - gs) / V * 100) + '%" title="' + esc(g.name) + '：点一下选中整个组合（预览区拖动 / 旋转 / 关键帧都是整组的）；双击进到里面改单个素材；拖动整组换时间">' +
        '<span class="tgt" title="' + (g.col ? '展开看里面的素材' : '折叠成一条') + '">' + (g.col ? '▸' : '▾') + '</span>▣ ' + esc(g.name) + '<i>' + m.length + ' 个素材</i>' + dm + '</div>';
    }
  });
  TL.clips.forEach(c => {
    const g = c.group && grp(c.group); if (g && g.col) return;
    const len = c._len != null ? c._len : c.len, top = RUL + rowIdx(R, c.layer) * TR + 3;
    const f = fxOf(c), nmx = esc(f ? f.name : c.fx);
    h += '<div class="tlc' + (c.id === tlSel && !tlGrp ? ' on' : '') + (tlMulti.has(c.id) && tlMulti.size > 1 ? ' ms' : '') + (g ? ' ing' : '') + (c.lock ? ' lk' : '') + (c.hide ? ' hd' : '') + '" data-id="' + c.id + '" style="top:' + top + 'px;left:' + c.start / V * 100 + '%;width:' + Math.max(0.4, len / V * 100) + '%;background:' + colorOf(c.fx) + '" title="' + nmx + '　' + c.start.toFixed(2) + ' → ' + (c.start + len).toFixed(2) + ' 秒（' + len.toFixed(2) + ' 秒）">' + nmx + '<i>' + len.toFixed(1) + 's</i><div class="tlr" title="拖动改时长"></div></div>';
  });
  h += '<div class="tlhd"></div>';
  trk.innerHTML = h; names.innerHTML = nm; headPos();
  if (panel.offsetHeight !== lastPH) { lastPH = panel.offsetHeight; fit(); }
}
let lastPH = 0;

// ---------- 鼠标 ----------
const W = () => trk.getBoundingClientRect();
const xT = x => { const r = W(); return Math.max(0, (x - r.left) / r.width * tlV); };
function snap(ex, s, len) {                          // 吸附：别的素材的头尾、播放头、0 秒（6 像素以内）
  const tol = 6 / W().width * tlV; let best = s, d0 = tol;
  const pts = [0, tlT]; TL.clips.forEach(o => { if (!ex.has(o.id)) pts.push(o.start, o.start + o.len); });
  pts.forEach(p => { if (Math.abs(p - s) < d0) { d0 = Math.abs(p - s); best = p; } if (Math.abs(p - (s + len)) < d0) { d0 = Math.abs(p - s - len); best = p - len; } });
  const tolH = 10 / W().width * tlV;                 // v21.0：播放头吸得更远一点（10 像素），方便「拖到播放头」
  if (best === s) { if (Math.abs(tlT - s) < tolH) best = tlT; else if (Math.abs(tlT - s - len) < tolH) best = tlT - len; }
  return Math.max(0, r2(best));
}
// 放到某一层：那一层同一时间段已经有素材，就不挤在一起，而是插成新的一层（往上去 → 插在它上面，往下去 → 插在它下面）
const overlaps = (a, b) => a !== b && a.start < b.start + b.len - 0.001 && b.start < a.start + a.len - 0.001;
function placeAt(c, L, up, force) {
  if (!force && !TL.clips.some(o => o.layer === L && overlaps(o, c))) { c.layer = L; normLayers(); return; }
  if (up) { TL.clips.forEach(o => { if (o !== c && o.layer > L) o.layer++; }); c.layer = L + 1; }
  else { TL.clips.forEach(o => { if (o !== c && o.layer >= L) o.layer++; }); c.layer = L; }
  normLayers();
}
// 层整理：去掉空层；同一组合的成员永远挨在一起（成员不会和组合外的素材混在同一层）
function layerItems() {
  TL.groups = TL.groups.filter(g => TL.clips.some(c => c.group === g.id));
  TL.clips.forEach(c => { if (c.group && !grp(c.group)) delete c.group; });
  const ls = [...new Set(TL.clips.map(c => c.layer))].sort((a, b) => b - a), items = [];
  ls.forEach(L => {
    const cs = TL.clips.filter(c => c.layer === L), non = cs.filter(c => !c.group);
    if (non.length) items.push({ g: null, clips: non });
    [...new Set(cs.filter(c => c.group).map(c => c.group))].forEach(g => items.push({ g, clips: cs.filter(c => c.group === g) }));
  });
  const out = [], done = new Set();
  items.forEach(it => { if (!it.g) out.push(it); else if (!done.has(it.g)) { done.add(it.g); items.filter(x => x.g === it.g).forEach(x => out.push(x)); } });
  return out;                                        // 从上到下
}
const applyItems = out => out.forEach((it, i) => it.clips.forEach(c => c.layer = out.length - 1 - i));
function normLayers() { applyItems(layerItems()); }
let gbLast = { id: null, t: 0 };                     // 双击组合条 = 进到组合里面（单击会重画时间线，浏览器的 dblclick 收不到，自己判断）
trk.addEventListener('mousedown', e => {
  if (e.button !== 0) return; trk.focus(); e.preventDefault();
  const R = buildRows();
  const gb = e.target.closest('.tlgb');
  if (gb) {
    const g = grp(gb.dataset.g); if (!g) return;
    if (e.target.classList.contains('tgt')) { g.col = !g.col; tlDraw(); tlSave(); return; }
    const now = Date.now();
    if (gbLast.id === g.id && now - gbLast.t < 400) { gbLast = { id: null, t: 0 }; enterGroup(g, tlSel); return; }
    gbLast = { id: g.id, t: now };
    selGroup(g.id);
    const m = TL.clips.filter(c => c.group === g.id);
    tlDragS = { k: 'gmove', g, R, x: e.clientX, s0: new Map(m.map(c => [c, c.start])), gs0: gRange(g)[0], len: gRange(g)[1] - gRange(g)[0], ex: new Set(m.map(c => c.id)), moved: false };
    trk.classList.add('mv'); tlDraw(); return;
  }
  const ce0 = e.target.closest('.tlc'), ce = ce0 && !(clip(ce0.dataset.id) || {}).lock ? ce0 : null;   // 锁定的素材点不中（v24.10）
  if (ce) {
    const c = clip(ce.dataset.id); if (!c) return;
    if (e.ctrlKey || e.metaKey || e.shiftKey) {               // 多选：Ctrl / Shift + 点击
      if (tlGrp) { tlGrp = null; gpBuild(); }
      if (!tlMulti.size && tlSel) tlMulti.add(tlSel);
      tlMulti.has(c.id) ? tlMulti.delete(c.id) : tlMulti.add(c.id);
      if (!tlSel) tlSelect(c.id);
      tlDraw(); return;
    }
    const multi = tlMulti.size > 1 && tlMulti.has(c.id) ? [...tlMulti].map(clip).filter(Boolean) : null;
    if (tlSel !== c.id || tlGrp) { tlKeepT = true; tlSelect(c.id, !!multi); tlKeepT = false; }   // v21.0：按下时播放头不跳，方便拖到播放头吸附
    if (e.target.classList.contains('tlr')) tlDragS = { k: 'len', c, R, x: e.clientX, len0: c.len, m: multi ? multi.map(o => [o, o.len]) : null };   // v21.0：多选时一起改时长
    else if (multi) tlDragS = { k: 'mmove', c, R, x: e.clientX, s0: new Map(multi.map(o => [o, o.start])), ex: new Set(multi.map(o => o.id)), moved: false };
    else tlDragS = { k: 'move', c, R, x: e.clientX, y: e.clientY, s0: c.start, l0: c.layer, moved: false };
    trk.classList.add(tlDragS.k === 'len' ? 'rs' : 'mv');
  } else if (e.clientY - W().top < RUL) { tlStop(); stop(); tlDragS = { k: 'scrub' }; tlSeek(xT(e.clientX)); }   // 顶上的刻度尺：拖 = 拖时间
  else {                                             // 空白处：按住左键拉一个框 = 框选素材（v13.1）；没拉开就当单击 = 跳到那一秒
    const add = e.ctrlKey || e.metaKey || e.shiftKey;
    tlDragS = { k: 'band', x: e.clientX, y: e.clientY, add: add ? new Set(tlMulti.size ? tlMulti : tlSel ? [tlSel] : []) : new Set(), moved: false };
    return;
  }
  tlDraw();
});
// 框选：框碰到的素材条（折叠的组合碰到组合条 = 里面的素材全算）都选上；Ctrl / Shift 按住再框 = 加选
function bandPick(d, e) {
  const x0 = Math.min(d.x, e.clientX), x1 = Math.max(d.x, e.clientX), y0 = Math.min(d.y, e.clientY), y1 = Math.max(d.y, e.clientY);
  let bx = trk.querySelector('.tlband'); if (!bx) { bx = document.createElement('div'); bx.className = 'tlband'; trk.appendChild(bx); }
  const r = W(); bx.style.cssText = 'left:' + (x0 - r.left) + 'px;top:' + (y0 - r.top) + 'px;width:' + (x1 - x0) + 'px;height:' + (y1 - y0) + 'px';
  const hit = el => { const b = el.getBoundingClientRect(); return b.right >= x0 && b.left <= x1 && b.bottom >= y0 && b.top <= y1; };
  const ids = new Set(d.add);
  trk.querySelectorAll('.tlc:not(.lk)').forEach(el => { if (hit(el)) ids.add(el.dataset.id); });
  trk.querySelectorAll('.tlgb').forEach(el => { if (hit(el)) TL.clips.forEach(c => { if (c.group === el.dataset.g) ids.add(c.id); }); });
  trk.querySelectorAll('.tlc').forEach(el => el.classList.toggle('ms', ids.has(el.dataset.id) && ids.size > 1));
  d.ids = ids;
  $('#hint').textContent = '框选：' + ids.size + ' 个素材（松手选中 · 按住 Ctrl / Shift 再框是加选）';
}
addEventListener('mousemove', e => {
  const d = tlDragS; if (!d) return;
  if (d.k === 'scrub') { tlSeek(xT(e.clientX)); return; }
  if (d.k === 'band') { if (!d.moved && Math.abs(e.clientX - d.x) < 4 && Math.abs(e.clientY - d.y) < 4) return; d.moved = true; bandPick(d, e); return; }
  const dt = (e.clientX - d.x) / W().width * tlV;
  if (d.k === 'len') { d.c._len = Math.max(0.5, r2(d.len0 + dt)); if (d.m) d.m.forEach(([o, l0]) => o._len = Math.max(0.5, r2(l0 + dt))); $('#hint').textContent = (d.m ? d.m.length + ' 个素材一起' : '素材') + '时长：' + (dt >= 0 ? '+' : '') + dt.toFixed(2) + ' 秒（松手生效）'; tlDraw(); return; }
  if (!d.moved && Math.abs(e.clientX - d.x) < 3 && (d.y == null || Math.abs(e.clientY - d.y) < 3)) return;
  d.moved = true;
  if (d.k === 'gmove' || d.k === 'mmove') {           // 整组 / 多选一起挪时间
    const first = Math.min(...[...d.s0.values()]), last = Math.max(...[...d.s0.keys()].map(o => d.s0.get(o) + o.len));
    const ns = snap(d.ex, Math.max(0, first + dt), last - first), k = ns - first;
    d.s0.forEach((s, o) => o.start = r2(s + k));
    $('#hint').textContent = '移动 ' + d.s0.size + ' 个素材：' + (k >= 0 ? '+' : '') + k.toFixed(2) + ' 秒';
    tlRender(); tlDraw(); return;
  }
  d.c.start = snap(new Set([d.c.id]), Math.max(0, d.s0 + dt), d.c.len);
  d.c.layer = rowLayer(rowAt(d.R, e.clientY));
  $('#hint').textContent = '移动素材：从 ' + d.c.start.toFixed(2) + ' 秒开始';
  tlRender(); tlDraw();
});
addEventListener('mouseup', () => {
  const d = tlDragS; if (!d) return;
  tlDragS = null; trk.classList.remove('rs', 'mv');
  if (d.k === 'band') {
    if (!d.moved) {                                  // 没拉开 = 单击空白处：跳时间 + 取消选择（v21.0 补丁，和一般软件一样；按住 Ctrl / Shift 点空白处不取消）
      // v24.10：点图层后面的空白处只取消选中，播放头不动；要跳到某一秒，点上面的刻度条
      if (!d.add.size && (tlSel || tlGrp || tlMulti.size)) { commitSel(); tlSel = null; tlPreview = false; tlMulti = new Set(); tlGrp = null; tlIn = null; gpBuild(); tlRender(); kfTrackDraw(); }
      tlDraw(); return;
    }
    const ids = [...(d.ids || [])].filter(id => clip(id));
    if (tlGrp) { tlGrp = null; gpBuild(); }
    tlMulti = new Set(ids);
    if (ids.length && !ids.includes(tlSel)) tlSelect(ids[0], true);
    tlDraw(); kfTrackDraw();
    toast(ids.length > 1 ? '已框选 ' + ids.length + ' 个素材：可以一起拖时间、Delete 删除、Ctrl+G 合成组合' : ids.length ? '已选中 1 个素材' : '框里没有素材');
    return;
  }
  if (d.k === 'len' && d.m) {                        // v21.0：多选一起改时长 —— 逐个选中、用和单个一样的 setDuration（停留 / 原生时长 / 拉伸自动判断），最后恢复多选
    const list = d.m.map(([o]) => { const L = o._len; delete o._len; return [o, L]; }).filter(([o, L]) => L != null && Math.abs(L - o.len) > 0.01);
    const keep = [...tlMulti], sel = tlSel; tlDraw();
    if (list.length) (async () => {
      for (let i = 0; i < list.length; i++) {
        const [o, L] = list[i]; $('#hint').textContent = '正在改时长 ' + (i + 1) + ' / ' + list.length + '…';
        tlKeepT = true; tlSelect(o.id, true); tlKeepT = false;
        await new Promise(r => whenReady(r)); setDuration(L); syncSel();
      }
      tlKeepT = true; tlSelect(sel, true); tlKeepT = false; tlMulti = new Set(keep);
      tlRender(); tlDraw(); tlSave(); toast(list.length + ' 个素材的时长一起改好了（每个右侧「持续时间」都同步变了）');
    })();
    return;
  }
  if (d.k === 'len') {
    const L = d.c._len; delete d.c._len;
    if (L != null && Math.abs(L - d.c.len) > 0.01) whenReady(() => { setDuration(L); syncSel(); tlRender(); tlDraw(); toast('素材时长改为 ' + dur.toFixed(2) + ' 秒（右侧「持续时间」同步变了）'); });
  }
  if (d.k === 'move' && d.moved) { placeAt(d.c, d.c.layer, d.c.layer >= d.l0); tlRender(); }
  if ((d.k === 'move' || d.k === 'mmove') && !d.moved && d.c && (tlT < d.c.start || tlT > d.c.start + d.c.len)) tlSeek(d.c.start);   // 只点不拖：和以前一样跳到这个素材
  tlDraw(); tlSave(); if (tlGrp) gpBuild();
});

// ---------- 按钮 / 键盘 ----------
// 从左边拖进来：用效果的默认参数新建一个素材，然后选中它（右侧面板就是它的参数）
function addFx(id, start, layer) {
  const e = effects.find(x => x.id === id); if (!e) return;
  if (e.combo && Array.isArray(e.combo.clips) && e.combo.clips.length) return addCombo(e, start);   // 组合预设：整组放进去（v25.0）
  const ps = {}; e.params.forEach(p => ps[p.key] = (p.default && typeof p.default === 'object') ? clone(p.default) : p.default);
  Object.assign(ps, clone(e.presetExtra || {}));
  const top = TL.clips.length ? Math.max(...TL.clips.map(c => c.layer)) + 1 : 0;
  const c = { id: 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), fx: id, params: ps, start: Math.max(0, r2(start)), len: 5, layer: top };
  TL.clips.push(c);
  if (layer != null && layer < top) placeAt(c, Math.max(0, layer), true); else c.layer = top;
  tlT = c.start; tlSelect(c.id); fit(); tlSave();
  toast('「' + e.name + '」已放到第 ' + (c.layer + 1) + ' 层，从 ' + c.start.toFixed(2) + ' 秒开始');
}
// 组合预设（v25.0）：把保存时的几个素材按原来的上下层、前后时间整组放到最上面；有组合就连组合关键帧一起恢复
function addCombo(e, start) {
  const s0 = Math.max(0, r2(start)), top = TL.clips.length ? Math.max(...TL.clips.map(c => c.layer)) + 1 : 0;
  const g = e.combo.group ? Object.assign(clone(e.combo.group), { id: nid('g'), name: e.name }) : null;
  if (g) TL.groups.push(g);
  const ids = e.combo.clips.map(k => {
    const c = { id: nid('c'), fx: k.fx, params: clone(k.params), start: r2(s0 + (+k.start || 0)), len: +k.len || 5, layer: top + (+k.layer || 0) };
    if (g) c.group = g.id; TL.clips.push(c); return c.id;
  });
  normLayers(); tlT = s0;
  if (g) selGroup(g.id); else tlSelect(ids[0]);
  fit(); tlRender(); tlDraw(); tlSave();
  toast('组合预设「' + e.name + '」已放进时间线：' + ids.length + ' 个素材，从 ' + s0.toFixed(2) + ' 秒开始');
}
function moveLayer(dir) {
  const g = grp(tlGrp);
  if (g) {                                           // 整个组合往上 / 往下挪一格（越过一个素材或一整个组合）
    const out = layerItems(), blk = out.filter(it => it.g === g.id), i0 = out.indexOf(blk[0]), i1 = out.indexOf(blk[blk.length - 1]);
    const ni = dir > 0 ? i0 - 1 : i1 + 1; if (ni < 0 || ni >= out.length) return toast(dir > 0 ? '已经在最上面' : '已经在最下面');
    const ng = out[ni].g, nb = ng ? out.filter(it => it.g === ng) : [out[ni]];
    const rest = out.filter(it => !blk.includes(it) && !nb.includes(it)), at = Math.min(i0, out.indexOf(nb[0]));
    rest.splice(at, 0, ...(dir > 0 ? blk.concat(nb) : nb.concat(blk)));
    applyItems(rest); tlRender(); tlDraw(); tlSave(); return;
  }
  const c = clip(tlSel); if (!c) return;
  const top = Math.max(...TL.clips.map(o => o.layer));
  const nb = L => { const o = TL.clips.find(x => x.layer === L); return o && o.group && o.group !== c.group ? grp(o.group) : null; };
  if (dir > 0) {
    if (c.layer >= top && !TL.clips.some(o => o !== c && o.layer === c.layer)) return toast('已经在最上面一层');
    const og = nb(c.layer + 1);
    if (og) { const ls = TL.clips.filter(o => o.group === og.id).map(o => o.layer); placeAt(c, Math.max(...ls), true, true); }   // 上面是组合：整个跳过去
    else placeAt(c, c.layer + 1, true);
  } else if (c.layer > 0) {
    const og = nb(c.layer - 1);
    if (og) { const ls = TL.clips.filter(o => o.group === og.id).map(o => o.layer); placeAt(c, Math.min(...ls), false, true); }
    else placeAt(c, c.layer - 1, false);
  }
  else if (TL.clips.some(o => o !== c && o.layer === 0)) placeAt(c, 0, false, true);   // 最底层还有别的素材：把它单独压到最下面
  else return toast('已经在最下面一层');
  tlRender(); tlDraw(); tlSave();
}
function removeClips(cs) {
  cs.forEach(c => dropGhost(c.id));
  TL.clips = TL.clips.filter(o => !cs.includes(o));
  if (cs.some(c => c.id === tlSel)) { tlSel = null; tlPreview = false; }
  tlMulti = new Set(); normLayers(); if (!TL.clips.length) tlPreview = true;
  if (tlGrp && !grp(tlGrp)) { tlGrp = null; gpBuild(); }
  fit(); tlRender(); tlDraw(); tlSave();
}
async function delSel() {
  const g = grp(tlGrp);
  if (g) {
    const m = TL.clips.filter(c => c.group === g.id);
    const ok = await dialog({ title: '删除「' + g.name + '」？', html: '组合和里面的 ' + m.length + ' 个素材都会从时间线删掉。只想拆开、保留素材，请用 Ctrl+Shift+G 解散组合。', buttons: [{ text: '取消', value: false, cls: 'ghost' }, { text: '删除', value: true, cls: 'pri' }] });
    if (ok) { removeClips(m); toast('已删除组合'); }
    return;
  }
  const cs = (tlMulti.size > 1 ? [...tlMulti] : [tlSel]).map(clip).filter(Boolean); if (!cs.length) return;
  removeClips(cs); toast(cs.length > 1 ? '已删掉 ' + cs.length + ' 个素材' : '已从时间线删掉');
}
const nid = p => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
function dupSel() {
  syncSel();
  const g = grp(tlGrp);
  if (g) {                                           // 复制整个组合（连同它的变换和关键帧），放到最上面
    const top = Math.max(...TL.clips.map(o => o.layer)) + 1, m = TL.clips.filter(c => c.group === g.id), lo = Math.min(...m.map(c => c.layer));
    const ng = Object.assign(clone(g), { id: nid('g'), name: g.name + ' 副本' }); TL.groups.push(ng);
    m.forEach(c => TL.clips.push(Object.assign(clone(c), { id: nid('c'), group: ng.id, layer: top + c.layer - lo })));
    normLayers(); selGroup(ng.id); tlRender(); tlSave(); return;
  }
  const c = clip(tlSel); if (!c) return;
  const n = Object.assign(clone(c), { id: nid('c'), layer: Math.max(...TL.clips.map(o => o.layer)) + 1 });
  delete n.group;
  TL.clips.push(n); normLayers(); ghost(n); tlSelect(n.id); tlSave();
}
