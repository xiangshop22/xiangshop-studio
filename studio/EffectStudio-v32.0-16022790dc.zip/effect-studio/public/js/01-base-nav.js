// 效果工坊 · 基础（$、挂钩 Hooks）· 左侧导航 · 选效果 · 参数面板
// 所有 js 文件共用同一个全局作用域，按 index.html 里的顺序加载（顺序不能乱）

const $ = s => document.querySelector(s);
const frame = $('#frame'), box = $('#box'), slider = $('#slider');
let effects = [], cur = null, params = {}, raf = 0, dur = 0, timer = 0;

// ---------- 挂钩（v24.0）：别的模块要在「选效果 / 缩放预览 / 跳到某一秒……」前后多做点事，就在这里登记，
// 不再把原函数一层一层地包起来。看一个函数之后还会发生什么：搜 Hooks.on('名字'
const Hooks = {
  m: {},
  on(name, fn) { (this.m[name] = this.m[name] || []).push(fn); },
  run(name, arg) { const l = this.m[name]; if (l) for (const fn of l) fn(arg); }
};
const res = () => { const [w, h] = $('#res').value.split('x').map(Number); return { w, h }; };

// ================= 左侧导航（v5） =================
// 偏好（视图、宽度、收起、收藏）存在浏览器里，下次打开还在
const store = { get(k, d) { try { const v = localStorage.getItem('fxnav:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
                set(k, v) { try { localStorage.setItem('fxnav:' + k, JSON.stringify(v)); } catch (e) {} if (window.__fxProj) __fxProj(k); } };
let navView = store.get('view', 'big'), favs = new Set(store.get('favs', [])), navQ = '';
async function load() {
  effects = await (await fetch('/api/effects')).json();
  window.__fxList = effects;                      // 给缩略图页面用（省得每张缩略图再去请求一次）
  if (!effects.length) { $('#list').textContent = 'effects 文件夹里还没有效果，把效果压缩包拖到上面的「加载效果」'; return; }
  const last = store.get('last', null);
  select(effects.some(e => e.id === last) ? last : effects[0].id);
}
// 缩略图（v32.0 改）：平时只显示一张静态图片（/api/thumb，server.js 区域T 截好，浏览器缓存一年；效果改了自动换新），
// 第一次打开要等它截，以后直接从缓存里出来，不用再跑效果。鼠标移上去才加载真正的效果循环播放。
// 截图失败（比如电脑没装好导出用的浏览器）时，退回以前的做法：直接加载效果显示静态帧。
function thumbLive(f) {                        // 加载真正的效果（悬停播放用；截图失败时也用它当静态图）
  if (f.src) return;
  f.onload = () => { const w = f.contentWindow; const ready = () => w.document.documentElement.dataset.ready ? (f.classList.add('ld'), f.__play && w.play()) : setTimeout(ready, 120); ready(); };
  f.src = f.dataset.src;
}
const thumbIO = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(en => {
  if (!en.isIntersecting) return; const th = en.target; thumbIO.unobserve(th);
  const img = th.querySelector('img'), f = th.querySelector('iframe');
  img.onload = () => img.classList.add('ld');
  img.onerror = () => { img.remove(); thumbLive(f); };
  img.src = img.dataset.src;
}), { root: null, rootMargin: '200px' }) : null;
// 卡片只建一次；搜索、收藏、切视图都只改显示和排序（用 CSS order），缩略图不会重新加载
let navBuilt = false; const navCards = {}; let secFav, secAll, emptyMsg;
function buildNav() {
  const l = $('#list'); l.innerHTML = '';
  const mkSec = t => { const d = document.createElement('div'); d.className = 'nav-sec'; d.textContent = t; l.appendChild(d); return d; };
  secFav = mkSec('★ 收藏'); secAll = mkSec('全部效果');
  emptyMsg = document.createElement('div'); emptyMsg.className = 'nav-empty'; emptyMsg.innerHTML = '没有找到相关效果<button class="ct" type="button">想要这个效果？联系我</button>'; emptyMsg.querySelector('.ct').onclick = () => openContact(); l.appendChild(emptyMsg);
  effects.forEach(e => {
    const b = document.createElement('div'); b.className = 'item'; b.dataset.id = e.id; b.title = e.name + '\n文件夹：effects\\' + e.id + (e.description ? '\n' + e.description : '');
    b.innerHTML = '<div class="th"><div class="pl">▶ 预览中</div></div><div class="tx"><b></b><span></span></div><a class="dl" title="导出这个效果（zip 压缩包，发给别人后，对方拖进工作台就能用）" download>⇩</a><button class="fav" type="button" title="收藏（排到最前面）">☆</button><button class="del" type="button" title="删除这张卡片（连同它的素材一起删，不能恢复）">🗑</button>';
    b.querySelector('b').textContent = e.name; b.querySelector('span').textContent = e.description || '';
    const dl = b.querySelector('.dl'); dl.href = '/api/effect-zip?id=' + encodeURIComponent(e.id); dl.onclick = ev => ev.stopPropagation();
    const f = document.createElement('iframe'); f.tabIndex = -1; f.title = e.name;
    f.dataset.src = '/thumb.html?fx=' + encodeURIComponent(e.id);
    const img = document.createElement('img'); img.alt = ''; img.decoding = 'async';
    img.dataset.src = '/api/thumb?id=' + encodeURIComponent(e.id) + '&r=' + (e.rev || '0');
    const th = b.querySelector('.th'); th.prepend(f); th.prepend(img);
    if (thumbIO) thumbIO.observe(th); else { img.src = img.dataset.src; img.classList.add('ld'); }
    // 鼠标移上去：加载效果、循环播放（盖在静态图上）；移开：回到静态画面
    b.onmouseenter = () => { if (navView === 'list') return; f.__play = true; if (!f.src) thumbLive(f); else try { f.contentWindow.play(); } catch (er) {} };
    b.onmouseleave = () => { f.__play = false; try { f.contentWindow.still(); } catch (er) {} };
    b.querySelector('.del').onclick = ev => { ev.stopPropagation(); delCard(e.id); };   // 删除这张卡片（v26.0，06-preset-theme.js）
    b.querySelector('.fav').onclick = ev => { ev.stopPropagation(); favs.has(e.id) ? favs.delete(e.id) : favs.add(e.id); store.set('favs', [...favs]); renderList(); };
    b.onclick = () => { if (!cur || cur.id !== e.id) select(e.id); };
    l.appendChild(b); navCards[e.id] = b;
  });
  navBuilt = true;
}
function renderList() {
  if (!navBuilt) buildNav();
  const l = $('#list');
  l.className = 'v-' + navView;
  document.querySelectorAll('#vmode button').forEach(b => b.classList.toggle('on', b.dataset.v === navView));
  const q = navQ.trim().toLowerCase();
  const hit = e => !q || (e.name + ' ' + (e.description || '') + ' ' + e.id).toLowerCase().includes(q);
  const shown = effects.filter(hit), fav = shown.filter(e => favs.has(e.id)), rest = shown.filter(e => !favs.has(e.id));
  $('#ncount').textContent = q ? `${shown.length} / ${effects.length}` : `共 ${effects.length} 个`;
  let o = 0;
  secFav.style.display = fav.length ? '' : 'none'; secFav.style.order = o++;
  fav.forEach(e => navCards[e.id].style.order = o++);
  secAll.style.display = fav.length && rest.length ? '' : 'none'; secAll.style.order = o++;
  rest.forEach(e => navCards[e.id].style.order = o++);
  emptyMsg.style.display = shown.length ? 'none' : ''; emptyMsg.style.order = o++;
  effects.forEach(e => {
    const b = navCards[e.id], on = favs.has(e.id), fv = b.querySelector('.fav');
    b.style.display = hit(e) ? '' : 'none';
    fv.classList.toggle('on', on); fv.textContent = on ? '★' : '☆';
    b.classList.toggle('on', !!cur && cur.id === e.id);
  });
}
// 只更新「选中」高亮，不重排（点效果时缩略图不闪）
function markCurrent() { document.querySelectorAll('#list .item').forEach(b => b.classList.toggle('on', !!cur && b.dataset.id === cur.id)); }
$('#q').addEventListener('input', e => { navQ = e.target.value; renderList(); });
document.querySelectorAll('#vmode button').forEach(b => b.onclick = () => { navView = b.dataset.v; store.set('view', navView); renderList(); });
// 导航栏宽度：拖右边缘调整，双击恢复；收起 / 展开
const app = $('#app');
const setNavW = w => { w = Math.max(200, Math.min(560, Math.round(w))); app.style.setProperty('--nav', w + 'px'); store.set('w', w); };
setNavW(store.get('w', 290));
const setNavC = c => { app.classList.toggle('navc', c); store.set('collapsed', c); setTimeout(() => { fit(); }, 30); };
setNavC(store.get('collapsed', false));
$('#navclose').onclick = () => setNavC(true);
$('#navopen').onclick = () => setNavC(false);
(() => {
  const rs = $('#navrs'); let d = null;
  rs.addEventListener('mousedown', e => { e.preventDefault(); d = { x: e.clientX, w: $('aside.l').getBoundingClientRect().width }; rs.classList.add('on'); document.body.style.cursor = 'col-resize'; });
  addEventListener('mousemove', e => { if (!d) return; setNavW(d.w + e.clientX - d.x); fit(); });
  addEventListener('mouseup', () => { if (!d) return; d = null; rs.classList.remove('on'); document.body.style.cursor = ''; fit(); });
  rs.addEventListener('dblclick', () => { setNavW(290); fit(); });
})();
function select(id) { Hooks.run('select:before', id); selectEffect(id); Hooks.run('select', id); }
function selectEffect(id) {
  cur = effects.find(e => e.id === id); params = {};
  cur.params.forEach(p => params[p.key] = (p.default && typeof p.default === 'object') ? JSON.parse(JSON.stringify(p.default)) : p.default);
  Object.assign(params, JSON.parse(JSON.stringify(cur.presetExtra || {})));   // 预设里存的额外值（如按比例伸缩的持续时间）
  DURP.default = (cur.presetExtra || {}).__dur;
  if (!navBuilt) renderList(); else markCurrent();
  store.set('last', id);
  const fi = $('#fxid'); fi.innerHTML = '<b></b><span>文件夹 <code></code> · 点击复制</span>';
  fi.querySelector('b').textContent = cur.name; fi.querySelector('code').textContent = cur.id;
  if (cur.preset) {                                  // 我的预设：可以删掉（先挪到 effects\_backup）
    const d = document.createElement('button'); d.type = 'button'; d.className = 'fxdel'; d.textContent = '删除这个预设';
    d.onclick = e => { e.stopPropagation(); delPreset(); }; fi.appendChild(d);
  }
  buildParams(); histReset(); stop(); fit(); $('#hint').textContent = cur.params.some(p => p.key === 'scale') ? '在预览区滚动鼠标滚轮调整卡片大小，双击预览区还原' : '';
  frame.src = '/effects/' + id + '/effect.html';
}
const inputs = {};
const hexOk = v => /^#[0-9a-f]{6}$/i.test(v || '');
function swatchPicker(p) {
  const colors = p.swatch || {}, wrap = document.createElement('div'); wrap.className = 'sw';
  const chips = [], custom = document.createElement('label'), ci = document.createElement('input');
  custom.className = 'chip'; ci.type = 'color'; custom.append('自定义', ci);
  const mark = () => {
    const v = params[p.key];
    chips.forEach(c => c.b.classList.toggle('on', c.v === v));
    const isC = hexOk(v) && !p.options.some(o => o[0] === v);
    custom.classList.toggle('on', isC); if (isC) ci.value = v;
  };
  const fire = () => { mark(); clearTimeout(timer); timer = setTimeout(() => reinit(false), 150); };   // v24.12：改参数不再从头重播，停在当前这一秒直接显示改后的样子
  p.options.forEach(([v, t]) => {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'chip';
    if (colors[v]) { const i = document.createElement('i'); i.style.background = colors[v]; b.append(i); }
    b.append(t);
    b.onclick = () => { params[p.key] = v; if (colors[v]) ci.value = colors[v]; fire(); };
    chips.push({ b, v }); wrap.appendChild(b);
  });
  ci.addEventListener('input', () => { params[p.key] = ci.value; fire(); });
  wrap.appendChild(custom);
  ci.value = colors[params[p.key]] || (hexOk(params[p.key]) ? params[p.key] : '#f28c0f');
  mark(); return wrap;
}
async function uploadImage(f) {
  const r = await (await fetch('/api/upload', { method: 'POST', headers: { 'Content-Type': f.type, 'X-FX': '1' }, body: f })).json();
  if (!r.url) throw new Error(r.error || '上传失败');
  return r.url;
}
const isImg = f => /^image\/(png|jpeg|webp|gif)$/.test(f.type);
// 输入框：输入法组合期间不提交
function imeInput(el, onCommit) {
  let composing = false;
  el.addEventListener('compositionstart', () => { composing = true; });
  el.addEventListener('compositionend', () => { composing = false; onCommit(el.value); });
  el.addEventListener('input', e => { if (composing || e.isComposing) return; onCommit(el.value); });
}
function cardsEditor(p) {
  const MAX = p.max || 12, MIN = p.min || 1;
  const v = params[p.key] = params[p.key] && typeof params[p.key] === 'object' ? params[p.key] : { count: 5, items: [] };
  const blank = type => ({ type: type || 'image', img: '', title: '', sub: '' });
  const pad = () => { while (v.items.length < v.count) v.items.push(blank(v.items.length ? v.items[v.items.length - 1].type : (p.defaultType || 'image'))); };
  pad();
  const refresh = (ms = 150) => { clearTimeout(timer); timer = setTimeout(() => reinit(false), ms); };

  const wrap = document.createElement('div'); wrap.className = 'ced';
  // 顶部：数量 + 全部切换 + 批量上传
  const head = document.createElement('div'); head.className = 'ced-head';
  head.innerHTML = '<label class="ced-n">卡片数量<span><button type="button" data-d="-1">−</button><input type="number"><button type="button" data-d="1">+</button></span></label>'
    + '<div class="ced-all"><span>全部设为</span><button type="button" data-all="image">照片</button><button type="button" data-all="text">文字</button></div>';
  const nIn = head.querySelector('input'); nIn.min = MIN; nIn.max = MAX; nIn.value = v.count;
  const setCount = n => {
    n = Math.max(MIN, Math.min(MAX, Math.round(+n || MIN)));
    v.count = n; nIn.value = n; pad(); draw(); refresh();
  };
  nIn.addEventListener('focus', () => setTimeout(() => nIn.select(), 0));
  nIn.addEventListener('mouseup', e => { e.preventDefault(); nIn.select(); });
  nIn.addEventListener('change', () => setCount(nIn.value));
  nIn.addEventListener('keydown', e => { if (e.key === 'Enter') { setCount(nIn.value); nIn.select(); } });
  head.querySelectorAll('[data-d]').forEach(b => b.onclick = () => setCount(v.count + +b.dataset.d));
  head.querySelectorAll('[data-all]').forEach(b => b.onclick = () => { v.items.slice(0, v.count).forEach(c => c.type = b.dataset.all); draw(); refresh(); });

  const bulk = document.createElement('button'); bulk.type = 'button'; bulk.className = 'sec ced-bulk';
  bulk.textContent = '批量上传照片（按顺序填进照片卡）';
  const bulkIn = document.createElement('input'); bulkIn.type = 'file'; bulkIn.multiple = true; bulkIn.hidden = true; bulkIn.accept = 'image/png,image/jpeg,image/webp,image/gif';
  const note = document.createElement('div'); note.className = 'imgnote';
  bulk.onclick = () => bulkIn.click();
  bulkIn.onchange = async () => {
    const files = [...bulkIn.files].filter(isImg); bulkIn.value = '';
    bulk.disabled = true; bulk.textContent = '上传中…';
    for (const f of files) {
      let i = v.items.slice(0, v.count).findIndex(c => c.type === 'image' && !c.img);
      if (i < 0) { if (v.count >= MAX) { note.textContent = '最多 ' + MAX + ' 张卡片'; break; } v.count++; pad(); i = v.count - 1; v.items[i] = blank('image'); }
      try { v.items[i].img = await uploadImage(f); v.items[i].type = 'image'; } catch (e) { note.textContent = e.message; }
    }
    nIn.value = v.count; bulk.disabled = false; bulk.textContent = '批量上传照片（按顺序填进照片卡）'; draw(); refresh();
  };

  const list = document.createElement('div'); list.className = 'ced-list';
  let dragFrom = -1;
  function draw() {
    list.innerHTML = '';
    v.items.slice(0, v.count).forEach((c, i) => {
      const it = document.createElement('div'); it.className = 'ci';
      it.innerHTML = '<div class="ci-top"><span class="grip" title="按住拖动调整顺序">⠿</span><b></b>'
        + '<div class="seg"><button type="button" data-t="image">照片</button><button type="button" data-t="text">文字</button></div>'
        + '<button type="button" class="ci-del" title="删除这张卡片">×</button></div><div class="ci-body"></div>';
      it.querySelector('b').textContent = i + 1;
      it.querySelectorAll('.seg button').forEach(b => { b.classList.toggle('on', b.dataset.t === c.type); b.onclick = () => { c.type = b.dataset.t; draw(); refresh(); }; });
      it.querySelector('.ci-del').onclick = () => { if (v.count <= MIN) return; v.items.splice(i, 1); v.count--; nIn.value = v.count; pad(); draw(); refresh(); };
      const body = it.querySelector('.ci-body');
      if (c.type === 'text') {
        body.innerHTML = '<input type="text" placeholder="标题（必填）"><input type="text" placeholder="副标题（可不填）">';
        const [t1, t2] = body.querySelectorAll('input');
        t1.value = c.title || ''; t2.value = c.sub || '';
        imeInput(t1, val => { c.title = val; refresh(300); });
        imeInput(t2, val => { c.sub = val; refresh(300); });
      } else {
        const drop = document.createElement('div'); drop.className = 'ci-photo' + (c.img ? ' has' : '');
        drop.innerHTML = c.img ? '<img alt=""><span>点击更换照片</span>' : '<span>点击上传照片<br><small>或把图片拖到这里</small></span>';
        if (c.img) drop.querySelector('img').src = c.img;
        const fin = document.createElement('input'); fin.type = 'file'; fin.hidden = true; fin.accept = 'image/png,image/jpeg,image/webp,image/gif';
        const put = async f => {
          if (!f || !isImg(f)) { note.textContent = '只支持 PNG / JPG / WEBP / GIF 图片'; return; }
          drop.innerHTML = '<span>上传中…</span>';
          try { c.img = await uploadImage(f); } catch (e) { note.textContent = e.message; }
          draw(); refresh();
        };
        drop.onclick = () => fin.click();
        fin.onchange = () => put(fin.files[0]);
        drop.addEventListener('dragover', e => { if (dragFrom < 0 && e.dataTransfer.types.includes('Files')) { e.preventDefault(); drop.classList.add('over'); } });
        drop.addEventListener('dragleave', () => drop.classList.remove('over'));
        drop.addEventListener('drop', e => { if (dragFrom >= 0 || !e.dataTransfer.files.length) return; e.preventDefault(); e.stopPropagation(); put(e.dataTransfer.files[0]); });
        body.append(drop, fin);
        if (c.img) {
          const clr = document.createElement('button'); clr.type = 'button'; clr.className = 'ci-clear'; clr.textContent = '移除照片';
          clr.onclick = () => { c.img = ''; draw(); refresh(); }; body.appendChild(clr);
        }
      }
      // 只有按住左边的拖动把手才能拖，避免影响输入框选字
      const grip = it.querySelector('.grip');
      grip.addEventListener('mousedown', () => { it.draggable = true; });
      grip.addEventListener('mouseup', () => { it.draggable = false; });
      it.addEventListener('dragstart', e => { dragFrom = i; it.classList.add('drag'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'card'); });
      it.addEventListener('dragend', () => { dragFrom = -1; it.draggable = false; it.classList.remove('drag'); list.querySelectorAll('.over').forEach(x => x.classList.remove('over')); });
      it.addEventListener('dragover', e => { if (dragFrom < 0) return; e.preventDefault(); it.classList.add('over'); });
      it.addEventListener('dragleave', e => { if (!it.contains(e.relatedTarget)) it.classList.remove('over'); });
      it.addEventListener('drop', e => {
        if (dragFrom < 0) return; e.preventDefault();
        const [m] = v.items.splice(dragFrom, 1); v.items.splice(i, 0, m); dragFrom = -1; draw(); refresh();
      });
      list.appendChild(it);
    });
    note.textContent = '按住 ⠿ 上下拖动可以调整出牌顺序，1 号最先发出';
  }
  wrap.append(head, list, bulk, bulkIn, note); draw();
  return wrap;
}
function imagePicker(p) {
  const wrap = document.createElement('div'); wrap.className = 'imgs';
  const grid = document.createElement('div'); grid.className = 'thumbs';
  const file = document.createElement('input'); file.type = 'file'; file.accept = 'image/png,image/jpeg,image/webp,image/gif'; file.multiple = true; file.hidden = true;
  const add = document.createElement('button'); add.type = 'button'; add.className = 'sec addimg'; add.textContent = '+ 上传图片（可多选，也可直接拖进来）';
  const note = document.createElement('div'); note.className = 'imgnote';
  let dragFrom = -1;
  const list = () => params[p.key] || (params[p.key] = []);
  const changed = () => { draw(); clearTimeout(timer); timer = setTimeout(() => reinit(false), 120); };
  function draw() {
    grid.innerHTML = '';
    list().forEach((u, i) => {
      const t = document.createElement('div'); t.className = 'thumb'; t.draggable = true;
      t.innerHTML = '<img alt=""><b></b><button type="button" title="删除">×</button>';
      t.querySelector('img').src = u; t.querySelector('b').textContent = i + 1;
      t.querySelector('button').onclick = () => { list().splice(i, 1); changed(); };
      t.addEventListener('dragstart', e => { dragFrom = i; t.classList.add('drag'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'x'); });
      t.addEventListener('dragend', () => { dragFrom = -1; t.classList.remove('drag'); grid.querySelectorAll('.over').forEach(x => x.classList.remove('over')); });
      t.addEventListener('dragover', e => { if (dragFrom < 0) return; e.preventDefault(); t.classList.add('over'); });
      t.addEventListener('dragleave', () => t.classList.remove('over'));
      t.addEventListener('drop', e => {
        if (dragFrom < 0) return; e.preventDefault(); e.stopPropagation();
        const a = list(), [m] = a.splice(dragFrom, 1); a.splice(i, 0, m); dragFrom = -1; changed();
      });
      grid.appendChild(t);
    });
    note.textContent = list().length ? '拖动缩略图可调整发牌顺序，1 号最先发出' : (p.emptyNote || '还没有图片，先用占位卡预览');
  }
  async function upload(files) {
    const imgs = [...files].filter(f => /^image\/(png|jpeg|webp|gif)$/.test(f.type));
    if (!imgs.length) return;
    if (p.max && list().length + imgs.length > p.max) { note.textContent = '最多 ' + p.max + ' 张'; imgs.length = Math.max(0, p.max - list().length); }
    add.disabled = true; add.textContent = '上传中…';
    for (const f of imgs) {
      try {
        const r = await (await fetch('/api/upload', { method: 'POST', headers: { 'Content-Type': f.type, 'X-FX': '1' }, body: f })).json();
        if (r.url) list().push(r.url); else note.textContent = r.error || '上传失败';
      } catch (e) { note.textContent = '上传失败：' + e.message; }
    }
    add.disabled = false; add.textContent = '+ 上传图片（可多选，也可直接拖进来）'; changed();
  }
  add.onclick = () => file.click();
  file.onchange = () => { upload(file.files); file.value = ''; };
  wrap.addEventListener('dragover', e => { if (dragFrom < 0 && e.dataTransfer.types.includes('Files')) { e.preventDefault(); wrap.classList.add('drop'); } });
  wrap.addEventListener('dragleave', e => { if (!wrap.contains(e.relatedTarget)) wrap.classList.remove('drop'); });
  wrap.addEventListener('drop', e => { wrap.classList.remove('drop'); if (dragFrom < 0 && e.dataTransfer.files.length) { e.preventDefault(); upload(e.dataTransfer.files); } });
  wrap.append(grid, add, file, note); draw(); return wrap;
}
function buildParams() {
  const box = $('#params'); box.innerHTML = ''; Object.keys(inputs).forEach(k => delete inputs[k]);
  // 持续时间（v8.1）：最上面一块，管整个效果的时长；能影响时长的分段参数也收进这一块
  const DP = durPlan(), segKeys = durSegKeys(DP), durBox = durBuild(DP, segKeys.length);
  box.appendChild(durBox);
  const segList = durBox.querySelector('.fxdur-list');
  // 持续时间下面一格「.fxtop」（v29.1）：放「排版」这类一上来就要选的东西——先定多长、再选排版。
  // effect.json 里写了 "top": true 的参数会放进来；效果自己做的排版选择块（如焦点格卡片的缩略图）也挂到这里。不进分组。
  const isTop = p => p.top === true;
  const topBox = document.createElement('div'); topBox.className = 'fxtop';
  box.appendChild(topBox);
  cur.params.forEach(p => {
    if (p.hidden) return;
    if (DP.own.includes(p.key)) return;                        // 「总时长」本身由上面的「持续时间」代替，不再重复列出
    const into = isTop(p) ? topBox : segKeys.includes(p.key) ? segList : box;
    const blk = isTop(p) ? topBox : box;
    if (p.type === 'cards') {
      const lab = document.createElement('div'); lab.className = 'lab'; lab.append(p.label, cardsEditor(p)); blk.appendChild(lab); return;
    }
    if (p.type === 'images') {
      const lab = document.createElement('div'); lab.className = 'lab'; lab.append(p.label, imagePicker(p)); blk.appendChild(lab); return;
    }
    if (p.type === 'select' && p.swatch) {
      const lab = document.createElement('div'); lab.className = 'lab'; lab.append(p.label, swatchPicker(p)); blk.appendChild(lab); return;
    }
    const lab = document.createElement('label'); lab.append(p.label);
    let el;
    if (p.type === 'select') {
      el = document.createElement('select');
      p.options.forEach(([v, t]) => { const o = document.createElement('option'); o.value = v; o.textContent = t; el.appendChild(o); });
    } else if (p.type === 'textarea') {
      el = document.createElement('textarea'); el.rows = p.rows || 5;
    } else {
      el = document.createElement('input'); el.type = p.type === 'color' ? 'color' : p.type === 'text' ? 'text' : 'number';
      if (p.min != null) el.min = p.min; if (p.max != null) el.max = p.max; if (p.step != null) el.step = p.step;
    }
    // 用「当前值」填，没有才退回默认：否则只恢复一部分参数时，没被恢复的那些会被面板写回默认值
    el.value = params[p.key] !== undefined && params[p.key] !== null ? params[p.key] : p.default;
    inputs[p.key] = el;
    // 输入法组合期间（拼音还没选字上屏）不刷新预览，选完字再更新，避免打断中文输入
    let composing = false;
    const apply = () => {
      params[p.key] = p.type === 'number' ? (el.value === '' ? p.default : parseFloat(el.value)) : el.value;
      clearTimeout(timer); timer = setTimeout(() => reinit(false), 250);
    };
    el.addEventListener('compositionstart', () => { composing = true; });
    el.addEventListener('compositionend', () => { composing = false; apply(); });
    el.addEventListener('input', e => { if (composing || e.isComposing) return; apply(); });
    lab.appendChild(el); into.appendChild(lab);
  });
  if (!segList.children.length) durBox.querySelector('.fxdur-tg').hidden = true;
  markDirty();
}
