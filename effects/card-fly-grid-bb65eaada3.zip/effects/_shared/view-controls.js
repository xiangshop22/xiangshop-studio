/* 效果工坊 · 通用预览操作（所有效果共用）
 * 在工作台预览区：
 *   - 鼠标滚轮：缩放大小（写入参数 scale）
 *   - 按住鼠标左键拖动：移动位置（写入参数 offsetX / offsetY，单位是 1920×1080 画布上的像素）
 *   - 双击：还原大小和位置
 * 改的是工作台里同一份参数，所以导出的视频和预览一致。
 * 导出时页面单独打开（没有工作台），这个脚本什么都不做。
 * 放在 effects/_shared 里：没有 effect.json，工作台不会把它当成一个效果。
 */

/* =====================================================================
 * 【整体时长 · 按比例伸缩】（v8.1）—— 预览和导出都生效
 *
 * 工作台右侧最上面的「持续时间」：
 *   - 效果自己有「总时长」参数（dur / total / 分+秒）→ 工作台直接改那个参数，这一层不管；
 *   - 有「停留」类参数 → 工作台把多出来 / 少掉的时间加减在停留上，这一层也不管；
 *   - 都没有 → 工作台写 params.__dur = 目标秒数，由这一层把整段动画按比例放慢 / 加快：
 *       getDuration() 返回目标秒数；renderAt(t) 换算成效果原来的时间 t × 原长 / 目标。
 * 效果在 init / renderAt 里面自己调 getDuration() 时，拿到的仍是原来的时长（inner 计数），
 * 所以效果内部的进度计算不会乱。window.__fxNativeDur() = 效果原来的时长（给工作台算用）。
 * ===================================================================== */
(function () {
  const oi = window.init, or = window.renderAt, og = window.getDuration;
  if (typeof oi !== 'function' || typeof or !== 'function' || typeof og !== 'function') return;
  let P = null, inner = 0;
  const native = () => { inner++; try { return +og.call(window) || 0; } catch (e) { return 0; } finally { inner--; } };
  const target = () => { const v = P ? +P.__dur : 0; return Number.isFinite(v) && v > 0 ? v : 0; };
  window.__fxNativeDur = native;
  window.__fxCurP = () => P;                        // 当前参数（清晰度那一层判断「大小 / 角度变了没有」用）
  window.init = function (p) { P = p || {}; inner++; try { return oi.apply(this, arguments); } finally { inner--; } };
  window.getDuration = function () { if (inner) return og.apply(this, arguments); return target() || og.apply(this, arguments); };
  window.renderAt = function (t) {
    const T = target();
    if (!T || inner) return or.apply(this, arguments);
    const D = native(), k = D > 0 ? D / T : 1;
    inner++; try { return or.call(this, Math.max(0, +t || 0) * k); } finally { inner--; }
  };
})();

(function () {
  let pw, pd;
  try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
  if (typeof window.init !== 'function' || typeof window.renderAt !== 'function') return;

  const CFG = window.VIEW_CONTROLS || {};          // { live: true } = renderAt 每帧都读参数，不用重新 init
  let lastP = null, lastT = 0;
  const origInit = window.init, origRender = window.renderAt;
  window.init = function (p) { lastP = p; const r = origInit.apply(this, arguments); setTimeout(() => { hideSize(); enhancePanel(); groupPanel(); }, 0); return r; };
  window.renderAt = function (t) { lastT = +t || 0; return origRender.apply(this, arguments); };

  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const box = () => pd.getElementById('box');
  const labelOf = el => {
    const f = el.firstChild; if (!f) return '';
    if (f.nodeType === 3) return f.textContent.trim();
    if (f.classList && f.classList.contains('fxr-row')) return (f.firstChild.textContent || '').trim();
    return '';
  };
  // 面板里的每一项（分组折叠后它们在分组里面，也要找得到）
  const panelItems = () => {
    const b = pd.getElementById('params'); if (!b) return [];
    return [...b.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children]
      : el.classList.contains('fxdur') ? [...el.querySelectorAll('.fxdur-list > *')]          // 顶部「时长」里的分段时间（v8.1）
      : el.classList.contains('fxtop') ? [...el.children]                                      // 持续时间下面的「排版」（v29.1）
        : el.classList.contains('fxg-bar') ? [] : [el]);
  };
  const panelLabel = prefix => panelItems().find(el => labelOf(el).startsWith(prefix));
  // 右侧面板精简：大小、水平偏移、垂直偏移都用鼠标在预览区直接调（滚轮 / 拖动 / 双击还原），面板里不再显示
  // v8.1：X / Y / Z 三个角度也不再列出来 —— 在预览区按住右键拖（Shift + 右键转 Z），右键双击归零
  function hideSize() {
    ['卡片大小', '水平偏移', '垂直偏移'].forEach(k => { const l = panelLabel(k); if (l) l.style.display = 'none'; });
    if (!defs) return;
    const M = (window.FXKeys && window.FXKeys.map) || { x: 'rotX', y: 'rotY', z: 'rotZ' };
    const rk = new Set(['rotX', 'rotY', 'rotZ', M.x, M.y, M.z]);
    defs.forEach(d => {
      if (!rk.has(d.key) || !d.label) return;
      panelItems().forEach(el => { if (el.tagName === 'LABEL' && labelOf(el) === d.label) el.style.display = 'none'; });
    });
  }
  function syncInputs() {
    [['水平偏移', 'offsetX'], ['垂直偏移', 'offsetY']].forEach(([lab, key]) => {
      const l = panelLabel(lab), i = l && l.querySelector('input');
      if (i && lastP) { i.value = Math.round(num(lastP[key], 0)); if (i.__fxRange) i.__fxRange.value = i.value; }
    });
  }

  // ---------- 规则：所有数字参数 = 文字后面一个数字框 + 下面一条滑块 ----------
  let defs = null;
  fetch(new URL('effect.json', location.href)).then(r => r.json()).then(j => { defs = j.params || []; hideSize(); enhancePanel(); groupPanel(); }).catch(() => {});
  function rangeOf(def, input) {
    const key = def && def.key, d = num(def && def.default, num(input.value, 0));
    let min = def && def.min != null ? +def.min : null, max = def && def.max != null ? +def.max : null;
    if (key === 'offsetX') { if (min == null) min = -960; if (max == null) max = 960; }
    if (key === 'offsetY') { if (min == null) min = -540; if (max == null) max = 540; }
    if (min == null) min = d < 0 ? d * 4 : 0;
    if (max == null) max = d > 0 ? Math.max(10, Math.ceil(d * 4)) : 100;
    if (max <= min) max = min + 1;
    let step = def && def.step != null && def.step !== 'any' ? +def.step : null;
    if (!step || !(step > 0)) { const raw = (max - min) / 200, p10 = Math.pow(10, Math.floor(Math.log10(raw))); step = [1, 2, 5, 10].map(m => m * p10).find(x => x >= raw) || raw; }
    return { min, max, step };
  }
  function enhancePanel() {
    const box = pd.getElementById('params'); if (!box || !defs) return;
    if (!pd.getElementById('fxr-style')) {
      const st = pd.createElement('style'); st.id = 'fxr-style';
      st.textContent = `
.fxr-row{display:flex;align-items:center;justify-content:space-between;gap:10px}
.fxr-row>span{flex:1;min-width:0}
.fxr-row input[type=number]{width:96px!important;flex:none;margin:0!important;display:inline-block!important;text-align:right;padding:6px 8px!important}
input.fxr-range{display:block!important;width:100%!important;margin:8px 0 2px!important;padding:0!important;border:0!important;background:none!important;height:18px;accent-color:#f28c0f;cursor:pointer}`;
      pd.head.appendChild(st);
    }
    panelItems().forEach(lab => {
      if (lab.tagName !== 'LABEL' || lab.dataset.fxr) return;
      const input = [...lab.children].find(x => x.tagName === 'INPUT' && x.type === 'number');
      if (!input) return;
      const text = labelOf(lab);
      const def = defs.find(q => q.type === 'number' && q.label === text) || defs.find(q => q.type === 'number' && text && q.label && text.startsWith(q.label));
      const { min, max, step } = rangeOf(def, input);
      lab.dataset.fxr = '1';
      const row = pd.createElement('div'); row.className = 'fxr-row';
      const span = pd.createElement('span'); span.textContent = text;
      lab.firstChild.remove();
      row.append(span, input);
      const rng = pd.createElement('input'); rng.type = 'range'; rng.className = 'fxr-range';
      rng.min = min; rng.max = max; rng.step = step; rng.value = input.value;
      input.__fxRange = rng;
      rng.addEventListener('input', () => {
        input.value = rng.value;
        input.dispatchEvent(new pw.Event('input', { bubbles: true }));
      });
      input.addEventListener('input', () => { if (input.value !== '') rng.value = input.value; });
      lab.prepend(row); lab.appendChild(rng);
    });
  }
  // ---------- 右侧参数分组折叠：内容 / 样式 / 数值调节 ----------
  const effId = (location.pathname.match(/effects\/([^/]+)\//) || [])[1] || 'fx';
  const store = {
    get(k) { try { return pw.localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { pw.localStorage.setItem(k, v); } catch (e) {} },
  };
  function groupPanel() {
    const box = pd.getElementById('params'); if (!box || !defs) return;
    if (box.querySelector(':scope > .fxg')) return;
    const top = box.querySelector(':scope > .fxdur');           // 顶部「时长」那一块（v8.1）：不进分组，永远放在最上面
    const top2 = box.querySelector(':scope > .fxtop');          // 紧跟着的「排版」（v29.1）：也不进分组
    const kids = [...box.children].filter(el => el !== top && el !== top2 && !el.classList.contains('fxcolor')); if (!kids.length) return;   // 「去色 · 高亮」那一块（v14.0）不进分组，永远放在最后
    if (!pd.getElementById('fxg-style')) {
      const st = pd.createElement('style'); st.id = 'fxg-style';
      st.textContent = `
.fxg-bar{display:flex;justify-content:flex-end;gap:6px;margin:-4px 0 8px}
.fxg-bar button{background:#1d1d1d;color:#aaa;border:1px solid #2c2c2c;border-radius:6px;padding:3px 10px;font-size:12px;cursor:pointer;font-family:inherit}
.fxg-bar button:hover{color:#f28c0f;border-color:#f28c0f}
.fxg{margin:0 0 10px;border:1px solid #262626;border-radius:8px;background:#121212}
.fxg-h{display:flex;align-items:center;gap:8px;width:100%;padding:10px 12px;background:none;border:0;color:#ddd;font-size:13px;font-weight:600;cursor:pointer;text-align:left;font-family:inherit}
.fxg-h:hover{color:#f28c0f}
.fxg-h i{font-style:normal;color:#f28c0f;display:inline-block;transition:transform .15s}
.fxg.off .fxg-h i{transform:rotate(-90deg)}
.fxg-h small{margin-left:auto;color:#666;font-weight:400;font-size:12px}
.fxg-b{padding:4px 12px 2px}
.fxg.off .fxg-b{display:none}`;
      pd.head.appendChild(st);
    }
    const kindOf = el => {
      if (el.classList.contains('cdx') || (el.dataset && el.dataset.fxContent)) return 'content';
      const t = labelOf(el);
      const d = defs.find(q => q.label && t && (t === q.label || t.startsWith(q.label)));
      if (!d) return 'look';
      if (d.type === 'text' || d.type === 'textarea' || d.type === 'images' || d.type === 'cards') return 'content';
      if (d.type === 'number') return 'num';
      return 'look';
    };
    const G = [['content', '内容'], ['look', '样式'], ['num', '数值调节']];
    const groups = [];
    G.forEach(([k, name]) => {
      const mine = kids.filter(el => kindOf(el) === k); if (!mine.length) return;
      const g = pd.createElement('div'); g.className = 'fxg'; g.dataset.k = k;
      const h = pd.createElement('button'); h.type = 'button'; h.className = 'fxg-h';
      const shown = mine.filter(el => el.style.display !== 'none').length;
      h.innerHTML = '<i>▾</i>' + name + '<small>' + (k === 'content' ? '' : shown + ' 项') + '</small>';
      const body = pd.createElement('div'); body.className = 'fxg-b';
      body.append(...mine); g.append(h, body);
      if (!shown) g.style.display = 'none';
      const key = 'fxg:' + effId + ':' + k;
      if (store.get(key) === '0') g.classList.add('off');
      h.onclick = () => { g.classList.toggle('off'); store.set(key, g.classList.contains('off') ? '0' : '1'); };
      groups.push(g);
    });
    const bar = pd.createElement('div'); bar.className = 'fxg-bar';
    bar.innerHTML = '<button type="button" data-f="0">全部折叠</button><button type="button" data-f="1">全部展开</button>';
    bar.querySelectorAll('button').forEach(b => b.onclick = () => groups.forEach(g => {
      g.classList.toggle('off', b.dataset.f === '0'); store.set('fxg:' + effId + ':' + g.dataset.k, b.dataset.f);
    }));
    box.innerHTML = '';
    if (top) box.append(top);
    if (top2) box.append(top2);
    box.append(bar, ...groups);
  }
  function hint(msg) { const h = pd.getElementById('hint'); if (h) h.textContent = msg; }
  function apply() {
    if (!lastP) return;
    const t = lastT;                                  // init 内部会 renderAt(0)，先记住当前时间
    if (CFG.live) window.renderAt(t);
    else { window.init(lastP); window.renderAt(t); }
    syncInputs();
  }
  // 预览区里 1 个屏幕像素 = 多少个 1920×1080 画布像素
  function stagePerScreen() {
    const b = box(); if (!b) return 1;
    const fitS = Math.min(innerWidth / 1920, innerHeight / 1080) || 1;
    return (innerWidth / (b.getBoundingClientRect().width || innerWidth)) / fitS;
  }
  const inBox = e => { const b = box(); return b && e.target instanceof pw.Node && b.contains(e.target); };

  function onWheel(e) {
    if (!inBox(e) || !lastP) return;
    e.preventDefault(); e.stopPropagation();          // 拦下工作台自带的滚轮处理，避免缩放两次
    begin();                                          // 从画面当前这一帧的大小开始缩放
    const s0 = num(lastP.scale, 1);
    let s = s0 * (e.deltaY < 0 ? 1.06 : 1 / 1.06);
    s = Math.min(5, Math.max(0.2, Math.round(s * 100) / 100));
    lastP.scale = s; apply();
    try { if (pw.__fxLive) pw.__fxLive('s', s0, s); } catch (x) { }   // 多选时其他素材实时跟着缩放（v24.5）
    hint('大小 ' + Math.round(s * 100) + '%　·　按住左键拖动位置　·　双击还原');
    changed('scale');                                 // 让关键帧那一层在这一秒记下大小
  }
  // 手动操作开始 / 结束：交给关键帧层（对齐当前帧 + 操作期间暂停曲线）
  const begin = () => { try { if (window.__fxViewBegin) window.__fxViewBegin(); } catch (e) { } };
  const end = () => { try { if (window.__fxViewEnd) window.__fxViewEnd(); } catch (e) { } };
  // 缩放 / 位置改完通知关键帧层（它在本文件末尾那个 IIFE 里，会按当前秒自动打点）
  let chT = 0;
  function changed(kind) {
    clearTimeout(chT);
    chT = setTimeout(() => { try { if (window.__fxViewChanged) window.__fxViewChanged(kind); } catch (e) { } }, 220);
  }
  let drag = null;
  function onDown(e) {
    if (!inBox(e) || e.button !== 0 || !lastP) return;
    e.preventDefault();
    begin();                                          // 从画面当前这一帧的位置开始拖
    drag = { x: e.clientX, y: e.clientY, ox: num(lastP.offsetX, 0), oy: num(lastP.offsetY, 0), k: stagePerScreen() };
    const b = box(); if (b) b.style.cursor = 'grabbing';
  }
  let raf = 0;
  function onMove(e) {
    if (!drag) return;
    lastP.offsetX = Math.round(drag.ox + (e.clientX - drag.x) * drag.k);
    lastP.offsetY = Math.round(drag.oy + (e.clientY - drag.y) * drag.k);
    // 辅助对齐（v24.4）：工作台按其他素材 / 画面的边和中线算吸附，返回修正后的挪动量（按住 Alt 临时不吸）
    try { if (pw.__fxSnap) { const r = pw.__fxSnap(lastP.offsetX - drag.ox, lastP.offsetY - drag.oy, drag.k, e.altKey); if (r) { lastP.offsetX = Math.round(drag.ox + r[0]); lastP.offsetY = Math.round(drag.oy + r[1]); } } } catch (x) { }
    if (!raf) raf = pw.requestAnimationFrame(() => { raf = 0; apply(); });
    hint('位置 X ' + lastP.offsetX + '　Y ' + lastP.offsetY + '　·　双击还原');
  }
  function onUp() {
    if (!drag) return;
    const moved = drag.ox !== num(lastP.offsetX, 0) || drag.oy !== num(lastP.offsetY, 0);
    drag = null; try { if (pw.__fxSnapEnd) pw.__fxSnapEnd(); } catch (x) { } const b = box(); if (b) b.style.cursor = 'grab';
    if (moved) changed('pos');                        // 松手就在这一秒记下位置
    else end();
  }
  function onDbl(e) {
    if (!inBox(e) || !lastP) return;
    e.preventDefault(); e.stopPropagation();
    // 有关键帧时交给关键帧层：只在这一秒打一个「还原」的点，不改原始参数（开场不受影响）
    try { if (window.__fxViewReset && window.__fxViewReset()) { hint('已在这一秒打了一个「还原」关键帧（大小 100%、位置居中、角度 0）'); return; } } catch (e2) { }
    lastP.scale = 1; lastP.offsetX = 0; lastP.offsetY = 0; apply();
    hint('已还原：大小 100%，位置居中');
  }

  // 上一个效果留下的监听先撤掉，再挂这个效果的
  try { if (pw.__fxViewDispose) pw.__fxViewDispose(); } catch (e) {}
  pd.addEventListener('wheel', onWheel, { capture: true, passive: false });
  pd.addEventListener('mousedown', onDown, true);
  pd.addEventListener('mousemove', onMove, true);
  pd.addEventListener('mouseup', onUp, true);
  pd.addEventListener('dblclick', onDbl, true);
  const dispose = () => {
    pd.removeEventListener('wheel', onWheel, { capture: true });
    pd.removeEventListener('mousedown', onDown, true);
    pd.removeEventListener('mousemove', onMove, true);
    pd.removeEventListener('mouseup', onUp, true);
    pd.removeEventListener('dblclick', onDbl, true);
    if (pw.__fxViewDispose === dispose) pw.__fxViewDispose = null;
  };
  pw.__fxViewDispose = dispose;
  window.addEventListener('pagehide', dispose);
  window.addEventListener('unload', dispose);
  const b = box(); if (b) { b.style.cursor = 'grab'; const f = pd.getElementById('frame'); if (f) f.style.pointerEvents = 'none'; }
  hint('滚轮缩放大小　·　按住左键拖动位置　·　按住右键转角度（Shift + 右键转 Z 轴）　·　双击还原');
})();

/* =====================================================================
 * 效果工坊 · 公共关键帧（FXKeys）—— 所有效果通用，v6.9 起
 *
 * 为什么放在 view-controls.js 里：**每一个效果都会加载这个文件**，所以关键帧成了
 * 全局能力 —— 以前做的、以后做的，都自动有，效果本身一行都不用改。
 *
 * 怎么做到不改效果：在 #stage 里插一层 <div id="fx-rot">，把原来 stage 下的内容
 * 整体搬进去，旋转 / 缩放都加在这一层上；透视加在 #stage 上（它是 fx-rot 的父节点）。
 * 效果自己的 DOM 结构、定位、裁剪都不受影响（fx-rot 和 stage 等大、同位置）。
 * 效果如果在 init 里清空过 #stage，init 之后会自动重新搬一次。
 *
 * 每个关键帧记的是【角度 x/y/z + 大小 s + 位置 ox/oy】三件事：
 *   右键拖转角度、滚轮缩放、左键拖位置，松手都会在当前这一秒自动打点。
 *   大小按「比例」、位置按「像素差」叠加到效果自己的 scale / offsetX / offsetY 上，不会打架。
 *   老数据里没有 ox/oy 的记录按默认值算，等于那一项没动过。
 *
 * 【核心语义】关键帧只管中间那一段：
 *   第一个关键帧之前、最后一个之后，角度 / 大小 / 位置回到参数里的默认值，
 *   所以每个效果自带的开场和结尾原样保留，不会被关键帧按住；
 *   两端用「首尾衔接（秒）」平滑过渡。想保持首尾角度就把「关键帧之外」改成「保持首尾」。
 *
 * 效果要做的事：只在 effect.json 里加 rotX / rotY / rotZ / persp / keys 五个参数。
 * 想自己接管（比如 ring-carousel 把关键帧接到它自己的 tilt / roll / startAngle 上）：
 *   window.VIEW_CONTROLS = { live:true, keys:{ apply:false, drag:false,
 *       map:{x:'tilt',y:'startAngle',z:'roll'}, labels:{...} } };
 *   然后自己在 renderAt 里调 FXKeys.at(P, t, 总时长)，在松手处调 FXKeys.recordNow()。
 * ===================================================================== */
(function () {
  const CFG0 = (window.VIEW_CONTROLS || {}).keys;
  if (CFG0 === false) return;                       // 明确关掉关键帧的效果
  const O = (CFG0 && typeof CFG0 === 'object') ? CFG0 : {};
  const MAP = O.map || { x: 'rotX', y: 'rotY', z: 'rotZ' };
  const APPLY = O.apply !== false;                  // false = 效果自己在 renderAt 里应用
  const DRAG = O.drag !== false;                    // false = 效果自己已经接管了右键
  const LB = O.labels || { y: 'Y 轴旋转', x: 'X 轴俯仰', z: 'Z 轴倾斜' };

  const origInit = window.init, origRender = window.renderAt;
  if (typeof origInit !== 'function' || typeof origRender !== 'function') return;

  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const prog = (t, a, b) => (b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1));
  const lerp = (a, b, k) => a + (b - a) * k;
  const smooth = x => x * x * (3 - 2 * x);
  const r1 = x => Math.round(x * 10) / 10;
  const r2 = x => Math.round(x * 100) / 100;

  let P = {}, lastT = 0, wrap = null;
  const K = { dragging: false, map: MAP };
  window.FXKeys = K;

  // ---------- 数据 ----------
  const KDEF = () => ({ on: true, auto: true, scale: true, pos: true, ease: 'smooth', edge: 'blend', fade: 0.6, list: [] });
  let _raw = null, _K = null;
  // 和 AE 一样分三条轨道，每条各自打点、互不牵连：
  //   P 位置 {t,k:'p',ox,oy}　S 大小 {t,k:'s',s}　R 旋转 {t,k:'r',x,y,z}
  // 老数据（一条记录里角度 / 大小 / 位置都有、没有 k）读进来自动拆成三条。
  const fin = v => (Number.isFinite(+v) ? +v : null);
  const norm = k => {
    const t = Math.max(0, r2(+k.t));
    if (k.k === 'p') return { t, k: 'p', ox: Math.round(num(k.ox, 0)), oy: Math.round(num(k.oy, 0)) };
    if (k.k === 's') return { t, k: 's', s: r2(clamp(num(k.s, 1), 0.1, 5)) };
    return { t, k: 'r', x: r1(+k.x || 0), y: r1(+k.y || 0), z: r1(+k.z || 0) };
  };
  const expand = k => (k.k ? [norm(k)] : [norm({ t: k.t, k: 'r', x: k.x, y: k.y, z: k.z })]
    .concat(fin(k.s) != null ? [norm({ t: k.t, k: 's', s: k.s })] : [])
    .concat(fin(k.ox) != null ? [norm({ t: k.t, k: 'p', ox: k.ox, oy: k.oy })] : []));
  const sortL = L => L.sort((a, b) => a.t - b.t || 'prs'.indexOf(a.k) - 'prs'.indexOf(b.k));
  K.norm = norm;
  K.read = p => {
    p = p || P;
    const raw = typeof p.keys === 'string' ? p.keys : JSON.stringify(p.keys || null);
    if (_raw === raw && _K) return _K;
    let v; try { v = typeof p.keys === 'string' ? JSON.parse(p.keys) : p.keys; } catch (e) { v = null; }
    const o = KDEF();
    if (v && typeof v === 'object') {
      o.on = v.on !== false; o.auto = v.auto !== false;
      o.scale = v.scale !== false; o.pos = v.pos !== false;
      o.ease = v.ease === 'linear' ? 'linear' : 'smooth';
      o.edge = v.edge === 'hold' ? 'hold' : 'blend';
      o.fade = Math.max(0, num(v.fade, 0.6));
      if (Array.isArray(v.list)) o.list = v.list;
    }
    o.list = sortL(o.list.filter(k => k && Number.isFinite(+k.t)).flatMap(expand));
    _raw = raw; _K = o;
    return o;
  };

  // ---------- 求值 ----------
  K.at = (p, t, total) => {
    t = Number.isFinite(+t) ? +t : 0;                        // 时间不合法时按 0 秒算，别让求值崩掉
    p = p || P;
    const def = { x: num(p[MAP.x], 0), y: num(p[MAP.y], 0), z: num(p[MAP.z], 0),
      s: clamp(num(p.scale, 1), 0.1, 5), ox: num(p.offsetX, 0), oy: num(p.offsetY, 0) };
    const out = { x: def.x, y: def.y, z: def.z, s: def.s, ox: def.ox, oy: def.oy,
      persp: clamp(num(p.persp, 2400), 400, 20000), on: false };
    const o = K.read(p);
    if (!o.on || !o.list.length) return out;
    // 拖动 / 缩放 / 旋转中（v24.5）：曲线照常走，再加上这次手动改的差值（P 现在 − 按下时的原始值）。
    // 以前是暂停曲线、把当前值塞进参数让效果自己画 —— 效果自己缩放的中心和关键帧那一层不一样，
    // 带「大小」关键帧的素材一按下去就偏一截、松手又弹回来。现在拖动时看到的就是松手后的样子。
    const B = K.dragging && K.dragBase;
    const dv = (f, d) => B ? num(p[f], d) - num(B[f], d) : 0;
    const ease = u => (o.ease === 'linear' ? u : smooth(u));
    // 一条轨道单独求值；边界语义不变：第一个点之前、最后一个点之后回到默认值（开场结尾保留）
    const lane = (kind, F) => {
      const L = o.list.filter(k => k.k === kind); if (!L.length) return null;
      const first = L[0], last = L[L.length - 1];
      const mix = (a, b, u) => { const r = {}; F.forEach(f => (r[f] = lerp(a[f], b[f], u))); return r; };
      if (t <= first.t) return o.edge === 'hold' ? first : o.fade <= 0 ? (t < first.t ? def : first)
        : mix(def, first, ease(prog(t, first.t - o.fade, first.t)));
      if (t >= last.t) return o.edge === 'hold' ? last : o.fade <= 0 ? (t > last.t ? def : last)
        : mix(last, def, ease(prog(t, last.t, last.t + o.fade)));
      let i = 0; while (i < L.length - 1 && L[i + 1].t <= t) i++;
      return mix(L[i], L[i + 1], ease((t - L[i].t) / Math.max(1e-6, L[i + 1].t - L[i].t)));
    };
    const R = lane('r', ['x', 'y', 'z']), S = o.scale ? lane('s', ['s']) : null, Pp = o.pos ? lane('p', ['ox', 'oy']) : null;
    if (R) { out.x = r1(R.x + dv(MAP.x, 0)); out.y = r1(R.y + dv(MAP.y, 0)); out.z = r1(R.z + dv(MAP.z, 0)); }
    if (S) out.s = clamp(S.s * (B ? num(p.scale, 1) / Math.max(0.01, num(B.scale, 1)) : 1), 0.1, 5);
    if (Pp) { out.ox = Math.round(Pp.ox + dv('offsetX', 0)); out.oy = Math.round(Pp.oy + dv('offsetY', 0)); }
    out.on = !!(R || S || Pp);
    return out;
  };

  // ---------- 【画面】在 #stage 里插一层，旋转加在这一层上 ----------
  // 有的老效果没有 #stage（直接往 body 里画），这时候就拿 body 当舞台
  function host() {
    return document.getElementById('stage')
      || (document.body && document.body.firstElementChild ? document.body : null);
  }
  function ensureWrap() {
    const st = host();
    if (!st) return null;
    if (st === document.body && getComputedStyle(st).position === 'static') st.style.position = 'relative';
    if (!wrap || wrap.parentNode !== st) {
      wrap = st.querySelector(':scope > #fx-rot');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.id = 'fx-rot';
        wrap.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;transform-origin:center center';
        st.appendChild(wrap);
      }
    }
    // 把 stage 下除 fx-rot 以外的节点搬进来（效果在 init 里清空过 stage 的话这里会重新搬）
    for (let n = st.firstChild; n;) { const next = n.nextSibling; if (n !== wrap) wrap.appendChild(n); n = next; }
    return wrap;
  }
  function applyRot(t) {
    const R = K.at(P, t, dur());
    const st = host();
    if (st) {
      // 效果自己已经乘过 P.scale / offsetX / offsetY 了，这里只补「关键帧带来的那一份」差值：
      // 大小是比例（没开就是 1），位置是像素差（没开就是 0），所以和效果自己的参数不会打架。
      const k = R.s / Math.max(0.01, num(P.scale, 1));
      const dx = R.ox - num(P.offsetX, 0), dy = R.oy - num(P.offsetY, 0);
      const move = (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5 ? 'translate(' + Math.round(dx) + 'px,' + Math.round(dy) + 'px) ' : '')
        + (Math.abs(k - 1) > 1e-4 ? 'scale(' + k.toFixed(4) + ') ' : '');
      // 角度由效果自己应用时（apply:false，如 ring-carousel），大小和位置仍然由这一层补
      const tr = APPLY
        ? move + 'rotateX(' + R.x + 'deg) rotateY(' + R.y + 'deg) rotateZ(' + R.z + 'deg)'
        : move.trim();
      if (APPLY || tr || wrap) {        // tr 变空时也要写回去，把上一帧的位移 / 缩放清掉
        const w = ensureWrap();
        if (APPLY && st.__p !== R.persp) { st.__p = R.persp; st.style.perspective = R.persp + 'px'; }
        if (w && w.__tr !== tr) { w.__tr = tr; w.style.transform = tr; }
      }
    }
    if (K.live) K.live(t, R.x, R.y, R.z, R.s, R);
    return R;
  }
  const dur = () => { try { return +window.getDuration() || 0; } catch (e) { return 0; } };

  window.init = function (p) {
    P = p || {};
    const r = origInit.apply(this, arguments);
    setTimeout(() => { try { ensureWrap(); mount(); applyRot(lastT); } catch (e) { console.error(e); } }, 0);
    return r;
  };
  window.renderAt = function (t) {
    lastT = +t || 0;
    const r = origRender.apply(this, arguments);
    try { applyRot(lastT); } catch (e) { }
    return r;
  };

  // ================= 工作台里的交互（右键拖动 + 面板 + 轨道接口） =================
  let mounted = false, panelBox = null, redraw = () => { }, field = null;
  let liveT = 0;                      // 放在最前面：面板找不到时 setKey 也会用到它
  let base = null;                    // 操作前存下的原始参数；放在 mount 外面——老效果每拖一下都会重新 init、重新 mount，放里面会被清掉
  function mount() {
    let pw, pd;
    try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
    const box = pd.getElementById('params'); if (!box) return;
    const boxOf = () => pd.getElementById('box');
    const inBox = e => { const b = boxOf(); return b && e.target instanceof pw.Node && b.contains(e.target); };
    const hint = s => { const h = pd.getElementById('hint'); if (h) h.textContent = s; };
    const slider = () => pd.getElementById('slider');
    const nowT = () => { const s = slider(); return s ? +s.value || 0 : 0; };
    const labelOf = el => { const f = el.firstChild; if (!f) return ''; return String(f.nodeType === 3 ? f.textContent : (f.firstChild && f.firstChild.textContent) || '').trim(); };
    const rowsOf = () => [...box.children].flatMap(el => el.classList && el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);

    // 存回参数：**不派发 input 事件**（工作台收到 input 会重新 init 并从 0 秒重播，关键帧就没法调了）。
    // P 就是工作台的 params（init 时按引用传进来的），直接写即可；导出照样读得到。
    const commit = () => {
      const o2 = K.read(P);
      const json = JSON.stringify({ on: o2.on, auto: o2.auto, scale: o2.scale, pos: o2.pos, ease: o2.ease, edge: o2.edge, fade: o2.fade, list: o2.list });
      P.keys = json; _raw = json;
      if (field) field.value = json;
      try { if (pw.markDirty) pw.markDirty(); } catch (e) { }
      try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }
    };
    // kind = 'r' / 's' / 'p'；同一条轨道 0.04 秒内已有点就改它
    function setKey(t, kind) {
      const o2 = K.read(P);
      t = Math.max(0, r2(t));
      const rec = norm(kind === 'p' ? { t, k: 'p', ox: P.offsetX, oy: P.offsetY }
        : kind === 's' ? { t, k: 's', s: P.scale }
          : { t, k: 'r', x: num(P[MAP.x], 0), y: num(P[MAP.y], 0), z: num(P[MAP.z], 0) });
      const hit = o2.list.find(k => k.k === kind && Math.abs(k.t - t) < 0.04);
      if (hit) Object.assign(hit, rec); else o2.list.push(rec);
      sortL(o2.list);
      liveT = 0; commit(); redraw();
    }
    const NAME = { p: '位置 P', s: '大小 S', r: '旋转 R' };
    const said = (t, kind) => hint('已在 ' + t.toFixed(2) + ' 秒记下【' + NAME[kind] + '】关键帧：'
      + (kind === 'p' ? 'X ' + Math.round(num(P.offsetX, 0)) + '　Y ' + Math.round(num(P.offsetY, 0))
        : kind === 's' ? Math.round(num(P.scale, 1) * 100) + '%'
          : 'X ' + r1(num(P[MAP.x], 0)) + '°　Y ' + r1(num(P[MAP.y], 0)) + '°　Z ' + r1(num(P[MAP.z], 0)) + '°'));
    // 在某一秒把三条轨道都打上点（面板按钮 / 轨道双击用）；kinds 不传 = 三条都打
    // 临时把参数改成 vals 去打点，打完马上还原 —— 参数是开场 / 结尾的默认值，打关键帧绝不能改它
    const SIX = () => [MAP.x, MAP.y, MAP.z, 'scale', 'offsetX', 'offsetY'];
    const withTemp = (vals, fn) => {
      const keep = {}; SIX().forEach(f => (keep[f] = P[f]));
      Object.assign(P, vals);
      try { fn(); } finally { Object.assign(P, keep); }
    };
    const keyAll = (t, kinds) => {
      const c = K.at(P, t, dur());
      withTemp({ [MAP.x]: c.x, [MAP.y]: c.y, [MAP.z]: c.z, scale: r2(c.s), offsetX: c.ox, offsetY: c.oy },
        () => (kinds || ['p', 's', 'r']).forEach(k => setKey(t, k)));
    };
    K.setAt = setKey;
    // 滚轮缩放 / 左键拖位置之后，由前面那一层调过来：在当前这一秒记一个关键帧
    // 任何手动操作（右键转 / 滚轮 / 左键拖）开始前：把角度、大小、位置都对齐到画面当前这一帧，
    // 并在操作期间暂停曲线（K.dragging），画面才跟手；松手打点后再恢复。
    // 关键：操作前先存下原始参数（= 开场 / 结尾的默认值），打完关键帧再还原。
    // 以前拖动会直接改掉这些参数，于是第一个关键帧之前的开场也跟着变了。
    const FIELDS = { r: [MAP.x, MAP.y, MAP.z], s: ['scale'], p: ['offsetX', 'offsetY'] };
    const finish = (kind, recorded) => {
      K.dragging = false; K.dragBase = null;
      if (base) {
        // 记成了关键帧：全部还原；没记（关键帧关着等）：这次手动改的那几项保留，其余还原
        const keep = recorded ? [] : (FIELDS[kind] || []);
        Object.keys(base).forEach(f => { if (!keep.includes(f)) P[f] = base[f]; });
        base = null;
      }
      window.renderAt(nowT());
    };
    K.finish = finish;
    window.__fxViewBegin = () => {
      if (K.dragging) return;
      base = {};
      [MAP.x, MAP.y, MAP.z, 'scale', 'offsetX', 'offsetY'].forEach(f => (base[f] = P[f]));
      const c = K.at(P, nowT(), dur());               // 按下这一刻画面上的值（曲线算出来的）
      startV = { x: c.x, y: c.y, z: c.z, s: r2(c.s), ox: Math.round(c.ox), oy: Math.round(c.oy) };
      K.dragBase = base; K.dragging = true;           // 参数先不动：拖动时画面 = 曲线 + 手动改的差值（见 K.at）
    };
    // 松手要记录时：把「原始值 + 差值」换算成「画面上的值」（按下时的曲线值 + 差值），后面打关键帧 / 摆位置都按画面上的值算
    const toScreenVals = () => {
      if (!base || !startV || !K.dragBase) return;    // 只换算一次
      const d = f => num(P[f], 0) - num(base[f], 0);
      P[MAP.x] = r1(startV.x + d(MAP.x)); P[MAP.y] = r1(startV.y + d(MAP.y)); P[MAP.z] = r1(startV.z + d(MAP.z));
      P.scale = r2(startV.s * num(P.scale, 1) / Math.max(0.01, num(base.scale, 1)));
      P.offsetX = Math.round(startV.ox + d('offsetX')); P.offsetY = Math.round(startV.oy + d('offsetY'));
      K.lastKw = startV.s / Math.max(0.01, num(base.scale, 1));   // 关键帧那一层的缩放倍数（位置关键帧不跟着它缩放，下面要换算）
      K.dragBase = null;
    };
    K.toScreenVals = () => toScreenVals();
    window.__fxViewEnd = () => finish(null, false);
    K.placing = () => placing(); K.placeShift = k => placeShift(k);
    // ---------- 摆位置模式（v24.4）：工作台播放器下面「自动关键帧」关掉时 ----------
    // 拖动 / 缩放 / 旋转不打关键帧，而是把「原始值 + 这条轨道上所有关键帧」一起挪同样多（缩放按同样比例）：
    // 整段动画的样子不变，只是换个地方演。没有关键帧的素材就是直接改原始值。
    let startV = null;
    const placing = () => { try { return !!pw.__fxPlace; } catch (e) { return false; } };
    const placeShift = kind => {
      if (!base || !startV) return finish(kind, false);
      const o2 = K.read(P);
      if (kind === 'p') {
        const dx = num(P.offsetX, 0) - startV.ox, dy = num(P.offsetY, 0) - startV.oy;
        base.offsetX = Math.round(num(base.offsetX, 0) + dx); base.offsetY = Math.round(num(base.offsetY, 0) + dy);
        o2.list.forEach(k => { if (k.k === 'p') { k.ox = Math.round(num(k.ox, 0) + dx); k.oy = Math.round(num(k.oy, 0) + dy); } });
      } else if (kind === 's') {
        const f = startV.s ? num(P.scale, 1) / startV.s : 1;
        base.scale = r2(num(base.scale, 1) * f);
        o2.list.forEach(k => { if (k.k === 's') k.s = r2(num(k.s, 1) * f); });
      } else if (kind === 'r') {
        const d = { x: num(P[MAP.x], 0) - startV.x, y: num(P[MAP.y], 0) - startV.y, z: num(P[MAP.z], 0) - startV.z };
        base[MAP.x] = r1(num(base[MAP.x], 0) + d.x); base[MAP.y] = r1(num(base[MAP.y], 0) + d.y); base[MAP.z] = r1(num(base[MAP.z], 0) + d.z);
        o2.list.forEach(k => { if (k.k === 'r') { k.x = r1(num(k.x, 0) + d.x); k.y = r1(num(k.y, 0) + d.y); k.z = r1(num(k.z, 0) + d.z); } });
      }
      startV = null;
      finish(kind, true);                       // 全部还原成（已经挪过的）原始值
      liveT = 0; commit(); redraw(); window.renderAt(nowT());
      hint('摆位置：整段动画一起' + (kind === 'p' ? '挪了位置' : kind === 's' ? '改了大小' : '转了角度') + '，没有打关键帧');
    };
    window.__fxViewReset = () => {
      const o2 = K.read(P); if (!o2.on || !o2.list.length) return false;
      const t = nowT();
      withTemp({ [MAP.x]: 0, [MAP.y]: 0, [MAP.z]: 0, scale: 1, offsetX: 0, offsetY: 0 }, () => ['p', 's', 'r'].forEach(k => setKey(t, k)));
      window.renderAt(t); return true;
    };
    window.__fxViewChanged = kind => {
      toScreenVals();
      const o2 = K.read(P), k = kind === 'pos' ? 'p' : 's';
      if (placing()) return placeShift(k);
      // 拖动时画面上挪的是「差值 × 关键帧层的缩放」；位置关键帧是在缩放外面平移的，所以记的时候乘上这个倍数，松手后不偏
      if (k === 'p' && o2.on && o2.auto && K.lastKw && Math.abs(K.lastKw - 1) > 1e-4) {
        P.offsetX = Math.round(startV.ox + (num(P.offsetX, 0) - startV.ox) * K.lastKw);
        P.offsetY = Math.round(startV.oy + (num(P.offsetY, 0) - startV.oy) * K.lastKw);
      }
      if (!o2.on || !o2.auto || (k === 's' && !o2.scale) || (k === 'p' && !o2.pos)) return finish(k, false);
      const t = nowT();
      setKey(t, k); said(t, k);                // 只记这一条轨道，别的轨道不动
      finish(k, true);
    };
    K.recordNow = () => {                 // 给自己接管右键的效果用（ring-carousel）
      toScreenVals();
      if (placing()) return placeShift('r');
      const o2 = K.read(P); if (!o2.on || !o2.auto) return finish('r', false);
      const t = nowT();
      setKey(t, 'r'); said(t, 'r');
      finish('r', true);
      window.renderAt(t);
    };
    // 给播放器下面那条轨道用的接口（挂在效果自己的 window 上，换效果时自动消失）
    window.__fxKeysApi = {
      get: () => K.read(P).list.map(k => ({ ...k })),
      set: list => { const o2 = K.read(P); o2.list = sortL(list.flatMap(expand)); commit(); redraw(); window.renderAt(nowT()); },
      addAt: (t, kind) => { keyAll(t, kind ? [kind] : null); window.renderAt(nowT()); },
      enabled: () => K.read(P).on,
      total: () => dur(),
      // v8.1：播放器下面的「关键帧之外：回到默认 / 保持首尾」按钮用（不用再去右侧面板里找）
      opt: () => { const o2 = K.read(P); return { on: o2.on, edge: o2.edge, fade: o2.fade }; },
      setOpt: o => {
        const o2 = K.read(P);
        if (o && 'edge' in o) o2.edge = o.edge === 'hold' ? 'hold' : 'blend';
        if (o && 'on' in o) o2.on = !!o.on;
        if (o && 'fade' in o) o2.fade = Math.max(0, num(o.fade, 0.6));
        liveT = 0; commit(); redraw(); window.renderAt(nowT());
      }
    };

    // ---------- 右键拖动转 XYZ ----------
    const syncRot = () => {
      const rows = rowsOf();
      [[LB.y, MAP.y], [LB.x, MAP.x], [LB.z, MAP.z]].forEach(([lab, key]) => {
        const row = rows.find(el => labelOf(el).startsWith(lab));
        const inp = row && row.querySelector('input[type=number]');
        if (inp) { inp.value = r1(num(P[key], 0)); if (inp.__fxRange) inp.__fxRange.value = inp.value; }
      });
    };
    if (DRAG && !mounted) {
      let drag = null, raf = 0, lastRight = 0, lastXY = [0, 0];
      const zeroAll = why => {
        const o2 = K.read(P);
        // 已经有旋转关键帧：只在这一秒打一个「归零」的点，原始角度不动（开场不受影响）
        if (o2.on && o2.list.some(k => k.k === 'r')) withTemp({ [MAP.x]: 0, [MAP.y]: 0, [MAP.z]: 0 }, () => setKey(nowT(), 'r'));
        else { P[MAP.x] = 0; P[MAP.y] = 0; P[MAP.z] = 0; }
        window.renderAt(nowT()); syncRot(); hint(why);
      };
      const onCtx = e => { if (inBox(e)) e.preventDefault(); };
      const onDown = e => {
        if (!inBox(e) || e.button !== 2) return;
        e.preventDefault(); e.stopPropagation();
        const now = Date.now();
        // 浏览器的 dblclick 只对左键触发，右键没有这个事件 → 自己判断双击
        if (now - lastRight < 350 && Math.abs(e.clientX - lastXY[0]) < 6 && Math.abs(e.clientY - lastXY[1]) < 6) {
          lastRight = 0; drag = null; K.dragging = false;
          const b0 = boxOf(); if (b0) b0.style.cursor = '';
          zeroAll('三轴角度已归零'); return;
        }
        lastRight = now; lastXY = [e.clientX, e.clientY];
        window.__fxViewBegin();                    // 角度、大小、位置都从当前这一帧开始，画面不跳
        drag = { x: e.clientX, y: e.clientY, rx: num(P[MAP.x], 0), ry: num(P[MAP.y], 0), rz: num(P[MAP.z], 0), shift: e.shiftKey };
        const b = boxOf(); if (b) b.style.cursor = 'move';
      };
      const onMove = e => {
        if (!drag) return;
        e.preventDefault();
        const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (drag.shift || e.shiftKey) P[MAP.z] = r1(clamp(drag.rz + dx * 0.25, -180, 180));
        else { P[MAP.y] = r1(clamp(drag.ry + dx * 0.3, -180, 180)); P[MAP.x] = r1(clamp(drag.rx - dy * 0.3, -90, 90)); }
        if (!raf) raf = pw.requestAnimationFrame(() => { raf = 0; window.renderAt(nowT()); syncRot(); });
        hint('X 轴 ' + r1(num(P[MAP.x], 0)) + '°　Y 轴 ' + r1(num(P[MAP.y], 0)) + '°　Z 轴 ' + r1(num(P[MAP.z], 0))
          + '°　·　Shift + 右键转 Z 轴　·　右键双击归零');
      };
      const onUp = () => {
        if (!drag) return;
        drag = null;
        const b = boxOf(); if (b) b.style.cursor = '';
        K.toScreenVals();                          // 换算成画面上的值再记录
        if (K.placeShift && K.placing()) { K.placeShift('r'); return; }   // 摆位置模式：整段一起转
        const o2 = K.read(P), rec = o2.on && o2.auto;
        if (rec) {                                 // 松手就在当前这一秒记一个关键帧
          const t = nowT();
          setKey(t, 'r'); said(t, 'r');           // 右键只记旋转这一条轨道
        }
        finish('r', rec);                          // 记成关键帧就把原始参数还原，开场不受影响
      };
      const onDbl = e => { if (inBox(e) && e.button === 0) setTimeout(() => zeroAll('已还原：大小、位置、角度'), 0); };
      try { if (pw.__fxRotDispose) pw.__fxRotDispose(); } catch (e) { }
      pd.addEventListener('contextmenu', onCtx, true);
      pd.addEventListener('mousedown', onDown, true);
      pd.addEventListener('mousemove', onMove, true);
      pd.addEventListener('mouseup', onUp, true);
      pd.addEventListener('dblclick', onDbl, true);
      pw.__fxRotDispose = () => {
        pd.removeEventListener('contextmenu', onCtx, true);
        pd.removeEventListener('mousedown', onDown, true);
        pd.removeEventListener('mousemove', onMove, true);
        pd.removeEventListener('mouseup', onUp, true);
        pd.removeEventListener('dblclick', onDbl, true);
        pw.__fxRotDispose = null;
      };
      mounted = true;
    }

    // ---------- 右侧面板里的「关键帧」一栏 ----------
    const jl = rowsOf().find(el => el.tagName === 'LABEL' && labelOf(el).startsWith('关键帧'));
    field = jl && jl.querySelector('input,textarea');
    if (!field) { redraw = () => { }; try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { } return; }
    if (panelBox && box.contains(panelBox)) { redraw(); try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { } return; }
    box.querySelectorAll('.kfx').forEach(x => x.remove());
    jl.style.display = 'none';

    if (!pd.getElementById('kfx-style')) {
      const st = pd.createElement('style'); st.id = 'kfx-style';
      st.textContent = '.kfx{display:block;font-size:12px;color:#999;margin-bottom:14px}'
        + '.kfx-b{margin-top:8px;padding:10px;background:#101010;border:1px solid #2c2c2c;border-radius:8px}'
        + '.kfx-top{display:flex;align-items:center;gap:8px;margin-bottom:8px}'
        + '.kfx-top>span{flex:1;color:#ccc;font-size:13px}'
        + '.kfx-seg{display:flex;background:#1d1d1d;border:1px solid #333;border-radius:6px;overflow:hidden}'
        + '.kfx-seg button{border:0;background:none;color:#aaa;padding:4px 11px;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap}'
        + '.kfx-seg button.on{background:#f28c0f;color:#000;font-weight:600}'
        + '.kfx-now{padding:7px 9px;background:#0b0b0b;border:1px solid #262626;border-radius:6px;font-size:12px;color:#bbb;line-height:1.7}'
        + '.kfx-now b{color:#f2a33d;font-weight:600}'
        + '.kfx-add{display:block;width:100%;margin-top:8px;padding:9px;font-size:13px;color:#111;border:0;border-radius:6px;cursor:pointer;font-family:inherit;font-weight:600;background:#f28c0f}'
        + '.kfx-add:hover{filter:brightness(1.08)}'
        + '.kfx-row{display:flex;align-items:center;gap:8px;margin-top:9px;color:#aaa}'
        + '.kfx-row>span{flex:1;min-width:0}'
        + '.kfx-clr{display:block;width:100%;margin-top:8px;padding:7px;font-size:12px;border-radius:6px;cursor:pointer;font-family:inherit;background:#262626;color:#bbb;border:1px solid #333}'
        + '.kfx-clr:hover{border-color:#5a1f1f;color:#fff}'
        + '.kfx-note{margin-top:7px;font-size:11.5px;color:#777;line-height:1.7}'
        + '.kfx-note b{color:#f2b56a;font-weight:500}';
      pd.head.appendChild(st);
    }
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const wrapEl = mk('div', 'kfx'); wrapEl.append('关键帧');
    const b = mk('div', 'kfx-b');
    const top = mk('div', 'kfx-top', '<span>关键帧动画</span>');
    const segOn = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    top.appendChild(segOn);
    const now = mk('div', 'kfx-now', '把进度条拖到某一秒，这里会显示那一帧的角度');
    const add = mk('button', 'kfx-add'); add.type = 'button';
    const rowAuto = mk('div', 'kfx-row', '<span>拖完自动打点</span>');
    const segAuto = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowAuto.appendChild(segAuto);
    const rowEase = mk('div', 'kfx-row', '<span>两点之间</span>');
    const segEase = mk('div', 'kfx-seg', '<button type="button" data-v="smooth">平滑</button><button type="button" data-v="linear">匀速</button>');
    rowEase.appendChild(segEase);
    const rowEdge = mk('div', 'kfx-row', '<span>关键帧之外</span>');
    const segEdge = mk('div', 'kfx-seg', '<button type="button" data-v="blend">回到默认</button><button type="button" data-v="hold">保持首尾</button>');
    rowEdge.appendChild(segEdge);
    const rowFade = mk('div', 'kfx-row', '<span>首尾衔接（秒）</span>');
    const fadeIn = mk('input'); fadeIn.type = 'number'; fadeIn.min = '0'; fadeIn.max = '10'; fadeIn.step = '0.1';
    fadeIn.style.cssText = 'width:72px;flex:none;margin:0;padding:5px 7px;text-align:right';
    rowFade.appendChild(fadeIn);
    const rowScale = mk('div', 'kfx-row', '<span>也记录大小（滚轮）</span>');
    const segScale = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowScale.appendChild(segScale);
    const rowPos = mk('div', 'kfx-row', '<span>也记录位置（左键拖）</span>');
    const segPos = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowPos.appendChild(segPos);
    const clr = mk('button', 'kfx-clr'); clr.type = 'button'; clr.textContent = '清空全部关键帧';
    const note = mk('div', 'kfx-note');

    const applyNow = () => { liveT = 0; redraw(); commit(); window.renderAt(nowT()); };
    segOn.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).on = x.dataset.v === '1'; applyNow(); });
    segAuto.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).auto = x.dataset.v === '1'; applyNow(); });
    segEase.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).ease = x.dataset.v; applyNow(); });
    segEdge.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).edge = x.dataset.v; applyNow(); });
    segScale.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).scale = x.dataset.v === '1'; applyNow(); });
    segPos.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).pos = x.dataset.v === '1'; applyNow(); });
    fadeIn.addEventListener('input', () => { K.read(P).fade = Math.max(0, num(fadeIn.value, 0.6)); liveT = 0; commit(); window.renderAt(nowT()); });
    add.onclick = () => { keyAll(nowT()); window.renderAt(nowT()); };
    clr.onclick = () => { K.read(P).list = []; applyNow(); };

    redraw = function () {
      const o2 = K.read(P), t = nowT(), n = o2.list.length;
      segOn.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.on));
      segAuto.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.auto));
      segEase.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.v === o2.ease));
      segEdge.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.v === o2.edge));
      segScale.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.scale));
      segPos.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.pos));
      if (pd.activeElement !== fadeIn) fadeIn.value = o2.fade;
      rowFade.style.display = o2.edge === 'blend' ? '' : 'none';
      add.textContent = '＋ 在 ' + t.toFixed(2) + ' 秒打一个关键帧';
      note.innerHTML = !o2.on
        ? '关键帧动画已关闭，现在用的是固定角度：在预览区按住右键拖动来转（Shift + 右键转 Z 轴，右键双击归零）。'
        : n === 0 ? '还没有关键帧。<b>把进度条拖到某一秒，在预览区按住右键转角度、滚轮缩放、或按住左键把素材拖到想要的位置，松手就自动记下这一帧</b>；播放器下面那条轨道上会出现一个点，可以框选、拖着前后移动。'
          : n + ' 个关键帧。每个点都记着<b>角度 + 大小 + 位置</b>：转一下（右键）、滚轮缩放、左键拖位置，松手都会在当前这一秒自动打点。<b>第一个点之前、最后一个点之后会回到默认值</b>，所以这个效果自带的开场和结尾原样保留；中间这一段才走你打的关键帧。点在播放器下面的轨道上，可以框选、拖动、按 Delete 删除。';
      try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }
    };
    K.live = (t, rx, ry, rz, s, R) => {
      const nn = Date.now(); if (nn - liveT < 80) return; liveT = nn;
      const o2 = K.read(P);
      now.innerHTML = '当前 <b>' + (+t).toFixed(2) + ' 秒</b>　X <b>' + r1(rx) + '°</b>　Y <b>' + r1(ry) + '°</b>　Z <b>' + r1(rz) + '°</b>'
        + (o2.scale ? '　大小 <b>' + Math.round(s * 100) + '%</b>' : '')
        + (o2.pos && R ? '　位置 <b>' + Math.round(R.ox) + ', ' + Math.round(R.oy) + '</b>' : '');
      add.textContent = '＋ 在 ' + (+t).toFixed(2) + ' 秒打一个关键帧';
    };
    b.append(top, now, add, rowAuto, rowEase, rowEdge, rowFade, rowScale, rowPos, clr, note);
    wrapEl.appendChild(b); jl.after(wrapEl);
    panelBox = wrapEl;
    redraw();
  }
})();

/* =====================================================================
 * 【去色 · 高亮关键帧 —— 所有效果通用】（v14.0）
 *
 * 从「缝线标题卡」来的那套「去色 · 高亮关键帧」，现在每个效果都有，效果本身一行不用改：
 *   - 色彩一行：去色 ↔ 彩色（整个画面变黑白再恢复彩色）
 *   - 高亮一行：常态 ↔ 高亮（画面提亮一点 + 一圈高亮色的光晕）
 *   - 每个点 =「从这一秒开始，用『颜色渐变秒数』变成这个状态」，保持到下一个点
 * 1）算法（FXColorKeys）放在这里，因为每个效果都会加载这个文件；公共模块 fx-skin.js 的同名函数也是转到这里来算，只有一份。
 * 2）数据存在 params.__color（和 __dur 一样是工作台层的参数）：{ keys:{c:[{t,v}],h:[{t,v}]}, desat:'on'|'off', fade:秒, hi:'#色' }，
 *    撤销 / 预设 / 导出都照常带着走。
 * 3）画面：滤镜加在 #stage（没有就 body）上，只在数值变化时写；没打任何点、开场也不是黑白时一个字都不写，老画面一个像素不变。
 * 4）面板：右侧参数最后多一块「去色 · 高亮关键帧」+「高亮色」，界面直接用 fx-skin.js 的 keysBlock / colorBlock
 *    （只在工作台预览里按需加载 fx-cards.js + fx-skin.js；导出时不加载，也用不着）。
 * 5）效果自己已经做了这一套的（effect.json 里有 colorKeys 参数：缝线标题卡、焦点格卡片），这一层自动让开，不重复。
 * ===================================================================== */
(function () {
  // ---------- 算法（FXColorKeys）----------
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const prog = (t, a, b) => (b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1));
  const lerp = (a, b, k) => a + (b - a) * k;
  const smooth = x => x * x * (3 - 2 * x);
  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const CK = window.FXColorKeys = window.FXColorKeys || {};
  CK.readKeys = raw => {
    let k = raw;
    if (typeof k === 'string') { try { k = JSON.parse(k); } catch (e) { k = null; } }
    const lane = a => (Array.isArray(a) ? a : [])
      .filter(x => x && Number.isFinite(+x.t))
      .map(x => ({ t: Math.max(0, Math.round(+x.t * 100) / 100), v: +x.v >= 0.5 ? 1 : 0 }))
      .sort((a, b) => a.t - b.t);
    return { c: lane(k && k.c), h: lane(k && k.h) };
  };
  // 某一秒的值：b0 = 第一个点之前的状态；每个点从自己那一秒开始用 fade 秒变过去
  const laneAt = CK.laneAt = (keys, b0, fade, t) => {
    let v = b0;
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      if (t < k.t) break;
      const from = i ? laneAt(keys.slice(0, i), b0, fade, k.t) : b0;   // 这个点开始时，上一段实际停在哪
      v = fade > 0 ? lerp(from, k.v, smooth(prog(t, k.t, k.t + fade))) : k.v;
    }
    return v;
  };
  // 这一秒的状态 { c: 0 黑白 ~ 1 彩色, h: 0 常态 ~ 1 高亮 }；P 里用 desat（开场是否黑白）、fadeK（颜色渐变秒数）
  CK.colorAt = (P, K, t) => {
    const fade = clamp(num(P.fadeK, 0.4), 0, 5);
    return { c: clamp(laneAt(K.c, P.desat === 'on' ? 0 : 1, fade, t), 0, 1),
             h: clamp(laneAt(K.h, 0, fade, t), 0, 1) };
  };
  // 去色的滤镜（c = 1 时为空字符串）
  CK.desatFilter = c => { const g = 1 - c; return g > 0.002 ? `grayscale(${g.toFixed(3)}) brightness(${(1 - 0.1 * g).toFixed(3)}) contrast(${(1 - 0.06 * g).toFixed(3)})` : ''; };
  // 通用的高亮：提亮一点 + 两层高亮色光晕（只在 h > 0 时有）
  const rgb = h => { const m = /^#?([0-9a-f]{6})$/i.exec(String(h || '').trim()); const v = parseInt(m ? m[1] : 'f28c0f', 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; };
  CK.hiFilter = (h, hex) => {
    if (h <= 0.002) return '';
    const [r, g, b] = rgb(hex);
    return `brightness(${(1 + 0.12 * h).toFixed(3)}) saturate(${(1 + 0.3 * h).toFixed(3)}) drop-shadow(0 0 ${(8 * h).toFixed(1)}px rgba(${r},${g},${b},${(0.95 * h).toFixed(3)})) drop-shadow(0 0 ${(26 * h).toFixed(1)}px rgba(${r},${g},${b},${(0.7 * h).toFixed(3)}))`;
  };

  // ---------- 通用层：包住 init / renderAt ----------
  const oi = window.init, or = window.renderAt;
  if (typeof oi !== 'function' || typeof or !== 'function') return;
  let P = null, lastT = 0, K = null, own = false, ED = null;
  const cfg = () => {
    let c = P && P.__color;
    if (typeof c === 'string') { try { c = JSON.parse(c); } catch (e) { c = null; } }
    return c && typeof c === 'object' && !Array.isArray(c) ? c : {};
  };
  const view = () => { const c = cfg(); return { desat: c.desat === 'on' ? 'on' : 'off', fadeK: c.fade == null ? 0.4 : c.fade }; };
  const host = () => document.getElementById('stage') || document.body;
  function paint(t) {
    if (own) return;
    const c = cfg();
    if (!K) K = CK.readKeys(c.keys);
    const on = c.desat === 'on' || K.c.length || K.h.length;
    let fl = '';
    if (on) { const st = CK.colorAt(view(), K, t); fl = [CK.desatFilter(st.c), CK.hiFilter(st.h, c.hi)].filter(Boolean).join(' '); }
    const el = host();
    if (el && el.__fxcf !== fl) { if (fl || el.__fxcf) el.style.filter = fl; el.__fxcf = fl; }
  }
  window.init = function (p) {
    P = p || {}; K = null;
    own = Object.prototype.hasOwnProperty.call(P, 'colorKeys');      // 效果自己有这一套：让开
    const r = oi.apply(this, arguments);
    try { paint(lastT); } catch (e) { }
    if (!own) setTimeout(() => { try { mountUI(); } catch (e) { console.error(e); } }, 30);
    return r;
  };
  window.renderAt = function (t) {
    lastT = +t || 0;
    const r = or.apply(this, arguments);
    try { paint(lastT); } catch (e) { }
    try { if (ED && ED.head) ED.head(lastT); } catch (e) { }
    return r;
  };

  // ---------- 工作台面板（只在预览里）----------
  let pw, pd;
  try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
  const load = src => new Promise(res => { const s = document.createElement('script'); s.src = src; s.onload = s.onerror = res; document.head.appendChild(s); });
  let loading = null;
  const ensure = () => loading || (loading = (async () => {
    if (!window.FXCards) await load('../_shared/fx-cards.js');
    if (!window.FXSkin || !window.FXSkin.keysBlock) await load('../_shared/fx-skin.js');
    if (!window.FXPalettes) await load('../_shared/fx-palettes.js');      // 公共配色库：高亮色多 16 个预设（2026-11-10）
  })());
  const save = c => { P.__color = c; K = CK.readKeys(c.keys); try { pw.markDirty && pw.markDirty(); } catch (e) { } try { pw.histSoon && pw.histSoon(); } catch (e) { } };
  // keysBlock / colorBlock 读写的是 P.colorKeys / desat / fadeK / cText / cHi，这里给它一个「替身」，背后读写 params.__color
  const PP = {
    get colorKeys() { return JSON.stringify(cfg().keys || { c: [], h: [] }); },
    set colorKeys(v) { const c = cfg(); try { c.keys = JSON.parse(v); } catch (e) { } save(c); },
    get desat() { return cfg().desat === 'on' ? 'on' : 'off'; },
    set desat(v) { const c = cfg(); c.desat = v === 'on' ? 'on' : 'off'; save(c); },
    get fadeK() { const c = cfg(); return c.fade == null ? 0.4 : c.fade; },
    set fadeK(v) { const c = cfg(); c.fade = clamp(num(v, 0.4), 0, 5); save(c); },
    get cText() { return '#d6d6d6'; }, set cText(v) { },
    get cHi() { return cfg().hi || '#f28c0f'; },
    set cHi(v) { const c = cfg(); c.hi = v; save(c); }
  };
  let wrapEl = null, mo = null;
  // 换效果时（这个页面要被卸掉了）把监视和面板一起收掉，免得旧面板被放回新效果的面板里
  window.addEventListener('pagehide', () => { try { mo && mo.disconnect(); } catch (e) { } try { wrapEl && wrapEl.remove(); } catch (e) { } mo = null; wrapEl = null; });
  async function mountUI() {
    if (!pd) return;                                   // 单独打开（导出 / 测试）：没有工作台面板
    const box = pd.getElementById('params'); if (!box) return;
    if (wrapEl && box.contains(wrapEl)) { ED && ED.refresh && ED.refresh(); return; }
    await ensure();
    const SK = window.FXSkin; if (!SK || !SK.keysBlock) return;
    box.querySelectorAll('.fxcolor').forEach(x => x.remove());
    SK.injectStyle(pd);
    const mk = SK.mk(pd);
    const render = t => { try { window.renderAt(t == null ? lastT : t); } catch (e) { } };
    const wrap = mk('div', 'stc fxcolor'); wrap.dataset.fxContent = '1';
    const keys = SK.keysBlock({
      pd, pw, P: PP, field: () => null, dirty: () => { },
      total: () => +window.getDuration() || 1, now: () => lastT, inDur: () => 0.5,
      render, setK: k => { K = k; },
      hiWord: ['常态', '高亮'], hiOff: '◆ 这一秒回到常态', hiNone: '一直是常态', hiBack: '回到常态',
      defText: '#d6d6d6', base: () => [40, 40, 40]
    });
    // 颜色渐变秒数：数字框 + 滑杆（规则 5）
    const fadeRow = mk('div', 'stc-lh', '<span>颜色渐变秒数</span>');
    const fadeIn = mk('input'); fadeIn.type = 'number'; fadeIn.min = 0; fadeIn.max = 5; fadeIn.step = 0.05;
    fadeIn.style.cssText = 'width:64px!important;margin:0!important;padding:3px 6px!important;font-size:12px!important';
    const fadeR = mk('input'); fadeR.type = 'range'; fadeR.min = 0; fadeR.max = 5; fadeR.step = 0.05; fadeR.style.cssText = 'flex:1;margin:0 8px!important';
    const setFade = v => { PP.fadeK = v; fadeIn.value = fadeR.value = PP.fadeK; keys.refresh(); render(); };
    fadeIn.oninput = () => setFade(fadeIn.value); fadeR.oninput = () => setFade(fadeR.value);
    fadeRow.append(fadeR, fadeIn);
    keys.el.insertBefore(fadeRow, keys.el.querySelector('.stc-qk'));
    const color = SK.colorBlock({
      pd, pw, P: PP, field: () => null, title: '高亮色', sub: '高亮时画面周围那圈光的颜色',
      keys: [{ key: 'cHi', name: '高亮色', tip: '高亮时画面周围那圈光的颜色', def: '#f28c0f' }],
      presets: [{ c: ['#f28c0f'], name: '橙' }, { c: ['#f5c542'], name: '金黄' }, { c: ['#ffffff'], name: '白' }, { c: ['#4c9aff'], name: '蓝' },
                { c: ['#3ecf8e'], name: '绿' }, { c: ['#f472b6'], name: '粉' }, { c: ['#ef5b5b'], name: '红' }, { c: ['#2dd4e0'], name: '青' }]
        .concat(window.FXPalettes && FXPalettes.forGlow ? FXPalettes.forGlow() : []),
      ls: 'fx-my-colors-hi', apply: () => { render(); keys.refresh(); }
    });
    const head = mk('div', 'stc-note', '这一块所有效果都有（v14.0）：<b>色彩</b>一行让整个画面变黑白再恢复彩色，<b>高亮</b>一行让画面提亮、外面亮起一圈高亮色的光。进度条拖到某一秒，点下面的按钮就在这一秒打一个点。');
    head.style.cssText = 'margin:0 0 10px!important';
    wrap.append(keys.el, color.el);
    keys.el.insertBefore(head, keys.el.children[1]);
    box.appendChild(wrap);
    wrapEl = wrap;
    ED = { head: keys.head, refresh: () => { K = null; fadeIn.value = fadeR.value = PP.fadeK; keys.refresh(); color.refresh(); } };
    ED.refresh();
    // 工作台重排面板（分组、恢复默认、撤销）会清掉这一块：清掉了就放回最后
    if (mo) mo.disconnect();
    mo = new pw.MutationObserver(() => { if (wrapEl && !box.contains(wrapEl) && box.children.length) { box.appendChild(wrapEl); } });
    mo.observe(box, { childList: true });
  }
})();

/* =====================================================================
 * 【清晰度 · 放大 / 转角度不发虚】（v29.0）—— 预览和导出都生效
 *
 * 文字、边框本来都是矢量，放多大都该清楚。发虚的原因：效果里为了流畅给元素写了 will-change: transform，
 * 浏览器会按「第一次画出来时的大小」把它拍成一张图，之后放大 / 转角度只是把这张图拉大，所以糊。
 *   - 导出（效果页单独打开，或在导出用的 comp.html 里）：直接关掉 will-change，每一帧都按真实大小画，最清楚。
 *     导出是一帧一帧截图，不追求实时帧率，关掉没有代价。
 *   - 预览（在工作台里）：保留 will-change（规则 16：关掉会掉帧），只在画面停下来（暂停、拖完进度条、
 *     改完大小 / 角度 / 组合变换）的那一刻把 will-change 摘掉一帧再加回去，浏览器就按现在的大小重新画一张清楚的。
 *     一直在播放时，最多每 1 秒重新画一次。
 * 实测（hierarchy-tree 放大 3 倍）：边缘清晰度从 329 → 1044，和完全不用 will-change 一样。
 * ===================================================================== */
(function () {
  const de = document.documentElement;
  const css = document.createElement('style');
  css.textContent = 'html.fx-crisp *,html.fx-crisp *::before,html.fx-crisp *::after{will-change:auto!important}';
  (document.head || de).appendChild(css);
  let exportMode = true;
  try { const pp = window.parent; exportMode = pp === window || (/\/comp\.html$/.test(pp.location.pathname) && pp.parent === pp); } catch (e) { }
  if (exportMode) { de.classList.add('fx-crisp'); return; }
  const num = v => (Number.isFinite(+v) ? Math.round(+v * 1000) / 1000 : '');
  const sigOf = () => {
    const P = window.__fxCurP ? window.__fxCurP() : null, w = document.getElementById('fx-rot');
    let fe = ''; try { fe = window.frameElement ? window.frameElement.style.transform : ''; } catch (e) { }
    return [innerWidth, innerHeight, fe, w ? w.style.transform.replace(/translate\([^)]*\)\s*/g, '') : '',
      P ? [num(P.scale), num(P.rotX), num(P.rotY), num(P.rotZ)].join(',') : ''].join('|');
  };
  let sig = sigOf(), last = 0, lastR = 0, dirty = false;
  const reraster = () => {
    last = performance.now(); dirty = false; de.classList.add('fx-crisp');
    requestAnimationFrame(() => requestAnimationFrame(() => de.classList.remove('fx-crisp')));
  };
  // 效果自己的动画也会放大元素（比如卡片从小弹到正常大小），所以每画一帧都记一下；
  // 画面停下来（暂停 / 拖完进度条）0.15 秒后重画一次；一直在播放时最多每 1 秒重画一次。
  const or = window.renderAt;
  if (typeof or === 'function') window.renderAt = function () { lastR = performance.now(); dirty = true; return or.apply(this, arguments); };
  setInterval(() => {                               // 每 0.15 秒看一眼，很便宜：只拼一个字符串
    const s = sigOf(); if (s !== sig) { sig = s; dirty = true; lastR = performance.now(); }
    if (!dirty) return;
    const now = performance.now();
    if (now - lastR > 150 || now - last > 1000) reraster();
  }, 150);
})();
