/* ===========================================================================
   fx-cardbg.js —— 卡片背景动效（工作台公共模块，2026-11-11 从「旗标名牌卡」抽出来，规则 40）
   ---------------------------------------------------------------------------
   做什么：卡片里面一层小图形（立方体 / 棱形 / 烟雾 / 光点）从卡片中间缓缓往外涌出、无限循环。
           画在每张卡自己的 canvas 上：在底色上面、文字 / 照片边框下面（照片卡在照片上面），跟着卡片一起动、一起裁圆角、一起去色。
   谁在用：所有引用了 _shared/fx-cards.js 的效果 —— fx-cards.js 末尾会自动把本文件带进来，效果里不用写 <script>。
           以后新做的卡片效果只要照规则 26 引用 fx-cards.js，并让卡片被「标记」（见下），就自动有这个功能和右侧面板。
   默认：关。只有用户在右侧「卡片背景动效」里打开才画；关着时一个像素都不改（规则 26 的逐像素回归）。
         某个效果想默认开（比如旗标名牌卡），在自己的脚本里设 FXCardBg.defaults（见【区域B3】）。

   区域地图（想改哪里，直接说「区域Bx 怎么改」）
   【区域B1 图形】   KINDS 四种图形 + 「轮流」；particles() 每个粒子在时间 t 的位置（纯函数，预览和逐帧导出一致）；draw() 画一帧
   【区域B2 标记卡片】FXCardBg.mark(卡片元素, { after, kind, seed, cy, radius })：告诉模块「这是一张卡，canvas 插在哪」
                     · FXCards.card() 画的卡（公共卡片那 7 个效果）已经在 fx-cards.js 里自动标记，不用管
                     · 自己画卡的效果：build 时对每张卡调一次 mark（不写 after = 插在最底下；卡里有 <img>/<video> 就插在它们上面）
                     · 每帧可以写 卡片元素.__fxbgK = 0~1（这张卡的粒子亮度，0 = 不画，比如卡片还没入场 / 高亮时变淡）
   【区域B3 设置】   存在参数 P.__cardbg 里：{ on, kind, color, amount, speed, size, op }
                     · 以 __ 开头，工作台的时间线、撤销、「保存为预设」都会原样带着走（server.js 的 presetExtra）
                     · FXCardBg.defaults = 对象 或 (P) => 对象：效果自己的默认值（只在用户没改过时生效）
   【区域B4 每帧】   页面加载完后包住 window.init / window.renderAt：每帧画完效果自己的东西，再给所有标记过的卡画粒子
   【区域B6 每张卡单独调】每张卡的数据里多一个 cardbg = { own, kind, color, amount, speed, size, op, blurOn, blur }（v31.4）：
                     own = true 时，写了的项盖过统一设置，没写的照样跟统一走；own = false / 没有 = 完全跟统一。
                     卡片编辑区底部的折叠块「单独调整背景动效」= FXCardBg.cardBlock({ pd, pw, get, set, key })，总开关关着时自动藏起来。
                     效果标记卡片时把这张卡的 cardbg 交给模块：FXCardBg.mark(卡片, { own: 卡片数据.cardbg })（可以写成 getter）。
   【区域B7 模糊】   「越远越糊、越近越清楚」：每个粒子有自己的远近，远的小一点、淡一点、糊；近的大、清楚。
                     分三层画：远的一层、中间一层先在缩小的画布上加模糊再贴回来，近的一层直接画（便宜）。模糊关着时画法和以前一模一样。
   【区域B5 面板】   右侧「卡片背景动效」：标题栏上一个 开 / 关，展开后：样式（立方体 / 棱形 / 烟雾 / 光点 / 轮流）、
                     粒子颜色（色块 + 取色 + ★ 保存为我的配色，规则 24）、数量 / 速度 / 大小 / 透明度（数字框 + 滑杆，规则 5）。默认折叠。
                     · 自动放在「数值调节」上面；效果想自己放（比如旗标名牌卡放在「排版」下面），设 FXCardBg.manual = true，
                       再把 FXCardBg.editor({ pd, pw, perCard }) 返回的 el 放到想放的地方
   =========================================================================== */
(function () {
  if (window.FXCardBg) return;
  const M = {};
  window.FXCardBg = M;
  const SRC = (document.currentScript && document.currentScript.src) || '';

  // ================= 【区域B1 图形】 =================
  const KINDS = [['cube', '立方体'], ['prism', '棱形'], ['smoke', '烟雾'], ['dust', '光点']];
  M.KINDS = KINDS;
  M.DEF = { on: false, kind: 'mix', color: '#ffffff', amount: 100, speed: 100, size: 100, op: 70, blurOn: false, blur: 60 };
  const OWN_KEYS = ['kind', 'color', 'amount', 'speed', 'size', 'op', 'blurOn', 'blur'];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, k) => a + (b - a) * k;
  const num = (v, d) => { const n = parseFloat(v); return Number.isFinite(n) ? n : d; };
  const rnd = (seed, k) => window.FXCards && FXCards.rnd ? FXCards.rnd(seed, k)
    : (x => x - Math.floor(x))(Math.sin(seed * 12.9898 + k * 78.233) * 43758.5453);
  const hexOk = c => /^#[0-9a-f]{6}$/i.test(String(c || '').trim());
  const rgbOf = c => { c = String(c).trim(); return [1, 3, 5].map(i => parseInt(c.substr(i, 2), 16)); };

  // 一个粒子在时间 t 的状态：每个粒子有自己的相位，一轮一轮从中间往外涌，每一轮换一个方向（种子 = 粒子号 + 第几轮）
  function particles(kind, t, W, H, seed, o){
    const N = Math.round({ cube: 16, prism: 18, smoke: 9, dust: 46 }[kind] * o.amount);
    const life = { cube: 7, prism: 7, smoke: 9, dust: 6 }[kind] / o.speed;
    const cx = W / 2, cy = H * o.cy, reach = Math.hypot(W, H) * 0.56;
    const out = [];
    for (let i = 0; i < N; i++){
      const ph = rnd(seed, i * 7 + 1);
      const x = t / life + ph, gen = Math.floor(x), u = x - gen;
      const k = i * 131 + gen * 7919 + 3;
      const a = rnd(seed, k) * Math.PI * 2;
      const r0 = rnd(seed, k + 1) * 0.18;                         // 出生点离中心多远（占涌出距离的比例）
      const d = reach * (r0 + (1 - r0) * Math.pow(u, 0.85));
      const wob = Math.sin((u * 2 + rnd(seed, k + 2)) * Math.PI) * reach * 0.04;
      out.push({
        x: cx + Math.cos(a) * d - Math.sin(a) * wob, y: cy + Math.sin(a) * d * 0.92 + Math.cos(a) * wob,
        u, a, s: lerp(0.55, 1.35, rnd(seed, k + 3)), rot: rnd(seed, k + 4) * 6.283 + u * lerp(-1.6, 1.6, rnd(seed, k + 5)),
        v: rnd(seed, k + 6), dz: rnd(seed, k + 7)               // dz = 远近：0 最远，1 最近（模糊开着时才用）
      });
    }
    return out;
  }
  // 生命周期透明度：出生淡入、中段最亮、走远淡出
  const lifeA = u => Math.pow(Math.sin(Math.PI * clamp(u, 0, 1)), 1.3);
  // 画一个粒子（A = 透明度，grow = 随寿命长大，sk = 额外的大小倍数）
  function paint(ctx, kind, p, A, grow, base, col, t){
    ctx.save(); ctx.translate(p.x, p.y);
    if (kind === 'cube'){
      // 等轴立方体：顶面最亮、左面次之、右面最暗，整体慢慢转
      const s = base * 0.075 * p.s * grow;
      ctx.rotate(p.rot * 0.35);
      const h = s * 0.5, w = s * 0.866;
      const face = (pts, a) => { ctx.beginPath(); pts.forEach(([x, y], j) => j ? ctx.lineTo(x, y) : ctx.moveTo(x, y)); ctx.closePath(); ctx.fillStyle = col(a); ctx.fill(); };
      face([[0, -s], [w, -h], [0, 0], [-w, -h]], A * 0.85);
      face([[-w, -h], [0, 0], [0, s], [-w, h]], A * 0.5);
      face([[w, -h], [w, h], [0, s], [0, 0]], A * 0.28);
    } else if (kind === 'prism'){
      // 半透明三角 / 菱形：淡淡的面 + 一圈亮边
      const s = base * 0.085 * p.s * grow;
      ctx.rotate(p.rot);
      ctx.beginPath();
      if (p.v < 0.6){ for (let j = 0; j < 3; j++){ const q = -Math.PI / 2 + j * 2.0944; ctx[j ? 'lineTo' : 'moveTo'](Math.cos(q) * s, Math.sin(q) * s); } }
      else { ctx.moveTo(0, -s * 1.15); ctx.lineTo(s * 0.62, 0); ctx.lineTo(0, s * 1.15); ctx.lineTo(-s * 0.62, 0); }
      ctx.closePath();
      ctx.fillStyle = col(A * 0.22); ctx.fill();
      ctx.lineWidth = Math.max(1, s * 0.06); ctx.strokeStyle = col(A * 0.6); ctx.stroke();
    } else if (kind === 'smoke'){
      // 大团柔和的雾：越往外越大越淡
      const s = base * 0.42 * p.s * lerp(0.6, 1.8, p.u) * (grow / lerp(0.45, 1.25, p.u));
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, s);
      g.addColorStop(0, col(A * 0.2)); g.addColorStop(0.45, col(A * 0.09)); g.addColorStop(1, col(0));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s, 0, 6.2832); ctx.fill();
    } else {
      // 光点：小亮点 + 一圈柔光，忽明忽暗
      const s = base * 0.012 * p.s * lerp(0.7, 1.2, p.u) * (grow / lerp(0.45, 1.25, p.u));
      const tw = 0.65 + 0.35 * Math.sin(t * 5 * (0.6 + p.v) + p.v * 20);
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, s * 4);
      g.addColorStop(0, col(A * tw)); g.addColorStop(0.25, col(A * tw * 0.55)); g.addColorStop(1, col(0));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s * 4, 0, 6.2832); ctx.fill();
    }
    ctx.restore();
  }
  // 【区域B7】模糊用的小画布（每张卡两张：远、中），只在模糊开着时才建
  const layerOf = (cache, name, W, H, k) => {
    const L = cache[name] || (cache[name] = document.createElement('canvas'));
    const w = Math.max(1, Math.round(W * k)), h = Math.max(1, Math.round(H * k));
    if (L.width !== w || L.height !== h){ L.width = w; L.height = h; L.__ctx = L.getContext('2d'); }
    return L;
  };
  // o = { rgb:[r,g,b], op 0~1, amount / speed / size 倍数, cy 0~1（涌出中心的高度，默认 0.45），blur 0~1（0 = 关），cache（放小画布的对象） }
  M.draw = function (ctx, kind, t, W, H, seed, o){
    ctx.clearRect(0, 0, W, H);
    if (!KINDS.some(k => k[0] === kind) || !o.op) return;
    o = Object.assign({ cy: 0.45 }, o);
    const c = o.rgb, base = Math.min(W, H) * o.size;
    const col = a => `rgba(${c[0]},${c[1]},${c[2]},${a.toFixed(3)})`;
    const ps = particles(kind, t, W, H, seed, o);
    if (!(o.blur > 0)){
      // 模糊关着：和 v31.3 一模一样（逐像素回归靠它）
      ps.forEach(p => {
        const A = lifeA(p.u) * o.op, grow = lerp(0.45, 1.25, p.u);
        if (A < 0.004) return;
        paint(ctx, kind, p, A, grow, base, col, t);
      });
      return;
    }
    // 【区域B7】模糊开着：按远近分三层，从远到近画。
    // 远 / 中两层：画在缩小的画布上，再放大贴回主画布 —— 放大本身就把它变糊了（不用 CSS / canvas 的 blur 滤镜，那个太慢）；
    // 先缩到很小、再分两步放大，糊得更顺。近的一层直接画，最清楚。模糊越强，缩得越小。
    const cache = o.cache || {};
    const Q = ctx.getTransform ? ctx.getTransform().a : 1;          // 主画布的分辨率倍数
    const px = Math.min(W, H) * Q;                                  // 卡片短边有多少画布像素
    const kOf = r => clamp(1 / Math.max(1, r * px), 0.04, 1);       // r = 要糊开多大（占短边的比例）；缩小 1/k 倍再放大 ≈ 糊开 1/k 个像素
    const layers = [
      { pick: p => p.dz < 0.34, name: 'far', k: kOf(0.025 * o.blur) },
      { pick: p => p.dz >= 0.34 && p.dz < 0.67, name: 'mid', k: kOf(0.01 * o.blur) },
      { pick: p => p.dz >= 0.67, name: null }
    ];
    layers.forEach(Ly => {
      const mine = ps.filter(Ly.pick); if (!mine.length) return;
      let g = ctx, cv = null;
      if (Ly.name){
        cv = layerOf(cache, Ly.name, W * Q, H * Q, Ly.k);
        g = cv.__ctx; g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, cv.width, cv.height);
        g.setTransform(Q * Ly.k, 0, 0, Q * Ly.k, 0, 0);
      }
      mine.forEach(p => {
        const A = lifeA(p.u) * o.op * lerp(0.55, 1, p.dz), grow = lerp(0.45, 1.25, p.u) * lerp(0.65, 1.2, p.dz);
        if (A < 0.004) return;
        paint(g, kind, p, A, grow, base, col, t);
      });
      if (cv){
        // 两步放大：小画布 → 中间画布（4 倍）→ 主画布，比一步放大更柔和、没有方格感
        let src = cv;
        if (Ly.k < 0.2){
          const k2 = Math.min(1, Ly.k * 4), mid = layerOf(cache, Ly.name + '2', W * Q, H * Q, k2), mg = mid.__ctx;
          mg.setTransform(1, 0, 0, 1, 0, 0); mg.clearRect(0, 0, mid.width, mid.height); mg.imageSmoothingEnabled = true;
          mg.drawImage(cv, 0, 0, mid.width, mid.height); src = mid;
        }
        ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = true;
        ctx.drawImage(src, 0, 0, ctx.canvas.width, ctx.canvas.height); ctx.restore();
      }
    });
  };

  // ================= 【区域B2 标记卡片】 =================
  // opts: after = canvas 插在哪个子元素后面（不写：卡里有 <img>/<video>/[data-fxbg-under] 就插在最后一个的后面，否则插在最底下）
  //       kind = 这张卡单独用哪种（'none' = 这张不画）；seed = 随机种子（不写按第几张卡）；cy = 涌出中心高度 0~1；radius = 圆角（px，不写跟着卡片）
  //       w / h = 卡片的准确宽高（不写就量 clientWidth / clientHeight，取整数）
  M.perCard = false;                                              // 有卡片把自己的 cardbg 交过来（opts 里有 own）= 这个效果支持每张卡单独调
  M.mark = (host, opts) => {
    if (!host || !host.setAttribute) return host;
    if (opts && 'own' in opts) M.perCard = true;
    host.setAttribute('data-fxcardbg', '');
    host.__fxbgO = opts || {};
    return host;
  };

  // ================= 【区域B3 设置】 =================
  let P = {}, lastT = 0;
  M.defaults = null;
  M.state = p => {
    p = p || P || {};
    let d = M.defaults;
    try { d = typeof d === 'function' ? d(p) : d; } catch (e) { d = null; }
    let s = p.__cardbg;
    if (typeof s === 'string'){ try { s = JSON.parse(s); } catch (e) { s = null; } }
    const o = Object.assign({}, M.DEF, d || {}, s && typeof s === 'object' ? s : {});
    o.on = o.on === true || o.on === 'on';
    if (!(o.kind === 'mix' || KINDS.some(k => k[0] === o.kind))) o.kind = 'mix';
    if (!hexOk(o.color)) o.color = '#ffffff';
    o.amount = clamp(num(o.amount, 100), 10, 300); o.speed = clamp(num(o.speed, 100), 10, 400);
    o.size = clamp(num(o.size, 100), 20, 300); o.op = clamp(num(o.op, 70), 0, 100);
    o.blurOn = o.blurOn === true || o.blurOn === 'on'; o.blur = clamp(num(o.blur, 60), 0, 100);
    return o;
  };
  // 【区域B6】一张卡实际用的设置 = 统一设置 + 这张卡单独改过的项（own 关着就完全跟统一）
  const readOwn = v => { if (typeof v === 'string'){ try { v = JSON.parse(v); } catch (e) { v = null; } } return v && typeof v === 'object' ? v : null; };
  M.effective = (st, own) => {
    own = readOwn(own);
    if (!own || !own.own) return st;
    const o = Object.assign({}, st);
    OWN_KEYS.forEach(k => { if (own[k] !== undefined && own[k] !== null && own[k] !== '') o[k] = own[k]; });
    if (!(o.kind === 'none' || o.kind === 'mix' || KINDS.some(k => k[0] === o.kind))) o.kind = st.kind;
    if (!hexOk(o.color)) o.color = st.color;
    o.amount = clamp(num(o.amount, st.amount), 10, 300); o.speed = clamp(num(o.speed, st.speed), 10, 400);
    o.size = clamp(num(o.size, st.size), 20, 300); o.op = clamp(num(o.op, st.op), 0, 100);
    o.blurOn = o.blurOn === true || o.blurOn === 'on'; o.blur = clamp(num(o.blur, st.blur), 0, 100);
    return o;
  };
  M.write = patch => { P.__cardbg = Object.assign(M.state(P), patch); };   // 存完整的一份，旧工程的默认值也一起定下来

  // ================= 【区域B4 每帧】 =================
  const live = new Set();
  const kill = h => { if (h.__fxbgCv){ h.__fxbgCv.remove(); h.__fxbgCv = null; } live.delete(h); };
  function canvasFor(h, i, wantQ){
    const O = h.__fxbgO || {};
    const W = O.w > 0 ? +O.w : h.clientWidth, H = O.h > 0 ? +O.h : h.clientHeight;   // 效果知道卡片的准确大小（带小数）就传 w / h
    if (!(W > 0 && H > 0)) return null;
    let cv = h.__fxbgCv;
    const Q = Math.min(wantQ, clamp(2400 / Math.max(W, H), 1, 2));   // 分辨率倍数（见 frameAt 里怎么定）；特别大的卡少一点，省内存
    if (cv && cv.isConnected && cv.parentNode === (cv.__ref || h) && cv.__W === W && cv.__H === H && cv.__Q === Q) return cv;
    if (cv) cv.remove();
    const o = h.__fxbgO || {};
    cv = document.createElement('canvas'); cv.className = 'fxcbg';
    cv.width = Math.round(W * Q); cv.height = Math.round(H * Q); cv.__W = W; cv.__H = H; cv.__Q = Q;
    // 圆角：卡片自己已经裁了（overflow 不是 visible）就不再加，免得多一层裁剪；没裁的跟着卡片的圆角
    const clipped = getComputedStyle(h).overflow !== 'visible';
    cv.style.cssText = `position:absolute;left:0;top:0;width:${W.toFixed(1)}px;height:${H.toFixed(1)}px;pointer-events:none;display:block;`
      + (o.radius != null ? `border-radius:${o.radius}px` : clipped ? '' : 'border-radius:inherit');
    let after = o.after;
    if (!(after && after.parentNode === h)){
      const ks = [...h.children].filter(c => c.tagName === 'IMG' || c.tagName === 'VIDEO' || (c.hasAttribute && c.hasAttribute('data-fxbg-under')));
      after = ks.length ? ks[ks.length - 1] : null;
    }
    let parent = h;
    if (after){
      after.after(cv);
      const st = after.style;                                     // 跟着底色那一层的遮罩走（「空着 + 导出透明」挖的洞）
      if (st && (st.maskImage || st.webkitMaskImage)) cv.style.cssText += ';' + ['mask', '-webkit-mask'].map(k => st.getPropertyValue(k) ? `${k}:${st.getPropertyValue(k)}` : '').filter(Boolean).join(';');
    } else {
      // 没有照片 / 视频、也没指定插哪：画在「底色」上面、文字下面。
      // 很多卡的底色画在一个铺满整张卡的子元素上（公共卡片的 .fxc-txt / .fxc-ph、发牌展开的 .txt / .ph……），那就放进它里面；
      // 放的方式：那一层设 isolation:isolate（自成一层），canvas 用 z-index:-1 → 正好在这一层的底色之上、它里面的字之下。
      const cover = [...h.children].find(c => {
        if (/^(IMG|VIDEO|CANVAS|SVG)$/i.test(c.tagName)) return false;
        const cs = getComputedStyle(c);
        if (cs.position !== 'absolute' || c.offsetWidth < W - 2 || c.offsetHeight < H - 2) return false;
        const bg = cs.backgroundColor.match(/[\d.]+/g);
        return cs.backgroundImage !== 'none' || (bg && (bg.length < 4 || +bg[3] > 0.5));
      });
      parent = cover || h;
      parent.style.isolation = 'isolate';
      cv.style.zIndex = '-1';
      parent.prepend(cv);
    }
    cv.__ref = parent;
    cv.__ctx = cv.getContext('2d');
    h.__fxbgCv = cv; live.add(h);
    return cv;
  }
  M.frameAt = t => {
    const st = M.state(P);
    if (!st.on){ if (live.size) [...live].forEach(kill); return; }
    [...live].forEach(h => { if (!h.isConnected) live.delete(h); });
    const hosts = document.querySelectorAll('[data-fxcardbg]');
    // 分辨率（量过：容器里每帧的大头就是画布有多大）：卡少（≤ 4 张）用 2 倍，最清楚；5~8 张 1.5 倍；更多张 1 倍；
    // 这张卡开了模糊也用 1 倍（远处本来就糊，近处 1 倍在 1080p 下照样清楚）。粒子群那种几十张卡的，2 倍会卡一半。
    const nQ = hosts.length <= 4 ? 2 : hosts.length <= 8 ? 1.5 : 1;
    hosts.forEach((h, i) => {
      const o = h.__fxbgO || {};
      const e = M.effective(st, o.own);                             // 【区域B6】这张卡自己的设置
      const base = { rgb: rgbOf(e.color), op: e.op / 100, amount: e.amount / 100, speed: e.speed / 100, size: e.size / 100, blur: e.blurOn ? e.blur / 100 : 0 };
      const ownKind = readOwn(o.own) && readOwn(o.own).own && readOwn(o.own).kind;
      let kind = ownKind || o.kind || e.kind;
      if (kind === 'mix') kind = KINDS[(o.index != null ? o.index : i) % KINDS.length][0];
      const k = h.__fxbgK == null ? 1 : +h.__fxbgK;
      const cv = canvasFor(h, i, e.blurOn ? 1 : nQ); if (!cv) return;
      const ctx = cv.__ctx;
      ctx.setTransform(cv.__Q, 0, 0, cv.__Q, 0, 0);
      if (kind === 'none' || !(k > 0.001) || !(base.op > 0)){ if (cv.__drawn){ ctx.clearRect(0, 0, cv.__W, cv.__H); cv.__drawn = false; } return; }
      M.draw(ctx, kind, t, cv.__W, cv.__H, o.seed != null ? o.seed : 101 + i * 37, Object.assign({}, base, { op: base.op * k, cy: o.cy != null ? o.cy : 0.45, cache: cv.__lay || (cv.__lay = {}) }));
      cv.__drawn = true;
    });
  };

  function wrap(){
    const oi = window.init, or = window.renderAt;
    if (typeof oi !== 'function' || typeof or !== 'function' || or.__fxbg) return;
    window.init = function (p){
      P = p || {};
      [...live].forEach(kill);                                    // 重新生成画面：旧的 canvas 跟着旧卡片一起丢掉
      const r = oi.apply(this, arguments);
      setTimeout(() => setTimeout(autoMount, 0), 0);              // 等工作台把参数面板分好组再放（view-controls.js 也是下一拍）
      return r;
    };
    const nr = function (t){
      const r = or.apply(this, arguments);
      lastT = Math.max(0, +t || 0);
      try { M.frameAt(lastT); } catch (e) { console.error(e); }
      return r;
    };
    nr.__fxbg = true;
    window.renderAt = nr;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wrap); else setTimeout(wrap, 0);

  // ================= 【区域B5 面板】 =================
  M.manual = false;
  let ED = null;
  const parentDoc = () => { try { if (window.parent === window) return null; return { pw: window.parent, pd: window.parent.document }; } catch (e) { return null; } };
  const needSkin = () => window.FXSkin ? Promise.resolve() : new Promise(res => {
    const s = document.createElement('script'); s.src = SRC.replace(/fx-cardbg\.js(\?.*)?$/, 'fx-skin.js');
    s.onload = s.onerror = () => res(); document.head.appendChild(s);
  });
  function autoMount(){
    if (M.manual) return;
    const pp = parentDoc(); if (!pp) return;
    const box = pp.pd.getElementById('params'); if (!box) return;
    if (!document.querySelector('[data-fxcardbg]')) return;     // 这个效果里没有卡片：不放面板
    if (ED && box.contains(ED.el)){ ED.refresh(); return; }
    needSkin().then(() => {
      if (!window.FXSkin || (ED && box.contains(ED.el))) return;
      ED = M.editor(pp);
      const num = box.querySelector(':scope > .fxg[data-k="num"]'), clr = box.querySelector(':scope > .fxcolor');
      if (num) num.before(ED.el); else if (clr) clr.before(ED.el); else box.appendChild(ED.el);
    });
  }

  const COLS = [{ c: ['#ffffff'], name: '白' }, { c: ['#f3d89a'], name: '金' }, { c: ['#bfe6ff'], name: '冰蓝' }, { c: ['#ffd1e6'], name: '粉' }, { c: ['#c8f3e3'], name: '薄荷' }];
  // o = { pd, pw, perCard（true = 每张卡在效果自己的面板里选样式，这里不显示「样式」那一排） }
  M.editor = o => {
    const pd = o.pd, pw = o.pw, SK = window.FXSkin;
    SK.injectStyle(pd);
    if (!pd.getElementById('fcb-style')){
      const s = pd.createElement('style'); s.id = 'fcb-style';
      s.textContent = `
html body #params .fcb{padding:0!important}
html body #params .fcb .fcb-h{display:flex!important;align-items:center!important;gap:8px!important;padding:11px!important;cursor:pointer!important;user-select:none!important}
html body #params .fcb .fcb-h b{color:#ddd!important;font-size:12.5px!important;font-weight:600!important;letter-spacing:.04em!important;white-space:nowrap!important}
html body #params .fcb .fcb-h:hover b{color:#f28c0f!important}
html body #params .fcb .fcb-h i{font-style:normal!important;color:#f28c0f!important;display:inline-block!important;transition:transform .15s!important}
html body #params .fcb.off .fcb-h i{transform:rotate(-90deg)!important}
html body #params .fcb .fcb-h .stc-seg{margin:0 0 0 auto!important;flex:none!important;width:auto!important}
html body #params .fcb .fcb-h .stc-seg button{padding:0 12px!important;height:24px!important;min-width:0!important}
html body #params .fcb .fcb-b{padding:0 11px 11px!important}
html body #params .fcb.off .fcb-b{display:none!important}
html body #params .fcb .fcb-b>label{margin-top:12px!important}
html body #params .fcb .fcb-dim{opacity:.45!important}
html body #params .fcb .fcb-blur label.fcb-hide,html body #params .fcb-card .fcb-blur label.fcb-hide{display:none!important}`;
      pd.head.appendChild(s);
    }
    const mk = SK.mk(pd);
    const el = mk('div', 'stc'); el.dataset.fxContent = '1';          // 外面一层 .stc：fx-skin 的面板样式都写在 .stc 下面
    const card = mk('div', 'stc-b fcb'); el.appendChild(card);
    const FOLD = 'fx-cardbg-fold';
    let open = false; try { open = pw.localStorage.getItem(FOLD) === '1'; } catch (e) {}
    card.classList.toggle('off', !open);
    const head = mk('div', 'fcb-h', '<i>▾</i><b>卡片背景动效</b>');
    const sw = mk('div', 'stc-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    head.appendChild(sw);
    head.onclick = e => { if (sw.contains(e.target)) return; card.classList.toggle('off'); try { pw.localStorage.setItem(FOLD, card.classList.contains('off') ? '0' : '1'); } catch (er) {} };
    const body = mk('div', 'fcb-b');
    card.append(head, body);

    const dirty = () => { try { pw.markDirty && pw.markDirty(); } catch (e) {} };
    const hist = () => { try { pw.histSoon && pw.histSoon(); } catch (e) {} };
    const redraw = () => { try { window.renderAt(lastT); } catch (e) {} };
    const set = (patch, h) => { M.write(patch); dirty(); if (h !== false) hist(); redraw(); refresh(); };
    sw.querySelectorAll('button').forEach(b => b.onclick = () => {
      const on = b.dataset.v === '1';
      set({ on });
      if (on && card.classList.contains('off')){ card.classList.remove('off'); try { pw.localStorage.setItem(FOLD, '1'); } catch (e) {} }
    });

    // 样式
    let kindRow = null;
    if (!o.perCard){
      const kb = mk('div', '', '<div class="stc-t"><b>样式</b><span>轮流 = 每张卡换一种</span></div>');
      kindRow = mk('div', 'stc-seg', KINDS.concat([['mix', '轮流']]).map(([v, n]) => `<button type="button" data-v="${v}">${n}</button>`).join(''));
      kindRow.querySelectorAll('button').forEach(b => b.onclick = () => set({ kind: b.dataset.v }));
      kb.appendChild(kindRow); body.appendChild(kb);
    } else body.appendChild(mk('div', 'stc-note', o.perCardNote || '每张卡用哪种图形，在上面「卡片」里每张单独选。'));

    // 粒子颜色（规则 24）
    const px = {};
    Object.defineProperty(px, 'cFx', { get: () => M.state(P).color, set: v => M.write({ color: v }) });
    const cb = SK.colorBlock({
      pd, pw, P: px, field: () => null, bare: true, title: '粒子颜色', sub: '立方体 / 棱形 / 烟雾 / 光点', apply: () => { dirty(); hist(); redraw(); refresh(); },
      keys: [{ key: 'cFx', name: '粒子颜色', tip: '背景里那些小图形的颜色', def: '#ffffff' }],
      presets: COLS, ls: 'fx-my-colors-fx'
    });
    const cw = mk('div', 'fbc-sub'); cw.style.cssText = 'margin-top:12px;padding-top:10px;border-top:1px solid #222';
    cw.appendChild(cb.el); body.appendChild(cw);

    // 数量 / 速度 / 大小 / 透明度：和工作台「数值调节」一样的数字框 + 滑杆
    const SL = [['amount', '粒子数量（%）', 10, 300, 5], ['speed', '粒子速度（%）', 10, 400, 5], ['size', '粒子大小（%）', 20, 300, 5], ['op', '粒子透明度（%）', 0, 100, 1]];
    const ins = {};
    SL.forEach(([k, label, mn, mx, step]) => {
      const lab = pd.createElement('label');
      const row = mk('div', 'fxr-row'); const sp = pd.createElement('span'); sp.textContent = label;
      const inp = pd.createElement('input'); inp.type = 'number'; inp.min = mn; inp.max = mx; inp.step = step;
      row.append(sp, inp);
      const rg = pd.createElement('input'); rg.type = 'range'; rg.className = 'fxr-range'; rg.min = mn; rg.max = mx; rg.step = step;
      lab.append(row, rg); body.appendChild(lab);
      const put = (v, h) => { if (v === '' || !Number.isFinite(+v)) return; set({ [k]: clamp(+v, mn, mx) }, h); };
      inp.oninput = () => { rg.value = inp.value; put(inp.value, false); };
      inp.onchange = () => { hist(); refresh(); };
      rg.oninput = () => { inp.value = rg.value; put(rg.value, false); };
      rg.onchange = () => hist();
      ins[k] = [inp, rg];
    });

    // 【区域B7】模糊：越远越糊、越近越清楚
    const bz = blurRows(pd, mk, () => M.state(P), (patch, h) => set(patch, h));
    body.appendChild(bz.el);

    function refresh(){
      const st = M.state(P);
      bz.refresh();
      refreshCards();
      sw.querySelectorAll('button').forEach(b => b.classList.toggle('on', (b.dataset.v === '1') === st.on));
      body.classList.toggle('fcb-dim', !st.on);
      if (kindRow) kindRow.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === st.kind));
      Object.keys(ins).forEach(k => { const [a, b] = ins[k]; if (pd.activeElement !== a) a.value = st[k]; b.value = st[k]; });
      cb.refresh();
    }
    refresh();
    return { el, refresh };
  };
  // ---------- 数字框 + 滑杆（和工作台「数值调节」同一个样子） ----------
  function sliderRow(pd, mk, label, mn, mx, step, get, put, done){
    const lab = pd.createElement('label');
    const row = mk('div', 'fxr-row'); const sp = pd.createElement('span'); sp.textContent = label;
    const inp = pd.createElement('input'); inp.type = 'number'; inp.min = mn; inp.max = mx; inp.step = step;
    row.append(sp, inp);
    const rg = pd.createElement('input'); rg.type = 'range'; rg.className = 'fxr-range'; rg.min = mn; rg.max = mx; rg.step = step;
    lab.append(row, rg);
    const go = v => { if (v === '' || !Number.isFinite(+v)) return; put(clamp(+v, mn, mx)); };
    inp.oninput = () => { rg.value = inp.value; go(inp.value); };
    inp.onchange = () => done && done();
    rg.oninput = () => { inp.value = rg.value; go(rg.value); };
    rg.onchange = () => done && done();
    return { el: lab, refresh: () => { const v = get(); if (pd.activeElement !== inp) inp.value = v; rg.value = v; } };
  }
  // 【区域B7】模糊那一小块：开 / 关 + 模糊强度
  function blurRows(pd, mk, get, put){
    const el = mk('div', 'fcb-blur');
    el.innerHTML = '<div class="stc-t"><b>模糊</b><span>越远越糊，越近越清楚</span></div>';
    const seg = mk('div', 'stc-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    seg.querySelectorAll('button').forEach(b => b.onclick = () => put({ blurOn: b.dataset.v === '1' }));
    const sl = sliderRow(pd, mk, '模糊强度（%）', 0, 100, 1, () => get().blur, v => put({ blur: v }, false), () => put({}, true));
    el.append(seg, sl.el);
    return { el, refresh: () => { const st = get(); seg.querySelectorAll('button').forEach(b => b.classList.toggle('on', (b.dataset.v === '1') === st.blurOn)); sl.el.classList.toggle('fcb-hide', !st.blurOn); sl.refresh(); } };
  }

  // ================= 【区域B6】每张卡底部的「单独调整背景动效」 =================
  // o = { pd, pw, get: () => 这张卡的 cardbg, set: 新的 cardbg => 存回卡片数据并重画, key: 记住展开 / 收起用的名字 }
  const CARDS = new Set();
  const OPEN = new Set();
  function refreshCards(){ [...CARDS].forEach(c => { if (!c.el.isConnected) CARDS.delete(c); else c.refresh(); }); }
  M.refreshCards = refreshCards;
  M.cardBlock = o => {
    const pd = o.pd, pw = o.pw;
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    injectCardStyle(pd);
    const el = mk('div', 'fcb-card');
    const head = mk('div', 'fcb-ch', '<i>▾</i><b>单独调整背景动效</b>');
    const seg = mk('div', 'fcb-cseg', '<button type="button" data-v="0">跟随统一</button><button type="button" data-v="1">单独设置</button>');
    head.appendChild(seg);
    const body = mk('div', 'fcb-cb');
    el.append(head, body);
    const key = o.key || null;
    if (!(key && OPEN.has(key))) el.classList.add('off');
    head.onclick = e => { if (seg.contains(e.target)) return; el.classList.toggle('off'); if (key){ if (el.classList.contains('off')) OPEN.delete(key); else OPEN.add(key); } };
    const own = () => readOwn(o.get()) || {};
    const glob = () => M.state(P);
    const eff = () => M.effective(glob(), Object.assign({}, own(), { own: true }));
    let T = 0;
    const save = (patch, now) => {
      const v = Object.assign({}, own(), patch);
      Object.keys(v).forEach(k => { if (v[k] === undefined) delete v[k]; });
      clearTimeout(T);
      const go = () => { o.set(v); try { pw.markDirty && pw.markDirty(); pw.histSoon && pw.histSoon(); } catch (e) {} };
      if (now === false) T = setTimeout(go, 250); else go();
      refreshBody(v);
    };
    seg.querySelectorAll('button').forEach(b => b.onclick = () => {
      const on = b.dataset.v === '1';
      save({ own: on });
      if (on && el.classList.contains('off')){ el.classList.remove('off'); if (key) OPEN.add(key); }
    });
    // 内容在第一次需要时再建（颜色块要 fx-skin.js，没有就先加载）
    let built = null;
    function build(){
      if (built || !window.FXSkin) return;
      const SK = window.FXSkin; SK.injectStyle(pd);
      const wrap = mk('div', 'stc');                                 // fx-skin 的面板样式都写在 .stc 下面
      const kb = mk('div', '', '<div class="stc-t"><b>样式</b><span>这张卡用哪种</span></div>');
      const kr = mk('div', 'stc-seg', [['', '跟随']].concat(KINDS, [['none', '无']]).map(([v, n]) => `<button type="button" data-v="${v}">${n}</button>`).join(''));
      kr.querySelectorAll('button').forEach(b => b.onclick = () => save({ kind: b.dataset.v || undefined }));
      kb.appendChild(kr);
      const px = {};
      Object.defineProperty(px, 'cFx', { get: () => eff().color, set: v => save({ color: v }) });
      const cb = SK.colorBlock({ pd, pw, P: px, field: () => null, bare: true, title: '粒子颜色', sub: '这张卡自己的颜色', apply: () => {},
        keys: [{ key: 'cFx', name: '粒子颜色', tip: '这张卡背景里小图形的颜色', def: '#ffffff' }], presets: COLS, ls: 'fx-my-colors-fx' });
      const cw = mk('div', ''); cw.style.cssText = 'margin-top:10px'; cw.appendChild(cb.el);
      const sls = [['amount', '粒子数量（%）', 10, 300, 5], ['speed', '粒子速度（%）', 10, 400, 5], ['size', '粒子大小（%）', 20, 300, 5], ['op', '粒子透明度（%）', 0, 100, 1]]
        .map(([k, l, a, b, st]) => sliderRow(pd, mk, l, a, b, st, () => eff()[k], v => save({ [k]: v }, false), () => {}));
      const bz = blurRows(pd, mk, eff, (patch, h) => { if (Object.keys(patch).length) save(patch, h); });
      const back = mk('button', 'stc-btn', '恢复跟随统一'); back.type = 'button';
      back.onclick = () => { o.set({ own: false }); try { pw.markDirty && pw.markDirty(); pw.histSoon && pw.histSoon(); } catch (e) {} refreshBody({ own: false }); };   // 单独改过的都清掉
      wrap.append(kb, cw, ...sls.map(x => x.el), bz.el, back);
      body.appendChild(wrap);
      built = { kr, cb, sls, bz };
    }
    function refreshBody(v){
      v = v || own();
      seg.querySelectorAll('button').forEach(b => b.classList.toggle('on', (b.dataset.v === '1') === !!v.own));
      body.classList.toggle('fcb-follow', !v.own);
      if (!v.own){ body.dataset.note = '现在跟着上面的统一设置走。点「单独设置」就能单独改这一张。'; }
      if (!built){ if (window.FXSkin) build(); else needSkin().then(() => { build(); refreshBody(); }); }
      if (built){
        built.kr.querySelectorAll('button').forEach(b => b.classList.toggle('on', (b.dataset.v || '') === (v.kind || '')));
        built.cb.refresh(); built.sls.forEach(x => x.refresh()); built.bz.refresh();
      }
    }
    const api = { el, refresh: () => { el.classList.toggle('fcb-hide', !M.state(P).on); refreshBody(); } };   // 总开关关着：整块藏起来
    CARDS.add(api);
    api.refresh();
    return api;
  };
  function injectCardStyle(pd){
    if (pd.getElementById('fcb-card-style')) return;
    const s = pd.createElement('style'); s.id = 'fcb-card-style';
    s.textContent = `
html body #params .fcb-card{display:block!important;margin:10px 0 0!important;border:1px solid #2a2a2a!important;border-radius:8px!important;background:#101010!important}
html body #params .fcb-card .fcb-ch{display:flex!important;align-items:center!important;gap:8px!important;padding:8px 10px!important;cursor:pointer!important;user-select:none!important}
html body #params .fcb-card .fcb-ch b{color:#ccc!important;font-size:12px!important;font-weight:600!important;white-space:nowrap!important}
html body #params .fcb-card .fcb-ch:hover b{color:#f28c0f!important}
html body #params .fcb-card .fcb-ch i{font-style:normal!important;color:#f28c0f!important;display:inline-block!important;transition:transform .15s!important}
html body #params .fcb-card.off .fcb-ch i{transform:rotate(-90deg)!important}
html body #params .fcb-card .fcb-cseg{display:flex!important;margin:0 0 0 auto!important;flex:none!important;background:#1d1d1d!important;border:1px solid #333!important;border-radius:6px!important;overflow:hidden!important}
html body #params .fcb-card .fcb-cseg button{display:block!important;width:auto!important;height:24px!important;min-width:0!important;margin:0!important;padding:0 9px!important;background:none!important;border:0!important;color:#999!important;font-size:11.5px!important;cursor:pointer!important;font-family:inherit!important;white-space:nowrap!important}
html body #params .fcb-card .fcb-cseg button.on{background:#f28c0f!important;color:#111!important}
html body #params .fcb-card .fcb-cb{padding:0 10px 10px!important}
html body #params .fcb-card.off .fcb-cb{display:none!important}
html body #params .fcb-card .fcb-cb.fcb-follow .stc{display:none!important}
html body #params .fcb-card .fcb-cb.fcb-follow::before{content:attr(data-note);display:block;font-size:11.5px;color:#777;line-height:1.6}
html body #params .fcb-card .fcb-cb label,html body #params .fcb .fcb-blur label{display:block!important;margin-top:10px!important}
html body #params .fcb .fcb-blur{margin-top:14px!important;padding-top:10px!important;border-top:1px solid #222!important}
html body #params .fcb-card .fcb-blur{margin-top:12px!important}
html body #params .fcb-card.fcb-hide,html body #params .fcb .fcb-blur label.fcb-hide,html body #params .fcb-card .fcb-blur label.fcb-hide{display:none!important}
html body #params .fcb-card .fcb-ch{flex-wrap:wrap!important}
html body #params .fcb-card .fcb-cseg{flex:1 0 100%!important;margin:2px 0 0!important}
html body #params .fcb-card .fcb-cseg button{flex:1 1 0!important;width:auto!important}
html body #params .fcb-card .stc-seg button{padding:0 2px!important;min-width:0!important;font-size:11.5px!important;white-space:nowrap!important}`;
    pd.head.appendChild(s);
  }
})();
