/* ===========================================================================
   fx-highlight.js —— 荧光笔标注（工作台公共模块，2026-11-25 新增，FXHighlight）
   ---------------------------------------------------------------------------
   做什么：在图片 / 截图上「画重点」的那一套，以后要荧光笔、下划线标注的效果都用这一份：
     · 一条荧光笔 = 一个裁切框 + 里面一块往右推的颜色块（每帧只写 transform）；颜色块右边缘带一点羽化，像笔头；
     · 好几条按顺序一条接一条划，每条用的时间按长短分（长的多、短的少），速度看起来是匀的；
     · 吸附文字行：用户随手拖一个框，读图片像素找出框里有几行字，拆成每行一条、上下贴着字、左右收到字的头尾；
       拖过好几行时像选文字一样：第一行从框的左边划到行尾，中间整行，最后一行从行首划到框的右边。
   谁在用：图片重点标注（image-highlight）。

   区域地图（想改哪里，直接说「区域Hx 怎么改」）
   【区域H1 颜色】   COLORS 荧光笔预设色（橙默认）；以后要并进 fx-palettes.js 时整组搬过去
   【区域H2 一条笔】 make(doc) 建一条；place(o, 框, 样式) 摆位置（marker 整行 / under 下划线）；set(o, k) 划到几成（0~1）
   【区域H3 时间表】 plan(框们) → 每条在总时长里从几成开始、到几成结束；at(plan, i, k) → 第 i 条划到几成
   【区域H4 吸附】   snap(图片地址, 框, { invert, under }) → Promise<{ lines:[框...], dark }>；读不了像素 / 框里没字 → null
                     bgDark(图片地址, …) → 这张图是不是深色底（「自动」混合方式用：浅底正片叠底，深底滤色）
   框一律用「占图片宽高的比例」{ x, y, w, h }（0~1），图片换大小、卡片缩放都跟着走。
   =========================================================================== */
(function () {
  const H = window.FXHighlight = window.FXHighlight || {};

  // ================= 【区域H1 颜色】 =================
  H.COLORS = [
    { c: ['#f28c0f'], name: '橙（默认）' },
    { c: ['#ffd84a'], name: '荧光黄' },
    { c: ['#86ef6c'], name: '荧光绿' },
    { c: ['#ff7fb8'], name: '荧光粉' },
    { c: ['#4f86e8'], name: '蓝（深色底上像参考图）' },
    { c: ['#a98bff'], name: '紫' },
    { c: ['#ff5a4e'], name: '红' },
    { c: ['#ffffff'], name: '白' }
  ];
  H.BLENDS = { multiply: 'multiply', screen: 'screen', normal: 'normal' };

  // ================= 【区域H2 一条笔】 =================
  const FEATHER = 0.6;                       // 笔头羽化 = 行高的几倍
  H.css = `.fxhl{position:absolute;overflow:hidden;pointer-events:none}
.fxhl>i{position:absolute;left:0;top:0;bottom:0;display:block;will-change:transform}`;
  H.injectCss = doc => {
    if (doc.getElementById('fxhl-css')) return;
    const s = doc.createElement('style'); s.id = 'fxhl-css'; s.textContent = H.css; doc.head.appendChild(s);
  };
  H.make = doc => {
    const el = doc.createElement('div'); el.className = 'fxhl';
    const i = doc.createElement('i'); el.appendChild(i);
    return { el, i, w: 0, k: -1 };
  };
  // r = { x, y, w, h } 像素（父元素坐标）；st = { shape: 'marker' | 'under', color, blend, op }
  H.place = (o, r, st) => {
    const sh = st.shape === 'under' ? 'under' : 'marker';
    const y = sh === 'under' ? r.y + r.h * 0.8 : r.y, h = sh === 'under' ? Math.max(3, r.h * 0.16) : r.h;
    const F = Math.max(4, Math.min(r.w * 0.3, r.h * FEATHER));
    const s = o.el.style;
    s.left = r.x + 'px'; s.top = y + 'px'; s.width = r.w + 'px'; s.height = h + 'px';
    s.borderRadius = (sh === 'under' ? h / 2 : Math.min(h * 0.22, 14)) + 'px';
    s.mixBlendMode = H.BLENDS[st.blend] || 'normal';
    s.opacity = st.op == null ? 1 : st.op;
    const is = o.i.style;
    is.width = r.w + F + 'px';
    is.background = `linear-gradient(90deg,${st.color} 0,${st.color} calc(100% - ${F}px),transparent 100%)`;
    o.w = r.w + F; o.k = -1;
  };
  H.set = (o, k) => {
    k = Math.max(0, Math.min(1, k));
    if (Math.abs(k - o.k) < 1e-4) return;
    o.k = k;
    o.el.style.visibility = k <= 0 ? 'hidden' : '';
    o.i.style.transform = `translateX(${(-(1 - k) * o.w).toFixed(2)}px)`;
  };

  // ================= 【区域H3 时间表】 =================
  // 按宽度分时间：每条 [a, b]（总进度 0~1 里的一段）
  H.plan = rs => {
    const ws = rs.map(r => Math.max(0.02, +r.w || 0)), sum = ws.reduce((a, b) => a + b, 0) || 1;
    let a = 0; return ws.map(w => { const b = a + w / sum, o = { a, b }; a = b; return o; });
  };
  const ease = u => u * u * (3 - 2 * u);
  H.at = (pl, i, k) => {
    const p = pl[i]; if (!p) return 0;
    const u = Math.max(0, Math.min(1, (k - p.a) / Math.max(1e-6, p.b - p.a)));
    return 0.65 * u + 0.35 * ease(u);        // 大体匀速，头尾稍微缓一点
  };

  // ================= 【区域H4 吸附】 =================
  const cache = new Map();
  const load = src => {
    if (cache.has(src)) return cache.get(src);
    const p = new Promise((res, rej) => {
      const im = new Image();
      if (/^https?:/i.test(src) && !src.startsWith(location.origin)) im.crossOrigin = 'anonymous';
      im.onload = () => res(im); im.onerror = () => rej(new Error('图片读不出来')); im.src = src;
    });
    cache.set(src, p); p.catch(() => cache.delete(src));
    return p;
  };
  // 把图片画到画布上，返回 { W, H, L: 亮度数组 0~255 }（长边最多 2000，够认字了）
  const pixels = async (src, o) => {
    const im = await load(src);
    const nw = im.naturalWidth || im.width || 1000, nh = im.naturalHeight || im.height || 600;
    const k = Math.min(1, 2000 / Math.max(nw, nh));
    const W = Math.max(1, Math.round(nw * k)), Hh = Math.max(1, Math.round(nh * k));
    const cv = document.createElement('canvas'); cv.width = W; cv.height = Hh;
    const cx = cv.getContext('2d', { willReadFrequently: true });
    cx.fillStyle = o.under || '#000'; cx.fillRect(0, 0, W, Hh);   // 透明的地方按卡片底色算
    cx.drawImage(im, 0, 0, W, Hh);
    let d; try { d = cx.getImageData(0, 0, W, Hh).data; } catch (e) { return null; }
    const L = new Uint8Array(W * Hh);
    for (let i = 0, j = 0; j < L.length; i += 4, j++) { const v = (d[i] * 54 + d[i + 1] * 183 + d[i + 2] * 19) >> 8; L[j] = o.invert ? 255 - v : v; }
    return { W, H: Hh, L };
  };
  // 底色 = 区域里最多的那档亮度
  const bgOf = (g, x0, y0, x1, y1) => {
    const hist = new Uint32Array(32), st = Math.max(1, Math.floor((x1 - x0) * (y1 - y0) / 60000));
    let n = 0;
    for (let y = y0; y < y1; y++) for (let x = x0 + (y % st); x < x1; x += st) { hist[g.L[y * g.W + x] >> 3]++; n++; }
    let b = 0; for (let i = 1; i < 32; i++) if (hist[i] > hist[b]) b = i;
    return b * 8 + 4;
  };
  H.bgDark = async (src, o = {}) => {
    try { const g = await pixels(src, o); if (!g) return null; return bgOf(g, 0, 0, g.W, g.H) < 128; } catch (e) { return null; }
  };
  H.snap = async (src, box, o = {}) => {
    let g; try { g = await pixels(src, o); } catch (e) { return null; }
    if (!g) return null;
    const { W, L } = g, Hh = g.H;
    const cl = (v, a, b) => Math.max(a, Math.min(b, v));
    const X0 = cl(Math.floor(box.x * W), 0, W - 1), X1 = cl(Math.ceil((box.x + box.w) * W), X0 + 1, W);
    const Y0 = cl(Math.floor(box.y * Hh), 0, Hh - 1), Y1 = cl(Math.ceil((box.y + box.h) * Hh), Y0 + 1, Hh);
    const bg = bgOf(g, X0, Y0, X1, Y1), thr = 46;
    const ink = (x, y) => Math.abs(L[y * W + x] - bg) > thr;
    const rowInk = (y, a, b) => { let n = 0; for (let x = a; x < b; x++) if (ink(x, y)) n++; return n; };
    const minRow = Math.max(1, Math.round((X1 - X0) * 0.002));
    // 1) 框里每一行像素有没有字 → 连成一段段（= 一行行字）
    let bands = [], cur = null;
    for (let y = Y0; y < Y1; y++) {
      if (rowInk(y, X0, X1) >= minRow) { if (cur && y - cur.b <= 2) cur.b = y + 1; else { cur = { a: y, b: y + 1 }; bands.push(cur); } }
    }
    if (!bands.length) return null;
    const med = a => { const s = a.slice().sort((p, q) => p - q); return s[s.length >> 1]; };
    let mh = med(bands.map(b => b.b - b.a));
    // 汉字上下结构中间的小空隙：空隙比行高的 0.35 小就并成一行
    const merged = [];
    bands.forEach(b => { const p = merged[merged.length - 1]; if (p && b.a - p.b < mh * 0.35) p.b = b.b; else merged.push({ a: b.a, b: b.b }); });
    mh = med(merged.map(b => b.b - b.a));
    bands = merged.filter(b => b.b - b.a >= mh * 0.3);
    if (!bands.length) return null;
    // 2) 碰到框上下边的那行：往外接着找完整的字
    const fb = bands[0], lb = bands[bands.length - 1];
    if (fb.a <= Y0 + 1) while (fb.a > 0 && rowInk(fb.a - 1, X0, X1) >= minRow && lb.b - fb.a < 40 * mh) fb.a--;
    if (lb.b >= Y1 - 1) while (lb.b < Hh && rowInk(lb.b, X0, X1) >= minRow && lb.b - fb.a < 40 * mh) lb.b++;
    // 3) 每行左右：先找框里的字，拖过多行时往外接着找（空隙不超过 2.5 个行高）
    const cols = (b) => { const c = new Uint8Array(W); for (let y = b.a; y < b.b; y++) for (let x = 0; x < W; x++) if (ink(x, y)) c[x] = 1; return c; };
    const inside = (c, a, z) => { let s = -1, e = -1; for (let x = a; x < z; x++) if (c[x]) { if (s < 0) s = x; e = x + 1; } return s < 0 ? null : [s, e]; };
    const grow = (c, s, e, G) => {
      let gap = 0; for (let x = e; x < W; x++) { if (c[x]) { e = x + 1; gap = 0; } else if (++gap > G) break; }
      gap = 0; for (let x = s - 1; x >= 0; x--) { if (c[x]) { s = x; gap = 0; } else if (++gap > G) break; }
      return [s, e];
    };
    const n = bands.length, out = [];
    bands.forEach((b, i) => {
      const bh = b.b - b.a, c = cols(b), G = Math.max(6, bh * 2.5);
      const r0 = inside(c, X0, X1); if (!r0) return;
      let s = r0[0], e = r0[1];
      if (n > 1) {
        const [gs, ge] = grow(c, s, e, G);
        if (i === 0) e = ge; else if (i === n - 1) s = gs; else { s = gs; e = ge; }
      }
      if (e - s < bh * 0.4) return;
      const py = bh * 0.2, px = bh * 0.14;
      const x = Math.max(0, s - px), y = Math.max(0, b.a - py), x2 = Math.min(W, e + px), y2 = Math.min(Hh, b.b + py);
      out.push({ x: x / W, y: y / Hh, w: (x2 - x) / W, h: (y2 - y) / Hh });
    });
    if (!out.length) return null;
    return { lines: out, dark: bg < 128 };
  };
})();
