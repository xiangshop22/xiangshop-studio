/* ===========================================================================
   fx-pyramid.js —— 立体金字塔公共模块（FXPyramid，2026-11-18 新增，第一个用它的是「层叠金字塔」pyramid-stack）
   ---------------------------------------------------------------------------
   做什么：把「一座方底金字塔切成几层」算出来、画出来。站在一个角上斜着往下看（和参考图一样，看到左右两个侧面 + 顶面）。
           只管几何和每一块的样子；时间、编辑器、文字内容由效果自己管。以后别的效果要画立体台阶 / 金字塔，直接调它（规则 28）。

   区域地图（想改哪里，直接说「区域Yx 怎么改」）
   【区域Y1 图标库】   ICONS：一套线条小图标（科技、金融、军事、数据、隐私……），白色描边 SVG；iconSvg / iconUrl 换颜色
   【区域Y2 几何】     build(o)：n 层 + 塔尖，每层是一个「台」（下大上小），台阶宽度 / 层间距 / 俯视程度可调；
                      返回每一块四个角在屏幕上的位置（原点 = 底面中心，单位 = 屏幕像素）
   【区域Y3 实心台阶】 solid(pc, 颜色)：顶面 + 左侧面（亮一点）+ 右侧面（暗一点）+ 前沿高光线，返回 SVG 内容
   【区域Y4 透明剖面】 section(pc, …)：深色半透明的塔身 + 渐变粗描边（左边 → 右边换色）+ 每层底部一块发光地板
   【区域Y5 平面上放东西】plane(G, pc, 'top'|'floor', 缩进)：顶面 / 地板这块菱形在屏幕上的中心、边长、压扁比例
                      → 效果把一个 S×S 的方块 scaleY(压扁比例) + 菱形裁剪，图片、文字贴上去就是「平放在面上」
   【区域Y6 侧面上写字】face(pc, 'left'|'right')：侧面中间那条带子的方向和大小 → css matrix，字顺着侧面斜过去
   【区域Y7 落下动作】 enter(方式, k, 距离)：落下 / 升起 / 弹出 / 淡入，返回 { y, s, o }，效果只写 transform / opacity（规则 16）

   坐标约定：x 向右、y 向上、z 向屏幕外；从 (1,·,1) 那个角看过去。投影 X = (x − z)·√½，Y = −y·cos(俯视) + (x + z)·√½·sin(俯视)。
   每一块的四个角：l 左、f 前（离镜头最近，最低）、r 右、k 后；b = 底面那一圈，t = 顶面那一圈；塔尖的 t 四个角都在尖上。
   =========================================================================== */
(function () {
  if (window.FXPyramid) return;
  const Y = window.FXPyramid = {};
  const C45 = Math.SQRT1_2;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const f1 = v => (Math.round(v * 10) / 10).toString();
  Y.clamp = clamp;

  // ================= 【区域Y1 图标库】viewBox 0 0 48 48，描边线条 =================
  Y.ICONS = [
    ['chip', '芯片 · 科技', '<rect x="13" y="13" width="22" height="22" rx="3"/><rect x="19" y="19" width="10" height="10" rx="1.5"/><path d="M19 6v7M24 6v7M29 6v7M19 35v7M24 35v7M29 35v7M6 19h7M6 24h7M6 29h7M35 19h7M35 24h7M35 29h7"/>'],
    ['coin', '钱 · 金融', '<ellipse cx="24" cy="13" rx="14" ry="5.5"/><path d="M10 13v8c0 3 6.3 5.5 14 5.5s14-2.5 14-5.5v-8"/><path d="M10 21v8c0 3 6.3 5.5 14 5.5s14-2.5 14-5.5v-8"/><path d="M10 29v6c0 3 6.3 5.5 14 5.5s14-2.5 14-5.5v-6"/>'],
    ['shield', '盾牌 · 军事 / 安全', '<path d="M24 5l15 6v11c0 10-6.5 17-15 21C15.5 39 9 32 9 22V11z"/><path d="M17 23l5 5 9-10"/>'],
    ['data', '数据库 · 数据', '<ellipse cx="24" cy="11" rx="13" ry="5"/><path d="M11 11v26c0 2.8 5.8 5 13 5s13-2.2 13-5V11"/><path d="M11 20c0 2.8 5.8 5 13 5s13-2.2 13-5M11 29c0 2.8 5.8 5 13 5s13-2.2 13-5"/>'],
    ['lock', '锁 · 隐私', '<rect x="11" y="21" width="26" height="20" rx="3"/><path d="M16 21v-6a8 8 0 0 1 16 0v6"/><path d="M24 29v5"/>'],
    ['chat', '对话 · 沟通', '<path d="M8 12a4 4 0 0 1 4-4h24a4 4 0 0 1 4 4v15a4 4 0 0 1-4 4H20l-8 7v-7a4 4 0 0 1-4-4z"/><path d="M17 19.5h.1M24 19.5h.1M31 19.5h.1" stroke-width="4.5"/>'],
    ['cart', '购物车 · 消费', '<path d="M5 8h6l5 22h21l4-15H14"/><circle cx="19" cy="38" r="3"/><circle cx="34" cy="38" r="3"/>'],
    ['chart', '上涨 · 增长', '<path d="M7 40h34"/><path d="M11 32l9-9 7 6 12-14"/><path d="M33 15h6v6"/>'],
    ['folder', '文件夹 · 资料', '<path d="M6 13a3 3 0 0 1 3-3h10l4 5h16a3 3 0 0 1 3 3v19a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3z"/>'],
    ['globe', '地球 · 国际', '<circle cx="24" cy="24" r="17"/><path d="M7 24h34M24 7c5 5 7 11 7 17s-2 12-7 17c-5-5-7-11-7-17s2-12 7-17z"/>'],
    ['people', '人 · 人才 / 人口', '<circle cx="17" cy="16" r="6"/><circle cx="33" cy="18" r="5"/><path d="M6 40c0-7 5-12 11-12s11 5 11 12M28 40c0-6 3-10 7-10s7 4 7 10"/>'],
    ['energy', '闪电 · 能源', '<path d="M27 5L12 27h11l-3 16 16-23H25z"/>'],
    ['factory', '工厂 · 制造', '<path d="M6 40V22l10 6v-6l10 6v-6l10 6V10h6v30z"/><path d="M12 34h4M22 34h4M32 34h4"/>'],
    ['bulb', '灯泡 · 创新', '<path d="M17 30a12 12 0 1 1 14 0v5H17z"/><path d="M19 40h10M21 44h6"/>'],
    ['star', '星 · 核心', '<path d="M24 6l5.3 11.6 12.7 1.4-9.5 8.6 2.7 12.4L24 33.6 12.8 40l2.7-12.4L6 19l12.7-1.4z"/>'],
    ['law', '天平 · 制度', '<path d="M24 6v34M14 40h20M10 12h28"/><path d="M10 12l-5 12a5 5 0 0 0 10 0zM38 12l-5 12a5 5 0 0 0 10 0z"/>']
  ];
  Y.icon = id => Y.ICONS.find(x => x[0] === id) || null;
  Y.iconSvg = (id, color, sw) => {
    const ic = Y.icon(id); if (!ic) return '';
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" fill="none" stroke="${color || '#fff'}" stroke-width="${sw || 3}" stroke-linecap="round" stroke-linejoin="round">${ic[2]}</svg>`;
  };
  Y.iconUrl = (id, color, sw) => { const s = Y.iconSvg(id, color, sw); return s ? 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s) : ''; };

  // ================= 【区域Y2 几何】 =================
  /* o = { n: 层数（不含塔尖）, apex: 有没有塔尖（默认有）, Hs: 整座塔在屏幕上多高（px）,
           hk: 高 / 底面半宽（默认 1.45）, step: 台阶宽度 0~0.9（0 = 侧面连成一条直线，越大每层顶面露出来的一圈越宽）,
           gap: 层间距（占一层高度的比例）, tilt: 俯视程度（度，越大越像从上往下看）, apexK: 塔尖高是一层的几倍（默认 1.35） }
     返回 G = { pieces: [从下往上每一块], R: 底面半宽（px）, se, ce, half: 左右最宽处离中心多远, top: 最高点 Y, bottom: 最低点 Y }
     每一块 pc = { j: 从下往上第几块, apex, b: {l,f,r,k}, t: {l,f,r,k}, B, T, y0, y1 }，角都是 [X, Y] 屏幕像素 */
  Y.build = o => {
    const n = Math.max(1, Math.round(+o.n || 1)), apex = o.apex !== false;
    const e = clamp(+o.tilt || 28, 2, 70) * Math.PI / 180, se = Math.sin(e), ce = Math.cos(e);
    const hk = Math.max(0.3, +o.hk || 1.45), apexK = apex ? Math.max(0.3, +o.apexK || 1.35) : 0;
    const step = clamp(+o.step || 0, 0, 0.9), gapK = Math.max(0, +o.gap || 0);
    const Hc = hk, h = Hc / (n + apexK), g = h * gapK;
    const r = y => Math.max(0, 1 - y / Hc);                       // 一座连续的金字塔：离底面 y 高处的半宽（底面半宽 = 1）
    const raw = [];
    for (let j = 0; j < n; j++){
      const y0 = j * h, y1 = (j + 1) * h, d = r(y0) - r(y1);
      raw.push({ j, apex: false, y0: y0 + j * g, y1: y1 + j * g, B: r(y0), T: Math.min(r(y0), r(y1) + step * d) });
    }
    if (apex) raw.push({ j: n, apex: true, y0: n * h + n * g, y1: Hc + n * g, B: r(n * h), T: 0 });
    const Htop = raw[raw.length - 1].y1;
    const R = Math.max(1, (+o.Hs || 700) / (Htop * ce + 2 * C45 * se));
    const P = (x, y, z) => [(x - z) * C45 * R, -y * ce * R + (x + z) * C45 * se * R];
    const ring = (s, y) => ({ l: P(-s, y, s), f: P(s, y, s), r: P(s, y, -s), k: P(-s, y, -s) });
    raw.forEach(pc => {
      pc.b = ring(pc.B, pc.y0); pc.t = ring(pc.T, pc.y1);
      const xs = [], ys = [];
      [pc.b, pc.t].forEach(q => ['l', 'f', 'r', 'k'].forEach(c => { xs.push(q[c][0]); ys.push(q[c][1]); }));
      pc.box = { x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) };
      pc.P = P;
    });
    return { pieces: raw, R, se, ce, half: 2 * C45 * R, top: -Htop * ce * R, bottom: 2 * C45 * se * R, P, hPx: h * ce * R };
  };

  // 小工具：[ [x,y], … ] → "x,y x,y"，减去这一块自己的左上角
  const pts = (arr, ox, oy) => arr.map(p => f1(p[0] - ox) + ',' + f1(p[1] - oy)).join(' ');
  const hex = c => (typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c.trim()) ? c.trim().toLowerCase() : '#888888');
  const rgb = c => { const v = parseInt(hex(c).slice(1), 16); return [v >> 16 & 255, v >> 8 & 255, v & 255]; };
  const toHex = a => '#' + a.map(x => clamp(Math.round(x), 0, 255).toString(16).padStart(2, '0')).join('');
  Y.mix = (a, b, k) => { const A = rgb(a), B = rgb(b); return toHex(A.map((x, i) => x + (B[i] - x) * k)); };
  Y.lum = c => { const A = rgb(c); return (0.2126 * A[0] + 0.7152 * A[1] + 0.0722 * A[2]) / 255; };
  // 一块的外轮廓（看得见的那一圈），给「压暗」层、点选用
  Y.outline = pc => (pc.apex ? [pc.b.l, pc.b.f, pc.b.r, pc.t.f] : [pc.b.l, pc.b.f, pc.b.r, pc.t.r, pc.t.k, pc.t.l]);
  Y.outlinePts = (pc, ox, oy) => pts(Y.outline(pc), ox, oy);

  // ================= 【区域Y3 实心台阶】 =================
  // col = 这一块的颜色；返回 SVG 内容（坐标已经减去 (ox, oy)）
  Y.solid = (pc, col, ox, oy) => {
    const b = pc.b, t = pc.t, c = hex(col);
    const L = Y.mix(c, '#ffffff', 0.1), Rr = Y.mix(c, '#000000', 0.17), Tp = Y.mix(c, '#ffffff', 0.03);
    const sw = Math.max(1, (pc.box.x1 - pc.box.x0) * 0.004);
    let s = '';
    if (pc.apex){
      s += `<polygon points="${pts([b.l, b.f, t.f], ox, oy)}" fill="${L}"/>`;
      s += `<polygon points="${pts([b.f, b.r, t.f], ox, oy)}" fill="${Rr}"/>`;
      s += `<polyline points="${pts([b.f, t.f], ox, oy)}" fill="none" stroke="rgba(255,255,255,.16)" stroke-width="${f1(sw)}"/>`;
      return s;
    }
    s += `<polygon points="${pts([t.l, t.f, t.r, t.k], ox, oy)}" fill="${Tp}"/>`;
    s += `<polygon points="${pts([b.l, b.f, t.f, t.l], ox, oy)}" fill="${L}"/>`;
    s += `<polygon points="${pts([b.f, b.r, t.r, t.f], ox, oy)}" fill="${Rr}"/>`;
    s += `<polyline points="${pts([t.l, t.f, t.r], ox, oy)}" fill="none" stroke="rgba(255,255,255,.28)" stroke-width="${f1(sw)}" stroke-linejoin="round"/>`;
    s += `<polyline points="${pts([b.f, t.f], ox, oy)}" fill="none" stroke="rgba(255,255,255,.14)" stroke-width="${f1(sw)}"/>`;
    return s;
  };

  // ================= 【区域Y4 透明剖面】 =================
  // o = { cA: 左边的描边色, cB: 右边的描边色, glow: 地板发光色, body: 塔身底色, half: 整座塔的半宽（渐变按整座塔铺）, id: 渐变 id（每块不同）, floor: 要不要地板 }
  Y.section = (pc, o, ox, oy) => {
    const b = pc.b, t = pc.t, W = o.half || 400, id = o.id || ('pyg' + pc.j);
    const sw = Math.max(2, W * 0.032), sw2 = sw * 0.42;
    let s = `<defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${f1(-W - ox)}" y1="0" x2="${f1(W - ox)}" y2="0">`
      + `<stop offset="0" stop-color="${hex(o.cA)}"/><stop offset="1" stop-color="${hex(o.cB)}"/></linearGradient>`
      + `<radialGradient id="${id}f" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="${hex(o.glow)}" stop-opacity=".55"/><stop offset=".65" stop-color="${hex(o.glow)}" stop-opacity=".16"/><stop offset="1" stop-color="${hex(o.glow)}" stop-opacity="0"/></radialGradient></defs>`;
    s += `<polygon points="${Y.outlinePts(pc, ox, oy)}" fill="${o.body || 'rgba(4,8,18,.86)'}"/>`;
    if (o.floor !== false && !pc.apex){
      const k = 0.84, fl = pc.P, y = pc.y0 + 0.001, q = [fl(-pc.B * k, y, pc.B * k), fl(pc.B * k, y, pc.B * k), fl(pc.B * k, y, -pc.B * k), fl(-pc.B * k, y, -pc.B * k)];
      s += `<polygon points="${pts(q, ox, oy)}" fill="url(#${id}f)" stroke="${hex(o.glow)}" stroke-opacity=".45" stroke-width="${f1(sw2 * 0.6)}"/>`;
    }
    const line = (arr, w, op) => `<polyline points="${pts(arr, ox, oy)}" fill="none" stroke="url(#${id})" stroke-width="${f1(w)}" stroke-linejoin="round" stroke-linecap="round"${op != null ? ` stroke-opacity="${op}"` : ''}/>`;
    if (pc.apex){
      s += line([b.l, t.f, b.r], sw * 2.2, 0.18) + line([b.l, t.f, b.r], sw);
      s += line([b.l, b.f, b.r], sw2);
      return s;
    }
    s += line([b.l, t.l], sw * 2.2, 0.18) + line([b.r, t.r], sw * 2.2, 0.18);    // 柔光（宽、淡）
    s += line([b.l, t.l], sw) + line([b.r, t.r], sw);                             // 左右两条粗边
    s += line([b.l, b.f, b.r], sw * 0.75);                                        // 底下那个浅浅的 V
    s += line([t.l, t.f, t.r], sw2);                                              // 顶上细线
    return s;
  };

  // ================= 【区域Y5 平面上放东西】 =================
  // which = 'top'（实心台阶的顶面）/ 'floor'（剖面里每层的地板）；inset = 缩进比例（1 = 整个面）
  // 返回 { cx, cy, S, sy }：把一个 S×S 的方块中心放到 (cx, cy)，scaleY(sy)，再裁成菱形，就平放在这个面上
  Y.plane = (G, pc, which, inset) => {
    const k = inset == null ? 1 : inset, s = (which === 'floor' ? pc.B : pc.T) * k, y = which === 'floor' ? pc.y0 : pc.y1;
    const c = G.P(0, y, 0);
    // 平面上 u = (x − z)·√½ 从 −√2·s 到 +√2·s，所以方块边长 = 2√2·s·R；竖直方向压扁成 sin(俯视)
    return { cx: c[0], cy: c[1], S: 2 * Math.SQRT2 * s * G.R, sy: G.se, s };
  };
  Y.DIAMOND = 'polygon(50% 0,100% 50%,50% 100%,0 50%)';

  // ================= 【区域Y6 侧面上写字】 =================
  // 侧面中间那条带子：中心 (cx, cy)、沿侧面的长度 len、竖直高度 hgt、方向 (ux, uy)。
  // 效果放一个 w×h 的字块，transform-origin 0 0，transform = Y.faceMatrix(fc, w, h)，字就顺着侧面斜过去
  // uc / vc（可选）：带子中心放在侧面的哪里（沿侧面 0~1、从下往上 0~1，默认正中间）
  Y.face = (pc, side, uc, vc) => {
    const b = pc.b, t = pc.t, u = uc == null ? 0.5 : uc, v = vc == null ? 0.5 : vc;
    const [A0, B0, A1, B1] = side === 'right' ? [b.f, b.r, t.f, t.r] : [b.l, b.f, t.l, t.f];
    const M0 = [A0[0] + (A1[0] - A0[0]) * v, A0[1] + (A1[1] - A0[1]) * v], M1 = [B0[0] + (B1[0] - B0[0]) * v, B0[1] + (B1[1] - B0[1]) * v];
    const dx = M1[0] - M0[0], dy = M1[1] - M0[1], len = Math.hypot(dx, dy) || 1;
    const hgt = ((A0[1] - A1[1]) + (B0[1] - B1[1])) / 2;
    return { cx: M0[0] + dx * u, cy: M0[1] + dy * u, len, hgt, ux: dx / len, uy: dy / len, topLen: Math.hypot(B1[0] - A1[0], B1[1] - A1[1]) };
  };
  Y.faceMatrix = (fc, w, h, ox, oy) => {
    const e = fc.cx - (ox || 0) - w / 2 * fc.ux, f = fc.cy - (oy || 0) - w / 2 * fc.uy - h / 2;
    return `matrix(${fc.ux.toFixed(5)},${fc.uy.toFixed(5)},0,1,${f1(e)},${f1(f)})`;
  };
  // 侧面上某一点（u = 沿侧面 0~1，v = 从下往上 0~1）：给连线找落点
  Y.facePoint = (pc, side, u, v) => {
    const b = pc.b, t = pc.t;
    const [A0, B0, A1, B1] = side === 'right' ? [b.f, b.r, t.f, t.r] : [b.l, b.f, t.l, t.f];
    const lo = [A0[0] + (B0[0] - A0[0]) * u, A0[1] + (B0[1] - A0[1]) * u], hi = [A1[0] + (B1[0] - A1[0]) * u, A1[1] + (B1[1] - A1[1]) * u];
    return [lo[0] + (hi[0] - lo[0]) * v, lo[1] + (hi[1] - lo[1]) * v];
  };

  // ================= 【区域Y7 落下动作】 =================
  // way = 'fall' 从上面落下（落地压一下再弹回）/ 'rise' 从下面升上来 / 'pop' 弹出 / 'fade' 淡入；k = 0 → 1；dist = 落多远（px）
  const backOut = (k, s) => 1 + (s + 1) * Math.pow(k - 1, 3) + s * Math.pow(k - 1, 2);
  const smooth = k => k * k * (3 - 2 * k);
  Y.WAYS = [['fall', '一层层落下'], ['rise', '一层层升起'], ['pop', '一层层弹出'], ['fade', '一层层淡入']];
  Y.enter = (way, k, dist) => {
    k = clamp(+k || 0, 0, 1); const v = { y: 0, s: 1, o: 1 };
    if (k >= 1) return v;
    if (way === 'rise'){ v.y = (1 - (1 - Math.pow(1 - k, 3))) * dist * 0.6; v.o = smooth(Math.min(1, k * 1.8)); }
    else if (way === 'pop'){ v.s = 0.55 + 0.45 * backOut(k, 1.8); v.o = smooth(Math.min(1, k * 2.2)); }
    else if (way === 'fade'){ v.o = smooth(k); }
    else { v.y = -(1 - backOut(k, 1.15)) * dist; v.o = smooth(Math.min(1, k * 3)); }
    return v;
  };
})();
