/* ===========================================================================
   fx-net.js —— 点 → 线 → 网（工作台公共模块，2026-11-25 新增，点线网 dot-line-net 第一个用）
   ---------------------------------------------------------------------------
   做什么：一张由「结点 + 连线」组成的网：撒点、谁连谁、一圈圈往外长的时间、平铺 / 透视投影、
           网上流动的小光点、「数据中心」那种大结点，全部画在一张 canvas 上。
           以后任何「从点到线、从线到面」「网络效应」「基础设施」类的说明都可以直接用。

   区域地图（想改哪里，直接说「区域Nx 怎么改」）
   【区域N1 小工具】   固定随机数（同一个种子永远同一张网，导出逐帧确定）、缓动
   【区域N2 生成网】   FXNet.build({ A, B, area, gap, jitter, drop, k, seed, keep })
                      A / B = 两个主结点（地面坐标，单位 = 设计像素）；在 area 里按网格 + 抖动撒点，
                      离 A / B 太近的点去掉；每个点连最近的 k 个邻居（不超过 1.8 格）；A—B 一定连上。
                      返回 { nodes:[{x,y,deg,ph}], edges:[{a,b}], adj, M }（nodes[0] = A，nodes[1] = B，edges[0] = A—B）
   【区域N3 时间表】   FXNet.schedule(net, { tA, tB, lineAt, lineDur, t3, g3, R3, t5, g5, eDur, full })
                      离两点中心近的先长（t3 开始，g3 秒长到半径 R3）；剩下的在 t5 开始，g5 秒铺满。
                      每条线从先出现的那一头画向后出现的那一头，画到时那个点正好弹出来。
   【区域N4 数据中心 / 光点路线】FXNet.hubs(net, n, R3) 挑度数大、彼此分开的几个点；
                      FXNet.walks(net, starts, n, seed, len)：每个光点一条固定的路线（随机游走，不走回头路）
   【区域N5 投影】     FXNet.view({ look:'flat'|'persp', tilt, zoom, cx, cy, D })：p(x,y) → 屏幕 {x,y,f}；inv(X,Y) → 地面
                      平铺 = 直接缩放；透视 = 网像一块斜放的地面往远处铺（远的小、淡）
   【区域N6 画】       FXNet.draw(ctx, S)：线（画到一半时线头带一个亮点）→ 发光层 → 结点（弹出 + 主结点的波纹）
                      → 数据中心的光圈 → 流动的光点。只画到 t 为止出现了的东西；画面是 t 的纯函数。
   =========================================================================== */
(function () {
  const N = window.FXNet = window.FXNet || {};

  // ================= 【区域N1 小工具】 =================
  N.rng = seed => { let s = (Math.floor(seed) * 2654435761 + 1013904223) >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const prog = (t, a, b) => (b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1));
  const backOut = k => { const c = 1.9; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); };
  const cubicOut = k => 1 - Math.pow(1 - k, 3);
  const smooth = k => k * k * (3 - 2 * k);
  N.prog = prog; N.smooth = smooth; N.cubicOut = cubicOut;

  // ================= 【区域N2 生成网】 =================
  N.build = o => {
    const rnd = N.rng(o.seed || 1), gap = Math.max(30, o.gap || 130), jit = o.jitter == null ? 0.36 : o.jitter, drop = o.drop == null ? 0.12 : o.drop;
    const A = o.A, B = o.B, M = { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 };
    const ar = o.area, keep = o.keep || (() => true);
    const nodes = [{ x: A.x, y: A.y, main: 1 }, { x: B.x, y: B.y, main: 2 }];
    const near = gap * 0.72;
    // 网格以两点中心为原点排，网就围着这两个点长
    const i0 = Math.floor((ar.x0 - M.x) / gap) - 1, i1 = Math.ceil((ar.x1 - M.x) / gap) + 1;
    const j0 = Math.floor((ar.y0 - M.y) / gap) - 1, j1 = Math.ceil((ar.y1 - M.y) / gap) + 1;
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const r1 = rnd(), r2 = rnd(), r3 = rnd();
      const x = M.x + (i + (j & 1) * 0.5 + (r1 - 0.5) * 2 * jit) * gap, y = M.y + (j * 0.88 + (r2 - 0.5) * 2 * jit) * gap;
      if (x < ar.x0 || x > ar.x1 || y < ar.y0 || y > ar.y1) continue;
      if (r3 < drop) continue;
      if (Math.hypot(x - A.x, y - A.y) < near || Math.hypot(x - B.x, y - B.y) < near) continue;
      // 两个主结点之间那条线附近也空出来，第一条线看得清楚
      const ux = B.x - A.x, uy = B.y - A.y, L2 = ux * ux + uy * uy || 1, u = ((x - A.x) * ux + (y - A.y) * uy) / L2;
      if (u > 0 && u < 1 && Math.abs((x - A.x) * uy - (y - A.y) * ux) / Math.sqrt(L2) < gap * 0.42) continue;
      if (!keep(x, y)) continue;
      nodes.push({ x, y });
    }
    const n = nodes.length, k = o.k || 3, maxD = gap * 1.8, adj = nodes.map(() => []), seen = new Set(), edges = [];
    const add = (a, b) => { const key = a < b ? a + ',' + b : b + ',' + a; if (a === b || seen.has(key)) return; seen.add(key); edges.push({ a, b }); adj[a].push(b); adj[b].push(a); };
    add(0, 1);
    // 按格子分桶找邻居（点多时不用两两比，透视下上千个点也很快）
    const bk = new Map(), cell = maxD, key2 = (i, j) => i + ',' + j;
    nodes.forEach((nd, i) => { const kk = key2(Math.floor(nd.x / cell), Math.floor(nd.y / cell)); if (!bk.has(kk)) bk.set(kk, []); bk.get(kk).push(i); });
    for (let a = 0; a < n; a++) {
      const ds = [], ci = Math.floor(nodes[a].x / cell), cj = Math.floor(nodes[a].y / cell);
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) (bk.get(key2(ci + di, cj + dj)) || []).forEach(b => { if (b === a) return; const d = Math.hypot(nodes[a].x - nodes[b].x, nodes[a].y - nodes[b].y); if (d <= maxD) ds.push([d, b]); });
      ds.sort((p, q) => p[0] - q[0]);
      const kk = nodes[a].main ? k + 1 : k;
      for (let m = 0; m < Math.min(kk, ds.length); m++) if (!(a <= 1 && ds[m][1] <= 1)) add(a, ds[m][1]);
    }
    nodes.forEach((nd, i) => { nd.deg = adj[i].length; nd.ph = rnd(); nd.d = Math.hypot(nd.x - M.x, nd.y - M.y); });
    return { nodes, edges, adj, M, gap };
  };

  // ================= 【区域N3 时间表】 =================
  // 每个点 at = 弹出来的秒数（Infinity = 不出现）；每条线 s / e = 开始画 / 画完，from = 从哪一头画
  N.schedule = (net, o) => {
    const { nodes, edges } = net, R3 = Math.max(10, o.R3), rnd = N.rng(7);
    let dmax = 1; nodes.forEach(nd => { dmax = Math.max(dmax, nd.d); });
    nodes.forEach((nd, i) => {
      if (i === 0) { nd.at = o.tA; nd.st = 1; return; }
      if (i === 1) { nd.at = o.tB; nd.st = 2; return; }
      const jit = (rnd() - 0.5) * 0.16;
      if (nd.d <= R3) { nd.st = 3; nd.at = o.t3 + o.eDur + Math.max(0, o.g3 - o.eDur) * clamp(nd.d / R3 + jit, 0, 1); }
      else { nd.st = 5; nd.at = o.full ? o.t5 + o.eDur + Math.max(0, o.g5 - o.eDur) * clamp(Math.pow((nd.d - R3) / Math.max(1, dmax - R3), 0.85) + jit * 0.6, 0, 1) : Infinity; }
    });
    edges.forEach((e, i) => {
      if (i === 0) { e.from = 0; e.s = o.lineAt; e.e = o.lineAt + o.lineDur; e.st = 2; return; }
      const A = nodes[e.a], B = nodes[e.b], first = A.at <= B.at ? e.a : e.b, late = first === e.a ? B : A;
      e.from = first; e.st = late.st;
      if (!isFinite(late.at)) { e.s = e.e = Infinity; return; }
      const st0 = late.st === 3 ? o.t3 : o.t5;
      e.e = late.at; e.s = Math.max(nodes[first].at, st0, late.at - o.eDur);
      if (e.e - e.s < 0.08) e.s = e.e - 0.08;
    });
    return net;
  };

  // ================= 【区域N4 数据中心 / 光点路线】 =================
  N.hubs = (net, n, R3) => {
    const c = net.nodes.map((nd, i) => i).filter(i => i > 1 && net.nodes[i].d <= R3 * 1.05).sort((a, b) => net.nodes[b].deg - net.nodes[a].deg || net.nodes[a].d - net.nodes[b].d);
    const out = [], minD = Math.max(net.gap * 1.6, R3 * 0.55);
    for (const i of c) { if (out.length >= n) break; if (out.every(j => Math.hypot(net.nodes[i].x - net.nodes[j].x, net.nodes[i].y - net.nodes[j].y) >= minD)) out.push(i); }
    for (const i of c) { if (out.length >= n) break; if (!out.includes(i)) out.push(i); }
    return out;
  };
  N.walks = (net, starts, n, seed, len) => {
    const rnd = N.rng(seed || 3), out = [], ekey = new Map();
    net.edges.forEach((e, i) => { ekey.set(e.a + ',' + e.b, i); ekey.set(e.b + ',' + e.a, i); });
    for (let w = 0; w < n; w++) {
      let cur = starts.length ? starts[w % starts.length] : 0, prev = -1;
      const steps = [];
      for (let s = 0; s < (len || 6); s++) {
        const nb = net.adj[cur].filter(x => x !== prev); if (!nb.length) break;
        const nx = nb[Math.floor(rnd() * nb.length)];
        steps.push({ e: ekey.get(cur + ',' + nx), a: cur, b: nx });
        prev = cur; cur = nx;
      }
      out.push({ steps, ph: rnd(), sp: 0.8 + rnd() * 0.5 });
    }
    return out;
  };

  // ================= 【区域N5 投影】 =================
  N.view = o => {
    const zoom = o.zoom || 1, cx = o.cx || 0, cy = o.cy || 0;
    if (o.look !== 'persp') return {
      persp: false,
      p: (x, y) => ({ x: cx + x * zoom, y: cy + y * zoom, f: zoom, k: 1 }),
      inv: (X, Y) => ({ x: (X - cx) / zoom, y: (Y - cy) / zoom })
    };
    const th = (o.tilt == null ? 60 : o.tilt) * Math.PI / 180, c = Math.cos(th), s = Math.sin(th), D = o.D || 1500;
    return {
      persp: true,
      // 地面上 y 往上（负）= 往远处；f = 这一点离镜头远近带来的缩放；k = 远处变淡用的系数（0~1）
      p: (x, y) => { const den = D - y * s; if (den < 60) return null; const f = D / den; return { x: cx + x * f * zoom, y: cy + y * c * f * zoom, f: f * zoom, k: clamp(f * 1.55 - 0.25, 0, 1) }; },
      inv: (X, Y) => { const sx = (X - cx) / zoom, sy = (Y - cy) / zoom, y = sy * D / (c * D + sy * s), f = D / (D - y * s); return { x: sx / f, y }; }
    };
  };

  // ================= 【区域N6 画】 =================
  /* S.part（可选）：'static' = 只画不会再变的（线、发光层、普通结点），'dynamic' = 只画还在动的（主结点、数据中心、光点）。
     全部长完、不再推拉镜头以后，效果可以把 static 画一次存起来，每帧只贴图 + 画 dynamic（透视时上千条线也不卡）。
     S = { net, V, t, W, H（画布设计尺寸，原点在中心）, col: { node, line, pulse, hub }, rA, rB, rN, lw, lwMain, lineOp,
           lit: 0~1（亮起来的程度）, hubs, hubK: 0~1, walks, pulseK: 0~1, pulseSize, pulseSpeed, edgeT（光点走一条线几秒）, glow } */
  N.draw = (ctx, S) => {
    const { net, V, t } = S, nodes = net.nodes, edges = net.edges, P = new Array(nodes.length);
    const hw = S.W / 2 + 80, hh = S.H / 2 + 80;
    const pt = i => { if (P[i] === undefined) P[i] = V.p(nodes[i].x, nodes[i].y); return P[i]; };
    const on = p => p && p.x > -hw && p.x < hw && p.y > -hh && p.y < hh;
    const lit = S.lit || 0, op = clamp(S.lineOp, 0, 1) * (1 + lit * 0.7);
    ctx.lineCap = 'round';
    const part = S.part || 'all', doS = part !== 'dynamic', doD = part !== 'static';
    // ---- 线 ----
    const done = [];
    ctx.strokeStyle = S.col.line;
    const heads = [];
    for (let i = doS ? 0 : edges.length; i < edges.length; i++) {
      const e = edges[i]; if (!(t > e.s)) continue;
      const a = e.from, b = a === e.a ? e.b : e.a, pa = pt(a), pb = pt(b);
      if (!pa || !pb || (!on(pa) && !on(pb))) continue;
      const u = i === 0 ? cubicOut(prog(t, e.s, e.e)) : smooth(prog(t, e.s, e.e));
      const dk = Math.min(pa.k, pb.k);
      let x2 = pb.x, y2 = pb.y;
      if (u < 1) { const q = V.p(nodes[a].x + (nodes[b].x - nodes[a].x) * u, nodes[a].y + (nodes[b].y - nodes[a].y) * u); if (!q) continue; x2 = q.x; y2 = q.y; heads.push([x2, y2, (pa.f + pb.f) / 2, dk]); }
      const w = (i === 0 ? S.lwMain : S.lw) * Math.sqrt((pa.f + pb.f) / 2);
      ctx.globalAlpha = clamp((i === 0 ? Math.max(0.8, op) : op) * dk, 0, 1);
      ctx.lineWidth = w;
      ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(x2, y2); ctx.stroke();
      if (u >= 1 && i > 0 && dk > 0.5) done.push(pa, pb);   // 发光层只给近处的线（远处的又细又淡，描了也看不出，还很费）
    }
    // ---- 亮起来：线外面再描一圈宽而淡的光（一次画完，不用 shadowBlur）----
    if (lit > 0.01 && S.glow !== false && done.length) {
      ctx.globalAlpha = 0.16 * lit; ctx.strokeStyle = S.col.node; ctx.lineWidth = S.lw * 4.5;
      ctx.beginPath(); for (let i = 0; i < done.length; i += 2) { ctx.moveTo(done[i].x, done[i].y); ctx.lineTo(done[i + 1].x, done[i + 1].y); } ctx.stroke();
    }
    // 正在画的线：线头一个小亮点
    ctx.fillStyle = S.col.pulse;
    heads.forEach(h => { ctx.globalAlpha = 0.9 * h[3]; ctx.beginPath(); ctx.arc(h[0], h[1], Math.max(1.5, S.lw * 1.6 * Math.sqrt(h[2])), 0, 6.2832); ctx.fill(); });
    // ---- 结点 ----
    const hubSet = new Set(S.hubs || []);
    for (let i = nodes.length - 1; i >= 0; i--) {
      const nd = nodes[i]; if (!(t >= nd.at)) continue;
      const dyn = nd.main || hubSet.has(i);
      if (dyn ? !doD : !doS) continue;
      const p = pt(i); if (!on(p)) continue;
      const kk = prog(t, nd.at, nd.at + (nd.main ? 0.55 : 0.35)), sc = kk < 1 ? Math.max(0, backOut(kk)) : 1;
      const hk = hubSet.has(i) ? smooth(S.hubK || 0) : 0;
      const r0 = nd.main === 1 ? S.rA : nd.main === 2 ? S.rB : S.rN * (1 + hk * 0.9);
      const r = r0 * sc * Math.sqrt(p.f), a = p.k;
      if (nd.main) {
        // 主结点：一圈淡光 + 实心 + 白芯；刚出现时一道波纹往外扩
        const br = 1 + 0.08 * Math.sin((t - nd.at) * 2.6);
        ctx.globalAlpha = 0.2 * a * Math.min(1, kk * 2); ctx.fillStyle = S.col.node;
        ctx.beginPath(); ctx.arc(p.x, p.y, r * 2.1 * br, 0, 6.2832); ctx.fill();
        const rk = prog(t, nd.at, nd.at + 1.3);
        if (rk > 0 && rk < 1) { ctx.globalAlpha = 0.55 * (1 - rk) * a; ctx.strokeStyle = S.col.node; ctx.lineWidth = Math.max(1.5, r * 0.12); ctx.beginPath(); ctx.arc(p.x, p.y, r * (1.2 + 3.2 * cubicOut(rk)), 0, 6.2832); ctx.stroke(); }
        ctx.globalAlpha = a; ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(0, r), 0, 6.2832); ctx.fill();
        ctx.globalAlpha = 0.85 * a; ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(0, r * 0.36), 0, 6.2832); ctx.fill();
      } else {
        ctx.globalAlpha = a * (0.78 + 0.22 * lit); ctx.fillStyle = S.col.node;
        ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(0, r), 0, 6.2832); ctx.fill();
        if (hk > 0.01) {
          // 数据中心：两道光圈，外面那道一下下往外扩
          const ph = ((t * 0.7 + nd.ph) % 1);
          ctx.strokeStyle = S.col.hub; ctx.lineWidth = Math.max(1.2, S.rN * 0.32 * Math.sqrt(p.f));
          ctx.globalAlpha = 0.9 * hk * a; ctx.beginPath(); ctx.arc(p.x, p.y, r * 1.75, 0, 6.2832); ctx.stroke();
          ctx.globalAlpha = 0.5 * hk * a * (1 - ph); ctx.beginPath(); ctx.arc(p.x, p.y, r * (1.9 + 2.2 * ph), 0, 6.2832); ctx.stroke();
          ctx.globalAlpha = 0.18 * hk * a; ctx.fillStyle = S.col.hub; ctx.beginPath(); ctx.arc(p.x, p.y, r * 1.75, 0, 6.2832); ctx.fill();
        }
      }
    }
    // ---- 流动的光点 ----
    const pk = S.pulseK || 0;
    if (doD && pk > 0.01 && S.walks && S.walks.length) {
      const eT = Math.max(0.1, S.edgeT || 0.5), rs = S.pulseSize || 4;
      S.walks.forEach(w => {
        const n = w.steps.length; if (!n) return;
        const tt = (t * (S.pulseSpeed || 1) * w.sp / eT + w.ph * n) % n, si = Math.floor(tt), u = tt - si, st = w.steps[si];
        const e = edges[st.e]; if (!e || !(t >= e.e)) return;
        const q = V.p(nodes[st.a].x + (nodes[st.b].x - nodes[st.a].x) * u, nodes[st.a].y + (nodes[st.b].y - nodes[st.a].y) * u);
        if (!on(q)) return;
        const fade = Math.sin(Math.PI * Math.min(1, tt / n * 1.02)) ** 0.35, rr = rs * Math.sqrt(q.f);
        ctx.fillStyle = S.col.node; ctx.globalAlpha = 0.28 * pk * q.k * fade; ctx.beginPath(); ctx.arc(q.x, q.y, rr * 2.4, 0, 6.2832); ctx.fill();
        ctx.fillStyle = S.col.pulse; ctx.globalAlpha = pk * q.k * fade; ctx.beginPath(); ctx.arc(q.x, q.y, rr, 0, 6.2832); ctx.fill();
      });
    }
    ctx.globalAlpha = 1;
    return P;
  };
})();
