/* 效果工坊 · 公共模块 FXRef（v1 2026-11-26；v2 v60.0：播到「出」停住、拾取、搜索）：把素材时间线上的另一条素材嵌进来当内容（「指定」= 第 4 种内容）
 *
 * 【区域R1 找素材】 resolve(id, P)：导出时从 P.__refs[id] 拿（工作台打包时塞进去）；工作台里一层层往上找 __fxRefClip(id)
 * 【区域R2 嵌入】   new FXRef.Slot(host)：在 host 里放一个 /ghost.html?fx=… 子页面（铺满 host），set(id, P) / render(t) / clear()
 * 【区域R3 同步】   r.at = 嵌着的拷贝比父素材晚开始几秒（时间线上拖它的素材条）；r.stop = 子素材「出」旗子在第几秒：播到那里就停住，一直保持到父素材结束（素材改过总时长 __dur 时按比例换算）
 * 【区域R3 同步】   工作台每改一次参数 __fxRefVer() 加 1；render 时版本变了才重新拿参数，参数真的变了才重新 init（不每帧比较）
 * 【区域R4 等帧】   导出时 window.__fxFrameWait 也等子素材这一帧画好（只在用到 Slot 的效果里挂，其它效果不受影响）
 * 【区域R5 面板】   FXRef.picker(o)：右侧「时间线素材」那一块 —— 选哪条素材、联动 / 拷贝一份、编辑这条素材
 *
 * 只嵌一层：子素材拿到的参数带 __fxRefDepth = 1，它自己再选「时间线素材」也不显示（防套娃、防循环引用）。
 * 引用的素材被删掉 / 找不到时：这一块什么都不画（和「不要背景」一样），不报错。
 */
(function () {
  if (window.FXRef) return;
  // 【区域R1】一层层往上找工作台挂的函数（预览里效果可能在 #frame，也可能在 ghost.html 里面那层）
  const up = name => { let w = window; for (let i = 0; i < 8; i++) { try { if (w[name]) return w[name]; } catch (e) { } if (w === w.parent) break; w = w.parent; } return null; };
  const ver = () => { const f = up('__fxRefVer'); try { return f ? f() : 0; } catch (e) { return 0; } };
  const depth = P => +(P && P.__fxRefDepth) || 0;
  function resolve(id, P) {
    if (!id) return null;
    const R = P && P.__refs; if (R && R[id]) return R[id];
    const f = up('__fxRefClip'); try { return f ? f(id) : null; } catch (e) { return null; }
  }
  const slots = [];
  function hookWait() {                               // 【区域R4】第一次用到 Slot 时才挂
    if (hookWait.done) return; hookWait.done = true;
    const old = window.__fxFrameWait;
    window.__fxFrameWait = () => Promise.all([old ? old() : null, ...slots.map(s => s.frameWait())]);
  }
  // 【区域R2】一个嵌入位
  class Slot {
    constructor(host) { this.host = host; this.fr = null; this.fx = ''; this.key = ''; this.ver = -1; this.id = ''; this.ci = 0; this.inited = false; this.lastT = null; this.wait = null; this.pending = Promise.resolve(); slots.push(this); hookWait(); }
    inner() { try { return this.fr.contentWindow.document.getElementById('fx').contentWindow; } catch (e) { return null; } }
    set(id, P) { if (id !== this.id) this.key = ''; this.id = id; this.P = P; this.ver = -1; this.sync(); return this.pending; }
    sync() {                                            // 【区域R3】
      const v = ver(); if (v === this.ver && (this.fr || !this.id)) return; this.ver = v;
      const r = this.id && depth(this.P) < 1 ? resolve(this.id, this.P) : null;
      if (!r || !r.fx) { this.clear(); return; }
      const p = JSON.parse(JSON.stringify(r.params || {})); delete p.__refs; p.__fxRefDepth = depth(this.P) + 1;
      if (this.P && this.P.__media && !p.__media) p.__media = this.P.__media;
      this.ci = +r.ci || 0; this.at = +r.at || 0; this.stop = r.stop != null && isFinite(+r.stop) ? +r.stop : null; this.T = +p.__dur || 0;
      const key = r.fx + '|' + JSON.stringify(p); if (key === this.key) return; this.key = key;
      if (!this.fr || this.fx !== r.fx) {
        if (this.fr) this.fr.remove();
        const fr = this.fr = document.createElement('iframe'); this.fx = r.fx; this.inited = false;
        fr.setAttribute('tabindex', '-1'); fr.className = 'fxref';
        fr.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;border:0;background:transparent;pointer-events:none';
        this.ok = new Promise(res => fr.addEventListener('load', res, { once: true }));
        fr.src = '/ghost.html?fx=' + encodeURIComponent(r.fx); this.host.appendChild(fr);
      }
      const fr = this.fr;
      this.pending = this.ok.then(async () => {
        if (fr !== this.fr) return;
        const w = this.inner(); if (!w || typeof w.init !== 'function') return;
        try { w.init(p); if (w.whenReady) await w.whenReady(); } catch (e) { return; }
        this.inited = true; if (this.lastT != null) this.render(this.lastT, true);
      });
    }
    clear() { if (this.fr) this.fr.remove(); this.fr = null; this.fx = ''; this.key = ''; this.inited = false; this.wait = null; }
    render(t, noSync) {
      if (!noSync) this.sync(); this.lastT = t; this.wait = null;
      if (!this.fr || !this.inited) return;
      const w = this.inner(); if (!w) return;
      let tt = Math.max(0, (+t || 0) - this.at) + this.ci;
      if (this.stop != null) { let s = this.stop; if (this.T > 0) { let N = 0; try { N = w.__fxNativeDur ? +w.__fxNativeDur() : 0; } catch (e) { } if (N > 0) s *= this.T / N; } tt = Math.min(tt, Math.max(this.ci, s)); }   // 【区域R3】停在「出」
      try { w.renderAt(tt); this.wait = w.__fxFrameWait ? w.__fxFrameWait() : null; } catch (e) { }
    }
    frameWait() { return Promise.resolve(this.pending).then(() => this.wait); }
    get on() { return !!this.fr; }
  }

  // 【区域R5】右侧面板：o = { pd, pw, mk, m（当前内容对象，m.ref / m.mode）, save, reload, redraw, el, note }
  // 🎯 拾取 = 点时间线上的素材条（AE 的拾取线）；下面的列表是备用：可以搜名字，按离这条素材最近排，只列前 10 条
  function picker(o) {
    const { pd, pw, mk, m, el, note } = o;
    if (pd && !pd.getElementById('fxref-css')) { const st = pd.createElement('style'); st.id = 'fxref-css'; st.textContent = 'html body #params .stc .stc-refq{display:block;width:100%;box-sizing:border-box;margin:8px 0 0}'; pd.head.appendChild(st); }   // 只管大小，颜色跟着面板的输入框
    const list = (() => { try { return pw.__fxRefList ? pw.__fxRefList() : null; } catch (e) { return null; } })();
    if (!list) { note.innerHTML = '要在<b>素材时间线</b>里用：先把这个效果放到时间线上、选中它，这里就会列出时间线上的其它素材。'; el.appendChild(note); return; }
    const cur = m.ref ? list.find(c => c.id === m.ref) : null;
    const mode = m.mode === 'copy' ? 'copy' : 'link';
    const choose = c => {
      if (m.mode === 'copy' && !(c.embedded && c.id === m.ref)) {
        let id = null; try { id = pw.__fxRefCopy(c.id); } catch (e) { }
        if (!id) { note.textContent = '拷贝失败：时间线上找不到这条素材'; return; }
        m.ref = id;
      } else m.ref = c.id;
      o.save(); o.reload(); o.redraw();
      if (m.mode === 'copy') { try { pw.__fxRefAfterCopy && pw.__fxRefAfterCopy(m.ref); } catch (e) { } }
      else { try { pw.histCheck && pw.histCheck(); } catch (e) { } }   // 换成联动：原来的拷贝没人用了，马上删掉
    };
    // 联动 / 拷贝一份
    const seg = mk('div', 'stc-seg', '<button type="button" data-v="link">联动（引用原素材）</button><button type="button" data-v="copy">拷贝一份</button>');
    seg.querySelectorAll('button').forEach(b => {
      b.classList.toggle('on', b.dataset.v === mode);
      b.onclick = () => {
        if (b.dataset.v === mode) return; m.mode = b.dataset.v;
        if (cur && m.mode === 'link' && cur.embedded) { const src = cur.src && list.find(c => c.id === cur.src); if (src) { choose(src); return; } }   // 拷贝 → 联动：改回引用原来那条
        if (cur) choose(cur); else { o.save(); o.redraw(); }
      };
    });
    el.appendChild(seg);
    // 🎯 拾取
    const pk = mk('button', 'stc-btn', '🎯 拾取：点时间线上的素材'); pk.type = 'button'; pk.setAttribute('data-fxpick', '');
    pk.title = '点一下，再去时间线上点要嵌进来的那条素材（像 AE 的拾取线）；Esc 取消';
    const pkSync = () => { const on = !!(pw.__fxRefPicking && pw.__fxRefPicking()); pk.classList.toggle('on', on); pk.textContent = on ? '🎯 去时间线上点一条素材…（再点这里 / Esc 取消）' : '🎯 拾取：点时间线上的素材'; };
    pk.onclick = () => { try { pw.__fxRefPick(c => { pkSync(); if (c.id !== m.ref) choose(c); }); } catch (e) { } pkSync(); };
    pkSync(); el.appendChild(pk);
    // 备用列表：搜索 + 最近的 10 条
    const shown = list.filter(c => m.mode === 'copy' ? (!c.embedded || c.id === m.ref) : true);
    const q = mk('input', 'stc-refq'); q.type = 'search'; q.placeholder = '搜素材名字…'; q.value = picker.q || '';
    const box = mk('div', 'stc-reflist');
    const fill = () => {
      const k = (q.value || '').trim().toLowerCase(); picker.q = q.value;
      let L = shown.filter(c => !k || c.name.toLowerCase().indexOf(k) >= 0);
      const more = Math.max(0, L.length - 10); L = L.slice(0, 10);
      if (cur && L.indexOf(cur) < 0 && shown.indexOf(cur) >= 0) L.unshift(cur);
      box.innerHTML = '';
      L.forEach(c => {
        const b = mk('button', 'stc-btn' + (c.id === m.ref ? ' on' : ''), (c.id === m.ref ? '✓ ' : '') + c.name + ' · ' + c.start.toFixed(1) + 's' + (c.embedded ? '（拷贝）' : c.hide ? '（隐藏）' : ''));
        b.type = 'button'; b.title = c.id === m.ref ? '正在用这条素材' : (m.mode === 'copy' ? '拷贝这条素材的一份放进来（原素材不受影响）' : '直接引用这条素材：改它，这里跟着变');
        b.onclick = () => { if (c.id !== m.ref) choose(c); };
        box.appendChild(b);
      });
      if (!L.length && shown.length) box.appendChild(mk('div', 'stc-note', '没有名字里带「' + q.value + '」的素材'));
      if (more) box.appendChild(mk('div', 'stc-note', '还有 ' + more + ' 条离得更远的没列出来：搜名字，或用上面的「🎯 拾取」直接点'));
    };
    if (shown.length > 10 || q.value) { q.oninput = fill; el.appendChild(q); }
    fill(); el.appendChild(box);
    if (!shown.length) { note.innerHTML = '时间线上还没有别的素材。先把要嵌进来的效果（比如「图片重点标注」）放到时间线上，再回来选。'; }
    if (m.ref) {
      const ed = mk('button', 'stc-btn', cur ? '✎ 编辑这条素材的参数' : '原素材已被删掉，请重新选'); ed.type = 'button';
      ed.title = '选中它：右侧换成它自己的参数（预览照样是整个画面），Esc 或点右侧顶上的「←」回来';
      ed.onclick = () => { try { pw.__fxRefEdit && pw.__fxRefEdit(m.ref); } catch (e) { } };
      const en = mk('button', 'stc-btn', '⤵ 进到它里面改'); en.type = 'button';
      en.title = '时间线只显示它、预览只显示它，可以直接在预览里拖、改字；Esc 回来（在预览里双击背景也一样）';
      en.onclick = () => { try { (pw.__fxRefEnter || pw.__fxRefEdit)(m.ref); } catch (e) { } };
      if (cur) { el.appendChild(ed); el.appendChild(en); } else { note.textContent = '原素材已被删掉，请重新选一条。'; }
    }
    if (!note.textContent) note.innerHTML = mode === 'copy'
      ? '<b>拷贝一份</b>：复制出一条只在这里显示的素材，时长和这条一样，不占轨道（点素材条上的 ▸ 能看到它）；改它只影响这里。它播到自己的「出」就停住，一直留到这条结束。'
      : '<b>联动</b>：原素材照常在原位显示，这里显示同一份内容；改原素材，两处一起变。它播到自己的「出」就停住，一直留到这条结束。';
    el.appendChild(note);
  }

  window.FXRef = { Slot, resolve, picker, depth };
})();
