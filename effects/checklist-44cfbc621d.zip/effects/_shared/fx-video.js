/* 效果工坊 · 卡片里的视频（所有卡片类效果共用）
 *
 * 【区域V1 数据】一张视频卡：{ type:'video', video:'/uploads/xxx.fx.mp4', poster, vdur(秒), loop(true/false) }
 *      上传时服务器会把视频转成一份「预览用小视频」（最长边 960px），网页预览更流畅
 * 【区域V2 时间】视频从整段动画开始就播放（第 0 秒 = 视频第 0 秒）
 *      上传时自动检测：视频比整段动画短 → 「无限循环」默认打开；开关一直在，也可以手动开 / 关
 *      开了循环就一直重复；没开就停在最后一帧（不会黑屏）
 * 【区域V3 预览】工作台里用 <video> 播放，拖动进度条时跳到对应画面
 * 【区域V4 导出（提速）】导出时服务器先用 FFmpeg 把视频一次性拆成图片（按导出帧率），
 *      每一帧直接换图片，不用让浏览器去「跳到某一秒」再等解码 → 快很多，而且每帧都准
 * 【区域V5 编辑器】卡片编辑器里的「视频」：上传、显示时长、循环开关
 *
 * 效果里只要做两件事：build() 里遇到视频卡调用 FXVideo.mount(容器, 卡片数据, 填充方式)；
 * 编辑器里视频卡的内容区调用 FXVideo.editorBody(...)。其余（每帧同步、导出等图片加载）这里自动处理。
 */
(function () {
  const FX = { P: {}, list: [], pending: [] };
  window.FXVideo = FX;
  const media = () => (FX.P && FX.P.__media) || null;          // 导出时服务器塞进来的：{ fps, map: { 视频地址: { dir, count } } }

  // ---------- 【区域V2 时间】 ----------
  FX.localTime = (item, t) => {
    const d = +item.vdur || 0;
    if (!(d > 0)) return Math.max(0, t);
    if (item.loop) return ((t % d) + d) % d;
    return Math.min(Math.max(0, t), Math.max(0, d - 0.04));       // 播完停在最后一帧
  };

  // ---------- 创建画面元素 ----------
  FX.reset = () => { FX.list.forEach(h => { try { h.el.pause && h.el.pause(); } catch (e) {} }); FX.list = []; };
  FX.mount = (box, item, fit) => {
    const m = media(), info = m && m.map && m.map[item.video];
    const css = `position:absolute;inset:0;width:100%;height:100%;display:block;object-fit:${fit === 'contain' ? 'contain' : 'cover'};background:#000`;
    let el, load;
    if (info) {                                                  // 【区域V4 导出】一帧一张图
      el = new Image(); el.style.cssText = css; el.decoding = 'sync';
      load = Promise.resolve();
    } else {                                                     // 【区域V3 预览】
      el = document.createElement('video');
      el.muted = true; el.playsInline = true; el.preload = 'auto'; el.loop = false;
      el.setAttribute('muted', ''); el.setAttribute('playsinline', '');
      el.style.cssText = css;
      if (item.poster) el.poster = item.poster;
      el.src = item.video;
      load = new Promise(r => { if (el.readyState >= 2) r(); else { el.addEventListener('loadeddata', r, { once: true }); el.addEventListener('error', r, { once: true }); setTimeout(r, 4000); } });
    }
    box.appendChild(el);
    const h = { el, item, info, last: null, wall: 0, idx: -1, stop: 0 };
    FX.list.push(h);
    return load;
  };

  // ---------- 每一帧：让视频画面对上时间 ----------
  function syncOne(h, t) {
    const lt = FX.localTime(h.item, t);
    if (h.info) {                                                // 导出：换成对应那一帧的图片
      const fps = media().fps, i = Math.max(0, Math.min(h.info.count - 1, Math.floor(lt * fps + 1e-6)));
      if (i === h.idx) return;
      h.idx = i;
      h.el.src = h.info.dir + String(i + 1).padStart(6, '0') + '.jpg';
      FX.pending.push(h.el.decode ? h.el.decode().catch(() => {}) : new Promise(r => { h.el.onload = h.el.onerror = r; }));
      return;
    }
    const v = h.el, now = performance.now();
    // 连续播放（时间和真实时间一起往前走）→ 让视频自己播；否则（拖动、跳转、循环回头）→ 直接跳到那一秒
    const running = h.last != null && lt >= h.last && lt - h.last < 0.25 && Math.abs((lt - h.last) - (now - h.wall) / 1000) < 0.12;
    h.last = lt; h.wall = now;
    if (running) {
      if (v.paused) v.play().catch(() => {});
      if (Math.abs(v.currentTime - lt) > 0.3) v.currentTime = lt;
    } else {
      if (!v.paused) v.pause();
      if (Math.abs(v.currentTime - lt) > 0.02) v.currentTime = lt;
    }
    clearTimeout(h.stop); h.stop = setTimeout(() => { try { v.pause(); } catch (e) {} }, 200);   // 预览停了，视频也停
  }
  FX.syncAll = t => FX.list.forEach(h => { try { syncOne(h, t); } catch (e) {} });
  // 导出时：等这一帧的图片都解码好再截图
  window.__fxFrameWait = () => { const p = FX.pending; FX.pending = []; return p.length ? Promise.all(p) : null; };

  // ---------- 自动接到效果的 init / renderAt / whenReady 上 ----------
  const oInit = window.init, oRender = window.renderAt, oReady = window.whenReady;
  if (typeof oInit === 'function') window.init = function (p) { FX.P = p || {}; return oInit.apply(this, arguments); };
  if (typeof oRender === 'function') window.renderAt = function (t) { const r = oRender.apply(this, arguments); FX.syncAll(+t || 0); return r; };
  window.whenReady = () => Promise.all([oReady ? oReady() : null, ...FX.list.filter(h => !h.info).map(h => h.el.readyState >= 2 ? null : new Promise(r => { h.el.addEventListener('loadeddata', r, { once: true }); setTimeout(r, 4000); }))]);

  // 卡片编辑器里「照片 / 文字 / 视频」三个按钮放得下：不换行、稍微收窄
  try {
    const pd = window.parent !== window && window.parent.document;
    if (pd && !pd.getElementById('fxv-seg-style')) {
      const st = pd.createElement('style'); st.id = 'fxv-seg-style';
      st.textContent = '.cdx-seg button,.crx-seg button,.rgx-seg button{white-space:nowrap;padding-left:9px!important;padding-right:9px!important}';
      pd.head.appendChild(st);
    }
  } catch (e) {}

  // ---------- 【区域V5 编辑器】视频卡的内容区 ----------
  // o = { pd: 工作台的 document, c: 这张卡的数据, total: () => 整段动画秒数, changed: () => 重画编辑器并保存, note: 文字 => 显示提示 }
  const fmt = s => (s >= 60 ? Math.floor(s / 60) + ' 分 ' : '') + (Math.round((s % 60) * 10) / 10) + ' 秒';
  FX.editorBody = o => {
    const { pd, c } = o;
    if (!pd.getElementById('fxv-style')) {
      const st = pd.createElement('style'); st.id = 'fxv-style';
      st.textContent = `
.fxv-drop{position:relative;height:92px;border:1px dashed #444;border-radius:6px;display:flex;align-items:center;justify-content:center;text-align:center;color:#999;font-size:12px;cursor:pointer;overflow:hidden;line-height:1.5;background:#0b0b0b}
.fxv-drop:hover,.fxv-drop.over{border-color:#f28c0f;color:#f28c0f}
.fxv-drop small{color:#666}
.fxv-drop.has{border-style:solid}
.fxv-drop img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.85}
.fxv-drop .fxv-tag{position:absolute;left:6px;top:6px;background:rgba(0,0,0,.7);color:#fff;font-size:11px;padding:2px 7px;border-radius:4px}
.fxv-drop.has>span:last-child{position:relative;background:rgba(0,0,0,.65);color:#fff;padding:3px 8px;border-radius:4px;opacity:0;transition:opacity .15s}
.fxv-drop.has:hover>span:last-child{opacity:1}
.fxv-loop{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:8px;font-size:12px;color:#ccc}
.fxv-loop .fxv-seg{display:flex;background:#1d1d1d;border:1px solid #333;border-radius:6px;overflow:hidden}
.fxv-loop .fxv-seg button{border:0;background:none;color:#aaa;padding:4px 12px;font-size:12px;cursor:pointer;font-family:inherit}
.fxv-loop .fxv-seg button.on{background:#f28c0f;color:#000;font-weight:600}
.fxv-tip{margin-top:6px;font-size:11.5px;line-height:1.5;color:#888}
.fxv-tip b{color:#f2b56a;font-weight:500}
.fxv-clr{margin-top:6px;background:none;border:0;color:#888;font-size:12px;cursor:pointer;padding:0}.fxv-clr:hover{color:#f28c0f}`;
      pd.head.appendChild(st);
    }
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const body = mk('div', 'fxv');
    const drop = mk('div', 'fxv-drop' + (c.video ? ' has' : ''));
    if (c.video) {
      drop.innerHTML = (c.poster ? '<img alt="">' : '') + '<span class="fxv-tag"></span><span>点击更换视频</span>';
      if (c.poster) drop.querySelector('img').src = c.poster;
      drop.querySelector('.fxv-tag').textContent = '▶ ' + fmt(+c.vdur || 0);
    } else drop.innerHTML = '<span>点击上传视频<br><small>或把视频拖到这里（MP4 / MOV / WEBM）</small></span>';
    const fin = mk('input'); fin.type = 'file'; fin.accept = 'video/*,.mp4,.mov,.webm,.m4v,.mkv'; fin.style.display = 'none';
    const put = async f => {
      if (!f) return;
      if (!/^video\//.test(f.type) && !/\.(mp4|mov|webm|m4v|mkv|avi)$/i.test(f.name)) { o.note && o.note('请上传视频文件（MP4 / MOV / WEBM）'); return; }
      drop.classList.remove('has'); drop.innerHTML = '<span>上传并处理中…<br><small>视频越长越久，请稍等</small></span>';
      try {
        const r = await (await fetch('/api/upload-video', { method: 'POST', headers: { 'X-FX': '1', 'X-File-Name': encodeURIComponent(f.name) }, body: f })).json();
        if (!r.video) throw new Error(r.error || '视频处理失败');
        c.video = r.video; c.poster = r.poster; c.vdur = r.vdur; c.vw = r.w; c.vh = r.h;
        c.loop = r.vdur < (o.total() || 0);                     // 比整段动画短 → 默认打开循环
      } catch (e) { o.note && o.note('视频上传失败：' + e.message + '（需要工作台 v6.3 以上）'); }
      o.changed();
    };
    drop.onclick = () => fin.click();
    fin.onchange = () => put(fin.files[0]);
    drop.addEventListener('dragover', e => { if ([...e.dataTransfer.types].includes('Files')) { e.preventDefault(); drop.classList.add('over'); } });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', e => { if (!e.dataTransfer.files.length) return; e.preventDefault(); e.stopPropagation(); drop.classList.remove('over'); put(e.dataTransfer.files[0]); });
    body.append(drop, fin);
    if (c.video) {
      const total = o.total() || 0, d = +c.vdur || 0, short = d > 0 && d < total - 0.05;
      const row = mk('div', 'fxv-loop', '<span>无限循环</span><div class="fxv-seg"><button type="button" data-l="1">开</button><button type="button" data-l="0">关</button></div>');
      row.querySelectorAll('button').forEach(b => { b.classList.toggle('on', !!c.loop === (b.dataset.l === '1')); b.onclick = () => { c.loop = b.dataset.l === '1'; o.changed(); }; });
      const tip = mk('div', 'fxv-tip');
      tip.innerHTML = short
        ? `视频 <b>${fmt(d)}</b>，比整段动画（${fmt(total)}）短。` + (c.loop ? '已开启循环，会一直重复播放，不会黑屏。' : '没开循环：播完会停在最后一帧。')
        : `视频 ${fmt(d)}，整段动画 ${fmt(total)}，够长，一般不需要循环${d > total + 0.05 ? '（只会用到前 ' + fmt(total) + '）' : ''}；想循环也可以手动打开。`;
      const clr = mk('button', 'fxv-clr'); clr.type = 'button'; clr.textContent = '移除视频';
      clr.onclick = () => { c.video = ''; c.poster = ''; c.vdur = 0; o.changed(); };
      // 循环开关一直显示：系统按长短给默认值（短 → 开），也可以手动改
      body.append(row, tip, clr);
    }
    return body;
  };
})();
