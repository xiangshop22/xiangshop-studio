/* ===========================================================================
   fx-caption.js —— 素材上叠文字（工作台公共模块，2026-11-16 新增，FXCaption）
   ---------------------------------------------------------------------------
   做什么：把一张图片 / 一段视频当成底图，在它上面叠一段文字。
           文字有单独的开关；能改字、字号、颜色（色块，规则 24）、放在上 / 中 / 下、底下压暗一层让字看得清。
           字一律用文字转场模块 FXTrans 画（规则 39），所以 **重点**、*加粗*、~划掉~、| 换行 照样能用。
   谁在用：限制卡（effects/restrict-card）。以后任何「图片 / 视频卡上要加字」的效果都直接调它，不要再写一份。

   区域地图（想改哪里，直接说「区域Cx 怎么改」）
   【区域C1 数据】     一段叠加文字 = { on, text, size, color, pos:'top'|'mid'|'bottom', shade:0~100, glow }
                      存在这张素材自己的数据里（效果参数里的一个 JSON 字符串），撤销 / 预设 / 导出都照常带着
   【区域C2 画面】     FXCaption.draw(底图容器, 数据, { W, H, accent, font })：
                      在容器里挂一层 .fxcap（压暗渐变 + 文字），只在数据变了时重画；关着时整层藏掉，一个像素都不画
                      字太长会自动缩小，不会超出底图
   【区域C3 编辑器样式】右侧面板里这一块的样式（挂在 #params .stc 下，浅色界面自动翻转）
   【区域C4 编辑器】   FXCaption.editor({ pd, pw, read, write, title, sub })：开 / 关 + 文字 + 字号 + 颜色 + 位置 + 压暗

   其他效果怎么接（三步）：
   ① 页面里引入（效果脚本之前）：fx-cards.js → fx-skin.js → fx-transition.js → fx-caption.js
   ② 画面：底图容器（position:absolute，宽高固定，overflow:hidden）build 时调
        FXCaption.draw(容器, P.caption, { W: 宽, H: 高, accent: 主题色 })
      叠在图片 / 视频上面（容器里最后一个子元素）。每帧不用调，数据变了再调就行。
   ③ 编辑器：const cb = FXCaption.editor({ pd, pw, read: () => P.caption, write: s => { P.caption = s; …markDirty / 重画 } });
      把 cb.el 放进右侧面板，外面要有一层 .stc（fx-skin 的样式都写在 .stc 下面）。
   =========================================================================== */
(function () {
  const C = window.FXCaption = window.FXCaption || {};
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const f2 = v => Math.round(v * 100) / 100;

  // ================= 【区域C1 数据】 =================
  C.DEF = { on: false, text: '在这里写字', size: 72, color: '#ffffff', pos: 'bottom', shade: 45, glow: true };
  C.POS = [['top', '上'], ['mid', '中'], ['bottom', '下']];
  const hex = v => (typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v.trim()) ? v.trim().toLowerCase() : null);
  // raw 可以是 JSON 字符串、对象、坏数据；一律读成完整的一份
  C.read = raw => {
    let v = raw;
    if (typeof v === 'string') { try { v = JSON.parse(v); } catch (e) { v = null; } }
    if (!v || typeof v !== 'object' || Array.isArray(v)) v = {};
    const d = C.DEF, n = (x, def, lo, hi) => (Number.isFinite(+x) && x !== '' && x != null ? clamp(+x, lo, hi) : def);
    return {
      on: v.on === true,
      text: v.text == null ? d.text : String(v.text),
      size: n(v.size, d.size, 8, 400),
      color: hex(v.color) || d.color,
      pos: ['top', 'mid', 'bottom'].includes(v.pos) ? v.pos : d.pos,
      shade: n(v.shade, d.shade, 0, 100),
      glow: v.glow !== false
    };
  };
  C.str = c => JSON.stringify(C.read(c));
  C.visible = raw => { const c = C.read(raw); return c.on && !!String(c.text).replace(/[*~|\s]/g, ''); };

  // ================= 【区域C2 画面】 =================
  // 压暗：从文字那一头往另一头渐变到透明（只画一次，是一张静态的渐变）
  function shadeCss(pos, k) {
    if (!(k > 0.001)) return '';
    const a = x => `rgba(0,0,0,${f2(k * x)})`;
    if (pos === 'top') return `linear-gradient(to bottom,${a(1)} 0%,${a(0.62)} 26%,${a(0)} 56%)`;
    if (pos === 'mid') return `linear-gradient(to bottom,${a(0)} 18%,${a(0.78)} 42%,${a(0.78)} 58%,${a(0)} 82%)`;
    return `linear-gradient(to top,${a(1)} 0%,${a(0.62)} 26%,${a(0)} 56%)`;
  }
  C.draw = (host, raw, o) => {
    if (!host) return null;
    o = o || {};
    let el = host.__fxcap;
    if (!el || el.parentNode !== host) {
      el = document.createElement('div'); el.className = 'fxcap';
      el.style.cssText = 'position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:2';
      host.appendChild(el); host.__fxcap = el; el.__k = '';
    } else if (el !== host.lastElementChild) host.appendChild(el);   // 永远叠在最上面（底图换过元素也一样）
    const c = C.read(raw);
    if (!C.visible(c)) { if (el.style.display !== 'none') el.style.display = 'none'; el.__k = ''; return el; }
    const W = Math.max(10, +o.W || host.offsetWidth || 800), H = Math.max(10, +o.H || host.offsetHeight || 450);
    const key = JSON.stringify([c, W, H, o.accent || '', o.font || '']);
    if (el.style.display === 'none') el.style.display = '';
    if (el.__k === key) return el;
    el.__k = key;
    const padX = W * 0.06, padY = H * 0.07, bw = W - padX * 2;
    el.innerHTML = '';
    const sh = document.createElement('div'); sh.className = 'fxcap-sh';
    sh.style.cssText = 'position:absolute;inset:0;' + (c.shade > 0 ? 'background:' + shadeCss(c.pos, c.shade / 100) : '');
    const tx = document.createElement('div'); tx.className = 'fxcap-tx';
    tx.style.cssText = `position:absolute;left:${f2(padX)}px;width:${f2(bw)}px;top:0;height:${f2(H)}px`;
    el.append(sh, tx);
    const opt = { id: 'static', b: c.text, fs: c.size, color: c.color, accent: o.accent || '#f28c0f', bold: true,
      shadow: c.glow ? `0 ${f2(c.size * 0.04)}px ${f2(c.size * 0.2)}px rgba(0,0,0,.6)` : '' };
    if (o.font) opt.font = o.font;
    const m = C.fitText(tx, opt, bw, H - padY * 2, fs => c.glow ? `0 ${f2(fs * 0.04)}px ${f2(fs * 0.2)}px rgba(0,0,0,.6)` : '');
    const fs = m.fs;
    // 按位置摆：上 = 贴上边，中 = 正中，下 = 贴下边
    const h = Math.max(1, m.h || fs * 1.3);
    const top = c.pos === 'top' ? padY : c.pos === 'mid' ? (H - h) / 2 : H - padY - h;
    tx.style.top = f2(top) + 'px'; tx.style.height = f2(h) + 'px';
    return el;
  };

  // 把一段字放进 bw × bh 的框里：太长的行先自动折成 2~4 行（不会把 **重点** 这种标记拆开），还放不下再整体缩小。
  // 字用 FXTrans.draw 画（规则 39）；o = FXTrans.draw 的参数（b = 文字，fs = 想要的字号）；shadowOf(fs) 可选：字号变了阴影跟着变。
  // 返回 { fs: 最后用的字号, w, h: 字块实际宽高 }。只在 build 时调（会量几次尺寸），不要每帧调。
  C.wrap = (text, n) => {
    if (n <= 1) return text;
    const lines = String(text).split('|');
    const vis = l => l.replace(/\*\*|\*|~~|~/g, '');
    const maxLen = Math.max(...lines.map(l => Array.from(vis(l)).length));
    const per = Math.ceil(maxLen / n);
    return lines.map(l => {
      const toks = l.match(/\*\*|~~|\*|~|[\s\S]/gu) || [];
      const open = { '**': 0, '*': 0, '~~': 0, '~': 0 };
      const out = []; let cnt = 0;
      toks.forEach(tk => {
        if (tk in open) { open[tk] ^= 1; out.push(tk); return; }
        const free = !open['**'] && !open['*'] && !open['~~'] && !open['~'];
        if (cnt >= per && free && !/^[，。、！？；：,.!?;:）)」』》]$/.test(tk)) { out.push('|'); cnt = 0; }
        out.push(tk); cnt++;
      });
      return out.join('');
    }).join('|');
  };
  C.fitText = (el, o, bw, bh, shadowOf) => {
    const paint = (b, fs) => {
      const x = Object.assign({}, o, { b, fs });
      if (shadowOf) x.shadow = shadowOf(fs);
      if (window.FXTrans) FXTrans.draw(el, x);
      else el.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;text-align:center;font:700 ${fs}px/1.3 'PingFang SC','Microsoft YaHei',sans-serif;color:${x.color || '#fff'}">${String(b).replace(/[<>&*~]/g, '').replace(/\|/g, '<br>')}</div>`;
      const g = el.querySelector('.fxt-g') || el.firstElementChild;
      const w = g ? (g.scrollWidth || g.offsetWidth) : 0, h = g ? (g.scrollHeight || g.offsetHeight) : 0;
      return { w, h, k: Math.min(1, w > 0 ? bw / w : 1, h > 0 ? bh / h : 1) };
    };
    const text = o.b == null ? '' : String(o.b), fs0 = +o.fs || 100;
    let best = null;
    for (let n = 1; n <= 4; n++) {                                   // 试 1~4 行，挑能放得最大的
      const b = C.wrap(text, n); if (n > 1 && b === best.b) break;
      const m = paint(b, fs0); m.b = b;
      if (!best || m.k > best.k + 0.02) best = m;
      if (m.k >= 0.995) break;
    }
    let fs = fs0, m = best;
    if (best.k < 0.995 || best.b !== text) {
      fs = Math.max(6, fs0 * Math.min(1, best.k * 0.98));
      m = paint(best.b, fs);
    }
    return { fs, w: m.w, h: m.h };
  };

  // ================= 【区域C3 编辑器样式】 =================
  C.injectStyle = pd => {
    if (pd.getElementById('fcap-style')) return;
    const st = pd.createElement('style'); st.id = 'fcap-style';
    // 选择器挂在 #params .stc 下并加 !important（工作台对 input / button 有全局样式）；颜色都写在样式表里（规则 6）
    st.textContent = `
html body #params .stc .fcap-bd{margin:10px 0 0!important}
html body #params .stc .fcap.off .fcap-bd{display:none!important}
html body #params .stc .fcap-seg2{width:96px!important;flex:none!important}
html body #params .stc .fcap-ta{display:block!important;width:100%!important;box-sizing:border-box!important;min-height:58px!important;height:auto!important;margin:0!important;padding:7px 9px!important;resize:vertical!important;background:#0b0b0b!important;color:#eee!important;border:1px solid #333!important;border-radius:6px!important;font-size:13px!important;line-height:1.5!important;font-family:inherit!important}
html body #params .stc .fcap-ta:focus{border-color:#f28c0f!important;outline:none!important}
html body #params .stc .fcap-n{margin:10px 0 0!important}
html body #params .stc .fcap-nh{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;margin:0 0 4px!important;font-size:12px!important;color:#ccc!important}
html body #params .stc .fcap-nh input{width:70px!important;height:24px!important;min-height:0!important;box-sizing:border-box!important;margin:0!important;padding:0 6px!important;background:#0b0b0b!important;color:#eee!important;border:1px solid #333!important;border-radius:5px!important;font-size:12px!important;text-align:right!important}
html body #params .stc .fcap-n input[type=range]{display:block!important;width:100%!important;height:16px!important;min-height:0!important;margin:0!important;padding:0!important;background:none!important;border:0!important;accent-color:#f28c0f}
html body #params .stc .fcap-lb{margin:12px 0 6px!important;font-size:12px!important;color:#ccc!important}
html body #params .stc .fcap-sub{margin:12px 0 0!important}`;
    pd.head.appendChild(st);
  };

  // 一行数字：名字 + 数字框，下面一条滑杆，两个联动（规则 5）
  C.numRow = (pd, o) => {
    const el = pd.createElement('div'); el.className = 'fcap-n';
    el.innerHTML = `<div class="fcap-nh"><span></span><input type="number"></div><input type="range">`;
    el.querySelector('span').textContent = o.label;
    const nb = el.querySelector('input[type=number]'), rg = el.querySelector('input[type=range]');
    [nb, rg].forEach(x => { x.min = o.min; x.max = o.max; x.step = o.step || 1; });
    const set = v => { nb.value = v; rg.value = v; };
    set(o.get());
    const go = (v, done) => { v = clamp(+v, o.min, o.max); if (!Number.isFinite(v)) return; set(v); o.set(v, done); };
    rg.oninput = () => go(rg.value, false); rg.onchange = () => go(rg.value, true);
    nb.oninput = () => { if (nb.value !== '') go(nb.value, false); }; nb.onchange = () => go(nb.value === '' ? o.get() : nb.value, true);
    return { el, refresh: () => set(o.get()) };
  };

  // ================= 【区域C4 编辑器】 =================
  // o = { pd, pw, read: () => 数据（字符串或对象）, write: JSON 字符串 => 存起来并重画, title, sub, hint, presets: [{c:['#色'], name}] }
  C.editor = o => {
    const pd = o.pd, pw = o.pw;
    C.injectStyle(pd);
    if (window.FXSkin) FXSkin.injectStyle(pd);
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const cap = C.read(o.read());
    const save = () => o.write(C.str(cap));
    const el = mk('div', 'stc-b fcap');
    const head = mk('div', 'stc-t');
    head.innerHTML = `<b>${o.title || '叠加文字'}</b>`;
    const onSeg = mk('div', 'stc-seg fcap-seg2', '<button type="button" data-v="on">开</button><button type="button" data-v="off">关</button>');
    head.appendChild(onSeg);
    const bd = mk('div', 'fcap-bd');
    el.append(head, bd);
    const hint = mk('div', 'stc-note', o.sub || '图片 / 视频当底图，上面叠一段字。');
    el.insertBefore(hint, bd);

    // 文字
    const ta = mk('textarea', 'fcap-ta'); ta.rows = 2; ta.placeholder = '在这里写字';
    let composing = false;
    ta.addEventListener('compositionstart', () => { composing = true; });
    // 回车换行：存成 |，和文字转场的换行写法一致
    const take = () => {
      if (/\n/.test(ta.value)) { const p = ta.selectionStart; ta.value = ta.value.replace(/\n/g, '|'); ta.selectionStart = ta.selectionEnd = p; }
      cap.text = ta.value; save();
    };
    ta.addEventListener('compositionend', () => { composing = false; take(); });
    ta.addEventListener('input', e => { if (composing || e.isComposing) return; take(); });
    const taNote = mk('div', 'stc-note', '<b>**重点**</b> = 加粗变主题色，<b>|</b> 或回车 = 换行。也可以在预览里双击这行字直接改。');
    ta.addEventListener('keydown', e => { e.stopPropagation(); });   // 打字时不抢工作台快捷键（规则 34）

    // 字号
    const sz = C.numRow(pd, { label: '字号（px）', min: 12, max: 300, step: 1, get: () => Math.round(cap.size), set: v => { cap.size = v; save(); } });

    // 颜色（色块，规则 24）
    const presets = o.presets || [
      { c: ['#ffffff'], name: '白' }, { c: ['#111111'], name: '黑' }, { c: ['#ffd60a'], name: '亮黄' },
      { c: ['#f28c0f'], name: '橙' }, { c: ['#ff3b30'], name: '红' }, { c: ['#4cc9f0'], name: '天蓝' }, { c: ['#9be564'], name: '嫩绿' }
    ];
    let colBlk = null;
    const colHost = mk('div', 'fcap-sub');
    if (window.FXSkin && FXSkin.colorBlock) {
      colBlk = FXSkin.colorBlock({
        pd, pw, P: cap, field: () => null, bare: true, title: '文字颜色', sub: '', presets, ls: 'fx-my-colors-captext',
        keys: [{ key: 'color', name: '文字颜色', tip: '叠加文字的颜色', def: '#ffffff' }],
        apply: () => { save(); colBlk && colBlk.refresh(); }
      });
      colHost.appendChild(colBlk.el);
    }

    // 位置
    const posLb = mk('div', 'fcap-lb', '放在哪');
    const posSeg = mk('div', 'stc-seg', C.POS.map(([v, n]) => `<button type="button" data-v="${v}">${n}</button>`).join(''));
    posSeg.querySelectorAll('button').forEach(b => b.onclick = () => { cap.pos = b.dataset.v; save(); sync(); });

    // 压暗
    const shd = C.numRow(pd, { label: '字后面压暗（%）', min: 0, max: 100, step: 1, get: () => Math.round(cap.shade), set: v => { cap.shade = v; save(); } });
    const glow = mk('label', 'stc-ck', '<input type="checkbox"><span>字带一圈柔和阴影（亮底上也看得清）</span>');
    const gk = glow.querySelector('input'); gk.onchange = () => { cap.glow = gk.checked; save(); };

    bd.append(ta, taNote, sz.el, colHost, posLb, posSeg, shd.el, glow);

    const sync = () => {
      onSeg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === (cap.on ? 'on' : 'off')));
      el.classList.toggle('off', !cap.on);
      posSeg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === cap.pos));
      if (pd.activeElement !== ta) ta.value = cap.text;
      gk.checked = cap.glow;
    };
    onSeg.querySelectorAll('button').forEach(b => b.onclick = () => {
      cap.on = b.dataset.v === 'on'; save(); sync();
      if (cap.on) setTimeout(() => { try { ta.focus(); ta.select(); } catch (e) {} }, 0);
    });
    const refresh = () => { Object.assign(cap, C.read(o.read())); sync(); sz.refresh(); shd.refresh(); colBlk && colBlk.refresh(); };
    sync();
    return { el, refresh };
  };
})();
