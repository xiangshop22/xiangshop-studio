/* 效果工坊 · 缓动库 FXEase（v53.0 新加，所有效果都能用）
 * ===========================================================================
 * 【区域Z1 清单】   FXEase.LIST：面板里给用户选的缓动方式 [id, 中文名, 一句话]
 * 【区域Z2 快进慢停】FXEase.tail(p, o)：刚开始很快，离终点还剩 o.tail 像素时变得很慢、缓缓走完
 *                    o = { dist: 总共走多少像素, tail: 最后慢走的那一段（像素，默认 28）,
 *                          part: 慢走那一段占总时间的比例（0~0.9，默认 0.55）, pow: 慢段的弯曲程度（默认 3） }
 *                    前一段和慢段在交界处速度一样，看不出接缝
 * 【区域Z3 统一入口】FXEase.at(id, p, o)：按 id 算，返回 0~1（走了总距离的几成）
 * 用法：k = FXEase.at(P.ease || 'tail', 进度, { dist: 520, tail: 28, part: 0.55 })，再按 k 去算位置。
 * 只是纯函数，没有画面、没有 DOM，不引用它的效果一个像素都不变。
 * =========================================================================== */
(function () {
  if (window.FXEase) return;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const E = window.FXEase = {};

  // 【区域Z1 清单】
  E.LIST = [
    ['tail', '快进慢停', '刚入画很快，快到终点时缓缓走完最后一小段'],
    ['out', '缓出', '越来越慢（普通的缓出）'],
    ['inout', '缓入缓出', '慢 → 快 → 慢'],
    ['back', '回弹', '冲过一点再弹回来'],
    ['linear', '匀速', '一直一个速度']
  ];

  // 【区域Z2 快进慢停】
  E.tail = (p, o) => {
    p = clamp(+p || 0, 0, 1); o = o || {};
    const D = Math.max(1, +o.dist || 600), tl = clamp(+o.tail || 28, 0, D), part = clamp(o.part == null ? 0.55 : +o.part, 0, 0.9);
    const n = clamp(+o.pow || 3, 1.5, 8);
    if (p >= 1) return 1;
    if (tl <= 0 || part <= 0) return 1 - Math.pow(1 - p, 2);                // 没有慢段 = 普通缓出
    const A = D - tl, T1 = 1 - part;
    if (A <= 0.5) return 1 - Math.pow(1 - p, n);                              // 总距离比慢段还短：整段都慢慢走
    const v1 = tl * n / part;                                                  // 慢段开头的速度（像素 / 单位时间）
    const a = clamp(2 - v1 * T1 / A, 0, 2);                                    // 前一段 s = A(a·u + (1-a)·u²)，末速度 = v1
    if (p < T1) { const u = p / T1; return A * (a * u + (1 - a) * u * u) / D; }
    const q = (p - T1) / part;
    return (A + tl * (1 - Math.pow(1 - q, n))) / D;
  };

  // 【区域Z3 统一入口】
  E.at = (id, p, o) => {
    p = clamp(+p || 0, 0, 1);
    switch (id) {
      case 'linear': return p;
      case 'out': return 1 - Math.pow(1 - p, 3);
      case 'inout': return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
      case 'back': { const c = 1.70158, x = p - 1; return 1 + (c + 1) * x * x * x + c * x * x; }
      default: return E.tail(p, o);
    }
  };
})();
