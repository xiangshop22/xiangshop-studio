/* =====================================================================
 * fx-arm.js · 手臂公共模块（全局 FXArm）——2026-11-16 新建
 * ---------------------------------------------------------------------
 * 从圆卡（或任何东西）后面伸出来的两条粘土质感手臂：张开的手 / 拳头 / 两只手握在一起，
 * 加上「啪」一下的撞击效果。全部是 SVG 矢量（放大不发虚，规则 36），颜色跟着传进来的颜色走。
 * 现在谁在用：圆形闪光换色卡 round-flash-card 的「合作 · 握手」「对抗 · 撞拳」。
 *
 * 【A1 小工具】      颜色混合、两节骨头的关节计算 ik()
 * 【A2 手臂形状】    大臂（带二头肌）/ 小臂 的轮廓，按骨头长度 a、b 和手腕粗细 h 生成
 * 【A3 手的形状】    张开的手 open / 拳头 fist / 握手 grip（两只手扣在一起，左 = 手臂 1，右 = 手臂 2）
 * 【A4 撞击效果】    clap（击掌：白光 + 短线）/ clash（对撞：白光 + 火花线 + 冲击波圈）/ glow（较劲时的光）
 * 【A6 imgRig()】 有 fx-arm-img.js 素材时用图片手臂（AI 生成的粘土手臂，按卡片颜色现换色），没有就用上面的矢量手臂
 * 【A5 rig()】      建好整套 SVG，返回 { under, over, set(pose) }：
 *                    under = 放在卡片「下面」的那层（手臂、手、握手），over = 放在卡片「上面」的那层（撞击效果）
 *
 * pose = {
 *   mx: 镜像中线的 x（手臂 2 是照着手臂 1 左右翻过来画的，所以「朝对方」永远是角度 0、「朝上」是 -90）,
 *   arms: [ { S:{x,y} 肩膀（藏在卡片后面）, W:{x,y} 手腕要去的地方, a, b 大臂 / 小臂长, ha 手的角度（度，自己的朝向）,
 *             open 0~1 张开的手的透明度, fist 0~1 拳头的透明度, grow 0~1 伸出来了多少, op 0~1 整条手臂透明度 }, … ],
 *   grip: { op 0~1, x, y }      握手（两只手扣在一起）的位置；op > 0 时两条手臂自己的手应该已经淡掉
 *   hits: [ { kind:'clap'|'clash', x, y, k 0~1 进度, s 大小 } ],  glow: { x, y, op, s }
 * }
 * 每帧只写 transform / opacity / 少量圆的半径（规则 16）。
 * ===================================================================== */
(function () {
  if (window.FXArm) return;
  const A = window.FXArm = {};
  const NS = 'http://www.w3.org/2000/svg';
  let UID = 0;

  // ================= 【A1 小工具】 =================
  const rgb = c => Array.isArray(c) ? c : (() => { const m = String(c || '').replace('#', ''); const v = m.length === 3 ? m.split('').map(x => x + x).join('') : m.padEnd(6, '0');
    return [parseInt(v.slice(0, 2), 16) || 0, parseInt(v.slice(2, 4), 16) || 0, parseInt(v.slice(4, 6), 16) || 0]; })();
  const mix = (a, b, k) => a.map((v, i) => Math.round(v + (b[i] - v) * k));
  const hex = c => '#' + c.map(v => Math.max(0, Math.min(255, v)).toString(16).padStart(2, '0')).join('');
  const W3 = [255, 255, 255], K3 = [0, 0, 0];
  A.rgb = rgb;
  // 两节骨头（大臂 a、小臂 b）：肩膀 S 不动，手腕尽量够到 T；手肘朝下（y 大的那一边）。够不着就伸直指过去
  A.ik = (S, T, a, b) => {
    const dx = T.x - S.x, dy = T.y - S.y, D0 = Math.hypot(dx, dy) || 1e-6;
    const D = Math.max(Math.abs(a - b) + 1e-3, Math.min(a + b - 1e-3, D0));
    const base = Math.atan2(dy, dx), c = Math.max(-1, Math.min(1, (a * a + D * D - b * b) / (2 * a * D))), off = Math.acos(c);
    const pick = s => { const th = base + s * off, E = { x: S.x + a * Math.cos(th), y: S.y + a * Math.sin(th) }; return { th, E }; };
    const p1 = pick(1), p2 = pick(-1), p = p1.E.y >= p2.E.y ? p1 : p2;      // 手肘朝下
    const Wx = S.x + dx / D0 * D, Wy = S.y + dy / D0 * D;
    return { E: p.E, W: { x: Wx, y: Wy }, th1: p.th, th2: Math.atan2(Wy - p.E.y, Wx - p.E.x) };
  };

  // ================= 【A2 手臂形状】骨头沿 +x，上边（-y）是二头肌那一侧 =================
  const f = v => (+v).toFixed(2);
  const upperPath = (a, h) => `M0 ${f(-0.95 * h)} C${f(0.25 * a)} ${f(-1.25 * h)} ${f(0.62 * a)} ${f(-1.3 * h)} ${f(a)} ${f(-0.74 * h)}`
    + ` L${f(a)} ${f(0.66 * h)} C${f(0.66 * a)} ${f(0.98 * h)} ${f(0.3 * a)} ${f(0.98 * h)} 0 ${f(0.92 * h)}`
    + ` C${f(-1.2 * h)} ${f(0.92 * h)} ${f(-1.2 * h)} ${f(-0.95 * h)} 0 ${f(-0.95 * h)}Z`;
  const forePath = (b, h) => { const x0 = -0.05 * b;
    return `M${f(x0)} ${f(-0.76 * h)} C${f(0.22 * b)} ${f(-0.98 * h)} ${f(0.58 * b)} ${f(-0.72 * h)} ${f(b)} ${f(-0.5 * h)}`
      + ` C${f(b + 0.22 * h)} ${f(-0.45 * h)} ${f(b + 0.22 * h)} ${f(0.45 * h)} ${f(b)} ${f(0.5 * h)} C${f(0.62 * b)} ${f(0.6 * h)} ${f(0.25 * b)} ${f(0.8 * h)} ${f(x0)} ${f(0.7 * h)}`
      + ` C${f(x0 - 0.98 * h)} ${f(0.7 * h)} ${f(x0 - 0.98 * h)} ${f(-0.76 * h)} ${f(x0)} ${f(-0.76 * h)}Z`; };

  // ================= 【A3 手的形状】单位 = 手腕粗细；手腕在原点，手指朝 +x，大拇指在上（-y） =================
  const cap = (x, y, len, w, ang, fill, extra) => `<g transform="translate(${f(x)} ${f(y)}) rotate(${f(ang)})"><rect x="${f(-w / 2)}" y="${f(-w / 2)}" width="${f(len + w / 2)}" height="${f(w)}" rx="${f(w / 2)}" fill="${fill}"${extra || ''}/></g>`;
  const handOpen = (g, st) =>
      `<path d="M-0.35 -0.46 L-0.05 -0.48 C0.35 -0.58 0.75 -0.62 1.02 -0.55 L1.08 0.5 C0.7 0.6 0.3 0.6 -0.05 0.5 L-0.35 0.48Z" fill="${g}"${st}/>`
    + cap(0.92, -0.4, 0.9, 0.27, -15, g, st) + cap(0.97, -0.13, 1.05, 0.28, -5, g, st)
    + cap(0.97, 0.14, 0.98, 0.27, 5, g, st) + cap(0.92, 0.4, 0.76, 0.24, 15, g, st)
    + cap(0.32, -0.42, 0.82, 0.31, -52, g, st)
    + `<path d="M0.55 -0.25 Q0.7 -0.05 0.6 0.25" fill="none" stroke="rgba(0,0,0,.22)" stroke-width="0.04" stroke-linecap="round"/>`
    + `<ellipse cx="0.45" cy="-0.28" rx="0.32" ry="0.12" fill="#fff" opacity=".18"/>`;
  const handFist = (g, st) => {
    let s = `<rect x="-0.4" y="-0.62" width="1.36" height="1.24" rx="0.42" fill="${g}"${st}/>`;
    for (let i = 0; i < 4; i++){ const y = -0.6 + i * 0.3; s += `<rect x="0.62" y="${f(y)}" width="0.6" height="0.31" rx="0.155" fill="${g}"${st}/>`
      + `<ellipse cx="1.06" cy="${f(y + 0.1)}" rx="0.1" ry="0.045" fill="#fff" opacity=".25"/>`; }
    s += cap(0.12, -0.5, 0.72, 0.3, 26, g, st);
    s += `<ellipse cx="0.2" cy="-0.38" rx="0.32" ry="0.1" fill="#fff" opacity=".2"/>`;
    return s;
  };
  // 握手：左手（手臂 1，手腕在 x = -1）手背朝外，右手（手臂 2，手腕在 x = +1）的四根手指从上面绕过来扣住左手手背
  const handGrip = (g1, g2, s1, s2) =>
      cap(0.08, 0.28, 0.4, 0.22, 88, g1, s1) + cap(0.3, 0.3, 0.38, 0.22, 86, g1, s1) + cap(0.52, 0.3, 0.32, 0.21, 84, g1, s1)   // 左手指尖从右手下面露出来
    + `<path d="M1.3 -0.44 C0.9 -0.5 0.3 -0.46 -0.15 -0.4 C-0.5 -0.34 -0.5 0.52 -0.15 0.58 C0.3 0.6 0.9 0.58 1.3 0.5Z" fill="${g2}"${s2}/>`                    // 右手掌
    + `<path d="M-1.35 -0.5 L-1 -0.52 C-0.5 -0.62 0 -0.64 0.3 -0.52 C0.5 -0.32 0.5 0.4 0.28 0.52 C-0.1 0.62 -0.6 0.6 -1 0.52 L-1.35 0.5Z" fill="${g1}"${s1}/>`   // 左手背
    + `<ellipse cx="-0.35" cy="-0.3" rx="0.38" ry="0.12" fill="#fff" opacity=".18"/>`
    + cap(-0.32, -0.46, 0.92, 0.27, -6, g1, s1)                                                                            // 左手大拇指压在右手上面
    + [0, 1, 2, 3].map(i => cap(-0.02 - i * 0.2, -0.6 + i * 0.03, 0.95 - i * 0.08, 0.24, 102 + i * 3, g2, s2)).join('')       // 右手四根手指扣住左手背
    + `<path d="M-0.05 -0.55 Q0.1 -0.62 0.25 -0.52" fill="none" stroke="#fff" stroke-width="0.05" opacity=".25" stroke-linecap="round"/>`;

  // ================= 【A5 rig】建好整套 SVG =================
  // o = { doc, W, H, colors: [颜色1, 颜色2], h: 手腕粗细(px), hand: 手的大小倍数（默认 1.08）}
  A.rig = o => {
    const doc = o.doc || document, W = o.W || 1920, H = o.H || 1080, h = o.h || 48, hk = o.hand || 1.08, id = 'fxa' + (++UID);
    const cols = (o.colors || ['#2f6cd0', '#d0402f']).map(rgb);
    const mkSvg = z => { const s = doc.createElementNS(NS, 'svg'); s.setAttribute('viewBox', `0 0 ${W} ${H}`); s.setAttribute('width', W); s.setAttribute('height', H);
      s.style.cssText = `position:absolute;left:0;top:0;width:${W}px;height:${H}px;overflow:visible;pointer-events:none;z-index:${z}`; return s; };
    const under = mkSvg(0), over = mkSvg(3);
    // 每条手臂两套渐变：手臂用像素单位（骨头坐标系里 y 从 -1.3h 到 h），手用「手腕粗细」单位
    const grad = (gid, c, y1, y2) => `<linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="0" y1="${f(y1)}" x2="0" y2="${f(y2)}">`
      + `<stop offset="0" stop-color="${hex(mix(c, W3, 0.5))}"/><stop offset=".28" stop-color="${hex(mix(c, W3, 0.16))}"/>`
      + `<stop offset=".62" stop-color="${hex(c)}"/><stop offset="1" stop-color="${hex(mix(c, K3, 0.5))}"/></linearGradient>`;
    let defs = '';
    cols.forEach((c, i) => { defs += grad(`${id}a${i}`, c, -1.3 * h, 1.0 * h) + grad(`${id}h${i}`, c, -0.75, 0.75); });
    under.innerHTML = `<defs>${defs}</defs>`;
    const stA = i => ` stroke="${hex(mix(cols[i], K3, 0.55))}" stroke-width="1.6" stroke-linejoin="round"`;
    const stH = i => ` stroke="${hex(mix(cols[i], K3, 0.55))}" stroke-width="0.035" stroke-linejoin="round"`;
    const G = (p, attrs) => { const g = doc.createElementNS(NS, 'g'); if (attrs) for (const k in attrs) g.setAttribute(k, attrs[k]); p.appendChild(g); return g; };
    const grip = G(under);   // 握手放在两条手臂下面：小臂末端盖住手掌根部
    const arms = cols.slice(0, 2).map((c, i) => {
      const wrap = G(under), ext = G(wrap), up = G(ext), hand = G(ext), fo = G(ext);   // 手在小臂下面：小臂的末端盖住手掌根部，接缝看不出来
      const ho = G(hand), hf = G(hand);
      ho.innerHTML = handOpen(`url(#${id}h${i})`, stH(i)); hf.innerHTML = handFist(`url(#${id}h${i})`, stH(i));
      if (i === 1) wrap.setAttribute('opacity', '1');
      return { i, wrap, ext, up, fo, hand, ho, hf, a: 0, b: 0, c };
    });
    grip.innerHTML = handGrip(`url(#${id}h0)`, `url(#${id}h1)`, stH(0), stH(1));
    // 撞击效果（盖在卡片上面）
    over.innerHTML = `<defs><radialGradient id="${id}fl2"><stop offset="0" stop-color="#fff" stop-opacity="1"/><stop offset=".3" stop-color="#fff" stop-opacity=".8"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>`
      + `<radialGradient id="${id}gl"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset=".25" stop-color="${hex(mix(cols[0], W3, 0.5))}" stop-opacity=".6"/><stop offset=".6" stop-color="${hex(mix(cols[1], W3, 0.4))}" stop-opacity=".25"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs>`;
    const fxg = G(over);
    const glow = doc.createElementNS(NS, 'circle'); glow.setAttribute('fill', `url(#${id}gl)`); fxg.appendChild(glow);
    const fl = doc.createElementNS(NS, 'circle'); fl.setAttribute('fill', `url(#${id}fl2)`); fxg.appendChild(fl);
    const ring = doc.createElementNS(NS, 'circle'); ring.setAttribute('fill', 'none'); ring.setAttribute('stroke', '#fff'); fxg.appendChild(ring);
    const NL = 12, lines = [];
    for (let i = 0; i < NL; i++){ const l = doc.createElementNS(NS, 'line'); l.setAttribute('stroke', '#fff'); l.setAttribute('stroke-linecap', 'round'); fxg.appendChild(l); lines.push(l); }
    // 只在数值变了才写（规则 16）
    const sa = (el, k, v) => { const key = '__' + k; if (el[key] !== v){ el[key] = v; el.setAttribute(k, v); } };
    const hideFx = () => { sa(fl, 'opacity', '0'); sa(ring, 'opacity', '0'); lines.forEach(l => sa(l, 'opacity', '0')); };
    const R = { under, over, h };
    R.set = pose => {
      const mx = pose.mx;
      (pose.arms || []).forEach((p, i) => {
        const r = arms[i]; if (!r) return;
        const op = Math.max(0, Math.min(1, p.op == null ? 1 : p.op)) * (p.grow > 0 ? 1 : 0);
        sa(r.wrap, 'opacity', op.toFixed(3));
        if (op <= 0.001) return;
        // 手臂 2：在镜像空间里算（朝对方 = 角度 0），整条手臂左右翻过来画
        const X = v => i === 1 ? 2 * mx - v : v;
        sa(r.wrap, 'transform', i === 1 ? `translate(${f(2 * mx)} 0) scale(-1 1)` : '');
        const S = { x: X(p.S.x), y: p.S.y }, T = { x: X(p.W.x), y: p.W.y };
        if (r.a !== p.a || r.b !== p.b){ r.a = p.a; r.b = p.b;
          r.up.innerHTML = `<path d="${upperPath(p.a, h)}" fill="url(#${id}a${i})"${stA(i)}/>`
            + `<ellipse cx="${f(0.45 * p.a)}" cy="${f(-0.72 * h)}" rx="${f(0.26 * p.a)}" ry="${f(0.2 * h)}" fill="#fff" opacity=".2"/>`
            + `<path d="M${f(0.1 * p.a)} ${f(0.25 * h)} Q${f(0.5 * p.a)} ${f(0.5 * h)} ${f(0.92 * p.a)} ${f(0.12 * h)}" fill="none" stroke="#000" stroke-opacity=".18" stroke-width="${f(0.07 * h)}" stroke-linecap="round"/>`;
          r.fo.innerHTML = `<path d="${forePath(p.b, h)}" fill="url(#${id}a${i})"${stA(i)}/>`
            + `<ellipse cx="${f(0.3 * p.b)}" cy="${f(-0.5 * h)}" rx="${f(0.22 * p.b)}" ry="${f(0.14 * h)}" fill="#fff" opacity=".18"/>`; }
        const k = A.ik(S, T, p.a, p.b), deg = v => f(v * 180 / Math.PI);
        sa(r.up, 'transform', `translate(${f(S.x)} ${f(S.y)}) rotate(${deg(k.th1)})`);
        sa(r.fo, 'transform', `translate(${f(k.E.x)} ${f(k.E.y)}) rotate(${deg(k.th2)})`);
        sa(r.hand, 'transform', `translate(${f(k.W.x)} ${f(k.W.y)}) rotate(${f(p.ha || 0)}) scale(${f(h * hk)})`);
        const g = Math.max(0, Math.min(1.3, p.grow == null ? 1 : p.grow));
        sa(r.ext, 'transform', g >= 0.999 && g <= 1.001 ? '' : `translate(${f(S.x)} ${f(S.y)}) scale(${g.toFixed(4)}) translate(${f(-S.x)} ${f(-S.y)})`);
        sa(r.ho, 'opacity', Math.max(0, Math.min(1, p.open || 0)).toFixed(3));
        sa(r.hf, 'opacity', Math.max(0, Math.min(1, p.fist || 0)).toFixed(3));
        r.W = k.W;
      });
      const gp = pose.grip || { op: 0 };
      sa(grip, 'opacity', Math.max(0, Math.min(1, gp.op || 0)).toFixed(3));
      if (gp.op > 0.001) sa(grip, 'transform', `translate(${f(gp.x)} ${f(gp.y)}) scale(${f(h * hk)})`);
      // 撞击效果：同一时间只画最新的一个
      const hit = (pose.hits || []).filter(q => q && q.k > 0 && q.k < 1).pop();
      if (!hit) hideFx();
      else {
        const k = hit.k, s = hit.s || 60, big = hit.kind === 'clash', x = hit.x, y = hit.y;
        const fk = Math.pow(1 - k, 2);
        sa(fl, 'cx', f(x)); sa(fl, 'cy', f(y)); sa(fl, 'r', f(s * (big ? 1.6 : 1.1) * (0.5 + 0.9 * Math.sqrt(k))));
        sa(fl, 'opacity', (fk * (big ? 1 : 0.9)).toFixed(3));
        sa(ring, 'cx', f(x)); sa(ring, 'cy', f(y)); sa(ring, 'r', f(s * (big ? 0.4 + 3.2 * Math.sqrt(k) : 0.3 + 1.6 * k)));
        sa(ring, 'stroke-width', f(s * (big ? 0.16 : 0.08) * (1 - k) + 0.5)); sa(ring, 'opacity', ((1 - k) * (big ? 0.85 : 0.55)).toFixed(3));
        lines.forEach((l, i) => {
          const n = big ? NL : 8; if (i >= n){ sa(l, 'opacity', '0'); return; }
          const ang = (i / n) * Math.PI * 2 + (big ? 0.13 : 0.39) + (i % 2) * 0.12;
          const len = s * (big ? (0.7 + 0.5 * ((i * 37) % 7) / 7) : 0.45) * (1 - k * 0.6);
          const r0 = s * (big ? 0.55 + 1.9 * Math.sqrt(k) : 0.6 + 0.9 * k);
          sa(l, 'x1', f(x + Math.cos(ang) * r0)); sa(l, 'y1', f(y + Math.sin(ang) * r0));
          sa(l, 'x2', f(x + Math.cos(ang) * (r0 + len))); sa(l, 'y2', f(y + Math.sin(ang) * (r0 + len)));
          sa(l, 'stroke-width', f(s * (big ? 0.09 : 0.07) * (1 - k) + 0.6)); sa(l, 'opacity', (Math.min(1, (1 - k) * 1.4)).toFixed(3));
        });
      }
      const gl = pose.glow || { op: 0 };
      sa(glow, 'opacity', Math.max(0, Math.min(1, gl.op || 0)).toFixed(3));
      if (gl.op > 0.001){ sa(glow, 'cx', f(gl.x)); sa(glow, 'cy', f(gl.y)); sa(glow, 'r', f(gl.s || 80)); }
    };
    R.wrist = i => arms[i] && arms[i].W;
    return R;
  };

  // ================= 【A6 图片手臂】用 fx-arm-img.js 里的素材（AI 生成的粘土手臂，存成「明暗图」）=================
  // 有素材（window.FXArmImg）就用图片，没有就退回上面画的矢量手臂。
  // 换色：每个像素只保留明暗 k（1 = 平均亮度），颜色换成卡片的颜色：比平均暗 = 颜色 × k，比平均亮 = 往白色推（高光）。
  //       加载时每种颜色算一次，存在画布里，播放时每帧只写 transform / opacity。
  const TINT = {};
  const imgOf = key => { const m = window.FXArmImg && FXArmImg[key]; if (!m) return null;
    if (!m.__p) m.__p = new Promise(res => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = m.src; }); return m.__p; };
  A.hasImg = () => !!(window.FXArmImg && FXArmImg.fist && FXArmImg.raise && FXArmImg.gripL && FXArmImg.gripR);
  // cut（可选）：{ x0 } = 图里 x 小于它的部分淡掉（肩膀那头太长、会从卡片另一边露出来时用）；{ x1 } = x 大于它的淡掉（握手图右手臂）
  A.tint = (key, col, doc, cut) => {
    const c = rgb(col), x0 = cut && cut.x0 > 0 ? Math.round(cut.x0) : 0, x1 = cut && cut.x1 > 0 ? Math.round(cut.x1) : 0, id = key + '|' + c.join(',') + '|' + x0 + '|' + x1;
    if (TINT[id]) return TINT[id];
    return TINT[id] = imgOf(key).then(im => {
      const m = FXArmImg[key], cv = (doc || document).createElement('canvas'); cv.width = m.w; cv.height = m.h;
      if (!im) return cv;
      const x = cv.getContext('2d'); x.drawImage(im, 0, 0);
      const d = x.getImageData(0, 0, m.w, m.h), a = d.data, t = c.map(v => v / 255), hk = 0.85 / Math.max(0.05, m.kmax - 1);
      for (let i = 0; i < a.length; i += 4){
        if (!a[i + 3]) continue;
        if (x0 || x1){ const px = (i >> 2) % m.w, fd = 50;
          const kk = Math.min(x0 ? Math.max(0, Math.min(1, (px - x0) / fd)) : 1, x1 ? Math.max(0, Math.min(1, (x1 - px) / fd)) : 1);
          if (kk < 1) a[i + 3] = Math.round(a[i + 3] * kk); }
        const k = a[i] / 128;
        for (let j = 0; j < 3; j++) a[i + j] = 255 * (k <= 1 ? t[j] * k : t[j] + (1 - t[j]) * Math.min(1, (k - 1) * hk));
      }
      x.putImageData(d, 0, 0); return cv;
    });
  };
  // o = { doc, colors: [色1, 色2], T: 小臂要画多粗（像素）, over: 手臂比能藏下的长了多少（画面像素，肩膀那头淡掉这么多）}
  // 返回 { el（放在卡片下面）, ready（换色画完的 Promise）, set(pose), sc(key) 这张图的缩放, A(key, 锚点名) 锚点 }
  // pose = { arms: [{ key: 'fist' | 'raise', x, y（S 肩膀这个锚点放在画面哪里）, rot（度，自己的朝向：顺时针为正）, g（伸出来的缩放）, op }],
  //          grip: { x, y（G 握手中心）, rot, op } }；手臂 2 自动左右翻过来（照着手臂 1 的样子画）
  A.imgRig = o => {
    const doc = o.doc || document, cols = (o.colors || ['#2f6cd0', '#d0402f']), T = o.T || 80;
    const el = doc.createElement('div'); el.style.cssText = 'position:absolute;left:0;top:0;width:1920px;height:1080px;pointer-events:none;z-index:0';
    const sc = key => T / FXArmImg[key].T;
    const mkHolder = (key, anchor, parent, z) => {
      const m = FXArmImg[key], k = sc(key) * (z || 1), h = doc.createElement('div');
      h.style.cssText = `position:absolute;left:${(-m[anchor][0] * k).toFixed(2)}px;top:${(-m[anchor][1] * k).toFixed(2)}px;width:${(m.w * k).toFixed(2)}px;height:${(m.h * k).toFixed(2)}px;`
        + `transform-origin:${(m[anchor][0] * k).toFixed(2)}px ${(m[anchor][1] * k).toFixed(2)}px;opacity:0;will-change:transform,opacity`;
      (parent || el).appendChild(h); return h;
    };
    const put = (h, cv) => { cv.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%'; h.appendChild(cv); };
    const loads = [], over = Math.max(0, o.over || 0);
    const cutOf = key => { const ov = over + (key === 'fist' ? Math.max(0, o.fistTail || 0) : 0); if (!ov) return null;   // fistTail：握拳手臂肩膀那头本来就藏着，多淡掉一截，蓄力往后缩时不会从卡片下面露出来
      const m = FXArmImg[key], k = sc(key) * (key === 'gripL' || key === 'gripR' ? 1.12 : 1), d0 = ov / k + 30;
      return key === 'gripR' ? { x1: m.w - d0 } : { x0: (key === 'gripL' ? 0 : m.S[0]) + d0 }; };
    const arms = [0, 1].map(i => {
      const r = { fist: mkHolder('fist', 'S'), raise: mkHolder('raise', 'S') };
      ['fist', 'raise'].forEach(k => loads.push(A.tint(k, cols[i], doc, cutOf(k)).then(cv => put(r[k], cv))));
      return r;
    });
    // 握手：两只手臂在一张图里（左 = 手臂 1 的颜色，右 = 手臂 2 的颜色），锚点 G = 两只手扣在一起的中心
    const grip = mkHolder('gripL', 'G', null, 1.12);   // 握手图稍微放大一点，和举手时的手臂看起来一样壮
    const gl = doc.createElement('div'), gr = doc.createElement('div'); gl.style.cssText = gr.style.cssText = 'position:absolute;inset:0'; grip.append(gl, gr);
    loads.push(A.tint('gripL', cols[0], doc, cutOf('gripL')).then(cv => put(gl, cv)), A.tint('gripR', cols[1], doc, cutOf('gripR')).then(cv => put(gr, cv)));
    const st = (h, tr, op) => { op = Math.max(0, Math.min(1, op)).toFixed(3); if (h.__op !== op){ h.__op = op; h.style.opacity = op; }
      if (+op > 0 && h.__tr !== tr){ h.__tr = tr; h.style.transform = tr; } };
    const R = { el, ready: Promise.all(loads), sc, A: (key, a) => FXArmImg[key][a] };
    R.set = pose => {
      (pose.arms || []).forEach((p, i) => { const r = arms[i]; if (!r) return;
        ['fist', 'raise'].forEach(k => {
          const on = p.key === k ? (p.op == null ? 1 : p.op) * (p.g > 0 ? 1 : 0) : 0;
          st(r[k], `translate(${f(p.x)}px,${f(p.y)}px)${i ? ' scaleX(-1)' : ''} rotate(${f(p.rot || 0)}deg) scale(${(p.g == null ? 1 : p.g).toFixed(4)})`, on);
        });
      });
      const g = pose.grip || { op: 0 };
      st(grip, `translate(${f(g.x || 0)}px,${f(g.y || 0)}px) rotate(${f(g.rot || 0)}deg)`, g.op || 0);
    };
    return R;
  };

  // ================= 【A7 拔河素材】pull 用力往回拉 / strain 被往前拽：手臂按颜色换色，绳子（pullRope / strainRope）保持原色 =================
  A.hasTug = () => !!(window.FXArmImg && FXArmImg.pull && FXArmImg.strain && FXArmImg.pullRope && FXArmImg.strainRope && FXArmImg.ropeTile);
  // 一块图：锚点 anchor 放在 (0,0)，返回 { el, ready, k 缩放 }。overlay = 同尺寸的原色图（绳子）叠在上面；cut = 换色时淡掉哪一截（同 A.tint）
  A.imgPart = o => {
    const doc = o.doc || document, m = FXArmImg[o.key], k = o.T / m.T, a = m[o.anchor || 'S'];
    const h = doc.createElement('div');
    h.style.cssText = `position:absolute;left:${(-a[0] * k).toFixed(2)}px;top:${(-a[1] * k).toFixed(2)}px;width:${(m.w * k).toFixed(2)}px;height:${(m.h * k).toFixed(2)}px;`
      + `transform-origin:${(a[0] * k).toFixed(2)}px ${(a[1] * k).toFixed(2)}px;opacity:0;will-change:transform,opacity`;
    const ready = A.tint(o.key, o.color, doc, o.cut).then(cv => { cv.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%'; h.insertBefore(cv, h.firstChild); });
    if (o.overlay){ const im = doc.createElement('img'); im.src = FXArmImg[o.overlay].src; im.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%'; h.appendChild(im); }
    return { el: h, ready, k, m };
  };
})();
