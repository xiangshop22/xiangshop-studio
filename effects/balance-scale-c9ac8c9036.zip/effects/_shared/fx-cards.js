/* 效果工坊 · 卡片类效果共用工具（fx-cards.js）
 *
 * 所有「卡片飞入」类效果共用这一套：三种卡（文字 / 照片 / 视频）、内容不够时的循环填充、
 * 节奏时间轴、卡片编辑器。效果自己只负责「卡片摆在哪、怎么动」。
 *
 * 【区域C1 数据】读参数里的卡片内容 → 规范成 { count, items, ui }
 * 【区域C2 填充】内容数量和卡片数量对不齐时，用已有的内容循环填充，绝不留空白卡片
 * 【区域C3 节奏】每张卡片的 进场 / 停留 / 退出 时间点（和发牌展开一致）
 * 【区域C4 画面】卡片外观：文字卡 / 照片卡 / 视频卡 / 占位卡，和文字标记（**重点** 等）
 * 【区域C5 编辑器】右侧面板里的卡片编辑器：数量、三种卡切换、上传、节奏、每张单独调时长
 * 【区域C6 大小和位置】上传照片 / 视频后弹窗：滚轮缩放、左键拖动、镜像 / 上下翻转 / 旋转 90°，确定后卡片里就按这个构图显示（FX.crop / FX.place）
 *
 * 效果里的用法（见各效果 effect.html 开头的区域地图）：
 *   const D = FXCards.read(P, { min:1, max:12, def:6 });      // 读内容
 *   const list = FXCards.fill(D.items, 张数);                  // 按张数填充，不留空
 *   const TM = FXCards.timing(list, D.ui, P, 要不要退场);       // 节奏
 *   FXCards.card(卡片元素, 内容, { W, H, ... , loads });        // 画一张卡
 *   FXCards.editor({ ... });                                   // 挂编辑器
 */
(function () {
  const FX = {};
  window.FXCards = FX;

  // ---------- 小工具 ----------
  const num = FX.num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const clamp = FX.clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const prog = FX.prog = (t, a, b) => (b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1));
  const lerp = FX.lerp = (a, b, k) => a + (b - a) * k;
  FX.backOut = s => x => 1 + (s + 1) * Math.pow(x - 1, 3) + s * Math.pow(x - 1, 2);   // GSAP back.out(s)
  FX.backIn = s => x => (s + 1) * x * x * x - s * x * x;                              // GSAP back.in(s)
  FX.cubicOut = x => 1 - Math.pow(1 - x, 3);
  FX.cubicIn = x => x * x * x;
  FX.cubicInOut = x => x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
  FX.smooth = x => x * x * (3 - 2 * x);
  // 固定随机：同一个种子永远得到同一串数，保证逐帧导出和预览完全一致
  FX.rnd = (seed, k) => {
    let h = (seed * 374761393 + k * 668265263) >>> 0;
    h = (h ^ (h >>> 13)) >>> 0; h = Math.imul(h, 1274126177) >>> 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  FX.rndAt = (seed, k, a, b) => a + (b - a) * FX.rnd(seed, k);
  // 每帧写样式前先比一下：值没变就不写。浏览器对「写了同样的值」也会标记为脏，省下来就是省重绘
  FX.put = (el, tr, op) => {
    if (el.__tr !== tr) { el.__tr = tr; el.style.transform = tr; }
    const o = (op <= 0 ? 0 : op >= 1 ? 1 : op).toFixed(3);
    if (el.__op !== o) { el.__op = o; el.style.opacity = o; }
  };
  FX.ACC = { orange: '#f28c0f', blue: '#4c9aff', green: '#3ecf8e', pink: '#f472b6', yellow: '#f5c542', red: '#ef5b5b', purple: '#a78bfa', cyan: '#2dd4e0' };
  FX.RATIO = { '16:9': 9 / 16, '4:3': 3 / 4, '3:2': 2 / 3, '1:1': 1, '3:4': 4 / 3, '2:3': 3 / 2, '9:16': 16 / 9 };
  FX.accOf = P => FX.ACC[P && P.accent] || (/^#[0-9a-f]{6}$/i.test((P && P.accent) || '') ? P.accent : FX.ACC.orange);
  FX.ratioOf = (P, d) => FX.RATIO[P && P.ratio] || FX.RATIO[d || '16:9'];
  // ---------- 裁剪保留哪一块（object-position） ----------
  FX.FOCUS = { center: '50% 50%', top: '50% 0%', bottom: '50% 100%', left: '0% 50%', right: '100% 50%' };
  FX.focusPos = f => FX.FOCUS[f] || FX.FOCUS.center;
  // 图片比例最接近哪个卡片比例选项
  FX.bestRatio = (iw, ih) => {
    const r = ih / iw; let best = '16:9', d = 1e9;
    for (const k in FX.RATIO) { const x = Math.abs(Math.log(FX.RATIO[k] / r)); if (x < d) { d = x; best = k; } }
    return best;
  };
  // 按「铺满」放进这个比例的卡里，会裁掉多少（面积比）、裁的是上下还是左右
  FX.cropInfo = (iw, ih, cardRatio) => {
    if (!(iw > 0 && ih > 0 && cardRatio > 0)) return null;
    const ir = ih / iw;
    const same = Math.abs(Math.log(ir / cardRatio)) < 0.1;        // 差不到 10% 就当一样
    const vis = ir > cardRatio ? cardRatio / ir : ir / cardRatio;
    return { ir, same, loss: 1 - vis, axis: ir > cardRatio ? 'v' : 'h', best: FX.bestRatio(iw, ih) };
  };

  // ---------- 【区域C4】文字标记（和 Markdown 一致，见规则 3）----------
  const esc = FX.esc = x => String(x == null ? '' : x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  // **重点** / ***重点*** → 加粗 + 主题色；*文字* → 只加粗；~划掉~ / ~~划掉~~ → 划掉
  FX.mark = x => esc(x)
    .replace(/\*\*\*(.+?)\*\*\*/g, '<em class="hi">$1</em>')
    .replace(/\*\*(.+?)\*\*/g, '<em class="hi">$1</em>')
    .replace(/\*(.+?)\*/g, '<b>$1</b>')
    .replace(/~~(.+?)~~/g, '<s>$1</s>')
    .replace(/~(.+?)~/g, '<s>$1</s>');
  const plain = FX.plain = x => String(x == null ? '' : x).replace(/\*{1,3}(.+?)\*{1,3}/g, '$1').replace(/~{1,2}(.+?)~{1,2}/g, '$1');
  // 标题字号随字数自动缩小（按卡片尺寸算，导出逐帧一致）
  FX.titleSize = (W, H, txt, room) => {
    const n = Array.from(txt).reduce((a, ch) => a + ((ch.codePointAt(0) || 0) >= 0x2e80 ? 1 : 0.55), 0) || 1;
    const inner = W * 0.78, cap = H * (room == null ? 0.46 : room);
    let fs = Math.min(W * 0.17, H * 0.3);
    for (; fs > W * 0.035; fs -= 1) {
      const perLine = Math.max(1, Math.floor(inner / (fs * 1.03)));
      if (Math.ceil(n / perLine) * fs * 1.22 <= cap) break;
    }
    return fs;
  };

  // ---------- 【区域C1 数据】 ----------
  // 返回 { count, items, ui }；items 是用户在编辑器里填的原始卡片（可能有空的）
  const TDEF = FX.TDEF = { stagger: 0.12, in: 0.8, hold: 2, out: 0.55, gap: 0.08, mode: 'lifo' };
  const MODES = FX.MODES = ['lifo', 'fifo', 'together', 'custom'];
  FX.read = (P, o) => {
    o = o || {};
    const min = o.min || 1, max = o.max || 12, def = o.def || 6;
    let C = P && P.cards;
    if (typeof C === 'string') { try { C = JSON.parse(C); } catch (e) { C = null; } }
    let items, count;
    if (C && Array.isArray(C.items)) {
      count = clamp(Math.round(num(C.count, C.items.length) || def), min, max);
      items = C.items.slice(0, Math.max(count, C.items.length));
    } else if (P && Array.isArray(P.images) && P.images.length) {
      items = P.images.filter(Boolean).map(u => ({ type: 'image', img: u }));
      count = clamp(items.length, min, max);
    } else {
      count = clamp(def, min, max);
      items = Array.from({ length: count }, () => ({ type: 'image', img: '' }));
    }
    while (items.length < count) items.push({ type: 'image', img: '' });
    const u0 = (C && C.ui) || {};
    const ui = {
      stagger: Math.max(0, num(u0.stagger, TDEF.stagger)),
      in: Math.max(0.05, num(u0.in, TDEF.in)),
      hold: Math.max(0, num(u0.hold, TDEF.hold)),
      out: Math.max(0.05, num(u0.out, TDEF.out)),
      gap: Math.max(0, num(u0.gap, TDEF.gap)),
      mode: MODES.includes(u0.mode) ? u0.mode : TDEF.mode
    };
    return { count, items: items.slice(0, count), all: items, ui };
  };

  // ---------- 【区域C2 填充】内容不够就用已有的循环填，不留空白卡 ----------
  const has = FX.hasContent = it => !!it && (
    it.type === 'hole' ? true                       // 镂空卡本身就是「内容」（透明窗口），不用借别人的
      : it.type === 'text' ? !!String(it.title || it.sub || '').trim()
        : it.type === 'video' ? !!it.video
          : !!it.img);
  // items：用户填的卡片；n：画面上要几张。返回长度 n 的数组，每一项都有内容（除非一张都没填）
  FX.fill = (items, n) => {
    items = Array.isArray(items) ? items : [];
    const src = items.filter(has);
    const out = [];
    // 借来的卡和被借的是同一个对象 —— 时间（出现在第几秒 / 进场 / 停留 / 退出）要按「第几个格子自己的那张」算，
    // 所以把原始列表挂在结果上，FX.timing 读时间时用它（2026-11-14，素材条小旗子）
    out.raw = items;
    for (let i = 0; i < n; i++) {
      const it = items[i];
      if (has(it)) out.push(it);                       // 自己有内容 → 用自己的
      else if (src.length) out.push(src[i % src.length]); // 空的 → 循环借用前面有内容的
      else out.push(it || { type: 'image', img: '' });    // 一张都没填 → 占位卡（有编号，不是空白）
    }
    return out;
  };
  // 有几张是「借来的」，编辑器里给个说明
  FX.fillInfo = (items, n) => {
    const real = (Array.isArray(items) ? items : []).filter(has).length;
    return { real, borrowed: Math.max(0, n - real), n };
  };

  // ---------- 【区域C3 节奏】每张卡片 进场 → 停留 → 退出 ----------
  // mode：lifo 后出现的先退 / fifo 先出现的先退 / together 同时退 / custom 按每张自己的停留时长
  FX.timing = (items, ui, P, exitOn) => {
    ui = ui || {}; P = P || {};
    const pos = (x, d) => Math.max(0, num(x, d));
    const st = pos(ui.stagger, TDEF.stagger);
    const inD = Math.max(0.05, num(ui.in, TDEF.in));
    const outD = Math.max(0.05, num(ui.out, TDEF.out));
    const H = pos(ui.hold, TDEF.hold);
    const gap = pos(ui.gap, TDEF.gap);
    const mode = MODES.includes(ui.mode) ? ui.mode : TDEF.mode;
    const n = items.length;
    // 每张卡自己的时间从「原始列表」里读（借来的卡和被借的是同一个对象，不能共用时间）
    const raw = Array.isArray(items.raw) ? items.raw : items;
    const own = i => raw[i] || {};
    // 出现在第几秒：卡片填了 at（素材条上拖旗子 / 右侧「出现」）就用它；没填 = 跟在上一张后面隔「出现间隔」。
    // 一张都没填时 = i × 间隔，和以前完全一样
    let baseA = 0, baseI = 0;
    const T = items.map((it, i) => {
      const at = own(i).at;
      const hasAt = at !== '' && at != null && Number.isFinite(Number(at));
      const a = hasAt ? Math.max(0, Number(at)) : baseA + (i - baseI) * st;
      if (hasAt) { baseA = a; baseI = i; }
      const d = Math.max(0.05, num(own(i).inDur, inD));
      return { a, in: d, land: a + d, out: Math.max(0.05, num(own(i).outDur, outD)), manual: hasAt };
    });
    const maxLand = Math.max(0, ...T.map(x => x.land));
    T.forEach((x, i) => {
      if (mode === 'custom') x.e = x.land + pos(own(i).hold, H);
      else if (mode === 'lifo') x.e = maxLand + H + (n - 1 - i) * gap;
      else if (mode === 'fifo') x.e = maxLand + H + i * gap;
      else x.e = maxLand + H;
      x.hold = x.e - x.land;
    });
    const total = exitOn === false
      ? (mode === 'custom' ? Math.max(0, ...T.map(x => x.e)) : maxLand + H)
      : Math.max(0, ...T.map(x => x.e + x.out));
    const R = { T, total: Math.max(0.2, total), st, inD, outD, H, gap, mode };
    // 效果自己算画面时传的是 FX.fill 的结果（带 raw）：记下来给素材条的小旗子用（编辑器自己算的不记）
    if (Array.isArray(items.raw)) { FX._tm = { T, items, P, exitOn: exitOn !== false, mode }; FX.marksOn(); }
    return R;
  };

  // ---------- 【区域C3b 素材条小旗子】每张卡一面「入」（绿）、一面「出」（红，下半行）----------
  // 规则 38「活」旗子 / 规则 42：工作台 public/js/22-fx-marks.js 只在选中的素材上调这三个函数。
  //   拖绿旗子 = 改这张卡「出现在第几秒」（写进卡片的 at，后面没填的卡跟着它往后排）
  //   拖红旗子 = 改这张卡「开始退场」的时间（自动切到「每张自定」，其他卡按现在的停留时长记下来，不会跳）
  //   点一下  = 右侧跳到这张卡片、展开、闪两下
  // 效果自己写了 __fxMarks 的（关系图、丝带连接卡……）不动它的。
  const r2s = x => Math.round(x * 100) / 100;
  FX.marksOn = () => {
    if (window.parent === window) return;                          // 导出时单独打开：不需要
    if (window.__fxMarks && !window.__fxMarks.__fxc) return;        // 效果有自己的旗子
    if (window.__fxMarks) return;
    const nameOf = it => {
      if (!it) return '';
      if (it.type === 'text') { const s = plain(it.title || it.sub || '').trim(); return s ? '「' + (s.length > 10 ? s.slice(0, 10) + '…' : s) + '」' : ''; }
      return it.type === 'video' ? '（视频）' : it.type === 'hole' ? '（镂空）' : '（照片）';
    };
    const marks = () => {
      const R = FX._tm; if (!R) return [];
      const out = [];
      R.T.forEach((T, i) => {
        const nm = nameOf(R.items[i]);
        out.push({ id: 'a' + i, t: T.a, d: T.in, label: String(i + 1), cls: 'n',
          tip: '第 ' + (i + 1) + ' 张卡片' + nm + '开始入场' + (T.manual ? '（手动定的时间）' : '') });
        if (R.exitOn) out.push({ id: 'x' + i, t: T.e, d: T.out, label: String(i + 1), cls: 'x', lo: true,
          tip: '第 ' + (i + 1) + ' 张卡片' + nm + '开始退场' });
      });
      return out;
    };
    marks.__fxc = 1;
    window.__fxMarks = marks;
    window.__fxMarkSet = (id, v) => {
      const R = FX._tm; if (!R || !R.P) return v;
      const k = String(id)[0], i = parseInt(String(id).slice(1), 10), P = R.P;
      if (!R.T[i]) return v;
      v = r2s(Math.max(0, +v || 0));
      let C = P.cards;
      if (typeof C === 'string') { try { C = JSON.parse(C); } catch (e) { C = null; } }
      else if (C && typeof C === 'object') C = JSON.parse(JSON.stringify(C));
      if (!C || !Array.isArray(C.items)) C = { count: R.T.length, items: R.items.map(x => Object.assign({}, x)) };
      while (C.items.length < R.T.length) C.items.push({ type: 'image', img: '', title: '', sub: '' });
      C.ui = C.ui || {};
      if (k === 'a') C.items[i].at = v;
      else if (k === 'x') {
        if (C.ui.mode !== 'custom') {                                // 先把每张现在的停留记下来，其他卡不会跳
          R.T.forEach((T, j) => { C.items[j].hold = r2s(T.hold); });
          C.ui.mode = 'custom';
        }
        C.items[i].hold = r2s(Math.max(0, v - R.T[i].land));
      } else return v;
      P.cards = JSON.stringify(C);                                   // P 就是工作台的 params；松手后工作台 buildParams + reinit
      try { window.init(P); } catch (e) { }
      const T = (FX._tm && FX._tm.T[i]) || R.T[i];
      // 预览停在「看得出变化」的那一刻：入场停在飞到一半多，退场停在走到一半
      const pt = k === 'a' ? T.a + T.in * 0.6 : T.e + T.out * 0.5;
      try { window.renderAt(pt); } catch (e) { }
      return pt;
    };
    window.__fxMarkFocus = id => {
      const i = parseInt(String(id).slice(1), 10);
      try { return FX._edFocus ? FX._edFocus(i) : null; } catch (e) { return null; }
    };
  };

  // ---------- 【区域C4 画面】卡片外观 ----------
  FX.css = () => {
    if (document.getElementById('fxc-style')) return;
    const st = document.createElement('style'); st.id = 'fxc-style';
    st.textContent = `
/* will-change 要留着：实测去掉以后帧率反而从 30 掉到 25（每帧都要重新提层）。
   投影分三档：默认那档有 60px 的大模糊，很漂亮但很吃填充率 —— 一屏几十张卡的效果（粒子群）
   必须用 sh-light，实测 40 张卡时差了 20+ fps。 */
.fxc{position:absolute;left:0;top:0;box-sizing:border-box;border-radius:var(--r);overflow:hidden;will-change:transform,opacity;
  contain:layout style paint;
  background:#141414;box-shadow:0 30px 60px -18px rgba(0,0,0,.55),0 10px 22px rgba(0,0,0,.28)}
.fxc.sh-light{box-shadow:0 10px 20px -10px rgba(0,0,0,.6)}
.fxc.sh-none{box-shadow:none}
.fxc.f-thin{border:2px solid color-mix(in srgb,var(--acc) 70%,transparent)}
.fxc.f-white{border:calc(var(--w)*.022px) solid #fafafa;background:#fafafa}
.fxc.f-line{border:1px solid rgba(255,255,255,.22)}
.fxc.f-none{border:0}
.fxc .fxc-img{position:absolute;inset:0;width:100%;height:100%;display:block}
.fxc .fxc-shine{position:absolute;inset:0;background:linear-gradient(160deg,rgba(255,255,255,.14) 0%,rgba(255,255,255,0) 38%);pointer-events:none}
.fxc .fxc-edge{position:absolute;left:0;top:0;bottom:0;width:calc(var(--w)*.012px);background:var(--acc);pointer-events:none}
/* 文字卡 */
.fxc-txt{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;padding:17% 9% 15%;box-sizing:border-box;
  background:radial-gradient(130% 90% at 0% 0%,color-mix(in srgb,var(--acc) 24%,#1b1b1b) 0%,#161616 52%,#101010 100%)}
.fxc-txt .k{position:absolute;left:9%;top:9%;display:flex;align-items:center;gap:calc(var(--w)*.025px);font:700 calc(var(--w)*.038px)/1 "Helvetica Neue",Arial,sans-serif;letter-spacing:.2em;color:var(--acc)}
.fxc-txt .k i{display:block;width:calc(var(--w)*.075px);height:calc(var(--w)*.0085px);border-radius:2px;background:var(--acc)}
.fxc-txt .t{font-weight:400;line-height:1.24;text-wrap:balance;color:#fff;letter-spacing:.01em;word-break:break-word;overflow-wrap:anywhere}
.fxc-txt .s{margin-top:calc(var(--w)*.035px);text-wrap:balance;font-weight:400;line-height:1.5;color:rgba(255,255,255,.6);word-break:break-word;overflow-wrap:anywhere}
.fxc-txt .u{position:absolute;left:9%;bottom:9%;width:calc(var(--w)*.13px);height:calc(var(--w)*.009px);border-radius:2px;background:var(--acc)}
.fxc-txt em.hi{font-style:normal;font-weight:800;color:var(--acc)}
.fxc-txt b{font-weight:800}
.fxc-txt s{text-decoration:line-through;text-decoration-thickness:.08em;opacity:.72}
.fxc-txt.bold .t,.fxc-txt.bold .s{font-weight:800}
.fxc-txt,.fxc-txt *{font-family:"PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif}
.f-white .fxc-txt{background:#fafafa}
.f-white .fxc-txt .t{color:#161616}
.f-white .fxc-txt .s{color:rgba(0,0,0,.55)}
/* 占位卡（没上传任何内容时的样子，缩略图也靠它好看）*/
.fxc-ph{position:absolute;inset:0;background:radial-gradient(120% 95% at 18% 0%,color-mix(in srgb,var(--acc) 30%,#1b1b1b) 0%,#161616 55%,#0f0f0f 100%)}
.fxc-ph .tag{position:absolute;left:8%;top:10%;font:600 calc(var(--w)*.038px)/1 "Helvetica Neue",Arial,"Microsoft YaHei",sans-serif;letter-spacing:.3em;color:rgba(255,255,255,.5)}
.fxc-ph .bar{position:absolute;left:8%;top:calc(10% + var(--w)*.07px);width:20%;height:calc(var(--w)*.008px);border-radius:2px;background:var(--acc)}
.fxc-ph .no{position:absolute;left:7.5%;bottom:8%;font:800 calc(var(--w)*.26px)/1 "Arial Black","Helvetica Neue",Arial,sans-serif;color:var(--acc);letter-spacing:-.02em}
.fxc-ph .rows{position:absolute;right:8%;bottom:12%;display:flex;flex-direction:column;align-items:flex-end;gap:calc(var(--w)*.022px)}
.fxc-ph .rows i{display:block;height:calc(var(--w)*.014px);border-radius:3px;background:rgba(255,255,255,.16)}
/* 镂空卡：卡片内部完全透明（导出的 ProRes 4444 里这块 alpha=0），
   只画一圈边框和外投影 —— 后期把自己的视频垫在下面一轨，就会从这个"窗口"透出来，
   不用把整段视频上传进来。边框和投影画在子元素上，方便推到满屏时单独淡掉。 */
.fxc.f-hole{background:transparent;box-shadow:none;border:0}
.fxc-holeframe{position:absolute;inset:0;border-radius:inherit;box-sizing:border-box;pointer-events:none;
  box-shadow:0 30px 60px -18px rgba(0,0,0,.45),0 10px 22px rgba(0,0,0,.22)}
.fxc-holeframe.hf-thin{border:2px solid color-mix(in srgb,var(--acc) 70%,transparent)}
.fxc-holeframe.hf-white{border:calc(var(--w)*.022px) solid #fafafa}
.fxc-holeframe.hf-line{border:1px solid rgba(255,255,255,.3)}
.fxc-holeframe.hf-none{border:0;box-shadow:none}`;
    document.head.appendChild(st);
  };

  // 画一张卡的内容。o = { W, H, fit, frame, accent, index, loads, bold, posterOnly, shine, edge }
  FX.card = (el, it, o) => {
    o = o || {}; it = it || {};
    const W = o.W, H = o.H == null ? W : o.H;
    const frame = ['thin', 'white', 'line', 'none'].includes(o.frame) ? o.frame : 'thin';
    const sh = o.shadow === 'light' ? ' sh-light' : o.shadow === 'none' ? ' sh-none' : '';
    el.className = 'fxc f-' + frame + sh;
    el.style.width = W + 'px'; el.style.height = H + 'px';
    el.style.setProperty('--w', W);
    el.style.setProperty('--r', Math.round(W * (frame === 'white' ? 0.028 : 0.038)) + 'px');
    const no = String((o.index || 0) + 1).padStart(2, '0');
    // 【区域C6】照片 / 视频摆在边框里面那一圈：按扣掉边框后的内框算构图（和下面 CSS 里的边框粗细一致）
    const bd = frame === 'thin' ? 2 : frame === 'line' ? 1 : frame === 'white' ? W * 0.022 : 0;
    const IW = W - 2 * bd, IH = H - 2 * bd;
    const loads = o.loads || [];
    // 镂空卡：里面什么都不画，保持透明；只放一层边框 / 投影（el.__hf 方便效果单独淡掉它）
    if (it.type === 'hole') {
      el.className = 'fxc f-hole' + sh;
      const fr = document.createElement('div');
      fr.className = 'fxc-holeframe hf-' + frame;
      el.appendChild(fr);
      el.__hf = fr;
      return el;
    }
    if (it.type === 'text') {
      const title = String(it.title || '').trim() || '写一句**重点**标题';
      const sub = String(it.sub || '').trim();
      // 标题字号自动收缩；有副标题时给标题留小一点的地方，避免副标题顶到底部的下划线
      const tfs = FX.titleSize(W, H, plain(title), sub ? 0.32 : 0.46);
      const sfs = Math.max(10, Math.min(W * 0.044, tfs * 0.46));
      el.innerHTML = `<div class="fxc-txt${o.bold ? ' bold' : ''}"><div class="k">${no}<i></i></div>`
        + `<div class="t" style="font-size:${tfs.toFixed(1)}px">${FX.mark(title)}</div>`
        + (sub ? `<div class="s" style="font-size:${sfs.toFixed(1)}px">${FX.mark(sub)}</div>` : '')
        + `<div class="u"></div></div>`;
    } else if (it.type === 'video' && it.video && !o.posterOnly && window.FXVideo) {
      loads.push(FXVideo.mount(el, it, o.fit));                       // 视频卡（见 _shared/fx-video.js）
      FX.place(el.lastElementChild, it, IW, IH);                        // 【区域C6】调过大小 / 位置就按它摆
    } else if (it.type === 'video' && it.video && o.posterOnly && it.poster) {
      // 粒子那种一次上百张的场合：超出「同时播放上限」的那些用封面图，画面不会黑
      const im = new Image();
      im.className = 'fxc-img'; im.style.objectFit = o.fit === 'contain' ? 'contain' : 'cover';
      im.src = it.poster;
      loads.push(im.decode ? im.decode().catch(() => { }) : new Promise(r => { im.onload = im.onerror = r; }));
      el.appendChild(im); FX.place(im, it, IW, IH);
    } else if (it.img) {
      const im = new Image();
      im.className = 'fxc-img'; im.style.objectFit = o.fit === 'contain' ? 'contain' : 'cover';
      im.style.objectPosition = FX.focusPos(it.focus);      // 裁剪时保留哪一块（见编辑器里的「保留」）
      im.src = it.img;
      loads.push(im.decode ? im.decode().catch(() => { }) : new Promise(r => { im.onload = im.onerror = r; }));
      el.appendChild(im); FX.place(im, it, IW, IH);
    } else {
      el.innerHTML = `<div class="fxc-ph"><div class="tag">${it.type === 'video' ? 'VIDEO' : 'PHOTO'}</div><div class="bar"></div>`
        + `<div class="rows"><i style="width:${(W * 0.3).toFixed(0)}px"></i><i style="width:${(W * 0.22).toFixed(0)}px"></i><i style="width:${(W * 0.26).toFixed(0)}px"></i></div>`
        + `<div class="no">${no}</div></div>`;
    }
    if (o.edge !== false && frame !== 'white') { const e = document.createElement('div'); e.className = 'fxc-edge'; el.appendChild(e); }
    if (o.shine !== false) { const sh = document.createElement('div'); sh.className = 'fxc-shine'; el.appendChild(sh); }
    if (window.FXCardBg) FXCardBg.mark(el, { index: o.index, own: it.cardbg });   // 卡片背景动效（_shared/fx-cardbg.js，规则 40）：只做标记，用户打开才画；own = 这张卡单独调的设置
    return el;
  };


  // ================= 【区域C6 大小和位置】 =================
  // 一张卡（或背景）里的照片 / 视频记四个数：原图尺寸 iw / ih、缩放 zoom、中心偏移 px / py。
  // zoom = 1 正好铺满；px / py = 画面中心离卡片中心多远，按卡片宽 / 高的比例记 ——
  // 所以卡片在不同效果、不同阶段被缩放成多大都没关系，构图永远等比跟着走。
  // 没调过（没有 zoom）的老卡片返回 null，照旧按「填充方式」显示，老工程一点不变。
  // v24.2：另外可选记 rot（顺时针 0 / 90 / 180 / 270 度）、flipX（左右镜像）、flipY（上下翻转）。
  // 显示时先镜像 / 翻转，再旋转；转了 90 / 270 度时宽高对调，「铺满」「完整显示」都按转过之后的样子算。
  const rotOf = it => { const r = Math.round(num(it && it.rot, 0) / 90) * 90; return ((r % 360) + 360) % 360; };
  FX.rect = (it, W, H) => {
    const iw = +(it && it.iw), ih = +(it && it.ih);
    if (!it || it.zoom == null || !(iw > 0 && ih > 0) || !(W > 0 && H > 0)) return null;
    const z = clamp(num(it.zoom, 1), 0.2, 8), rot = rotOf(it), side = rot === 90 || rot === 270;
    const ew = side ? ih : iw, eh = side ? iw : ih;                 // 转过之后看到的宽高
    const s = Math.max(W / ew, H / eh) * z, w = ew * s, h = eh * s;
    return { x: W / 2 + num(it.px, 0) * W - w / 2, y: H / 2 + num(it.py, 0) * H - h / 2, w, h, rot, side, fx: !!it.flipX, fy: !!it.flipY };
  };
  // 按 rect 摆一个元素：k = 再整体缩放多少，ox / oy = 再挪多少（调整弹窗里用）
  FX.setBox = (el, r, k = 1, ox = 0, oy = 0) => {
    const w = (r.side ? r.h : r.w) * k, h = (r.side ? r.w : r.h) * k;  // 元素本身按原图方向摆，再用 rotate 转过去
    el.style.left = (ox + r.x * k + (r.w * k - w) / 2).toFixed(2) + 'px'; el.style.top = (oy + r.y * k + (r.h * k - h) / 2).toFixed(2) + 'px';
    el.style.width = w.toFixed(2) + 'px'; el.style.height = h.toFixed(2) + 'px';
    el.style.rotate = r.rot ? r.rot + 'deg' : '';                    // 用单独的 rotate / scale 属性，不碰效果自己的 transform 动画
    el.style.scale = r.fx || r.fy ? (r.fx ? -1 : 1) + ' ' + (r.fy ? -1 : 1) : '';
  };
  // 把一个 <img> / <video> 按记下的构图摆进 W×H 的框里（只在 build 时写一次，不是每帧）
  FX.place = (el, it, W, H) => {
    const r = FX.rect(it, W, H);
    if (!r || !el || !el.style) return false;
    el.style.inset = 'auto'; el.style.right = el.style.bottom = 'auto';
    FX.setBox(el, r);
    el.style.maxWidth = 'none'; el.style.maxHeight = 'none'; el.style.objectFit = 'fill';
    return true;
  };
  // 新上传的素材：把旧构图清掉，从「铺满、居中、不翻不转」开始
  FX.resetPlace = it => { if (it) { delete it.zoom; delete it.px; delete it.py; delete it.rot; delete it.flipX; delete it.flipY; } };

  // 调整弹窗（在工作台页面里弹）。o = { it, ratio(高/宽), title, scrim(0~1，可选), onOk(),
  //   guide(W, H, u) → SVG 内容（可选：画在橙框上的参考线，坐标就是 W×H 的框，u = 屏幕 1px 多少单位）, guideNote（参考线说明，HTML） }
  // 中间橙框 = 卡片里能看到的范围，框外压暗 = 会被裁掉的部分。滚轮以鼠标为中心缩放，左键拖动，双击回到铺满。
  // 确定 / Enter 才写回 it，取消 / Esc / 点外面什么都不改。
  FX.crop = o => {
    let pd, pw; try { pw = window.parent; pd = pw.document; } catch (e) { return; }
    const it = o.it || {}, src = it.type === 'video' ? it.video : it.img;
    if (!src || !pd || !pd.body) return;
    if (!pd.getElementById('fxcrop-style')) {
      const st = pd.createElement('style'); st.id = 'fxcrop-style';
      st.textContent = `
.fxcrop{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;font-family:"PingFang SC","Microsoft YaHei",sans-serif}
.fxcrop-box{background:#161616;border:1px solid #333;border-radius:12px;padding:16px 18px 14px;box-shadow:0 30px 80px rgba(0,0,0,.6);color:#ddd}
.fxcrop-h{display:flex;align-items:baseline;gap:12px;margin-bottom:12px;font-size:15px;font-weight:600;color:#fff}
.fxcrop-h small{font-size:12px;font-weight:400;color:#888}
.fxcrop-st{position:relative;overflow:hidden;border-radius:8px;cursor:grab;user-select:none;touch-action:none;background-color:#0a0a0a;
  background-image:linear-gradient(45deg,#151515 25%,transparent 25%,transparent 75%,#151515 75%),linear-gradient(45deg,#151515 25%,transparent 25%,transparent 75%,#151515 75%);
  background-size:20px 20px;background-position:0 0,10px 10px}
.fxcrop-st.drag{cursor:grabbing}
.fxcrop-st img,.fxcrop-st video{position:absolute;display:block;max-width:none;max-height:none;margin:0;padding:0;border:0;pointer-events:none}
.fxcrop-win{position:absolute;pointer-events:none;box-shadow:0 0 0 9999px rgba(0,0,0,.86);outline:2px solid #f28c0f}
.fxcrop-sc{position:absolute;inset:0;background:#000}
.fxcrop-f{display:flex;align-items:center;gap:8px;margin-top:12px;font-size:12px;color:#999}
.fxcrop-f .sp{flex:1}
.fxcrop-f b{color:#f28c0f;font-weight:600;min-width:46px;display:inline-block}
.fxcrop-b{width:auto;padding:7px 14px;margin:0;border:1px solid #333;border-radius:7px;background:#262626;color:#eee;cursor:pointer;font-size:13px;font-family:inherit}
.fxcrop-b:hover{border-color:#f28c0f}
.fxcrop-b.ok{background:#f28c0f;border-color:#f28c0f;color:#000;font-weight:700}
.fxcrop-tf{display:flex;justify-content:center;gap:10px;margin-top:10px}
.fxcrop-i{width:46px;height:38px;padding:0;margin:0;display:flex;align-items:center;justify-content:center;border:1px solid #333;border-radius:7px;background:#262626;color:#ddd;cursor:pointer}
.fxcrop-i:hover{border-color:#f28c0f;color:#fff}
.fxcrop-i.on{border-color:#f28c0f;color:#f28c0f}
.fxcrop-i svg{width:24px;height:24px;display:block}
.fxcrop-gd{position:absolute;left:0;top:0;overflow:visible;pointer-events:none}
.fxcrop-gn{font-size:12px;color:#aaa;margin:-4px 0 10px;line-height:1.6}`;
      pd.head.appendChild(st);
    }
    const W = 1000, H = 1000 * (o.ratio > 0 ? o.ratio : 9 / 16);   // 构图按比例记，所以这里取任意尺寸都一样
    const wantGuide = typeof o.guide === 'function';
    // 看的范围（框单位）：默认橙框四周各留 14%；参考线带 bounds 时按它来（圆卡 = 整个圆都看得到）
    let bd = null; if (wantGuide && typeof o.guide.bounds === 'function') { try { bd = o.guide.bounds(W, H); } catch (e) { bd = null; } }
    if (!bd) { const m0 = wantGuide ? 0.22 : 0.14; bd = { l: -W * m0, t: -H * m0, r: W * (1 + m0), b: H * (1 + m0) }; }
    const maxW = Math.min(pw.innerWidth * 0.82, 1180), maxH = pw.innerHeight * 0.68;
    const k = Math.min(maxW / (bd.r - bd.l), maxH / (bd.b - bd.t));
    const fw = W * k, fh = H * k, mx = -bd.l * k, my = -bd.t * k, stW = (bd.r - bd.l) * k, stH = (bd.b - bd.t) * k;
    const circ = wantGuide && o.guide.frame === 'circle';             // 圆卡：真正的可见范围是圆，橙框只是「铺满 / 完整显示」的参照
    const hasScrim = o.scrim > 0;
    let gSvg = '';
    if (wantGuide) { try { gSvg = o.guide(W, H, 1 / k) || ''; } catch (e) { gSvg = ''; } }
    const hasGuide = !!gSvg;
    // 镜像 / 上下翻转 / 旋转 的图标（上下翻转 = 镜像图标转 90°）
    const icoMirror = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"><path d="M12 2.5v19" stroke-dasharray="1.6 2.4"/><path d="M9.5 5 2.5 19h7z"/><path d="M14.5 5 21.5 19h-7z" fill="currentColor"/></svg>';
    const icoFlip = icoMirror.replace('<svg ', '<svg style="transform:rotate(90deg)" ');
    const icoRot = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10.5A8.2 8.2 0 0 0 5.6 6.6"/><path d="M5 2.8v4.4h4.4"/><path d="M4 13.5a8.2 8.2 0 0 0 14.4 3.9"/><path d="M19 21.2v-4.4h-4.4"/></svg>';
    const ov = pd.createElement('div'); ov.className = 'fxcrop';
    ov.innerHTML = `<div class="fxcrop-box"><div class="fxcrop-h">${o.title || '调整大小和位置'}`
      + `<small>滚轮 = 放大缩小　·　按住左键拖动 = 挪位置　·　双击 = 回到铺满　·　${circ ? '白圈里就是最后显示的样子' : '橙色框里就是最后显示的样子'}</small></div>`
      + (hasGuide && o.guideNote ? `<div class="fxcrop-gn">${o.guideNote}</div>` : '')
      + `<div class="fxcrop-st" style="width:${stW.toFixed(0)}px;height:${stH.toFixed(0)}px"></div>`
      + `<div class="fxcrop-tf"><button type="button" class="fxcrop-i" data-a="mirror" title="左右镜像">${icoMirror}</button>`
      + `<button type="button" class="fxcrop-i" data-a="flip" title="上下翻转">${icoFlip}</button>`
      + `<button type="button" class="fxcrop-i" data-a="rot" title="顺时针旋转 90°">${icoRot}</button></div>`
      + `<div class="fxcrop-f">缩放 <b class="z">100%</b><span class="sp"></span>`
      + `<button type="button" class="fxcrop-b" data-a="cover">铺满</button>`
      + `<button type="button" class="fxcrop-b" data-a="contain">完整显示</button>`
      + `<button type="button" class="fxcrop-b" data-a="center">居中</button>`
      + (hasScrim ? `<button type="button" class="fxcrop-b" data-a="scrim">看原图</button>` : '')
      + (hasGuide ? `<button type="button" class="fxcrop-b" data-a="guide">参考线：开</button>` : '')
      + `<span style="width:14px"></span>`
      + `<button type="button" class="fxcrop-b" data-a="cancel">取消</button>`
      + `<button type="button" class="fxcrop-b ok" data-a="ok">确定</button></div></div>`;
    const stg = ov.querySelector('.fxcrop-st'), zl = ov.querySelector('.z');
    let media;
    if (it.type === 'video') {
      media = pd.createElement('video');
      media.muted = true; media.loop = true; media.autoplay = true; media.playsInline = true;
      media.setAttribute('muted', ''); media.setAttribute('playsinline', '');
    } else media = pd.createElement('img');
    const win = pd.createElement('div'); win.className = 'fxcrop-win';
    win.style.cssText = `left:${mx}px;top:${my}px;width:${fw}px;height:${fh}px` + (circ ? ';box-shadow:none;outline:1px dashed rgba(242,140,15,.75)' : '');
    const sc = pd.createElement('div'); sc.className = 'fxcrop-sc';
    if (hasScrim) { sc.style.opacity = clamp(o.scrim, 0, 1).toFixed(3); win.appendChild(sc); }
    stg.append(media, win);
    if (hasGuide) {                                                   // 参考线画在橙框里，圆形等可以超出框（框外本来就压暗）
      win.insertAdjacentHTML('beforeend', `<svg class="fxcrop-gd" width="${fw.toFixed(1)}" height="${fh.toFixed(1)}" viewBox="0 0 ${W} ${H.toFixed(1)}">${gSvg}</svg>`);
    }
    pd.body.appendChild(ov);

    const S = { iw: +it.iw || 0, ih: +it.ih || 0, zoom: num(it.zoom, 1), px: num(it.px, 0), py: num(it.py, 0), rot: rotOf(it), flipX: !!it.flipX, flipY: !!it.flipY };
    const draw = () => {
      ov.querySelector('[data-a=mirror]').classList.toggle('on', S.flipX);
      ov.querySelector('[data-a=flip]').classList.toggle('on', S.flipY);
      const rb = ov.querySelector('[data-a=rot]'); rb.classList.toggle('on', S.rot > 0); rb.title = '顺时针旋转 90°' + (S.rot ? '（现在转了 ' + S.rot + '°）' : '');
      if (!(S.iw > 0)) return;
      FX.setBox(media, FX.rect(S, W, H), k, mx, my);
      zl.textContent = Math.round(S.zoom * 100) + '%';
    };
    const ready = (iw, ih) => { if (iw > 0 && ih > 0) { S.iw = iw; S.ih = ih; draw(); } };
    if (it.type === 'video') media.addEventListener('loadedmetadata', () => ready(media.videoWidth, media.videoHeight), { once: true });
    else media.addEventListener('load', () => ready(media.naturalWidth, media.naturalHeight), { once: true });
    media.src = src;
    draw();

    const toBox = e => { const b = stg.getBoundingClientRect(); return { x: (e.clientX - b.left - mx) / k, y: (e.clientY - b.top - my) / k }; };
    stg.addEventListener('wheel', e => {
      e.preventDefault();
      if (!(S.iw > 0)) return;
      const z0 = S.zoom, z1 = clamp(z0 * Math.pow(1.0015, -e.deltaY), 0.2, 8);
      const p = toBox(e), cx = W / 2 + S.px * W, cy = H / 2 + S.py * H;
      S.px = (p.x + (cx - p.x) * (z1 / z0) - W / 2) / W;
      S.py = (p.y + (cy - p.y) * (z1 / z0) - H / 2) / H;
      S.zoom = z1; draw();
    }, { passive: false });
    let drag = null;
    stg.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      drag = { x: e.clientX, y: e.clientY, px: S.px, py: S.py };
      stg.classList.add('drag'); try { stg.setPointerCapture(e.pointerId); } catch (x) { }
    });
    stg.addEventListener('pointermove', e => {
      if (!drag) return;
      S.px = drag.px + (e.clientX - drag.x) / k / W;
      S.py = drag.py + (e.clientY - drag.y) / k / H;
      draw();
    });
    const up = () => { drag = null; stg.classList.remove('drag'); };
    stg.addEventListener('pointerup', up); stg.addEventListener('pointercancel', up);
    stg.addEventListener('dblclick', () => { S.zoom = 1; S.px = 0; S.py = 0; draw(); });

    const key = e => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
      else if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); ok(); }
    };
    const close = () => { pd.removeEventListener('keydown', key, true); try { media.pause && media.pause(); } catch (x) { } ov.remove(); };
    const ok = () => {
      if (S.iw > 0) {
        it.iw = S.iw; it.ih = S.ih; it.zoom = +S.zoom.toFixed(4); it.px = +S.px.toFixed(4); it.py = +S.py.toFixed(4);
        if (S.rot) it.rot = S.rot; else delete it.rot;                 // 没翻没转就不记，老工程的数据保持原样
        if (S.flipX) it.flipX = true; else delete it.flipX;
        if (S.flipY) it.flipY = true; else delete it.flipY;
      }
      close(); o.onOk && o.onOk();
    };
    const act = {
      cover: () => { S.zoom = 1; S.px = 0; S.py = 0; },
      contain: () => { if (S.iw > 0) { const sd = S.rot % 180 !== 0, ew = sd ? S.ih : S.iw, eh = sd ? S.iw : S.ih; S.zoom = Math.min(W / ew, H / eh) / Math.max(W / ew, H / eh); S.px = 0; S.py = 0; } },
      // 按看到的方向翻：已经转过 90° 时，「左右镜像」仍然是屏幕上的左右（数学上：先镜像再转 θ = 先转 -θ 再镜像）
      mirror: () => { S.flipX = !S.flipX; S.rot = (360 - S.rot) % 360; },
      flip: () => { S.flipY = !S.flipY; S.rot = (360 - S.rot) % 360; },
      rot: () => { S.rot = (S.rot + 90) % 360; },
      center: () => { S.px = 0; S.py = 0; },
      guide: () => { const g = win.querySelector('.fxcrop-gd'), b = ov.querySelector('[data-a=guide]'); if (!g) return; const off = g.style.display !== 'none'; g.style.display = off ? 'none' : ''; b.textContent = off ? '参考线：关' : '参考线：开'; },
      scrim: () => { const off = sc.style.display !== 'none'; sc.style.display = off ? 'none' : ''; ov.querySelector('[data-a=scrim]').textContent = off ? '带蒙版' : '看原图'; },
      cancel: close, ok
    };
    ov.querySelectorAll('[data-a]').forEach(b => b.onclick = () => { act[b.dataset.a](); if (pd.body.contains(ov)) draw(); });
    ov.addEventListener('pointerdown', e => { if (e.target === ov) close(); });
    pd.addEventListener('keydown', key, true);
  };
  // 编辑器里每张照片 / 视频卡下面的「✥ 调整大小和位置」按钮（自己写编辑器的效果也用它）
  // o = { pd, it, ratio: () => 高/宽, onOk: () => {重画 + 保存} }
  FX.adjustBtn = o => {
    const b = o.pd.createElement('button'); b.type = 'button'; b.className = 'fxcrop-adj';
    b.textContent = '✥ 调整大小和位置';
    b.style.cssText = 'display:block;width:100%;margin:8px 0 0;padding:7px 8px;font-size:12px;background:#1d1d1d;color:#ccc;'
      + 'border:1px solid #333;border-radius:6px;cursor:pointer;font-family:inherit';
    b.onmouseenter = () => { b.style.borderColor = '#f28c0f'; b.style.color = '#f28c0f'; };
    b.onmouseleave = () => { b.style.borderColor = '#333'; b.style.color = '#ccc'; };
    b.onclick = () => FX.crop({ it: o.it, ratio: o.ratio(), onOk: o.onOk });
    return b;
  };
  // 视频卡：FXVideo.editorBody 的 changed 回调外面包一层 —— 换了一段新视频就清掉旧构图并弹出调整窗口
  FX.wrapVideoChanged = (it, ratio, done) => {
    const before = it.video;
    return () => {
      const fresh = it.video && it.video !== before;
      if (fresh) { FX.resetPlace(it); delete it.iw; delete it.ih; }
      done();
      if (fresh) FX.crop({ it, ratio: ratio(), onOk: done });
    };
  };

  // ================= 【区域C5 编辑器】 =================
  // 在工作台里预览时，把右侧「卡片内容」那一栏换成卡片编辑器；编辑结果写回隐藏输入框。
  // 导出时本页单独打开（没有父页面），这段不会运行。
  FX.editor = (o) => {
    o = o || {};
    let P = o.P || {};                       // 可变：工作台每次改参数都会重新 init，这里要换成新的 P
    const ED = o.ED || (o.ED = {});
    let pd, pw;
    try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
    const box = pd.getElementById('params'); if (!box) return;
    // 已经挂好了就不要重建（重建会把用户正在输入的文字框干掉）；
    // 只把新的参数交给它，刷新一下和参数有关的提示（比例提醒、缩略图裁剪、时间）
    if (ED.mounted && box.contains(ED.mounted)) { if (ED.setP) ED.setP(o.P || {}); return; }
    box.querySelectorAll('.cdx').forEach(x => x.remove());
    const labelOf = el => (el.firstChild && el.firstChild.nodeType === 3 ? el.firstChild.textContent : el.textContent || '').trim();
    const kids = [...box.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);
    const key = o.label || '卡片内容';
    const jl = kids.find(el => el.tagName === 'LABEL' && labelOf(el).startsWith(key));
    const field = jl && jl.querySelector('input,textarea');
    if (!field) return;
    (o.hideParams || ['卡片大小']).forEach(h => kids.filter(el => labelOf(el).startsWith(h)).forEach(el => el.style.display = 'none'));
    jl.style.display = 'none';

    if (!pd.getElementById('cdx-style')) {
      const st = pd.createElement('style'); st.id = 'cdx-style';
      st.textContent = `
.cdx{display:block;font-size:12px;color:#999;margin-bottom:14px}
.cdx-h{display:flex;flex-direction:column;gap:8px;margin:8px 0}
.cdx input.cdx-num{width:56px!important;margin:0!important;text-align:center;padding:6px!important;display:inline-block!important}
.cdx-b{background:#262626;color:#eee;border:1px solid #333;border-radius:6px;cursor:pointer;font-family:inherit;font-size:12px;padding:4px 10px}
.cdx-b:hover{border-color:#f28c0f}
.cdx-all{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.cdx-list{display:flex;flex-direction:column;gap:8px}
.cdx-i{background:#101010;border:1px solid #2c2c2c;border-radius:8px;padding:8px}
.cdx-i.drag{opacity:.35}.cdx-i.over{border-color:#f28c0f;box-shadow:0 0 0 1px #f28c0f}
.cdx-top{display:flex;align-items:center;gap:8px}
.cdx-grip{cursor:grab;color:#777;font-size:16px;line-height:1;padding:2px;user-select:none}.cdx-grip:hover{color:#f28c0f}
.cdx-no{min-width:20px;height:20px;padding:0 5px;border-radius:10px;background:#f28c0f;color:#000;font-size:12px;line-height:20px;text-align:center;font-weight:700}
.cdx-seg{display:flex;margin-left:auto;background:#1d1d1d;border:1px solid #333;border-radius:6px;overflow:hidden}
.cdx-seg button{border:0;background:none;color:#aaa;padding:4px 12px;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap}
.cdx-seg button.on{background:#f28c0f;color:#000;font-weight:600}
.cdx-del{width:22px;height:22px;padding:0;border:0;border-radius:50%;background:#262626;color:#bbb;cursor:pointer;font-size:14px;line-height:22px}
.cdx-del:hover{background:#5a1f1f;color:#fff}
.cdx-body{margin-top:8px}
.cdx-body input.cdx-txt{display:block!important;width:100%;box-sizing:border-box;margin:6px 0 0!important;padding:8px 10px;font-size:14px;background:#0b0b0b;color:#eee;border:1px solid #333;border-radius:6px;font-family:inherit}
.cdx-body input.cdx-txt:first-child{margin-top:0!important}.cdx-body input.cdx-txt:focus{outline:none;border-color:#f28c0f}
.cdx-ph{position:relative;height:92px;border:1px dashed #444;border-radius:6px;display:flex;align-items:center;justify-content:center;text-align:center;color:#999;font-size:12px;cursor:pointer;overflow:hidden;line-height:1.5}
.cdx-ph:hover,.cdx-ph.over{border-color:#f28c0f;color:#f28c0f}.cdx-ph small{color:#666}
.cdx-ph.has{border-style:solid}.cdx-ph img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
/* 缩略图按卡片比例显示：所见即所得，一眼看出「铺满」会裁掉哪一块 */
.cdx-ph.ar{height:auto;aspect-ratio:var(--ar,1.777);margin:0 auto}
.cdx-warn{margin-top:8px;padding:8px 10px;background:#16100a;border:1px solid #4a3312;border-radius:6px;font-size:12px;line-height:1.7;color:#d8ab6a}
.cdx-warn>b:first-child{display:block;color:#f2a33d;font-weight:600;margin-bottom:2px}
.cdx-warn u{text-decoration:none;color:#ffcf8a;font-weight:600}
.cdx-wbtn{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}
.cdx-wbtn .cdx-b{flex:1;min-width:120px;padding:6px 8px}
.cdx-focus{display:flex;align-items:center;gap:8px;margin-top:8px;color:#c8a46a}
.cdx-focus span{flex:1;min-width:0}
.cdx-focus .cdx-seg{margin:0}.cdx-focus .cdx-seg button{padding:4px 14px}
.cdx-ph.has span{position:relative;background:rgba(0,0,0,.65);color:#fff;padding:3px 8px;border-radius:4px;opacity:0;transition:opacity .15s}
.cdx-ph.has:hover span{opacity:1}
.cdx-clr{margin-top:6px;background:none;border:0;color:#888;font-size:12px;cursor:pointer;padding:0;font-family:inherit}.cdx-clr:hover{color:#f28c0f}
.cdx-bulk{display:block;width:100%;margin-top:10px;padding:10px;font-size:13px;background:#262626;color:#eee;border:0;border-radius:6px;cursor:pointer;font-family:inherit}
.cdx-bulk:hover{background:#2f2f2f}.cdx-bulk:disabled{opacity:.6}
.cdx-note{margin-top:6px;font-size:12px;color:#777;line-height:1.6}
.cdx-fill{margin-top:8px;padding:8px 10px;background:#141008;border:1px solid #3a2c10;border-radius:6px;font-size:12px;line-height:1.6;color:#c8a964}
.cdx-hole{padding:8px 10px;background:#0c1014;border:1px dashed #30444f;border-radius:6px;font-size:12px;line-height:1.7;color:#8fa9b5}
.cdx-hole b{display:inline;color:#6fd3ea;font-weight:600}
.cdx-hole>b:first-child{display:block;color:#6fd3ea;margin-bottom:2px}
.cdx-c{display:block;margin:0}
.cdx-cr{display:flex;align-items:center;justify-content:space-between;gap:6px;color:#ccc;font-size:13px}
.cdx-cr span{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cdx input.cdx-cn{width:64px!important;flex:none;margin:0!important;padding:5px 6px!important;text-align:right;display:inline-block!important;font-size:13px}
.cdx input.cdx-rg{display:block!important;width:100%!important;margin:6px 0 2px!important;padding:0!important;border:0!important;background:none!important;height:16px;accent-color:#f28c0f;cursor:pointer}
.cdx-rh{display:flex;flex-direction:column;gap:10px;margin:10px 0 12px;padding:10px;background:#101010;border:1px solid #2c2c2c;border-radius:8px}
.cdx-rh .cdx-seg{margin:0}.cdx-rh .cdx-seg button{flex:1;padding:6px 4px}
.cdx-ord{display:flex;flex-direction:column;gap:6px;color:#ccc;font-size:13px}
.cdx-auto{margin-top:6px;font-size:11px}
.cdx-i.off .cdx-auto{display:none!important}
.cdx-tm{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px;padding-top:8px;border-top:1px solid #222}
.cdx-tm .cdx-cr{flex-direction:column;align-items:stretch;gap:4px;font-size:12px;color:#999}
.cdx-tm input.cdx-cn{width:100%!important}
.cdx-when{font-size:11px;color:#777;margin-top:6px;line-height:1.5}
.cdx-fold{width:22px;height:22px;padding:0;border:0;background:none;color:#f28c0f;cursor:pointer;font-size:13px;line-height:22px;transition:transform .15s;flex:none}
.cdx-i.off .cdx-fold{transform:rotate(-90deg)}
.cdx-i.off .cdx-body,.cdx-i.off .cdx-tm{display:none}
.cdx-rh>.cdx-rhh{display:flex;align-items:center;gap:6px;background:none;border:0;padding:0;color:#f28c0f;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;text-align:left}
.cdx-rhh i{font-style:normal;display:inline-block;transition:transform .15s}
.cdx-rh.off .cdx-rhh i{transform:rotate(-90deg)}
.cdx-rhh small{margin-left:auto;color:#777;font-weight:400;font-size:12px}
.cdx-rh.off>:not(.cdx-rhh){display:none}
.cdx-folds{display:flex;align-items:center;gap:6px}`;
      pd.head.appendChild(st);
    }

    const MIN = o.min || 1, MAX = o.max || 12, DEF = o.def || 6;
    let v; try { v = JSON.parse(field.value); } catch (e) { v = null; }
    if (!v || !Array.isArray(v.items)) v = { count: DEF, items: [] };
    v.count = clamp(Math.round(num(v.count, DEF)), MIN, MAX);
    const blank = t => ({ type: t || 'image', img: '', title: '', sub: '' });
    const pad = () => { while (v.items.length < v.count) v.items.push(blank(v.items.length ? v.items[v.items.length - 1].type : 'image')); };
    pad();
    const items = () => v.items.slice(0, v.count);
    const FOLD = ED.FOLD || (ED.FOLD = new WeakSet());
    const u0 = v.ui || {};
    v.ui = {
      stagger: num(u0.stagger, TDEF.stagger), in: num(u0.in, TDEF.in), hold: num(u0.hold, TDEF.hold),
      out: num(u0.out, TDEF.out), gap: num(u0.gap, TDEF.gap), mode: MODES.includes(u0.mode) ? u0.mode : TDEF.mode
    };
    const exitOn = () => (o.exitOn ? o.exitOn() : P.exit !== 'off');
    const tm = () => FX.timing(items(), v.ui, P, exitOn());
    let commitT = 0;
    const commit = (ms = 120) => {
      clearTimeout(commitT);
      commitT = setTimeout(() => {
        field.value = JSON.stringify({ count: v.count, ui: v.ui, items: v.items.slice(0, Math.max(v.count, v.items.length)) });
        field.dispatchEvent(new pw.Event('input', { bubbles: true }));
      }, ms);
    };
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const fileInput = multi => { const f = mk('input'); f.type = 'file'; f.accept = 'image/png,image/jpeg,image/webp,image/gif'; f.multiple = !!multi; f.style.display = 'none'; return f; };
    const isImg = f => f && /^image\/(png|jpeg|webp|gif)$/.test(f.type);
    // ---------- 图片：传到工作台的 uploads\ 里，参数里只存一个路径 ----------
    // 以前是读成 base64 直接塞进参数：几张图就是好几 MB 的字符串，每改一次参数都要重新解析、
    // 重新解码所有图片 —— 又占内存又卡。现在改成 POST /api/upload（存到硬盘，返回 /uploads/xxx），
    // 参数里只剩一行路径，浏览器按普通图片加载、自带 HTTP 缓存，旧电脑也扛得住。
    // 上传前先缩到最长边 1920（够 1080p 出片和推近用），避免几十 MB 的原图把解码内存吃爆。
    const MAXEDGE = 1920;
    const decode = file => new Promise((res, rej) => {
      const url = URL.createObjectURL(file);
      const im = new Image();
      im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('图片无法识别')); };
      im.onload = () => res({ im, url });
      im.src = url;
    });
    const toBlob = (cv, type, q) => new Promise(r => cv.toBlob(r, type, q));
    const putImage = async file => {
      const { im, url } = await decode(file);
      const iw = im.naturalWidth, ih = im.naturalHeight;     // 原图尺寸（比例提醒要用）
      let body = file, type = file.type;
      try {
        if (Math.max(iw, ih) > MAXEDGE && file.type !== 'image/gif') {
          const k = MAXEDGE / Math.max(iw, ih);
          const cv = document.createElement('canvas');
          cv.width = Math.max(1, Math.round(iw * k)); cv.height = Math.max(1, Math.round(ih * k));
          cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
          let b = await toBlob(cv, 'image/webp', 0.92);
          if (!b || !/webp/.test(b.type)) b = await toBlob(cv, 'image/jpeg', 0.92);
          if (b) { body = b; type = b.type; }
        }
      } catch (e) { /* 缩不动就按原图传 */ }
      URL.revokeObjectURL(url);
      try {
        const r = await fetch('/api/upload', { method: 'POST', headers: { 'X-FX': '1', 'Content-Type': type }, body });
        const j = await r.json();
        if (!j.url) throw new Error(j.error || '上传失败');
        return { img: j.url, iw, ih };
      } catch (e) {
        // 接口不通（工作台太旧 / 单独打开页面）时退回老办法：内嵌 base64，功能不受影响
        const fr = await new Promise((res2, rej2) => { const f2 = new FileReader(); f2.onload = () => res2(f2.result); f2.onerror = () => rej2(new Error('图片读取失败')); f2.readAsDataURL(body); });
        return { img: fr, iw, ih, inline: true };
      }
    };
    const ime = (el, onCommit) => {
      let comp = false;
      el.addEventListener('compositionstart', () => { comp = true; });
      el.addEventListener('compositionend', () => { comp = false; onCommit(el.value); });
      el.addEventListener('input', e => { if (comp || e.isComposing) return; onCommit(el.value); });
    };
    // 规则 5：属性文字 + 后面一个数字框 + 下面一条滑杆，两个都能调
    const r2 = x => Math.round(x * 100) / 100;
    const ctl = (label, op, get, set) => {
      const w = mk('div', 'cdx-c'), row = mk('div', 'cdx-cr'), sp = mk('span'), bx = mk('input', 'cdx-cn'), rg = mk('input', 'cdx-rg');
      sp.textContent = label; sp.title = label;
      const hi = op.boxMax != null ? op.boxMax : op.max;
      bx.type = 'number'; bx.min = op.min; bx.max = hi; bx.step = op.step;
      rg.type = 'range'; rg.min = op.min; rg.max = op.max; rg.step = op.step;
      row.append(sp, bx); w.append(row, rg);
      w.show = () => { const x = r2(get()); rg.value = x; if (pd.activeElement !== bx) bx.value = x; };
      bx.addEventListener('input', () => {
        if (bx.value === '') return; const x = Number(bx.value); if (!Number.isFinite(x)) return;
        rg.value = clamp(x, op.min, hi); set(clamp(x, op.min, hi));
      });
      bx.addEventListener('change', () => { bx.blur(); w.show(); });
      bx.addEventListener('focus', () => setTimeout(() => bx.select(), 0));
      rg.addEventListener('input', () => { bx.value = rg.value; set(+rg.value); });
      w.show(); return w;
    };
    const SEC = { min: 0.1, max: 5, step: 0.05, boxMax: 60 }, HOLD = { min: 0, max: 30, step: 0.1, boxMax: 600 };

    // ---------- 【比例检查】图片比例和卡片比例对不上时，提醒 + 一键处理 ----------
    const cardRatio = () => FX.ratioOf(P, '16:9');
    // 【区域C6】弹窗用的卡片比例（高/宽）：效果自己的卡片不是按「卡片比例」参数算的，就传 o.cropRatio(卡片, 第几张)
    const cropRatio = (c, i) => {
      try { const r = o.cropRatio && o.cropRatio(c, i); if (r > 0) return r; } catch (e) { }
      const el = document.querySelector('.fxc:not(.f-hole)');            // 画面里真实卡片的内框（扣掉边框）
      if (el && el.clientWidth > 0 && el.clientHeight > 0) return el.clientHeight / el.clientWidth;
      return cardRatio();
    };
    // 改右侧面板里的某个参数（用来一键「把卡片比例改成 9:16」「改成完整显示」）
    const setParam = (labelPrefix, value) => {
      const rows = [...box.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);
      const row = rows.find(el => el.tagName === 'LABEL' && labelOf(el).startsWith(labelPrefix));
      const inp = row && row.querySelector('select,input');
      if (!inp) return false;
      inp.value = value;
      inp.dispatchEvent(new pw.Event('input', { bubbles: true }));
      inp.dispatchEvent(new pw.Event('change', { bubbles: true }));
      return true;
    };
    const pct = x => Math.round(x * 100) + '%';
    // 缩略图按卡片比例显示（所见即所得）；竖卡会很高，所以按高度封顶 190px，宽度跟着缩
    const applyThumb = (ph, c) => {
      if (!ph) return;
      const ar = 1 / cardRatio();                        // 宽 / 高
      ph.classList.add('ar');
      ph.style.setProperty('--ar', String(ar));
      ph.style.maxWidth = ar < 1.4 ? Math.round(190 * ar) + 'px' : '';
      const im = ph.querySelector('img');
      if (im) { im.style.objectPosition = FX.focusPos(c.focus); im.style.objectFit = P.fit === 'contain' ? 'contain' : 'cover'; }
    };
    function ratioBox(c) {
      const info = FX.cropInfo(+c.iw, +c.ih, cardRatio());
      if (!info || info.same) return null;              // 没记尺寸（老卡片）或比例本来就一致 → 不啰嗦
      if (c.zoom != null) return null;                  // 已经在弹窗里定过构图，裁哪块是用户自己选的，不再提醒
      const contain = P.fit === 'contain';
      const w = mk('div', 'cdx-warn');
      w.innerHTML = '<b>比例对不上</b>图片 ' + (+c.iw) + '×' + (+c.ih) + '（≈' + info.best + '），卡片是 ' + (P.ratio || '16:9') + '。'
        + (contain ? '现在是「完整显示」，不裁剪，但卡片里会留边。'
          : '按现在的「铺满卡片」会裁掉大约 <u>' + pct(info.loss) + '</u> 的画面。');
      const btns = mk('div', 'cdx-wbtn');
      const b1 = mk('button', 'cdx-b'); b1.type = 'button'; b1.textContent = '把卡片比例改成 ' + info.best;
      b1.onclick = () => { if (!setParam('卡片比例', info.best)) note.textContent = '这个效果没有「卡片比例」参数'; };
      const b2 = mk('button', 'cdx-b'); b2.type = 'button';
      b2.textContent = contain ? '改回铺满（会裁剪）' : '完整显示（留边，不裁）';
      b2.onclick = () => { if (!setParam('照片', contain ? 'cover' : 'contain')) note.textContent = '这个效果没有「填充方式」参数'; };
      btns.append(b1, b2);
      w.appendChild(btns);
      if (!contain) {
        const vert = info.axis === 'v';
        const opts = vert ? [['top', '上'], ['center', '中'], ['bottom', '下']] : [['left', '左'], ['center', '中'], ['right', '右']];
        const row = mk('div', 'cdx-focus', '<span>裁剪保留' + (vert ? '上 / 中 / 下' : '左 / 中 / 右') + '</span>');
        const seg = mk('div', 'cdx-seg');
        opts.forEach(([k, label]) => {
          const b = mk('button'); b.type = 'button'; b.textContent = label;
          if ((c.focus || 'center') === k) b.className = 'on';
          b.onclick = () => { c.focus = k; draw(); commit(); };
          seg.appendChild(b);
        });
        row.appendChild(seg);
        w.appendChild(row);
      }
      return w;
    }
    const RH = Object.assign({ title: '节奏 · 统一设置所有卡片', in: '进场时长（秒）', hold: '停留时长（秒）', out: '退出时长（秒）', stagger: '出现间隔（秒）', gap: '退场间隔（秒）', order: '退场顺序' }, o.rhythm || {});
    const ORD = Object.assign({
      lifo: '全部出现后一起停留，从最后一张开始依次退场', fifo: '全部出现后一起停留，从第 1 张开始依次退场',
      together: '全部出现后一起停留，同时退场', custom: '每张卡片出现后，按它自己的「停留」时长退场'
    }, o.orderNote || {});
    const hasRh = o.rhythm !== false;        // 有的效果（粒子群）不按张排时间，用整体浮现 / 消散
    let cardCtl = [];
    const fmtS = x => r2(x).toFixed(2).replace(/\.?0+$/, '') + ' 秒';
    function refreshTimes() {
      if (hasRh) {
        const R = tm(), ex = exitOn();
        rhythm.querySelectorAll('.cdx-c').forEach(c => c.show());
        ordSeg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.m === v.ui.mode));
        gapCtl.style.display = (v.ui.mode === 'lifo' || v.ui.mode === 'fifo') ? '' : 'none';
        ordNote.textContent = ORD[v.ui.mode];
        cardCtl.forEach(k => {
          k.ctls.forEach(c => c.show());
          const T = R.T[k.i]; if (!T) return;
          const desc = k.c.type === 'hole' ? '镂空窗口'
            : k.c.type === 'text' ? '「' + (plain(k.c.title || '').trim() || '标题') + '」'
              : k.c.type === 'video' ? (k.c.video ? '视频' : '视频（未上传）') : k.c.img ? '照片' : '照片（未上传）';
          if (k.auto) k.auto.style.display = T.manual ? '' : 'none';
          k.line.textContent = (k.it.classList.contains('off') ? desc + ' · ' : '')
            + '第 ' + fmtS(T.a) + '出现' + (T.manual ? '（手动定的）' : '') + (ex ? ' · 第 ' + fmtS(T.e) + '开始退场 · ' + fmtS(T.e + T.out) + '离场' : ' · 之后一直停在画面上');
        });
        totalNote.textContent = '整段动画约 ' + fmtS(R.total);
        rhSum.textContent = '共 ' + fmtS(R.total);
      }
      if (fillBox) {
        const n = o.screenCount ? o.screenCount() : v.count;
        const f = FX.fillInfo(items(), n);
        if (f.real === 0) { fillBox.style.display = ''; fillBox.textContent = '还没填任何内容，画面上先用带编号的占位卡顶着。上传照片 / 填文字 / 传视频后会自动替换。'; }
        else if (f.borrowed > 0) { fillBox.style.display = ''; fillBox.textContent = `画面上要 ${f.n} 张，你填了 ${f.real} 张有内容的 —— 剩下 ${f.borrowed} 张会循环借用这 ${f.real} 张的内容，不会出现空白卡。`; }
        else fillBox.style.display = 'none';
      }
      if (o.onRefresh) try { o.onRefresh(); } catch (e) { }
    }
    const changed = () => { refreshTimes(); commit(); };
    // 改了某一张的停留：先把当前每张的实际停留写下来，再切到「每张自定」，其他卡片不会跳
    const toCustom = () => {
      if (v.ui.mode === 'custom') return;
      const T = tm().T; items().forEach((c, k) => { c.hold = r2(T[k].hold); }); v.ui.mode = 'custom';
    };

    const wrap = mk('div', 'cdx'); wrap.append(key);
    const head = mk('div', 'cdx-h');
    const cntCtl = ctl(o.countLabel || '卡片数量', { min: MIN, max: MAX, step: 1 }, () => v.count, x => setCount(x));
    if (!o.hideCount) head.append(cntCtl);
    head.append(
      mk('div', 'cdx-folds', '卡片<button type="button" class="cdx-b" data-fold="1">全部收起</button><button type="button" class="cdx-b" data-fold="0">全部展开</button>'),
      mk('div', 'cdx-all', '全部设为<button type="button" class="cdx-b" data-all="image">照片</button><button type="button" class="cdx-b" data-all="text">文字</button><button type="button" class="cdx-b" data-all="video">视频</button>')
    );
    // ---------- 节奏 ----------
    const rhythm = mk('div', 'cdx-rh', `<button type="button" class="cdx-rhh"><i>▾</i>${RH.title}<small></small></button>`);
    const rhSum = rhythm.querySelector('small');
    if (ED.rhOff) rhythm.classList.add('off');
    rhythm.querySelector('.cdx-rhh').onclick = () => { ED.rhOff = rhythm.classList.toggle('off'); };
    const allIn = ctl(RH.in, SEC, () => v.ui.in, x => { v.ui.in = x; items().forEach(c => c.inDur = x); changed(); });
    const allHold = ctl(RH.hold, HOLD, () => v.ui.hold, x => { v.ui.hold = x; if (v.ui.mode === 'custom') items().forEach(c => c.hold = x); changed(); });
    const allOut = ctl(RH.out, SEC, () => v.ui.out, x => { v.ui.out = x; items().forEach(c => c.outDur = x); changed(); });
    const stagCtl = ctl(RH.stagger, { min: 0, max: 5, step: 0.02, boxMax: 60 }, () => v.ui.stagger, x => { v.ui.stagger = x; changed(); });
    const ord = mk('div', 'cdx-ord', RH.order);
    const ordSeg = mk('div', 'cdx-seg', '<button type="button" data-m="lifo">后出先退</button><button type="button" data-m="fifo">先出先退</button><button type="button" data-m="together">同时</button><button type="button" data-m="custom">每张自定</button>');
    const ordNote = mk('div', 'cdx-note'); ordNote.style.marginTop = '0';
    ordSeg.querySelectorAll('button').forEach(b => b.onclick = () => { if (b.dataset.m === 'custom') toCustom(); else v.ui.mode = b.dataset.m; changed(); });
    ord.append(ordSeg, ordNote);
    const gapCtl = ctl(RH.gap, { min: 0, max: 3, step: 0.02, boxMax: 60 }, () => v.ui.gap, x => { v.ui.gap = x; changed(); });
    const totalNote = mk('div', 'cdx-note'); totalNote.style.marginTop = '0';
    rhythm.append(allIn, allHold, allOut, stagCtl, ord, gapCtl, totalNote);

    const fillBox = o.screenCount !== false ? mk('div', 'cdx-fill') : null;
    const list = mk('div', 'cdx-list');
    const bulk = mk('button', 'cdx-bulk'); bulk.type = 'button'; bulk.textContent = '批量上传照片（按顺序填进照片卡）';
    const bulkIn = fileInput(true);
    const note = mk('div', 'cdx-note');
    // 老项目里的图片是以 base64 内嵌在参数里的（占内存、每次改参数都要重新解码）。
    // 这个按钮把它们转存到 uploads\，参数里只留路径。
    const mig = mk('button', 'cdx-bulk'); mig.type = 'button';
    const inlineN = () => items().filter(c => c.type === 'image' && /^data:/.test(c.img || '')).length;
    const showMig = () => {
      const n = inlineN();
      mig.style.display = n ? '' : 'none';
      mig.textContent = '把 ' + n + ' 张内嵌图片转存到硬盘（更省内存、更流畅）';
    };
    mig.onclick = async () => {
      mig.disabled = true; mig.textContent = '转存中…';
      for (const c of items()) {
        if (c.type !== 'image' || !/^data:/.test(c.img || '')) continue;
        try {
          const b = await (await fetch(c.img)).blob();
          const d = await new Promise(r => { const im = new Image(); im.onload = () => r({ w: im.naturalWidth, h: im.naturalHeight }); im.onerror = () => r({ w: 0, h: 0 }); im.src = c.img; });
          const j = await (await fetch('/api/upload', { method: 'POST', headers: { 'X-FX': '1', 'Content-Type': b.type }, body: b })).json();
          if (j.url) { c.img = j.url; if (d.w) { c.iw = d.w; c.ih = d.h; } }
        } catch (e) { note.textContent = '转存失败：' + e.message; }
      }
      mig.disabled = false; draw(); commit();
    };
    const setCount = n => { const c = clamp(Math.round(+n || MIN), MIN, MAX); if (c === v.count) return; v.count = c; pad(); draw(); commit(); };
    head.querySelectorAll('[data-fold]').forEach(b => b.onclick = () => { items().forEach(c => b.dataset.fold === '1' ? FOLD.add(c) : FOLD.delete(c)); draw(); });
    head.querySelectorAll('[data-all]').forEach(b => b.onclick = () => { v.items.slice(0, v.count).forEach(c => c.type = b.dataset.all); draw(); commit(); });
    bulk.onclick = () => bulkIn.click();
    bulkIn.onchange = async () => {
      const files = [...bulkIn.files].filter(isImg); bulkIn.value = '';
      if (!files.length) return;
      bulk.disabled = true; bulk.textContent = '读取中…';
      for (const f of files) {
        let i = v.items.slice(0, v.count).findIndex(c => c.type === 'image' && !c.img);
        if (i < 0) { if (v.count >= MAX) { note.textContent = '最多 ' + MAX + ' 张卡片'; break; } v.count++; pad(); i = v.count - 1; v.items[i] = blank('image'); }
        try { FX.resetPlace(v.items[i]); Object.assign(v.items[i], await putImage(f), { type: 'image' }); } catch (e) { note.textContent = e.message; }
      }
      cntCtl.show(); bulk.disabled = false; bulk.textContent = '批量上传照片（按顺序填进照片卡）'; draw(); commit();
    };

    // 图片卡的「比例提醒 / 缩略图」要跟着卡片比例、填充方式变，但又不能重建整个列表（会打断输入），
    // 所以单独记下来，参数变了只换这一小块
    let imgCards = [];
    const refreshRatio = () => {
      imgCards.forEach(k => {
        const old = k.body.querySelector('.cdx-warn');
        const adv = ratioBox(k.c);
        if (old && adv) k.body.replaceChild(adv, old);
        else if (old) old.remove();
        else if (adv) k.body.insertBefore(adv, k.clr || null);
        applyThumb(k.ph, k.c);
      });
    };
    ED.setP = p => { P = p || {}; refreshTimes(); refreshRatio(); };

    let dragFrom = -1;
    function draw() {
      list.innerHTML = ''; cardCtl = []; imgCards = [];
      v.items.slice(0, v.count).forEach((c, i) => {
        const it = mk('div', 'cdx-i',
          '<div class="cdx-top"><button type="button" class="cdx-fold" title="收起 / 展开">▾</button><span class="cdx-grip" title="按住拖动调整顺序">⠿</span><span class="cdx-no"></span>'
          + '<div class="cdx-seg"><button type="button" data-t="image">照片</button><button type="button" data-t="text">文字</button><button type="button" data-t="video">视频</button>'
          + '<button type="button" data-t="hole" title="镂空：这块导出后是透明的，后期在下面垫自己的视频">镂空</button></div>'
          + '<button type="button" class="cdx-del" title="删除这张卡片">×</button></div><div class="cdx-body"></div>');
        it.querySelector('.cdx-no').textContent = i + 1;
        if (FOLD.has(c)) it.classList.add('off');
        it.querySelector('.cdx-fold').onclick = () => { it.classList.toggle('off') ? FOLD.add(c) : FOLD.delete(c); refreshTimes(); };
        it.querySelectorAll('.cdx-seg button').forEach(b => { b.classList.toggle('on', b.dataset.t === c.type); b.onclick = () => { c.type = b.dataset.t; draw(); commit(); }; });
        it.querySelector('.cdx-del').onclick = () => { if (v.count <= MIN) return; v.items.splice(i, 1); v.count--; cntCtl.show(); pad(); draw(); commit(); };
        const body = it.querySelector('.cdx-body');
        if (c.type === 'text') {
          const t1 = mk('input', 'cdx-txt'), t2 = mk('input', 'cdx-txt');
          t1.type = t2.type = 'text';
          t1.placeholder = '标题（用 **文字** 标出重点）'; t2.placeholder = '副标题（可不填，也支持 **重点**）';
          t1.value = c.title || ''; t2.value = c.sub || '';
          ime(t1, val => { c.title = val; commit(300); });
          ime(t2, val => { c.sub = val; commit(300); });
          body.append(t1, t2);
        } else if (c.type === 'video') {
          body.append(FXVideo.editorBody({ pd, c, total: () => +window.getDuration() || 0,
          changed: FX.wrapVideoChanged(c, () => cropRatio(c, i), () => { draw(); commit(); }), note: m => { note.textContent = m; } }));
        if (c.video) body.append(FX.adjustBtn({ pd, it: c, ratio: () => cropRatio(c, i), onOk: () => { draw(); commit(); } }));
        } else if (c.type === 'hole') {
          body.append(mk('div', 'cdx-hole',
            '<b>这块是透明的</b>导出的 ProRes 4444 里这张卡内部 alpha = 0，只留一圈边框和投影。<br>'
            + '剪辑软件里把<b>你自己的视频放在下面一轨</b>，这个效果放上面一轨，视频就会从这个窗口里透出来 ——'
            + '<b>一秒视频都不用上传</b>，10 分钟的片子也不怕。'));
        } else {
          const ph = mk('div', 'cdx-ph' + (c.img ? ' has' : ''), c.img ? '<img alt=""><span>点击更换照片</span>' : '<span>点击上传照片<br><small>或把图片拖到这里</small></span>');
          if (c.img) { ph.querySelector('img').src = c.img; applyThumb(ph, c); }
          const fin = fileInput(false);
          const put = async f => {
            if (!isImg(f)) { note.textContent = '只支持 PNG / JPG / WEBP / GIF 图片'; return; }
            ph.innerHTML = '<span>上传中…</span>';
            let ok = false;
            try { FX.resetPlace(c); Object.assign(c, await putImage(f)); ok = true; } catch (e) { note.textContent = e.message; }
            draw(); commit();
            if (ok) FX.crop({ it: c, ratio: cropRatio(c, i), onOk: () => { draw(); commit(); } });   // 【区域C6】上传完自动弹出调整窗口
          };
          ph.onclick = () => fin.click();
          fin.onchange = () => put(fin.files[0]);
          ph.addEventListener('dragover', e => { if (dragFrom < 0 && [...e.dataTransfer.types].includes('Files')) { e.preventDefault(); ph.classList.add('over'); } });
          ph.addEventListener('dragleave', () => ph.classList.remove('over'));
          ph.addEventListener('drop', e => { if (dragFrom >= 0 || !e.dataTransfer.files.length) return; e.preventDefault(); e.stopPropagation(); put(e.dataTransfer.files[0]); });
          body.append(ph, fin);
          if (c.img) {
            const adv = ratioBox(c);                      // 比例不匹配时的提醒 + 一键处理
            if (adv) body.appendChild(adv);
            body.appendChild(FX.adjustBtn({ pd, it: c, ratio: () => cropRatio(c, i), onOk: () => { draw(); commit(); } }));
            const clr = mk('button', 'cdx-clr'); clr.type = 'button'; clr.textContent = '移除照片';
            clr.onclick = () => { c.img = ''; c.iw = c.ih = 0; FX.resetPlace(c); draw(); commit(); };
            body.appendChild(clr);
            imgCards.push({ c, body, ph, clr });
          }
        }
        if (o.extraCard) { const ex = o.extraCard(c, i, { mk, ctl, commit, draw, changed }); if (ex) body.append(ex); }
        if (hasRh) {
          const tb = mk('div', 'cdx-tm'), line = mk('div', 'cdx-when');
          const T = () => tm().T[i] || { in: v.ui.in, hold: v.ui.hold, out: v.ui.out };
          const ctls = [
            // 出现在第几秒 = 素材条上这张卡的绿旗子（两边是同一个值）；不填就跟着「出现间隔」自动排
            ctl('出现在第几秒', { min: 0, max: 30, step: 0.05, boxMax: 600 }, () => T().a || 0, x => { c.at = r2(x); changed(); }),
            ctl('进场', SEC, () => T().in, x => { c.inDur = x; changed(); }),
            ctl('停留', HOLD, () => T().hold, x => { toCustom(); c.hold = x; changed(); }),
            ctl('退出', SEC, () => T().out, x => { c.outDur = x; changed(); }),
          ];
          const auto = mk('button', 'cdx-b cdx-auto'); auto.type = 'button'; auto.textContent = '出现时间恢复自动';
          auto.title = '不再单独定这张卡的出现时间，跟在上一张后面隔「出现间隔」出现';
          auto.onclick = () => { delete c.at; changed(); };
          tb.append(...ctls); it.append(tb, line, auto);
          cardCtl.push({ i, ctls, line, c, it, auto });
        }
        // 卡片背景动效：这张卡单独调（_shared/fx-cardbg.js【区域B6】，总开关关着时自动藏起来）
        if (window.FXCardBg && FXCardBg.perCard && FXCardBg.cardBlock) it.append(FXCardBg.cardBlock({ pd, pw, key: 'cdx' + i, get: () => c.cardbg, set: x => { c.cardbg = x; commit(); } }).el);
        const grip = it.querySelector('.cdx-grip');
        grip.addEventListener('mousedown', () => { it.draggable = true; });
        grip.addEventListener('mouseup', () => { it.draggable = false; });
        it.addEventListener('dragstart', e => { dragFrom = i; it.classList.add('drag'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'card'); });
        it.addEventListener('dragend', () => { dragFrom = -1; it.draggable = false; it.classList.remove('drag'); list.querySelectorAll('.over').forEach(x => x.classList.remove('over')); });
        it.addEventListener('dragover', e => { if (dragFrom < 0) return; e.preventDefault(); it.classList.add('over'); });
        it.addEventListener('dragleave', e => { if (!it.contains(e.relatedTarget)) it.classList.remove('over'); });
        it.addEventListener('drop', e => {
          if (dragFrom < 0) return; e.preventDefault();
          const [m] = v.items.splice(dragFrom, 1); v.items.splice(i, 0, m); dragFrom = -1; draw(); commit();
        });
        list.appendChild(it);
      });
      note.innerHTML = (o.note || '') + '文字卡里用 <b>**文字**</b> 标出重点（主题色），<b>*文字*</b> 只加粗，<b>~文字~</b> 划掉。按住 ⠿ 上下拖动调整顺序'
        + (hasRh ? '，1 号最先出现。每张卡片下面可以单独调进场、停留、退出时长。' : '。')
        + '预览区：滚轮缩放 · 按住左键拖动位置 · 双击还原。';
      showMig();
      refreshTimes();
    }
    wrap.append(head);
    if (hasRh) wrap.append(rhythm);
    if (o.extraTop) { const ex = o.extraTop({ mk, ctl, commit, refreshTimes }); if (ex) wrap.append(ex); }
    if (fillBox) wrap.append(fillBox);
    wrap.append(list, bulk, mig, bulkIn, note);
    jl.after(wrap);
    ED.mounted = wrap; ED.refresh = refreshTimes;
    // 点素材条上第 i 张卡的旗子：展开这张卡（节奏块不动），返回它给工作台滚到中间、闪两下
    FX._edFocus = i => {
      const c = items()[i], el = list.children[i]; if (!el) return null;
      if (c) FOLD.delete(c);
      el.classList.remove('off'); refreshTimes();
      return el.querySelector('.cdx-tm') || el;
    };
    draw();
  };
})();

/* 卡片背景动效（规则 40）：所有引用本文件的效果自动带上 _shared/fx-cardbg.js，效果里不用自己写 <script>。
   用 document.write 是为了让它在效果自己的脚本之前就加载好（同步、顺序不变）。 */
(function () {
  if (window.FXCardBg || document.readyState !== 'loading') return;
  const me = document.currentScript; if (!me || !me.src) return;
  document.write('<script src="' + me.src.replace(/fx-cards\.js(\?.*)?$/, 'fx-cardbg.js') + '"><\/script>');
})();
