/* =====================================================================
 * 效果工坊 · 圆卡公共模块 FXDisc（v33.5，2026-11-13 从「圆形闪光换色卡」round-flash-card 抽出来）
 * ---------------------------------------------------------------------
 * 管什么：画一张圆形名牌卡（一层）——
 *   【D1 样式表】   圆卡用到的 class（.ly .disc .rim .tx …），加载时自动装进页面
 *   【D2 版式库】   SPEC：文字 / 图标 / 人物在圆里怎么摆（坐标都是占直径的比例）；logo / logoFill = 纯 logo（2026-11-18）
 *   【D3 示例素材】 DEMO_ICON / DEMO_PERSON（没上传时用）
 *   【D4 小工具】   花纹 ORN、环形文字 ringSvg、按字宽缩字号 fitFs
 *   【D5 画一层】   FXDisc.layer(o)：圆底（玻璃）+ 金属描边 + 外发光 + 文字 + 图标 + 人物 + 高亮层 + （可选）闪光层 + 编号小圆
 *   【D6 形状】     圆形 / 方形 / 长方形 / 六边形（P.shape 或 o.shape，2026-11-18）
 *   【D7 图片底卡】 版式 bgText：上传的背景图铺满整张卡（o.bg，readBg），P.bgDim 调明暗，上面写字（2026-11-18）
 * 谁在用：圆形闪光换色卡 round-flash-card、竞价柱状图 bid-bar-chart
 * 引入顺序：fx-cards.js → fx-skin.js → fx-transition.js → fx-disc.js → 效果脚本
 * 规则 28：这里的代码是从圆形闪光换色卡原样搬过来的，原效果改成调用它，画面逐像素一致。
 * ===================================================================== */
(function () {
  if (window.FXDisc) return;
  const D_ = window.FXDisc = {};
  const F = () => window.FXCards, SK = () => window.FXSkin, TX = () => window.FXTrans;

  // ================= 【D1 样式表】 =================
  D_.CSS = `
.ly{position:absolute;will-change:filter,opacity}
.disc{position:absolute;inset:0;border-radius:50%;overflow:hidden}
.disc .fill{position:absolute;inset:0}
.disc .gl{position:absolute;inset:0;border-radius:50%;pointer-events:none}
.badge{position:absolute;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:"Montserrat","Segoe UI","Arial",sans-serif!important;font-weight:700;color:#eef0f5;z-index:5}
.rim{position:absolute;border-radius:50%;pointer-events:none;z-index:2;will-change:transform}
.hl{position:absolute;inset:0;border-radius:50%;pointer-events:none;opacity:0}
.flash,.sweep,.shade{position:absolute;pointer-events:none;opacity:0;will-change:opacity}
.disc .gl{will-change:opacity}
.tx{position:absolute;white-space:nowrap;text-align:center;line-height:1.1}
.tx em.hi{font-style:normal}
.tcn{font-weight:900;letter-spacing:.12em}
.ten{font-family:"Montserrat","Segoe UI","Arial",sans-serif!important;font-weight:700;letter-spacing:.14em}
.tsc{font-family:"Playfair Display",Georgia,"Times New Roman",serif!important;font-style:italic;font-weight:600;letter-spacing:.01em}
.dots{position:absolute;height:0}
.orn,.ring{position:absolute;overflow:visible}
.band{position:absolute;left:0;right:0}
.bign{position:absolute;display:flex;justify-content:space-between;align-items:center;white-space:nowrap}
.ic,.pp{position:absolute;overflow:visible}
.ic>*,.pp>*{position:absolute;inset:0;width:100%;height:100%;display:block}
.ic img{object-fit:contain}
.ic .tint{-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;-webkit-mask-size:contain;mask-size:contain}
.pp img,.pp video{object-fit:contain;object-position:50% 100%}`;
  D_.injectCss = doc => {
    doc = doc || document;
    if (doc.getElementById('fxdisc-css')) return;
    const s = doc.createElement('style'); s.id = 'fxdisc-css'; s.textContent = D_.CSS;
    (doc.head || doc.documentElement).appendChild(s);
  };
  D_.injectCss();

  // ================= 【D2 版式库】坐标都是「占圆直径的比例」，x 是文字中线 =================
  // 每个版式：ornT / ornB 上下花纹，icon {x,y,w,h}（中心点 + 宽高），script / en / cn {x,y,fs,mw}（y = 文字中线），
  // dots {x,y,w}，person {x,y,w,h}（左上角 + 宽高，人物贴着框底），head {x,y,w,h}（裁剪参考线里「头放这里」的位置：中心 + 宽高），band 底部压暗条 {y}，ring 环形英文，bigName 人名背景，top 人物盖在文字上面
  const STD = { ornT: 0.065, ornB: 0.93, icon: { x: 0.5, y: 0.25, w: 0.21, h: 0.17 }, script: { x: 0.5, y: 0.395, fs: 0.07, mw: 0.6 },
    dots: { x: 0.5, y: 0.462, w: 0.52 }, cn: { x: 0.5, y: 0.585, fs: 0.19, mw: 0.78 }, en: { x: 0.5, y: 0.735, fs: 0.042, mw: 0.6 } };
  D_.SPEC = {
    std: STD,                                                     // 文字名牌：图标 + 花体 + 点线 + 大字 + 英文（圆形闪光换色卡的开场版式）
    personTop: { ornT: 0.065, cn: { x: 0.5, y: 0.17, fs: 0.13, mw: 0.6 }, en: { x: 0.5, y: 0.255, fs: 0.036, mw: 0.5 },
      person: { x: 0.13, y: 0.29, w: 0.74, h: 0.73 }, head: { x: 0.5, y: 0.48, w: 0.28, h: 0.36 }, top: true },   // 人物居中、名字在头顶
    ref: { ornT: 0.065, en: { x: 0.42, y: 0.17, fs: 0.042, mw: 0.5 }, cn: { x: 0.42, y: 0.29, fs: 0.165, mw: 0.62 },
      dots: { x: 0.42, y: 0.4, w: 0.48 }, icon: { x: 0.42, y: 0.545, w: 0.2, h: 0.16 }, script: { x: 0.42, y: 0.69, fs: 0.07, mw: 0.5 },
      person: { x: 0.44, y: 0.27, w: 0.64, h: 0.75 }, head: { x: 0.74, y: 0.44, w: 0.32, h: 0.42 }, top: true },   // 参考图：文字在左、人物在右
    left: { ornT: 0.065, en: { x: 0.6, y: 0.17, fs: 0.042, mw: 0.5 }, cn: { x: 0.6, y: 0.29, fs: 0.165, mw: 0.62 },
      dots: { x: 0.6, y: 0.4, w: 0.48 }, icon: { x: 0.6, y: 0.545, w: 0.2, h: 0.16 }, script: { x: 0.6, y: 0.69, fs: 0.07, mw: 0.5 },
      person: { x: -0.08, y: 0.27, w: 0.64, h: 0.75 }, head: { x: 0.26, y: 0.44, w: 0.32, h: 0.42 }, top: true },  // 人物在左
    bigA: { ornT: 0.08, ornB: 0.915, cn: { x: 0.5, y: 0.46, fs: 0.23, mw: 0.8 }, en: { x: 0.5, y: 0.625, fs: 0.046, mw: 0.62 }, dots: { x: 0.5, y: 0.7, w: 0.3 } },   // 极简大字
    bigB: { person: { x: 0.08, y: 0.12, w: 0.84, h: 0.9 }, head: { x: 0.5, y: 0.36, w: 0.3, h: 0.38 }, band: { y: 0.6 }, cn: { x: 0.5, y: 0.79, fs: 0.13, mw: 0.62 }, en: { x: 0.5, y: 0.885, fs: 0.034, mw: 0.44 } },
    ringA: { ring: true, icon: { x: 0.5, y: 0.31, w: 0.2, h: 0.16 }, cn: { x: 0.5, y: 0.54, fs: 0.17, mw: 0.66 }, dots: { x: 0.5, y: 0.65, w: 0.34 }, script: { x: 0.5, y: 0.735, fs: 0.06, mw: 0.5 } },
    ringB: { ring: true, person: { x: 0.17, y: 0.2, w: 0.66, h: 0.82 }, head: { x: 0.5, y: 0.41, w: 0.27, h: 0.34 }, band: { y: 0.62 }, cn: { x: 0.5, y: 0.8, fs: 0.12, mw: 0.56 } },
    portrait: { en: { x: 0.5, y: 0.15, fs: 0.055, mw: 0.62 }, bigName: { y: 0.47, fs: 0.3, w: 0.84 },
      person: { x: 0.14, y: 0.2, w: 0.72, h: 0.82 }, head: { x: 0.5, y: 0.43, w: 0.28, h: 0.36 }, top: true },
    mergeA: { ornT: 0.07, ornB: 0.925, icon: { x: 0.5, y: 0.25, w: 0.24, h: 0.19 }, dots: { x: 0.5, y: 0.4, w: 0.56 },
      cn: { x: 0.5, y: 0.555, fs: 0.2, mw: 0.8 }, en: { x: 0.5, y: 0.72, fs: 0.05, mw: 0.66 } },
    // 纯 logo（2026-11-18）：圆里只放一个 logo，没有文字 / 花纹 / 人物。logo 用的是这张卡的「图标」素材（icon），没上传时显示 DEMO_LOGO。
    //   logo = 'contain'：logo 放在圆中间、占直径 86%；'cover'：logo 铺满整个圆、被圆裁掉（像圆头像）
    logo: { icon: { x: 0.5, y: 0.5, w: 0.86, h: 0.86 }, logo: 'contain' },   // 2026-11-18 用户嫌小：66% → 86%（圆里能放下的最大方块是 71%，方形 logo 四角会被圆轻轻切到，透明 PNG 一般没事）
    logoFill: { icon: { x: 0.5, y: 0.5, w: 1, h: 1 }, logo: 'cover' },
    // 图片底卡（2026-11-18）：上传的背景图铺满整张卡（明暗可调），上面一行大字 + 点线 + 英文
    bgText: { bgImg: true, cn: { x: 0.5, y: 0.46, fs: 0.2, mw: 0.8 }, dots: { x: 0.5, y: 0.565, w: 0.3 }, en: { x: 0.5, y: 0.63, fs: 0.046, mw: 0.62 } }
  };
  // 【D6 形状】（2026-11-18）圆形 / 方形（圆角）/ 长方形（宽 = 1.5 倍高）/ 六边形。P.shape 或 o.shape；圆形 = 原来的代码一行不变
  D_.SHAPES = [['circle', '圆形'], ['square', '方形'], ['rect', '长方形'], ['hex', '六边形']];
  D_.shapeOf = v => (D_.SHAPES.some(x => x[0] === v) ? v : 'circle');
  D_.shapeW = (shape, D) => (shape === 'rect' ? D * 1.5 : D);       // 卡片宽（高永远是 D）
  // 形状的轮廓点（顺时针，从正上方开始），用来画金属描边；圆角矩形按弧长采样
  const HEX = [[0.25, 0.067], [0.75, 0.067], [1, 0.5], [0.75, 0.933], [0.25, 0.933], [0, 0.5]];
  D_.hexClip = 'polygon(' + HEX.map(([x, y]) => (x * 100).toFixed(1) + '% ' + (y * 100).toFixed(1) + '%').join(',') + ')';
  const shapeRad = (shape, D) => (shape === 'square' ? D * 0.14 : shape === 'rect' ? D * 0.1 : 0);
  const outline = (shape, W, H, inset) => {
    const pts = [];
    if (shape === 'hex'){
      const P0 = HEX.map(([x, y]) => [inset + x * (W - 2 * inset), inset + y * (H - 2 * inset)]);
      for (let i = 0; i < 6; i++){ const a = P0[i], b = P0[(i + 1) % 6]; for (let k = 0; k < 24; k++) pts.push([a[0] + (b[0] - a[0]) * k / 24, a[1] + (b[1] - a[1]) * k / 24]); }
      return pts;
    }
    const r = Math.max(0, shapeRad(shape, H) - inset), x0 = inset, y0 = inset, x1 = W - inset, y1 = H - inset;
    const seg = (ax, ay, bx, by) => { for (let k = 0; k < 20; k++) pts.push([ax + (bx - ax) * k / 20, ay + (by - ay) * k / 20]); };
    const arc = (cx, cy, a0) => { for (let k = 0; k < 12; k++){ const a = a0 + Math.PI / 2 * k / 12; pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); } };
    seg(x0 + r, y0, x1 - r, y0); arc(x1 - r, y0 + r, -Math.PI / 2);
    seg(x1, y0 + r, x1, y1 - r); arc(x1 - r, y1 - r, 0);
    seg(x1 - r, y1, x0 + r, y1); arc(x0 + r, y1 - r, Math.PI / 2);
    seg(x0, y1 - r, x0, y0 + r); arc(x0 + r, y0 + r, Math.PI);
    return pts;
  };
  // 形状外面一圈的光 / 高亮色描边（box-shadow 跟不了六边形，六边形用一张 SVG）
  const shapeAura = (shape, W, H, color, blur, stroke) => {
    const pad = blur * 2 + stroke, d = 'M' + outline(shape, W, H, 0).map(p => (p[0] + pad).toFixed(1) + ' ' + (p[1] + pad).toFixed(1)).join('L') + 'Z';
    const id = 'fxa' + Math.random().toString(36).slice(2, 8);
    return `<svg width="${(W + 2 * pad).toFixed(1)}" height="${(H + 2 * pad).toFixed(1)}" style="position:absolute;left:${(-pad).toFixed(1)}px;top:${(-pad).toFixed(1)}px;overflow:visible">`
      + (blur > 0 ? `<defs><filter id="${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="${(blur / 2).toFixed(1)}"/></filter></defs>` : '')
      + `<path d="${d}" fill="none" stroke="${color}" stroke-width="${stroke.toFixed(1)}" stroke-linejoin="round"${blur > 0 ? ` filter="url(#${id})"` : ''}/></svg>`;
  };
  // 示例背景（没上传时）：通用的抽象渐变山景
  D_.DEMO_BG = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a6fb0"/><stop offset=".6" stop-color="#9cc3e6"/><stop offset="1" stop-color="#f1d9b5"/></linearGradient></defs><rect width="300" height="300" fill="url(#s)"/><circle cx="215" cy="105" r="26" fill="#fff4d6" fill-opacity=".85"/><path d="M0 220L60 150L110 195L170 120L235 185L300 140V300H0Z" fill="#2d4a6d"/><path d="M0 255L80 205L150 240L220 200L300 235V300H0Z" fill="#1b2f48"/></svg>');
  D_.readBg = raw => { let m = raw; if (typeof m === 'string'){ try { m = JSON.parse(m); } catch (e) { m = null; } } m = m && typeof m === 'object' && !Array.isArray(m) ? m : { type: 'demo' }; if (!['demo', 'image', 'none'].includes(m.type)) m.type = 'demo'; return m; };
  D_.isLogo = sp => !!(sp && sp.logo);

  // ================= 【D3 示例素材】（没上传时用；都是通用图形） =================
  const svgUrl = s => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s);
  D_.DEMO_ICON = svgUrl('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 100"><g fill="#fff"><circle cx="60" cy="50" r="40" fill="none" stroke="#fff" stroke-width="5"/><path d="M60 16 L68 42 L94 50 L68 58 L60 84 L52 58 L26 50 L52 42Z"/></g></svg>');
  D_.DEMO_LOGO = svgUrl('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><circle cx="100" cy="100" r="92" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="4" stroke-dasharray="12 9"/><text x="100" y="98" font-family="Montserrat,Segoe UI,Arial,sans-serif" font-weight="800" font-size="46" fill="#fff" text-anchor="middle" letter-spacing="4">LOGO</text><text x="100" y="134" font-family="PingFang SC,Microsoft YaHei,sans-serif" font-size="17" fill="#fff" fill-opacity=".6" text-anchor="middle">上传替换</text></svg>');
  D_.DEMO_PERSON = svgUrl('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e4def0"/><stop offset="1" stop-color="#9a91b3"/></linearGradient><linearGradient id="s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3b3352"/><stop offset="1" stop-color="#1c1828"/></linearGradient></defs><ellipse cx="150" cy="105" rx="62" ry="74" fill="url(#g)"/><path d="M118 165h64v30h-64z" fill="#b9b1c9"/><path d="M10 340C20 230 70 196 150 192C230 196 280 230 290 340Z" fill="url(#s)"/><path d="M130 194L150 250L170 194Z" fill="#cfc6e4"/><text x="150" y="300" font-family="sans-serif" font-size="18" fill="#fff" fill-opacity=".5" text-anchor="middle">示例人物 · 上传替换</text></svg>');

  // ================= 【D4b 裁剪参考线】给「调整人物大小和位置」弹窗画示意图（规则 44） =================
  // o = { spec, P, txt: {cn, en} } → 返回 (W, H, u) => SVG 内容；W×H = 人物框（弹窗橙框），u = 屏幕 1px 等于多少单位
  // 画三样：白虚线圆 = 卡片边缘（圆外压暗 = 会被切掉）；名字 / 英文名 = 字在卡上的位置；蓝色虚线人形 = 头和肩膀最合适的位置
  D_.guideNote = '<b style="color:#fff">白圈里就是卡片上看到的样子</b>（照片可以超出橙框，只要在圈里都显示）　·　<span style="color:#5cd0ff">蓝色虚线人形</span> = 脸要放大到填满这个头像框　·　浅色字 = 名字的位置　·　右下「参考线」可以关掉';
  D_.cropGuide = o => { const fn = (W, H, u) => {
    const sp = o.spec || {}, pb = sp.person; if (!pb) return '';
    const P = o.P || {}, sc = Math.min(200, Math.max(30, +P.personSize || 100)) / 100;
    const bw = pb.w * sc, bh = pb.h * sc, bx = pb.x + (pb.w - bw) / 2, by = pb.y + pb.h - bh, k = W / bw;
    const X = v => ((v - bx) * k).toFixed(1), Y = v => ((v - by) * k).toFixed(1), L = v => (v * k).toFixed(1);
    u = u > 0 ? u : 1;
    const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const txt = o.txt || {}, out = [];
    // 圆外压暗 + 圆边
    const cx = X(0.5), cy = Y(0.5), r = L(0.5);
    const g0 = -3 * W, g1 = 4 * W;                                  // 圈外整片压暗（不只是人物框里）：卡片上只有圆里面看得到
    out.push(`<path fill="rgba(0,0,0,.78)" fill-rule="evenodd" d="M${g0} ${g0}H${g1}V${g1}H${g0}Z M${cx} ${(+cy - +r).toFixed(1)}A${r} ${r} 0 1 0 ${cx} ${(+cy + +r).toFixed(1)}A${r} ${r} 0 1 0 ${cx} ${(+cy - +r).toFixed(1)}Z"/>`);
    out.push(`<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#fff" stroke-opacity=".85" stroke-width="${(1.6 * u).toFixed(1)}" stroke-dasharray="${(7 * u).toFixed(1)} ${(5 * u).toFixed(1)}"/>`);
    // 底部压暗条（人物大字版式）
    if (sp.band) out.push(`<rect x="${X(0)}" y="${Y(sp.band.y)}" width="${L(1)}" height="${L(1 - sp.band.y)}" fill="rgba(0,0,0,.28)"/>`);
    // 名字
    const word = (t, b, wt, op) => {
      t = String(t || '').replace(/<[^>]*>/g, '').trim(); if (!t || !b) return;
      const n = Math.max(1, Array.from(t).length), ascii = /^[\x00-\x7f]*$/.test(t);
      const fs = Math.min(b.fs, (b.mw || b.w || 0.8) / (n * (ascii ? 0.58 : 1.02)));
      out.push(`<text x="${X(b.x == null ? 0.5 : b.x)}" y="${Y(b.y)}" font-size="${L(fs)}" font-weight="${wt}" fill="#fff" fill-opacity="${op}" text-anchor="middle" dominant-baseline="central" font-family="PingFang SC,Microsoft YaHei,sans-serif">${esc(t)}</text>`);
    };
    if (sp.bigName) word(txt.cn || '名字', { x: 0.5, y: sp.bigName.y, fs: sp.bigName.fs, w: sp.bigName.w }, 900, 0.32);
    word(txt.cn || '名字', sp.cn, 800, 0.62);
    word(txt.en, sp.en, 600, 0.5);
    // 人形：头（椭圆）+ 脖子 + 肩膀，肩膀一直画到卡片底
    const hd = sp.head || { x: pb.x + pb.w / 2, y: pb.y + pb.h * 0.22, w: pb.w * 0.27, h: pb.w * 0.34 };
    const hx = hd.x, hy = hd.y, hw = hd.w / 2, hh = hd.h / 2;
    const ny = hy + hh * 0.8, sy = hy + hh * 1.45, bot = Math.min(1.02, pb.y + pb.h), nk = hw * 0.42, sw = hw * 3.3;
    const sil = `M${X(hx - nk)} ${Y(ny)}L${X(hx - nk)} ${Y(sy)}C${X(hx - sw * 0.55)} ${Y(sy + 0.01)} ${X(hx - sw)} ${Y(sy + 0.04)} ${X(hx - sw)} ${Y(bot)}`
      + `M${X(hx + nk)} ${Y(ny)}L${X(hx + nk)} ${Y(sy)}C${X(hx + sw * 0.55)} ${Y(sy + 0.01)} ${X(hx + sw)} ${Y(sy + 0.04)} ${X(hx + sw)} ${Y(bot)}`;
    const st = `fill="none" stroke="#5cd0ff" stroke-width="${(2 * u).toFixed(1)}" stroke-dasharray="${(8 * u).toFixed(1)} ${(5 * u).toFixed(1)}" stroke-linecap="round"`;
    out.push(`<ellipse cx="${X(hx)}" cy="${Y(hy)}" rx="${L(hw)}" ry="${L(hh)}" fill="rgba(92,208,255,.10)" ${st}/>`);
    out.push(`<clipPath id="fxdg-c"><circle cx="${cx}" cy="${cy}" r="${r}"/></clipPath><path d="${sil}" ${st} clip-path="url(#fxdg-c)"/>`);
    const tf = (13 * u).toFixed(1);
    out.push(`<text x="${X(hx)}" y="${Y(hy)}" font-size="${tf}" fill="#5cd0ff" text-anchor="middle" dominant-baseline="central" font-family="PingFang SC,Microsoft YaHei,sans-serif" style="paint-order:stroke" stroke="rgba(0,0,0,.6)" stroke-width="${(3 * u).toFixed(1)}">头放这里</text>`);
    return out.join('');
  };
  // 弹窗要看到的范围：整个圆再往外留一点（人物框单位）
  fn.bounds = (W, H) => {
    const sp = o.spec || {}, pb = sp.person; if (!pb) return null;
    const sc = Math.min(200, Math.max(30, +(o.P || {}).personSize || 100)) / 100, bw = pb.w * sc, bh = pb.h * sc, bx = pb.x + (pb.w - bw) / 2, by = pb.y + pb.h - bh, k = W / bw;
    return { l: Math.min(0, (-0.04 - bx) * k), t: Math.min(0, (-0.04 - by) * k), r: Math.max(W, (1.04 - bx) * k), b: Math.max(H, (1.04 - by) * k) };
  };
  fn.frame = 'circle';
  return fn; };

  // 纯 logo 的裁剪参考线（2026-11-18）：白虚线圆 = 卡片边缘，圆外压暗 = 会被切掉。sp = SPEC.logo / logoFill
  D_.logoGuide = sp => { const ib = sp && sp.icon; if (!ib) return null;
    const fn = (W, H, u) => {
      u = u > 0 ? u : 1; const k = W / ib.w, cx = ((0.5 - (ib.x - ib.w / 2)) * k).toFixed(1), cy = ((0.5 - (ib.y - ib.h / 2)) * k).toFixed(1), r = (0.5 * k).toFixed(1);
      const g0 = -3 * W, g1 = 4 * W;
      return `<path fill="rgba(0,0,0,.72)" fill-rule="evenodd" d="M${g0} ${g0}H${g1}V${g1}H${g0}Z M${cx} ${(cy - r).toFixed(1)}A${r} ${r} 0 1 0 ${cx} ${(+cy + +r).toFixed(1)}A${r} ${r} 0 1 0 ${cx} ${(cy - r).toFixed(1)}Z"/>`
        + `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#fff" stroke-opacity=".85" stroke-width="${(1.6 * u).toFixed(1)}" stroke-dasharray="${(7 * u).toFixed(1)} ${(5 * u).toFixed(1)}"/>`;
    };
    fn.bounds = (W, H) => { const k = W / ib.w, e = Math.max(0, (1.04 - ib.w) / 2) * k; return { l: -e, t: -e, r: W + e, b: H + e }; };
    fn.frame = 'circle';
    return fn; };

  // ================= 【D4 小工具】 =================
  const TXT = s => String(s == null ? '' : s).trim();
  const em = s => Math.max(0.6, TX() && TX().emWidth ? TX().emWidth(F().plain(s)) : F().plain(s).length * 0.9);
  const nChars = s => Math.max(1, Array.from(F().plain(s)).length);
  const fitFs = D_.fitFs = (txt, fs, maxW, ls) => Math.min(fs, maxW / Math.max(0.6, em(txt) + nChars(txt) * ls));
  D_.em = em;
  // 图标 / 人物素材读法（坏数据兜住）
  const jsonOf = (v, def) => { let o = v; if (typeof o === 'string'){ try { o = JSON.parse(o); } catch (e) { o = null; } } return o && typeof o === 'object' && !Array.isArray(o) ? o : JSON.parse(JSON.stringify(def)); };
  D_.readIcon = raw => { const m = jsonOf(raw, { type: 'demo', tint: true }); if (!['demo', 'image', 'none'].includes(m.type)) m.type = 'demo'; m.tint = m.tint !== false; return m; };
  D_.readPerson = raw => { const m = jsonOf(raw, { type: 'image', img: '' }); if (!['image', 'video', 'none'].includes(m.type)) m.type = 'image'; return m; };
  // 上下花纹
  const ORN = D_.ORN = `<g fill="none" stroke="#fff" stroke-width="1.2" stroke-linecap="round"><path d="M4 12H60M90 12H146"/><path d="M60 12C66 4 70 4 75 10C80 4 84 4 90 12"/><path d="M68 12C70 16 73 16 75 13C77 16 80 16 82 12"/></g><path d="M75 3l3 4-3 4-3-4z" fill="#fff"/>`;
  // 环形文字
  const ringSvg = D_.ringSvg = (D, txt, col) => {
    const r = D * 0.44, fs = D * 0.04, circ = 2 * Math.PI * r;
    const unit = (TXT(txt) || 'TEXT').toUpperCase() + '  ·  ';
    const unitW = (em(unit) + unit.length * 0.3) * fs;
    const rep = Math.max(1, Math.floor(circ / Math.max(20, unitW)));
    const f = v => v.toFixed(1);
    return `<svg width="${f(D)}" height="${f(D)}" viewBox="0 0 ${f(D)} ${f(D)}"><defs><path id="rgp${Math.round(D)}" d="M${f(D / 2)} ${f(D / 2 - r)}a${f(r)} ${f(r)} 0 1 1 -0.01 0"/></defs>`
      + `<circle cx="${f(D / 2)}" cy="${f(D / 2)}" r="${f(r + fs * 0.95)}" fill="none" stroke="${col}" stroke-opacity=".35" stroke-width="${f(Math.max(1, D * 0.002))}"/>`
      + `<circle cx="${f(D / 2)}" cy="${f(D / 2)}" r="${f(r - fs * 0.6)}" fill="none" stroke="${col}" stroke-opacity=".25" stroke-width="${f(Math.max(1, D * 0.002))}"/>`
      + `<text font-family="Montserrat,Segoe UI,Arial,sans-serif" font-weight="700" font-size="${f(fs)}" fill="${col}" fill-opacity=".7" textLength="${f(circ - 2)}" lengthAdjust="spacing"><textPath href="#rgp${Math.round(D)}">${F().esc(unit.repeat(rep))}</textPath></text></svg>`;
  };

  /* ================= 【D5 画一层】 =================
     o = {
       D: 直径（px）, off: 这一层在外框里的左上偏移（px，默认 0）, base: 卡片底色 [r,g,b],
       C: { tx: 文字色 [r,g,b], hi: 高亮色 [r,g,b] }, spec: 版式（D2 里的一个，或自己写）,
       txt: { cn, en, sc }, icon: 图标素材（readIcon 的结果）, person: 人物素材（readPerson 的结果）,
       P: 读样式的参数对象（stroke / strokeW / strokeShine / cRim / ornament / titleFs / personSize / iconSize / showScript / flashRange，没写用默认）,
       flash: true = 加闪光层（明暗蒙版 + 边缘闪光 + 扫光）, num: 顶上编号（空 = 没有）,
       mark: true = 标记给卡片背景动效（fx-cardbg.js，规则 40）, loads: 数组，图片 / 视频的加载 Promise 往里推
     }
     返回 r = { ly: 这一层的元素, hi: [高亮层…], glow, rim, ring, person, dark, light, flash, sweep, disc } */
  D_.layer = o => {
    const Fc = F(), S = SK(), Tx = TX();
    const num = Fc.num, clamp = Fc.clamp, css = S.css, mix = S.mix, W3 = S.W3, K3 = S.K3, rgbOf = S.rgbOf, norm = S.norm;
    const P = o.P || {}, D = o.D, C = o.C, spec = o.spec, base = o.base, loads = o.loads || [];
    const shape = D_.shapeOf(o.shape || P.shape), nc = shape !== 'circle', W = D_.shapeW(shape, D), rad = shapeRad(shape, D);
    const ly = document.createElement('div'); ly.className = 'ly';
    const off = o.off || 0;
    ly.style.cssText += `;left:${(off - (W - D) / 2).toFixed(1)}px;top:${off.toFixed(1)}px;width:${W.toFixed(1)}px;height:${D.toFixed(1)}px`;
    const r = { ly, hi: [], shape, W };
    const shapeCss = el => { if (!nc) return; if (shape === 'hex'){ el.style.borderRadius = '0'; el.style.clipPath = D_.hexClip; } else el.style.borderRadius = rad.toFixed(1) + 'px'; };
    // 【区域C】圆底：中心亮、边缘暗 + 亮边 + 外发光
    const disc = document.createElement('div'); disc.className = 'disc';
    const rim = Math.max(2, D * 0.0065);
    const strokeOn = P.stroke !== 'off';
    disc.style.boxShadow = (strokeOn ? '' : `0 0 0 ${rim.toFixed(1)}px ${css(mix(base, W3, 0.55))}, 0 0 0 ${(rim * 2.2).toFixed(1)}px ${css(base, 0.35)}, `) + `0 ${(D * 0.03).toFixed(0)}px ${(D * 0.09).toFixed(0)}px rgba(0,0,0,.45)`;
    disc.innerHTML = `<div class="fill" style="background:radial-gradient(${nc ? 'ellipse' : 'circle'} at 50% 42%,${css(mix(base, W3, 0.22))} 0%,${css(base)} 48%,${css(mix(base, K3, 0.45))} 100%)"></div>`;
    shapeCss(disc);
    if (shape === 'hex') disc.style.boxShadow = '';                      // 六边形：box-shadow 会被裁掉，投影改用外面那层的 drop-shadow
    ly.appendChild(disc); r.disc = disc;
    // 【D7 图片底卡】版式带 bgImg 时：背景图铺满整张卡（调过大小位置就按 FXCards.place 摆），上面一层明暗（P.bgDim：负 = 压暗，正 = 提亮）
    if (spec && spec.bgImg){
      const bm = D_.readBg(o.bg);
      if (bm.type !== 'none'){
        const bw = document.createElement('div'); bw.className = 'bgi'; bw.style.cssText = 'position:absolute;inset:0;overflow:hidden';
        const im = new Image(); im.alt = ''; im.draggable = false; im.src = bm.type === 'image' && bm.img ? bm.img : D_.DEMO_BG;
        im.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;object-fit:cover';
        bw.appendChild(im); loads.push(im.decode ? im.decode().catch(() => {}) : Promise.resolve());
        if (bm.type === 'image' && bm.img && Fc.place) try { Fc.place(im, bm, W, D); } catch (e) {}
        const dv = clamp(num(P.bgDim, -30), -100, 100);
        if (dv){ const sh2 = document.createElement('div'); sh2.style.cssText = `position:absolute;inset:0;background:${dv < 0 ? `rgba(0,0,0,${(-dv / 100 * 0.88).toFixed(3)})` : `rgba(255,255,255,${(dv / 100 * 0.75).toFixed(3)})`}`; bw.appendChild(sh2); }
        disc.appendChild(bw); r.bg = bw;
      }
    }
    if (o.mark) window.FXCardBg && FXCardBg.mark(disc, Object.assign({ after: disc.firstElementChild, seed: 101, index: 0 }, o.markOpt || {}));   // 卡片背景动效（_shared/fx-cardbg.js，规则 40）
    // 【区域M】金属描边：先在一张 canvas 上把圆环画好（暗底 + 几处亮斑），之后转动只转这张图（纯 transform，不重画）
    if (strokeOn && nc){
      // 【D6】方形 / 长方形 / 六边形的金属描边：沿形状的轮廓一小段一小段画，亮斑按「从中心看过去的角度」算（和圆的一样）；不转（转起来形状会歪）
      const k = D / 460, sw = clamp(num(P.strokeW, 7), 1, 30) * k, shine = clamp(num(P.strokeShine, 100), 0, 200) / 100;
      const mc = rgbOf(norm(P.cRim) || '#cfe6ff');
      const dark = mix(mix(mc, base, 0.5), K3, 0.45), light = mix(mc, W3, 0.7);
      const spots = [[315, 1], [272, 0.75], [218, 0.9], [145, 1], [72, 0.85], [20, 0.35]];
      const Q = 1.5, pad = sw, cv = document.createElement('canvas');
      cv.width = Math.ceil((W + 2 * pad) * Q); cv.height = Math.ceil((D + 2 * pad) * Q);
      const g = cv.getContext('2d'); g.scale(Q, Q); g.lineWidth = sw; g.lineCap = 'round'; g.lineJoin = 'round';
      const pts = outline(shape, W, D, 0), n = pts.length;
      for (let i = 0; i < n; i++){
        const a0 = pts[i], a1 = pts[(i + 1) % n];
        const deg = (Math.atan2((a0[0] + a1[0]) / 2 - W / 2, -(((a0[1] + a1[1]) / 2) - D / 2)) * 180 / Math.PI + 360) % 360;
        let b = 0.12;
        spots.forEach(([c, w]) => { let d = Math.abs(deg - c); d = Math.min(d, 360 - d); b = Math.max(b, w * Math.exp(-(d * d) / (2 * 11 * 11))); });
        g.strokeStyle = css(mix(dark, light, clamp(b * shine, 0, 1)));
        g.beginPath(); g.moveTo(a0[0] + pad, a0[1] + pad); g.lineTo(a1[0] + pad, a1[1] + pad); g.stroke();
      }
      const rm = document.createElement('div'); rm.className = 'rim';
      rm.style.cssText += `;left:${(-pad).toFixed(1)}px;top:${(-pad).toFixed(1)}px;width:${(W + 2 * pad).toFixed(1)}px;height:${(D + 2 * pad).toFixed(1)}px;border-radius:0`;
      cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%';
      rm.appendChild(cv); ly.appendChild(rm); r.rimS = rm;                  // 不放进 r.rim：效果转 r.rim 时它不跟着转
    } else if (strokeOn){
      const k = D / 460, sw = clamp(num(P.strokeW, 7), 1, 30) * k, shine = clamp(num(P.strokeShine, 100), 0, 200) / 100;
      const mc = rgbOf(norm(P.cRim) || '#cfe6ff');
      const dark = mix(mix(mc, base, 0.5), K3, 0.45), light = mix(mc, W3, 0.7);
      const spots = [[315, 1], [272, 0.75], [218, 0.9], [145, 1], [72, 0.85], [20, 0.35]];   // 亮斑的位置（0° = 正上方，顺时针）
      const size = D + sw, Q = 1.5, cv = document.createElement('canvas');
      cv.width = cv.height = Math.ceil(size * Q);
      const g = cv.getContext('2d'), c0 = size * Q / 2, ro = (D / 2 + sw / 2) * Q, ri = (D / 2 - sw / 2) * Q;
      for (let a = 0; a < 360; a += 2){                                    // 每 2° 一小段扇环，颜色按亮斑高斯混合
        let b = 0.12;
        spots.forEach(([c, w]) => { let d = Math.abs(a + 1 - c); d = Math.min(d, 360 - d); b = Math.max(b, w * Math.exp(-(d * d) / (2 * 11 * 11))); });
        const a0 = (a - 90.6) * Math.PI / 180, a1 = (a + 2 - 89.4) * Math.PI / 180;
        g.beginPath(); g.arc(c0, c0, ro, a0, a1); g.arc(c0, c0, ri, a1, a0, true); g.closePath();
        g.fillStyle = css(mix(dark, light, clamp(b * shine, 0, 1))); g.fill();
      }
      const rm = document.createElement('div'); rm.className = 'rim';
      rm.style.cssText += `;inset:${(-sw * 0.5).toFixed(1)}px`;
      cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%';
      rm.appendChild(cv);
      ly.appendChild(rm); r.rim = rm;
    }
    // 外发光（闪的时候加强）
    const glow = document.createElement('div'); glow.className = 'gl';
    if (shape === 'hex'){ glow.style.borderRadius = '0'; glow.innerHTML = shapeAura(shape, W, D, css(mix(base, W3, 0.3), 0.55), D * 0.05, D * 0.02); }
    else { glow.style.boxShadow = `0 0 ${(D * 0.06).toFixed(0)}px ${css(mix(base, W3, 0.3), 0.55)}, inset 0 0 ${(D * 0.08).toFixed(0)}px ${css(mix(base, W3, 0.5), 0.45)}`; shapeCss(glow); }
    ly.appendChild(glow); r.glow = glow;
    // 玻璃反光
    const gls = document.createElement('div'); gls.className = 'gl';
    gls.style.background = 'linear-gradient(160deg,rgba(255,255,255,.16),rgba(255,255,255,0) 38%,rgba(255,255,255,0) 70%,rgba(255,255,255,.05))';
    shapeCss(gls);
    ly.appendChild(gls);

    const txC = css(C.tx), enC = css(C.tx, 0.62), lineC = css(C.tx, 0.36), scC = css(mix(base, W3, 0.72)), hiC = css(C.hi);
    const ornOn = P.ornament !== 'off';
    // 长方形：字 / 图标 / 人物按原来的版式摆在中间那块 D×D 里（版式坐标都是按 D 算的）
    let inner = disc;
    if (W !== D){ inner = document.createElement('div'); inner.style.cssText = `position:absolute;left:${((W - D) / 2).toFixed(1)}px;top:0;width:${D.toFixed(1)}px;height:${D.toFixed(1)}px`; disc.appendChild(inner); }
    const put = (el, front) => { inner.appendChild(el); if (front) el.style.zIndex = 3; return el; };
    const textBox = (sp, cls, html, color, extra = '') => {
      if (!sp || !html) return null;
      const d = document.createElement('div'); d.className = 'tx ' + cls;
      const fs = sp.fsPx;
      d.style.cssText += `;left:${(sp.x * D - D).toFixed(1)}px;width:${(D * 2).toFixed(1)}px;top:${(sp.y * D - fs * 0.55).toFixed(1)}px;font-size:${fs.toFixed(1)}px;color:${color};${extra}`;
      d.innerHTML = html.replace(/<em class="hi">/g, `<em class="hi" style="color:${hiC}">`);
      return d;
    };
    const txt = o.txt || { cn: '', en: '', sc: '' };
    const fsOf = (sp, s, ls) => { if (!sp) return; sp.fsPx = fitFs(s, sp.fs * D * clamp(num(P.titleFs, 100), 40, 180) / 100, sp.mw * D, ls); };
    const S2 = JSON.parse(JSON.stringify(spec));
    fsOf(S2.cn, txt.cn, 0.12); fsOf(S2.en, txt.en, 0.14); fsOf(S2.script, txt.sc, 0.01);

    // 人物：盖在文字上面（top）或下面
    let person = null;
    const pm = o.person || { type: 'none' };
    if (S2.person && pm.type !== 'none'){
      const pb = S2.person, w = pb.w * D, h = pb.h * D * clamp(num(P.personSize, 100), 30, 200) / 100;
      person = document.createElement('div'); person.className = 'pp';
      const hw = pb.w * D * clamp(num(P.personSize, 100), 30, 200) / 100;
      person.style.cssText += `;left:${(pb.x * D + (w - hw) / 2).toFixed(1)}px;top:${(pb.y * D + pb.h * D - h).toFixed(1)}px;width:${hw.toFixed(1)}px;height:${h.toFixed(1)}px`;
      person.style.filter = `drop-shadow(${(-D * 0.012).toFixed(1)}px 0 ${(D * 0.03).toFixed(1)}px rgba(0,0,0,.35))`;
      if (pm.type === 'video' && pm.video && window.FXVideo){
        loads.push(FXVideo.mount(person, pm, 'contain'));
        Fc.place(person.lastElementChild, pm, hw, h);
      } else {
        const im = new Image(); im.alt = ''; im.src = pm.type === 'image' && pm.img ? pm.img : D_.DEMO_PERSON;
        loads.push(im.decode ? im.decode().catch(() => {}) : Promise.resolve());
        person.appendChild(im);
        if (pm.img) Fc.place(im, pm, hw, h);
      }
    }
    if (person && !S2.top) put(person);
    // 人名背景：每个字一个格子，左右撑开（人物挡住中间），从上到下渐变变淡
    if (S2.bigName && txt.cn){
      const chars = Array.from(Fc.plain(txt.cn)), n = chars.length, bw = S2.bigName.w * D;
      const fs = Math.min(S2.bigName.fs * D * clamp(num(P.titleFs, 100), 40, 180) / 100, bw / Math.max(1, n) * (n <= 2 ? 0.62 : 0.95));
      const bn = document.createElement('div'); bn.className = 'bign';
      bn.style.cssText += `;left:${((D - bw) / 2).toFixed(1)}px;width:${bw.toFixed(1)}px;top:${(S2.bigName.y * D - fs * 0.6).toFixed(1)}px;height:${(fs * 1.2).toFixed(1)}px;`
        + `filter:drop-shadow(0 0 ${(D * 0.02).toFixed(1)}px ${css(mix(base, W3, 0.5), 0.55)})`;
      // 渐隐的字直接调公共模块 fx-transition.js【区域T11】（上实下透）（规则 39）
      const col = css(mix(C.tx, mix(base, W3, 0.72), 0.25));
      chars.forEach(ch => {
        const cell = document.createElement('span');
        cell.style.cssText = `position:relative;display:block;width:${(fs * 1.05).toFixed(1)}px;height:${(fs * 1.2).toFixed(1)}px`;
        Tx.draw(cell, { id: 'static', b: ch, fs, color: col, bold: true, weight: 900, lh: 1.2, ls: 0, grad: { dir: 'b' } });
        bn.appendChild(cell);
      });
      put(bn);
    }
    if (S2.band){
      const b = document.createElement('div'); b.className = 'band';
      b.style.cssText += `;top:${(S2.band.y * D).toFixed(1)}px;bottom:0;background:linear-gradient(180deg,${css(mix(base, K3, 0.35), 0)} 0%,${css(mix(base, K3, 0.35), 0.82)} 45%,${css(mix(base, K3, 0.45), 0.95)} 100%)`;
      put(b);
    }
    if (S2.ring){ const rg = document.createElement('div'); rg.className = 'ring'; rg.style.cssText += `;left:0;top:0;width:${D.toFixed(1)}px;height:${D.toFixed(1)}px`; rg.innerHTML = ringSvg(D, txt.en || txt.sc, txC); put(rg); r.ring = rg; }
    const orn = (y, flip) => { if (y == null || !ornOn) return; const w = D * 0.33, h = w * 18 / 150, e = document.createElement('div'); e.className = 'orn';
      e.style.cssText += `;left:${((D - w) / 2).toFixed(1)}px;top:${(y * D - h / 2).toFixed(1)}px;width:${w.toFixed(1)}px;height:${h.toFixed(1)}px;opacity:.72${flip ? ';transform:scaleY(-1)' : ''}`;
      e.innerHTML = `<svg viewBox="0 0 150 18" width="100%" height="100%">${ORN}</svg>`; put(e); };
    orn(S2.ornT); orn(S2.ornB, true);
    // 图标
    const icm = o.icon || { type: 'none' };
    if (S2.icon && icm.type !== 'none'){
      const ib = S2.icon, iw = ib.w * D * clamp(num(P.iconSize, 100), 30, 250) / 100, ih = ib.h * D * clamp(num(P.iconSize, 100), 30, 250) / 100;
      const ic = document.createElement('div'); ic.className = 'ic';
      ic.style.cssText += `;left:${(ib.x * D - iw / 2).toFixed(1)}px;top:${(ib.y * D - ih / 2).toFixed(1)}px;width:${iw.toFixed(1)}px;height:${ih.toFixed(1)}px`;
      const src = icm.type === 'image' && icm.img ? icm.img : (S2.logo ? D_.DEMO_LOGO : D_.DEMO_ICON);
      if (S2.logo === 'cover' && !(icm.type === 'image' && icm.img)) ic.style.transform = 'scale(.7)';   // 纯 logo · 铺满：示例图缩小一点，不被圆切掉
      if (icm.tint){
        const t = document.createElement('div'); t.className = 'tint';
        t.style.background = css(mix(base, W3, 0.7));
        t.style.webkitMaskImage = t.style.maskImage = `url("${src}")`;
        if (S2.logo === 'cover') t.style.webkitMaskSize = t.style.maskSize = 'cover';
        if (icm.type === 'image' && icm.img && Fc.place(t, icm, iw, ih)){ t.style.webkitMaskSize = t.style.maskSize = '100% 100%'; }
        ic.appendChild(t);
        if (icm.type === 'image' && icm.img){ const pre = new Image(); pre.src = src; loads.push(pre.decode ? pre.decode().catch(() => {}) : Promise.resolve()); }
      } else {
        const im = new Image(); im.alt = ''; im.src = src; ic.appendChild(im);
        if (S2.logo === 'cover') im.style.objectFit = 'cover';            // 纯 logo · 铺满：没调过大小位置时按铺满显示
        loads.push(im.decode ? im.decode().catch(() => {}) : Promise.resolve());
        if (icm.type === 'image' && icm.img) Fc.place(im, icm, iw, ih);
      }
      put(ic);
    }
    // 文字
    const sh = spec && spec.bgImg ? `text-shadow:0 ${(D * 0.005).toFixed(1)}px ${(D * 0.03).toFixed(1)}px rgba(0,0,0,.55),0 0 ${(D * 0.012).toFixed(1)}px rgba(0,0,0,.35)`   // 图片底卡：字压在照片上，阴影重一点
      : `text-shadow:0 ${(D * 0.004).toFixed(1)}px ${(D * 0.02).toFixed(1)}px rgba(0,0,0,.3)`;
    [[S2.script, 'tsc', txt.sc, scC], [S2.en, 'ten', txt.en, enC], [S2.cn, 'tcn', txt.cn, txC]].forEach(([sp, cls, s, col]) => {
      if (cls === 'tsc' && P.showScript === 'off') return;
      const d = textBox(sp, cls, Fc.mark(s), col, sh); if (d) put(d);
    });
    if (S2.dots){ const dd = document.createElement('div'); dd.className = 'dots'; const w = S2.dots.w * D;
      dd.style.cssText += `;left:${(S2.dots.x * D - w / 2).toFixed(1)}px;top:${(S2.dots.y * D).toFixed(1)}px;width:${w.toFixed(1)}px;border-top:${Math.max(1.5, D * 0.0035).toFixed(1)}px dotted ${lineC}`; put(dd); }
    if (person && S2.top) put(person, true);
    r.person = person;

    // 【区域I】高亮层：卡片里泛起高亮色的光 + 外圈一圈高亮色（透明度 = 高亮程度 0~1，用 FXSkin.applyColor 或自己写）
    const h1 = document.createElement('div'); h1.className = 'hl';
    h1.style.cssText += `;background:radial-gradient(${nc ? 'ellipse' : 'circle'} at 50% 45%,${css(C.hi, 0.42)} 0%,${css(C.hi, 0.14)} 55%,${css(C.hi, 0)} 75%);z-index:4`;
    disc.appendChild(h1);
    const h2 = document.createElement('div'); h2.className = 'hl';
    if (shape === 'hex'){ h2.style.borderRadius = '0'; h2.innerHTML = shapeAura(shape, W, D, css(C.hi, 0.75), D * 0.07, D * 0.02) + shapeAura(shape, W, D, css(C.hi), 0, rim * 2.4); }
    else { h2.style.boxShadow = `0 0 0 ${(rim * 1.2).toFixed(1)}px ${css(C.hi)}, 0 0 ${(D * 0.09).toFixed(0)}px ${(D * 0.01).toFixed(0)}px ${css(C.hi, 0.75)}`; shapeCss(h2); }
    ly.appendChild(h2);
    r.hi.push(h1, h2);

    // 闪光层（可选）；明暗用两层蒙版做（比每帧改 brightness 滤镜省很多，规则 16）
    if (o.flash){
      const dk = document.createElement('div'); dk.className = 'shade'; dk.style.cssText += ';inset:0;z-index:5;background:#000';
      const lt = document.createElement('div'); lt.className = 'shade'; lt.style.cssText += `;inset:0;z-index:5;background:radial-gradient(circle at 50% 42%,${css(mix(base, W3, 0.75))} 0%,${css(mix(base, W3, 0.4))} 70%)`;
      disc.append(dk, lt); r.dark = dk; r.light = lt;
      // 闪光：从圆的边缘往里渐变，越靠近中心越透明；「闪光范围」= 从边缘往里亮多深（占半径的百分比）
      const rg = clamp(num(P.flashRange, 45), 5, 100), edgeC = css(mix(base, W3, 0.75), 0.7);
      const fl = document.createElement('div'); fl.className = 'flash';
      fl.style.cssText += `;inset:0;border-radius:${nc ? '0' : '50%'};z-index:6;background:radial-gradient(${nc ? 'ellipse' : 'circle'} closest-side at 50% 50%,rgba(255,255,255,0) ${(100 - rg).toFixed(1)}%,${edgeC} ${(100 - rg * 0.35).toFixed(1)}%,rgba(255,255,255,.95) 100%)`;
      disc.appendChild(fl); r.flash = fl;
      const sw = document.createElement('div'); sw.className = 'sweep'; sw.style.cssText += ';inset:-20%;z-index:6;background:linear-gradient(115deg,rgba(255,255,255,0) 40%,rgba(255,255,255,.75) 50%,rgba(255,255,255,0) 60%)';
      disc.appendChild(sw); r.sweep = sw;
    }
    // 编号小圆（压在上边框，跟着这一层一起糊 / 一起换色）
    const nm = TXT(o.num);
    if (nm){
      const bd = D * 0.1, b = document.createElement('div'); b.className = 'badge';
      b.style.cssText += `;left:${((W - bd) / 2).toFixed(1)}px;top:${(-bd * (shape === 'hex' ? 0.62 - 0.067 * D / bd : 0.62)).toFixed(1)}px;width:${bd.toFixed(1)}px;height:${bd.toFixed(1)}px;font-size:${(bd * 0.48).toFixed(1)}px;`
        + `background:radial-gradient(circle at 50% 35%,#3a4152,#171b25);box-shadow:0 0 0 ${Math.max(1.5, bd * 0.035).toFixed(1)}px ${css(mix(base, W3, 0.6))},0 0 ${(bd * 0.3).toFixed(1)}px ${css(base, 0.8)}`;
      b.textContent = nm; ly.appendChild(b);
    }
    return r;
  };
})();
