/* ===========================================================================
   fx-matte.js —— 抠图：去掉纯色背景（工作台公共模块，2026-11-18 新增，FXMatte）
   ---------------------------------------------------------------------------
   做什么：上传的图片（logo、贴纸、截图）如果是「纯色底」—— 白底、黑底、红底、黄底……什么颜色都行，
          自动认出底色，把底去干净，变成透明 PNG。
   谁在用：FXSkin.mediaBlock（fx-skin.js【区域S7】）的「✂ 去掉纯色背景」开关 —— 所有用它上传图片的效果都有。
          这个文件平时不加载，用户第一次点开关时才由 fx-skin.js 按需加载（没用到的效果一点开销都没有）。

   区域地图
   【区域M1 认底色】   只看图片四条边：把边上的像素按颜色分桶，数量最多的那一桶就是底色（取它们的平均）。
                      四边大多已经透明 = 本来就是透明图，不用抠。
   【区域M2 去底】     每个像素算和底色的距离：
                        近于 t1 = 完全透明；t1~t2 之间 = 半透明（软边）；远于 t2 = 不动。
                      「只去外面一圈」：从四条边往里连通地找（logo 里面的白字、白色眼睛不会被去掉）；
                      「同色全去掉」：整张图里和底色一样的都去掉（字母 O、A 中间的小洞也透明）。
   【区域M3 修边】     抗锯齿的边缘像素（字边那一圈既不是底色也不是字色）：按「离底色多远 / 里面实心像素离底色多远」
                      估出它本来有多透明，所以边上不会留一圈白边 / 黑边。
   【区域M4 去色边】   半透明的像素把混进来的底色减掉（c = (c - 底色 × (1-a)) / a），换到别的底上也不会发白 / 发灰。
   【区域M5 编辑块】   FXMatte.block(o)：开 / 关、认出来的底色（色块）、去除范围（数字框 + 滑杆）、只去外圈 / 同色全去。
                      原图路径存在 m.img0，抠好的图换进 m.img（参数 m.matte = { on, tol, mode, bg }）；关掉 = 换回原图。
                      只在「松开滑杆 / 点按钮」时才重新抠一次、上传一张（不会边拖边往硬盘里塞图）。
   =========================================================================== */
(function () {
  if (window.FXMatte) return;
  const M = window.FXMatte = {};
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const hex = c => '#' + c.map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');

  M.load = src => new Promise((res, rej) => {
    const im = new Image(); im.crossOrigin = 'anonymous';
    im.onload = () => res(im); im.onerror = () => rej(new Error('图片读不出来'));
    im.src = src;
  });

  // ================= 【区域M1 认底色】 =================
  M.detect = (d, w, h) => {
    const bins = new Map(); let n = 0, clear = 0;
    const add = i => {
      n++;
      if (d[i + 3] < 16) { clear++; return; }
      const k = (d[i] >> 4) << 8 | (d[i + 1] >> 4) << 4 | (d[i + 2] >> 4);
      let b = bins.get(k); if (!b) bins.set(k, b = [0, 0, 0, 0]);
      b[0]++; b[1] += d[i]; b[2] += d[i + 1]; b[3] += d[i + 2];
    };
    for (let x = 0; x < w; x++) { add(x * 4); add(((h - 1) * w + x) * 4); }
    for (let y = 1; y < h - 1; y++) { add(y * w * 4); add((y * w + w - 1) * 4); }
    if (clear > n * 0.6) return { transparent: true, share: clear / Math.max(1, n) };
    // 相邻的桶并进来（底色正好落在两个桶交界时不会被拆开）
    let best = null;
    bins.forEach((b, k) => { if (!best || b[0] > best[0]) best = Object.assign([...b], { k }); });
    const r0 = best[1] / best[0], g0 = best[2] / best[0], b0 = best[3] / best[0];
    let s = [0, 0, 0, 0];
    bins.forEach(b => { const r = b[1] / b[0], g = b[2] / b[0], bb = b[3] / b[0]; if (Math.hypot(r - r0, g - g0, bb - b0) < 24) { s[0] += b[0]; s[1] += b[1]; s[2] += b[2]; s[3] += b[3]; } });
    return { rgb: [s[1] / s[0], s[2] / s[0], s[3] / s[0]], share: s[0] / Math.max(1, n - clear), transparent: false };
  };

  // ================= 【区域M2 ~ M4 去底 + 修边 + 去色边】 =================
  // o = { tol: 0~100（默认 25）, mode: 'edge'（只去外面一圈）| 'all'（同色全去掉）, bg: [r,g,b]（不给 = 自动认） }
  M.process = (im, o) => {
    o = o || {};
    const w = im.naturalWidth || im.width, h = im.naturalHeight || im.height;
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    const g = cv.getContext('2d', { willReadFrequently: true });
    g.drawImage(im, 0, 0);
    const id = g.getImageData(0, 0, w, h), d = id.data, N = w * h;
    const det = M.detect(d, w, h);
    const bg = o.bg || det.rgb;
    if (!bg) return { canvas: cv, bg: null, removed: 0, transparent: true };
    const [br, bgc, bb] = bg;
    const tol = clamp(+o.tol || 0, 0, 100);
    const t1 = 6 + tol * 1.5, t2 = t1 + 14 + tol * 0.8;       // 距离：0 ~ 441
    const dist = new Float32Array(N);
    for (let p = 0, i = 0; p < N; p++, i += 4) dist[p] = Math.hypot(d[i] - br, d[i + 1] - bgc, d[i + 2] - bb);
    const A = new Float32Array(N).fill(1);                     // 新的不透明度（0~1），最后乘上原来的
    const aOf = x => x <= t1 ? 0 : x >= t2 ? 1 : (x - t1) / (t2 - t1);
    if (o.mode === 'all') {
      for (let p = 0; p < N; p++) A[p] = aOf(dist[p]);
    } else {
      // 从四条边往里连通地找（4 邻接）：只有连到外面的底色才去掉
      const seen = new Uint8Array(N), q = new Int32Array(N); let qh = 0, qt = 0;
      const push = p => { if (!seen[p] && dist[p] < t2) { seen[p] = 1; q[qt++] = p; } };
      for (let x = 0; x < w; x++) { push(x); push((h - 1) * w + x); }
      for (let y = 0; y < h; y++) { push(y * w); push(y * w + w - 1); }
      while (qh < qt) {
        const p = q[qh++], x = p % w;
        A[p] = aOf(dist[p]);
        if (x > 0) push(p - 1); if (x < w - 1) push(p + 1);
        if (p >= w) push(p - w); if (p < N - w) push(p + w);
      }
    }
    // 【区域M3 修边】离透明区 2 像素以内、还是实心的像素 = 抗锯齿的边：按「我离底色多远 / 旁边实心像素离底色多远」估透明度
    const near = new Uint8Array(N);
    for (let p = 0; p < N; p++) if (A[p] < 0.5) near[p] = 1;
    for (let pass = 0; pass < 2; pass++) {
      const nx = near.slice();
      for (let p = 0; p < N; p++) {
        if (near[p]) continue;
        const x = p % w;
        if ((x > 0 && near[p - 1]) || (x < w - 1 && near[p + 1]) || (p >= w && near[p - w]) || (p < N - w && near[p + w])) nx[p] = 2 + pass;
      }
      near.set(nx);
    }
    // 边上的像素 = 底色和旁边实心颜色 f 混出来的：透明度 = 把它的颜色投到「底色 → f」这条线上（比只比距离准）；
    // 颜色直接用 f（JPEG 边上的噪点就不会被「减底色」放大成白点 / 黑点）
    const A0 = A.slice(), fg = new Int32Array(N).fill(-1);
    for (let p = 0; p < N; p++) {
      if (!near[p] || A0[p] <= 0) continue;
      const x = p % w, y = (p / w) | 0;
      let ref = 0, rk = -1;
      for (let dy = -3; dy <= 3; dy++) {
        const yy = y + dy; if (yy < 0 || yy >= h) continue;
        for (let dx = -3; dx <= 3; dx++) {
          const xx = x + dx; if (xx < 0 || xx >= w) continue;
          const k = yy * w + xx; if (!near[k] && A0[k] >= 1 && dist[k] > ref) { ref = dist[k]; rk = k; }
        }
      }
      if (rk < 0 || ref < t2) continue;
      const i = p * 4, j = rk * 4;
      const fr = d[j] - br, fgg = d[j + 1] - bgc, fb = d[j + 2] - bb;
      const a = ((d[i] - br) * fr + (d[i + 1] - bgc) * fgg + (d[i + 2] - bb) * fb) / Math.max(1, fr * fr + fgg * fgg + fb * fb);
      A[p] = Math.min(A0[p], clamp((a - 0.06) / 0.9, 0, 1));     // 两头各留一点余量：很淡的噪点直接透明，接近实心的直接实心
      if (A[p] < 1) fg[p] = rk;
    }
    // 【区域M4 去色边】+ 写回
    let removed = 0;
    for (let p = 0, i = 0; p < N; p++, i += 4) {
      const a = A[p];
      if (a >= 1) continue;
      if (a <= 0.004) { d[i + 3] = 0; removed++; continue; }
      if (fg[p] >= 0) { const j = fg[p] * 4; d[i] = d[j]; d[i + 1] = d[j + 1]; d[i + 2] = d[j + 2]; d[i + 3] = Math.round(d[i + 3] * a); if (a < 0.5) removed++; continue; }
      d[i] = clamp((d[i] - br * (1 - a)) / a, 0, 255);
      d[i + 1] = clamp((d[i + 1] - bgc * (1 - a)) / a, 0, 255);
      d[i + 2] = clamp((d[i + 2] - bb * (1 - a)) / a, 0, 255);
      d[i + 3] = Math.round(d[i + 3] * a);
      if (a < 0.5) removed++;
    }
    g.putImageData(id, 0, 0);
    return { canvas: cv, bg, removed: removed / N, share: det.share || 0, transparent: !!det.transparent };
  };

  // 抠一张图：src → { file: PNG 文件, bg: '#rrggbb', removed: 去掉的比例 }
  M.remove = async (src, o) => {
    const im = await M.load(src);
    const r = M.process(im, o);
    if (!r.bg) return { transparent: true };
    const blob = await new Promise(res => r.canvas.toBlob(res, 'image/png'));
    if (!blob) throw new Error('生成透明图失败');
    return { file: new File([blob], 'matte.png', { type: 'image/png' }), bg: hex(r.bg), removed: r.removed, share: r.share };
  };

  // ================= 【区域M5 编辑块】 =================
  // o = { pd, m: 素材对象（m.img 是现在的图）, save(), redraw(): 重画整个上传块, reload(): 重画画面 }
  const CSS = `
html body #params .fxm{margin:8px 0 2px!important;padding:8px!important;border:1px dashed #2c2c2c!important;border-radius:7px!important}
html body #params .fxm-h{display:flex!important;align-items:center!important;gap:8px!important}
html body #params .fxm-h b{font-size:12px!important;color:#ccc!important;font-weight:600!important;white-space:nowrap!important}
html body #params .fxm-h .stc-seg{margin-left:auto!important;width:96px!important;flex:none!important}
html body #params .fxm-bd{display:flex!important;flex-direction:column!important;gap:6px!important;margin:8px 0 0!important}
html body #params .fxm-l{display:flex!important;align-items:center!important;gap:6px!important;font-size:11px!important;color:#888!important}
html body #params .fxm-l>span{white-space:nowrap!important}
html body #params .fxm-sw{display:inline-block!important;width:16px!important;height:16px!important;border-radius:4px!important;border:1px solid #555!important;flex:none!important}
html body #params .fxm-l input[type=number]{width:52px!important;flex:none!important;padding:2px 4px!important;font-size:11.5px!important}
html body #params .fxm-l input[type=range]{flex:1 1 auto!important;min-width:0!important}
html body #params .fxm-n{font-size:10.5px!important;color:#888!important;line-height:1.5!important}
html body #params .fxm-n.err{color:#e0796b!important}`;
  M.block = o => {
    const pd = o.pd, m = o.m;
    if (!pd.getElementById('fxmatte-css')) { const s = pd.createElement('style'); s.id = 'fxmatte-css'; s.textContent = CSS; pd.head.appendChild(s); }
    const mk = (t, c, h) => { const e = pd.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; };
    const el = mk('div', 'fxm');
    const mt = Object.assign({ on: false, tol: 25, mode: 'edge' }, m.matte || {});
    let busy = false;
    const note = mk('div', 'fxm-n');
    const run = async () => {
      if (busy) return; busy = true;
      if (!m.img0) m.img0 = m.img;
      note.className = 'fxm-n'; note.textContent = '抠图中…';
      try {
        const r = await M.remove(m.img0, { tol: mt.tol, mode: mt.mode });
        if (r.transparent) { note.textContent = '这张图四周本来就是透明的，不用抠。'; mt.on = false; m.matte = Object.assign({}, mt); m.img = m.img0; o.save(); busy = false; o.redraw(); return; }
        const up = await window.FXSkin.upImage(r.file);
        m.img = up.img; mt.on = true; mt.bg = r.bg;
        m.matte = Object.assign({}, mt);
        o.save(); o.reload && o.reload();
        busy = false; o.redraw();
        return;
      } catch (e) { note.className = 'fxm-n err'; note.textContent = '抠图失败：' + e.message; }
      busy = false;
    };
    const off = () => { if (m.img0) m.img = m.img0; mt.on = false; m.matte = Object.assign({}, mt); o.save(); o.reload && o.reload(); o.redraw(); };

    const hd = mk('div', 'fxm-h', '<b>✂ 去掉纯色背景</b>');
    const seg = mk('div', 'stc-seg', '<button type="button" data-v="0">关</button><button type="button" data-v="1">开</button>');
    seg.querySelectorAll('button').forEach(b => {
      b.classList.toggle('on', (b.dataset.v === '1') === !!mt.on);
      b.title = b.dataset.v === '1' ? '自动认出底色（白、黑、红、黄……都行），把底去干净' : '换回原图';
      b.onclick = () => { if (b.dataset.v === '1') { if (!mt.on) run(); } else if (mt.on) off(); };
    });
    hd.appendChild(seg); el.appendChild(hd);
    if (mt.on) {
      const bd = mk('div', 'fxm-bd');
      const l1 = mk('div', 'fxm-l');
      const sw = mk('span', 'fxm-sw'); sw.style.background = mt.bg || '#fff';   // 色块是数据颜色，写行内（规则 24）
      l1.append(mk('span', '', '认出的底色'), sw, mk('span', '', E(mt.bg || '')));
      bd.appendChild(l1);
      // 去除范围：数字框 + 滑杆（规则 5）；松手才重新抠
      const l2 = mk('div', 'fxm-l');
      const num = mk('input'); num.type = 'number'; num.min = 0; num.max = 100; num.step = 1; num.value = mt.tol;
      const rg = mk('input'); rg.type = 'range'; rg.min = 0; rg.max = 100; rg.step = 1; rg.value = mt.tol;
      rg.oninput = () => { num.value = rg.value; };
      const apply = v => { v = clamp(Math.round(+v || 0), 0, 100); num.value = rg.value = v; if (v !== mt.tol) { mt.tol = v; run(); } };
      rg.onchange = () => apply(rg.value); num.onchange = () => apply(num.value);
      l2.append(mk('span', '', '去除范围'), num, rg);
      bd.appendChild(l2);
      const s2 = mk('div', 'stc-seg', '<button type="button" data-v="edge">只去外面一圈</button><button type="button" data-v="all">同色全去掉</button>');
      s2.querySelectorAll('button').forEach(b => {
        b.classList.toggle('on', b.dataset.v === (mt.mode === 'all' ? 'all' : 'edge'));
        b.title = b.dataset.v === 'edge' ? '只去掉和四边连着的底色：logo 里面和底同色的字、图案会留着' : '整张图里和底色一样的地方都去掉：字母中间的小洞也会透明';
        b.onclick = () => { if (mt.mode !== b.dataset.v) { mt.mode = b.dataset.v; run(); } };
      });
      bd.appendChild(s2);
      note.innerHTML = '没去干净 → 把「去除范围」调大；logo 边上被吃掉 → 调小。<br>logo 里面有和底色一样的字（比如白底上的白字）用「只去外面一圈」。';
      bd.appendChild(note);
      el.appendChild(bd);
    } else {
      note.textContent = '白底、黑底、红底……只要是一种颜色的底，打开就自动去干净，变成透明的。';
      el.appendChild(note);
    }
    return el;
  };
  const E = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
})();
