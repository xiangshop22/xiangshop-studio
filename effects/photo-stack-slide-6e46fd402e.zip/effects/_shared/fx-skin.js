/* ===========================================================================
   fx-skin.js —— 卡片皮肤（工作台公共模块，v11.1 从「缝线标题卡」抽出来）
   ---------------------------------------------------------------------------
   做什么：一张卡片「换底色 / 高亮过渡 / 去色再恢复彩色 / 入场出场 / 配色色块 / 上传图片视频」这一整套。
   谁在用：缝线标题卡（effects/stitch-title-card）、焦点格卡片（effects/focus-slot-card）。
   依赖：先引入 ../_shared/fx-cards.js（数学小工具、上传后的「调整大小和位置」都在那里），再引入本文件。

   区域地图（想改哪里，直接说「区域Sx 怎么改」）
   【区域S1 颜色小工具】 #色号规范化、RGB 混色、HSL
   【区域S2 颜色关键帧】 （v14.0 起算法在 view-controls.js 的 FXColorKeys，这里转过去）数据 { c:[{t,v}], h:[{t,v}] }：c = 色彩（0 黑白 / 1 彩色），h = 高亮（0 常态 / 1 高亮）
                        每个点 =「从这一秒开始，用『颜色渐变秒数』变成这个状态」，保持到下一个点
   【区域S3 应用到画面】 去色 = 整张卡片的灰度滤镜（只在变化时写）；高亮 = 常态层 / 高亮层交叉淡入（只写 opacity）
   【区域S4 缝线 / 边框】 stitchSvg：一整圈缝纫线；frameSvg：细线 / 缝线边框，可以在文字经过的地方断开
   【区域S5 入场 / 出场】 弹出 / 淡入 / 浮上 / 无；结尾缩小淡出（只算数，画面由效果自己写 transform）
   【区域S6 编辑器样式】 右侧面板里这几块的样式（.stc 开头）
   【区域S7 编辑器·素材】 照片 / 视频 / 不要图片（或别的选项），上传后自动弹「调整大小和位置」（规则 26）
   【区域S8 编辑器·关键帧】「色彩」「高亮」两行小轨道 + 一键示范
   【区域S9 编辑器·配色】 预设色块 + 取色按钮 + ★ 保存为我的配色（规则 24），一个颜色或一对颜色都行

   画面相关的函数都是纯计算（同一个 t 永远同一个结果），逐帧导出和预览一致。
   =========================================================================== */
(function () {
  const F = window.FXCards;
  const S = window.FXSkin = window.FXSkin || {};
  const num = F.num, clamp = F.clamp, prog = F.prog, lerp = F.lerp, smooth = F.smooth;

  // ================= 【区域S1 颜色小工具】 =================
  const norm = S.norm = h => {                          // #abc / abcdef → #aabbcc；写错了返回 null
    h = String(h || '').trim();
    if (/^[0-9a-f]{6}$/i.test(h)) h = '#' + h;
    if (/^#[0-9a-f]{3}$/i.test(h)) h = '#' + h[1] + h[1] + h[2] + h[2] + h[3] + h[3];
    return /^#[0-9a-f]{6}$/i.test(h) ? h.toLowerCase() : null;
  };
  const rgbOf = S.rgbOf = h => { const v = parseInt(h.slice(1, 7), 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; };
  const css = S.css = (c, a) => a == null ? `rgb(${c.map(x => Math.round(clamp(x, 0, 255))).join(',')})`
    : `rgba(${c.map(x => Math.round(clamp(x, 0, 255))).join(',')},${a})`;
  const mix = S.mix = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
  S.W3 = [255, 255, 255]; S.K3 = [0, 0, 0];
  S.toHsl = c => {
    const r = c[0] / 255, g = c[1] / 255, b = c[2] / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
    if (mx === mn) return [0, 0, l];
    const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    const h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return [h * 60, s, l];
  };
  S.hsl = (h, s, l) => `hsl(${h.toFixed(1)},${(s * 100).toFixed(1)}%,${(l * 100).toFixed(1)}%)`;
  S.lum = c => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;   // 亮度 0~1（浅底配深字用）

  // ================= 【区域S2 颜色关键帧】 =================
  // v14.0：算法搬到 view-controls.js 的 FXColorKeys（每个效果都会加载它，所有效果通用的「去色 · 高亮」也用它），
  // 这里转过去，只留一份。用法和以前完全一样。
  const CK = () => window.FXColorKeys;
  S.readKeys = raw => CK().readKeys(raw);
  // 某一秒的值：b0 = 第一个点之前的状态；每个点从自己那一秒开始用 fade 秒变过去
  const laneAt = S.laneAt = (keys, b0, fade, t) => CK().laneAt(keys, b0, fade, t);
  // 这一秒的颜色状态：P 里用 desat（开场是否黑白）、fadeK（颜色渐变秒数）
  S.colorAt = (P, K, t) => CK().colorAt(P, K, t);

  // ================= 【区域S3 应用到画面】 =================
  // card：整张卡片（灰度滤镜加在它上面）；hi：高亮层（跟着 h 显现）；lo：常态层（跟着 h 隐去）
  S.applyColor = (card, st, hi, lo) => {
    const fl = CK().desatFilter(st.c);                 // 去色滤镜也在 FXColorKeys 里（v14.0）
    if (card && card.__fl !== fl) { card.__fl = fl; card.style.filter = fl; }
    const ho = st.h.toFixed(3), no = (1 - st.h).toFixed(3);
    const set = (el, o) => { if (el && el.__o !== o) { el.__o = o; el.style.opacity = o; } };
    (hi || []).forEach(el => set(el, ho));
    (lo || []).forEach(el => set(el, no));
  };

  // ================= 【区域S4 缝线 / 边框】 =================
  // 一整圈缝纫线（缝线标题卡用）：L = { W, H, sin: 离边, rad: 圆角 }；一层深色「针眼」+ 一层线
  S.stitchSvg = (L, style, line, under) => {
    const st = ['dash', 'long', 'dot', 'off'].includes(style) ? style : 'dash';
    if (st === 'off') return '';
    const W = L.W, H = L.H, s = L.sin;
    const sw = Math.max(1.6, W * 0.0028);
    const rx = Math.max(0, L.rad - s * 0.55);
    const dash = st === 'dot' ? `0.01 ${(sw * 2.9).toFixed(1)}` : st === 'long' ? `${(sw * 6.5).toFixed(1)} ${(sw * 3.2).toFixed(1)}`
      : `${(sw * 3.6).toFixed(1)} ${(sw * 2.6).toFixed(1)}`;
    const w2 = st === 'dot' ? sw * 1.5 : sw;
    const cap = st === 'dot' ? 'round' : 'butt';
    const r = (dx, col) => `<rect x="${(s + dx).toFixed(1)}" y="${(s + dx).toFixed(1)}" width="${(W - s * 2).toFixed(1)}" height="${(H - s * 2).toFixed(1)}"`
      + ` rx="${rx.toFixed(1)}" fill="none" stroke="${col}" stroke-width="${w2.toFixed(2)}" stroke-dasharray="${dash}" stroke-linecap="${cap}"/>`;
    return `<svg width="${W.toFixed(1)}" height="${H.toFixed(1)}" viewBox="0 0 ${W.toFixed(1)} ${H.toFixed(1)}">`
      + r(sw * 0.7, under) + r(0, line) + '</svg>';
  };
  // 边框（可以断开）：o = { W, H, x, y, w, h, rx, style: line|dash|long|dot|off, sw, color, under,
  //                        top:[[x0,x1],…], bottom:[[x0,x1],…] }  top / bottom = 这一段不画（文字压在线上）
  S.frameSvg = o => {
    const st = ['line', 'dash', 'long', 'dot', 'off'].includes(o.style) ? o.style : 'line';
    if (st === 'off') return '';
    const f = v => (+v).toFixed(1);
    const x = o.x, y = o.y, w = o.w, h = o.h, rx = clamp(o.rx || 0, 0, Math.min(w, h) / 2), sw = o.sw;
    const dash = st === 'dot' ? `0.01 ${f(sw * 2.9)}` : st === 'long' ? `${f(sw * 6.5)} ${f(sw * 3.2)}` : st === 'dash' ? `${f(sw * 3.6)} ${f(sw * 2.6)}` : '';
    const w2 = st === 'dot' ? sw * 1.5 : sw, cap = st === 'dot' ? 'round' : 'butt';
    // 一条横边减掉若干段空缺，剩下的一段段画
    const pieces = (a, b, gaps) => {
      let out = [[a, b]];
      (gaps || []).forEach(g => {
        const g0 = Math.min(g[0], g[1]), g1 = Math.max(g[0], g[1]);
        out = out.flatMap(([p, q]) => (g1 <= p || g0 >= q) ? [[p, q]] : [[p, Math.min(q, g0)], [Math.max(p, g1), q]].filter(s => s[1] - s[0] > 0.5));
      });
      return out;
    };
    const d = [];
    pieces(x + rx, x + w - rx, o.top).forEach(([a, b]) => d.push(`M${f(a)} ${f(y)}H${f(b)}`));
    d.push(`M${f(x + w - rx)} ${f(y)}A${f(rx)} ${f(rx)} 0 0 1 ${f(x + w)} ${f(y + rx)}V${f(y + h - rx)}A${f(rx)} ${f(rx)} 0 0 1 ${f(x + w - rx)} ${f(y + h)}`);
    pieces(x + rx, x + w - rx, o.bottom).forEach(([a, b]) => d.push(`M${f(b)} ${f(y + h)}H${f(a)}`));
    d.push(`M${f(x + rx)} ${f(y + h)}A${f(rx)} ${f(rx)} 0 0 1 ${f(x)} ${f(y + h - rx)}V${f(y + rx)}A${f(rx)} ${f(rx)} 0 0 1 ${f(x + rx)} ${f(y)}`);
    const path = (dx, col) => `<path transform="translate(${f(dx)},${f(dx)})" d="${d.join('')}" fill="none" stroke="${col}" stroke-width="${w2.toFixed(2)}"`
      + `${dash ? ` stroke-dasharray="${dash}"` : ''} stroke-linecap="${cap}"/>`;
    return `<svg width="${f(o.W)}" height="${f(o.H)}" viewBox="0 0 ${f(o.W)} ${f(o.H)}">`
      + (o.under && st !== 'line' ? path(sw * 0.7, o.under) : '') + path(0, o.color) + '</svg>';
  };

  // ================= 【区域S5 入场 / 出场】 =================
  // 返回这一秒各部分的状态：卡片 cs 缩放 / cy 下移 / co 透明度；标题 tX tO；副标题 bY bO；图片 iS iR iO
  // L = { inDur, left(图片在左), W, H, exitOn, outStart, outDur }
  const back = F.backOut(1.3), backBig = F.backOut(2);
  S.motion = (way, t, L) => {
    way = ['pop', 'fade', 'up', 'none'].includes(way) ? way : 'pop';
    const d = L.inDur, dir = L.left ? 1 : -1;
    let cs = 1, cy = 0, co = 1;
    let tX = 0, tO = 1, bY = 0, bO = 1, iS = 1, iR = 0, iO = 1;
    if (way === 'pop') {
      const k = prog(t, 0, d * 0.6);
      cs = lerp(0.86, 1, back(k)); co = smooth(k);
      const k2 = F.cubicOut(prog(t, d * 0.18, d * 0.72)); tX = dir * (1 - k2) * L.W * 0.06; tO = k2;
      const k3 = F.cubicOut(prog(t, d * 0.34, d * 0.88)); bY = (1 - k3) * L.H * 0.06; bO = k3;
      const k4 = prog(t, d * 0.28, d); iS = lerp(0.45, 1, backBig(k4)); iR = (1 - k4) * -dir * 9; iO = smooth(prog(t, d * 0.28, d * 0.55));
    } else if (way === 'fade') { co = smooth(prog(t, 0, d)); }
    else if (way === 'up') { const k = F.cubicOut(prog(t, 0, d)); cy = (1 - k) * L.H * 0.35; co = smooth(prog(t, 0, d * 0.7)); }
    if (L.exitOn) {
      const k = prog(t, L.outStart, L.outStart + L.outDur);
      cs *= 1 - 0.07 * F.cubicIn(k); co *= 1 - smooth(k);
    }
    return { cs, cy, co, tX, tO, bY, bO, iS, iR, iO };
  };

  // ================= 【区域S6 编辑器样式】 =================
  S.injectStyle = pd => {
    if (pd.getElementById('stc-style')) return;
    const st = pd.createElement('style'); st.id = 'stc-style';
    // 选择器都挂在 #params .stc 下并加 !important —— 工作台面板对 input / button 有全局样式，不这样会被撑大
    // 颜色都写在样式表里（浅色界面自动翻转）；橙色写在具体类上（规则 6）
    st.textContent = `
html body #params .stc{display:block!important;margin:0 0 6px!important;font-size:12px;color:#999}
html body #params .stc .stc-b{display:block!important;background:#121212!important;border:1px solid #262626!important;border-radius:10px!important;padding:11px!important;margin:0 0 10px!important}
html body #params .stc .stc-t{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;margin:0 0 10px!important}
html body #params .stc .stc-t b{font-size:12.5px!important;font-weight:600!important;color:#ddd!important;letter-spacing:.04em!important}
html body #params .stc .stc-t span{font-size:11px!important;color:#777!important;white-space:nowrap!important}
html body #params .stc .stc-seg{display:flex!important;background:#1d1d1d!important;border:1px solid #333!important;border-radius:6px!important;overflow:hidden!important;margin:0!important}
html body #params .stc .stc-seg button{flex:1!important;width:auto!important;height:auto!important;min-width:0!important;margin:0!important;border:0!important;border-radius:0!important;background:none!important;color:#aaa!important;padding:5px 8px!important;font-size:12px!important;cursor:pointer!important;font-family:inherit!important;white-space:nowrap!important}
html body #params .stc .stc-seg button.on{background:#f28c0f!important;color:#000!important;font-weight:600!important}
html body #params .stc .stc-ph{position:relative!important;height:110px!important;margin:10px 0 0!important;border:1px dashed #444!important;border-radius:6px!important;display:flex!important;align-items:center!important;justify-content:center!important;text-align:center!important;color:#999!important;font-size:12px!important;cursor:pointer!important;overflow:hidden!important;line-height:1.5!important;background:#0b0b0b!important}
html body #params .stc .stc-ph:hover,html body #params .stc .stc-ph.over{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc .stc-ph small{color:#666!important}
html body #params .stc .stc-ph.has{border-style:solid!important}
html body #params .stc .stc-ph img{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;object-fit:contain!important}
html body #params .stc .stc-ph.has span{position:relative!important;background:rgba(0,0,0,.65)!important;color:#fff!important;padding:3px 8px!important;border-radius:4px!important;opacity:0!important;transition:opacity .15s!important}
html body #params .stc .stc-ph.has:hover span{opacity:1!important}
html body #params .stc .stc-btn{display:block!important;width:100%!important;height:auto!important;margin:8px 0 0!important;padding:7px 8px!important;font-size:12px!important;background:#1d1d1d!important;color:#ccc!important;border:1px solid #333!important;border-radius:6px!important;cursor:pointer!important;font-family:inherit!important;text-align:center!important}
html body #params .stc .stc-btn:hover{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc .stc-lnk{display:inline-block!important;width:auto!important;height:auto!important;margin:6px 0 0!important;padding:0!important;background:none!important;border:0!important;color:#888!important;font-size:12px!important;cursor:pointer!important;font-family:inherit!important}
html body #params .stc .stc-lnk:hover{color:#f28c0f!important}
html body #params .stc .stc-note{margin:6px 0 0!important;font-size:11.5px!important;color:#777!important;line-height:1.6!important}
html body #params .stc .stc-note b{color:#c89b4d!important;font-weight:500!important}
/* 去色 · 高亮关键帧 */
html body #params .stc .stc-ln{margin:10px 0 0!important}
html body #params .stc .stc-lh{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;margin:0 0 5px!important;color:#ccc!important;font-size:12px!important}
html body #params .stc .stc-lh small{color:#666!important;font-size:11px!important}
html body #params .stc .stc-tr{position:relative!important;height:22px!important;border-radius:5px!important;border:1px solid #2e2e2e!important;cursor:pointer!important;user-select:none!important;touch-action:none!important}
html body #params .stc .stc-pt{position:absolute!important;top:50%!important;width:11px!important;height:11px!important;margin:-6.5px 0 0 -6.5px!important;transform:rotate(45deg)!important;border:1.5px solid #fff!important;box-shadow:0 0 0 1px rgba(0,0,0,.7)!important;cursor:ew-resize!important;box-sizing:content-box!important}
html body #params .stc .stc-pt.v1{background:#f28c0f!important}
html body #params .stc .stc-pt.v0{background:#3a3a3a!important}
html body #params .stc .stc-pt:hover{border-color:#f28c0f!important}
html body #params .stc .stc-hd{position:absolute!important;top:-3px!important;bottom:-3px!important;width:2px!important;margin-left:-1px!important;background:#ff4d4d!important;pointer-events:none!important;border-radius:1px!important}
html body #params .stc .stc-two{display:grid!important;grid-template-columns:1fr 1fr!important;gap:6px!important;margin:6px 0 0!important}
html body #params .stc .stc-two button{display:block!important;width:100%!important;height:auto!important;margin:0!important;padding:6px 4px!important;font-size:12px!important;background:#1d1d1d!important;color:#ccc!important;border:1px solid #333!important;border-radius:6px!important;cursor:pointer!important;font-family:inherit!important;white-space:nowrap!important}
html body #params .stc .stc-two button:hover{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc .stc-qk{display:flex!important;flex-wrap:wrap!important;gap:6px!important;margin:12px 0 0!important;padding:10px 0 0!important;border-top:1px solid #222!important}
html body #params .stc .stc-qk button{flex:1 1 auto!important;width:auto!important;height:auto!important;margin:0!important;padding:5px 8px!important;font-size:11.5px!important;background:none!important;color:#999!important;border:1px dashed #3a3a3a!important;border-radius:6px!important;cursor:pointer!important;font-family:inherit!important;white-space:nowrap!important}
html body #params .stc .stc-qk button:hover{border-color:#f28c0f!important;border-style:solid!important;color:#f28c0f!important}
/* 配色（规则 24） */
html body #params .stc .stc-sw{display:flex!important;flex-wrap:wrap!important;gap:8px!important;margin:0!important}
html body #params .stc .stc-sw button{display:block!important;width:22px!important;height:22px!important;min-width:0!important;padding:0!important;margin:0!important;border:0!important;border-radius:50%!important;cursor:pointer!important;flex:none!important;box-shadow:inset 0 0 0 1px rgba(255,255,255,.14)!important;transition:transform .12s ease!important}
html body #params .stc .stc-sw button:hover{transform:scale(1.12)!important}
html body #params .stc .stc-sw button.on{box-shadow:inset 0 0 0 1px rgba(255,255,255,.14),0 0 0 2px #121212,0 0 0 3.5px #f28c0f!important}
html body #params .stc .stc-sw button.mine{border-radius:6px!important}
html body #params .stc .stc-cb{position:relative!important;display:flex!important;align-items:center!important;gap:7px!important;height:30px!important;box-sizing:border-box!important;padding:0 9px!important;margin:0!important;background:#1a1a1a!important;border:1px solid #2a2a2a!important;border-radius:7px!important;cursor:pointer!important;font-size:12px!important;color:#bbb!important;line-height:1!important;overflow:hidden!important}
html body #params .stc .stc-cb:hover{border-color:#4a4a4a!important;color:#eee!important}
html body #params .stc .stc-cb i{display:block!important;width:14px!important;height:14px!important;flex:none!important;border-radius:50%!important;box-shadow:inset 0 0 0 1px rgba(255,255,255,.2)!important}
html body #params .stc .stc-cb span{display:inline!important;margin:0!important;white-space:nowrap!important}
html body #params .stc .stc-cb input{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;min-height:0!important;margin:0!important;padding:0!important;border:0!important;background:none!important;opacity:0!important;cursor:pointer!important}
html body #params .stc .stc-f{display:flex!important;align-items:center!important;gap:8px!important;margin:8px 0 0!important;min-height:24px!important}
html body #params .stc .stc-msg{flex:1!important;min-width:0!important;font-size:11px!important;color:#777!important;line-height:1.4!important}
html body #params .stc .stc-msg.ok{color:#c89b4d!important}
html body #params .stc .stc-save{display:inline-flex!important;align-items:center!important;width:auto!important;height:24px!important;padding:0 9px!important;margin:0!important;flex:none!important;background:none!important;border:1px dashed #3a3a3a!important;border-radius:6px!important;color:#999!important;font-size:11.5px!important;cursor:pointer!important;font-family:inherit!important}
html body #params .stc .stc-save:hover{border-color:#f28c0f!important;border-style:solid!important;color:#f28c0f!important}
/* 勾选框 / 版式缩略图（v11.1 焦点格卡片加的） */
html body #params .stc .stc-ck{display:flex!important;align-items:flex-start!important;gap:7px!important;margin:10px 0 0!important;font-size:12px!important;color:#ccc!important;cursor:pointer!important;line-height:1.5!important}
html body #params .stc .stc-ck input{width:15px!important;height:15px!important;min-height:0!important;margin:2px 0 0!important;padding:0!important;flex:none!important;accent-color:#f28c0f}
html body #params .stc .stc-lay{display:grid!important;grid-template-columns:repeat(5,1fr)!important;gap:6px!important;margin:0!important}
html body #params .stc .stc-lay button{display:flex!important;flex-direction:column!important;align-items:center!important;gap:4px!important;width:auto!important;height:auto!important;min-width:0!important;margin:0!important;padding:6px 2px 5px!important;background:#1a1a1a!important;border-width:1px!important;border-style:solid!important;border-radius:7px!important;font-size:11px!important;cursor:pointer!important;font-family:inherit!important;white-space:nowrap!important}
html body #params .stc .stc-lay button:not(.on){border-color:#2a2a2a!important;color:#999!important}
html body #params .stc .stc-lay button:not(.on):hover{border-color:#4a4a4a!important;color:#eee!important}
html body #params .stc .stc-lay button.on{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc .stc-lay svg{display:block!important;width:100%!important;height:30px!important}
html body #params .stc .stc-sub{margin:12px 0 0!important;padding:10px 0 0!important;border-top:1px solid #222!important}`;
    pd.head.appendChild(st);
  };
  const mkr = pd => (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  S.mk = mkr;

  // ================= 【区域S7 编辑器·素材】 =================
  // 上传到 uploads\（规则 13：参数里只存路径）；最长边缩到 1920，PNG 透明保留；接口不通时退回内嵌
  S.upImage = async file => {
    const MAXEDGE = 1920;
    const url = URL.createObjectURL(file);
    const im = await new Promise((res, rej) => { const x = new Image(); x.onload = () => res(x); x.onerror = () => rej(new Error('图片无法识别')); x.src = url; });
    const iw = im.naturalWidth, ih = im.naturalHeight;
    let body = file, type = file.type, ow = iw, oh = ih;
    try {
      if (Math.max(iw, ih) > MAXEDGE && file.type !== 'image/gif') {
        const k = MAXEDGE / Math.max(iw, ih);
        const cv = document.createElement('canvas');
        cv.width = ow = Math.round(iw * k); cv.height = oh = Math.round(ih * k);
        cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
        let b = await new Promise(r => cv.toBlob(r, 'image/webp', 0.92));
        if (!b || !/webp/.test(b.type)) b = await new Promise(r => cv.toBlob(r, 'image/png'));
        if (b) { body = b; type = b.type; }
      }
    } catch (e) { ow = iw; oh = ih; }
    URL.revokeObjectURL(url);
    try {
      const j = await (await fetch('/api/upload', { method: 'POST', headers: { 'X-FX': '1', 'Content-Type': type }, body })).json();
      if (!j.url) throw new Error(j.error || '上传失败');
      return { img: j.url, iw: ow, ih: oh };
    } catch (e) {
      const fr = await new Promise((res, rej) => { const f = new FileReader(); f.onload = () => res(f.result); f.onerror = () => rej(new Error('图片读取失败')); f.readAsDataURL(body); });
      return { img: fr, iw: ow, ih: oh, inline: true };
    }
  };
  // o = { pd, read: () => 素材对象, write: m => 存起来, reload: () => 重画, ratio: () => 高/宽, total: () => 总秒数,
  //       contain: () => 上传后从「完整显示」开始调, title, sub, types:[[值, 名字]], other: (m, el, note) => 别的选项自己画,
  //       noneNote, emptyNote, clearLabel, keepTitle(选中照片/视频之外的选项时仍画标题) }
  S.mediaBlock = o => {
    const pd = o.pd, mk = mkr(pd);
    const el = mk('div', o.bare ? '' : 'stc-b');
    const types = o.types || [['image', '照片'], ['video', '视频'], ['none', '不要图片']];
    let m = o.read();
    const save = () => o.write(m);
    const reload = o.reload;
    const ratio = o.ratio;
    const crop = () => F.crop({ it: m, ratio: ratio(), title: o.cropTitle || '调整图片大小和位置', onOk: () => { save(); reload(); } });
    const draw = () => {
      m = o.read();
      el.innerHTML = o.title === '' ? '' : `<div class="stc-t"><b>${o.title || '图片'}</b><span>${o.sub == null ? '卡片右边那张图' : o.sub}</span></div>`;
      const seg = mk('div', 'stc-seg', types.map(([v, n]) => `<button type="button" data-v="${v}">${n}</button>`).join(''));
      seg.querySelectorAll('button').forEach(b => {
        b.classList.toggle('on', b.dataset.v === m.type);
        b.onclick = () => { m = o.read(); m.type = b.dataset.v; save(); draw(); reload(); if (o.switched) o.switched(m.type); };   // 先重读：别的面板（比如格子文字）可能刚改过
      });
      el.appendChild(seg);
      const note = mk('div', 'stc-note', '');
      if (m.type !== 'image' && m.type !== 'video') {
        if (o.other && o.other(m, el, note, { save, draw, reload })) return;
        note.textContent = o.noneNote || '不放图片：标题会居中占满整张卡片。';
        el.appendChild(note); return;
      }
      if (m.type === 'video') {
        if (!window.FXVideo) { note.textContent = '视频模块没加载'; el.appendChild(note); return; }
        const done = () => { save(); draw(); reload(); };
        el.appendChild(FXVideo.editorBody({ pd, c: m, total: o.total,
          changed: F.wrapVideoChanged(m, ratio, done), note: s => { note.textContent = s; } }));
        if (m.video) { const a = mk('button', 'stc-btn', '✥ 调整大小和位置'); a.type = 'button'; a.onclick = crop; el.appendChild(a); }
        el.appendChild(note); return;
      }
      const ph = mk('div', 'stc-ph' + (m.img ? ' has' : ''),
        m.img ? '<img alt=""><span>点击更换图片</span>' : `<span>点击上传图片<br><small>${o.dropTip || '或把图片拖到这里 · 去掉背景的 PNG 最好看'}</small></span>`);
      if (m.img) ph.querySelector('img').src = m.img;
      const fin = pd.createElement('input'); fin.type = 'file'; fin.accept = 'image/*'; fin.style.display = 'none';
      const put = async f => {
        if (!f || !/^image\//.test(f.type)) { note.textContent = '只支持 PNG / JPG / WEBP / GIF 图片'; return; }
        ph.innerHTML = '<span>上传中…</span>';
        let ok = false;
        try {
          F.resetPlace(m);
          Object.assign(m, await S.upImage(f), { type: 'image' });
          // 贴纸样式：从「完整显示」开始调（铺满会把 PNG 贴纸的边裁掉）；照片样式从「铺满」开始
          if (o.contain && o.contain() && m.iw > 0 && m.ih > 0) {
            const r = ratio(), W = 1000, H = 1000 * r;
            m.zoom = +(Math.min(W / m.iw, H / m.ih) / Math.max(W / m.iw, H / m.ih)).toFixed(4); m.px = 0; m.py = 0;
          }
          note.textContent = ''; ok = true;
        } catch (e) { note.textContent = e.message; }
        save(); draw(); reload();
        if (ok) crop();                                         // 规则 26：上传完自动弹出调整窗口
      };
      ph.onclick = () => fin.click();
      fin.onchange = () => { const f = fin.files[0]; fin.value = ''; put(f); };
      ph.addEventListener('dragover', e => { e.preventDefault(); ph.classList.add('over'); });
      ph.addEventListener('dragleave', () => ph.classList.remove('over'));
      ph.addEventListener('drop', e => { e.preventDefault(); e.stopPropagation(); ph.classList.remove('over'); put(e.dataTransfer.files[0]); });
      el.append(ph, fin);
      if (m.img) {
        const a = mk('button', 'stc-btn', '✥ 调整大小和位置'); a.type = 'button'; a.onclick = crop; el.appendChild(a);
        const clr = mk('button', 'stc-lnk', o.clearLabel || '移除图片（换回示例插画）'); clr.type = 'button';
        clr.onclick = () => { m.img = ''; F.resetPlace(m); delete m.iw; delete m.ih; save(); draw(); reload(); };
        el.appendChild(clr);
      } else note.innerHTML = o.emptyNote || '现在显示的是<b>示例插画</b>，上传自己的图片就会替换掉。';
      el.appendChild(note);
    };
    draw();
    return { el, refresh: draw };
  };

  // ================= 【区域S8 编辑器·关键帧】「色彩」「高亮」两行小轨道 =================
  // o = { pd, pw, P, field: 面板名字 => 输入框, total: () => 秒, now: () => 当前秒, inDur: () => 入场秒,
  //       render: () => 按当前秒重画, setK: K => 效果里缓存的关键帧, dirty, hiWord:['常态','高亮'], hiOff: '◆ 这一秒回到黑底', hiNone: '一直黑底', base: [r,g,b] 常态底色 }
  // 用到 P.colorKeys / P.desat / P.fadeK / P.cText / P.cHi
  S.keysBlock = o => {
    const pd = o.pd, pw = o.pw, P = o.P, mk = mkr(pd);
    const el = mk('div', 'stc-b');
    const total = o.total, nowT = o.now;
    const r2 = x => Math.round(x * 100) / 100;
    const fieldOf = o.field;
    let K = S.readKeys(P.colorKeys);
    const save = () => {
      K.c.sort((a, b) => a.t - b.t); K.h.sort((a, b) => a.t - b.t);
      P.colorKeys = JSON.stringify({ c: K.c.map(k => ({ t: r2(k.t), v: k.v })), h: K.h.map(k => ({ t: r2(k.t), v: k.v })) });
      const f = fieldOf('颜色关键帧'); if (f) f.value = P.colorKeys;
      o.setK(S.readKeys(P.colorKeys));
      o.dirty(); o.render(); drawLanes();
    };
    // 跳到某一秒（换算成工作台进度条上的时间：持续时间被按比例拉伸过时也对得上）
    const seek = t => {
      const k = (+window.getDuration() || total()) / total();
      try { pw.stop && pw.stop(); pw.seek && pw.seek(Math.max(0, t * k)); } catch (e) { o.render(t); }
    };
    const hint = s => { const h = pd.getElementById('hint'); if (h) h.textContent = s; };
    const hw = o.hiWord || ['常态', '高亮'];
    const LANES = [
      { k: 'c', name: '色彩', b0: () => (P.desat === 'on' ? 0 : 1), v0: '◆ 这一秒去色', v1: '◆ 这一秒恢复彩色',
        col: v => css(mix([70, 70, 70], rgbOf(norm(P.cText) || o.defText || '#f3c55c'), v)), word: v => (v ? '彩色' : '去色') },
      { k: 'h', name: '高亮', b0: () => 0, v0: o.hiOff || '◆ 这一秒回到黑底', v1: '◆ 这一秒高亮',
        col: v => css(mix(o.base ? o.base() : [22, 22, 22], rgbOf(norm(P.cHi) || o.defHi || '#dfe8a4'), v)), word: v => (v ? hw[1] : hw[0]) }
    ];
    el.innerHTML = '<div class="stc-t"><b>去色 · 高亮关键帧</b><span class="stc-now"></span></div>';
    const nowEl = el.querySelector('.stc-now');
    // 开场状态：彩色 / 去色（= 参数「去色（开场状态）」）
    const st = mk('div', 'stc-lh', '<span>开场状态</span>');
    const seg = mk('div', 'stc-seg', '<button type="button" data-v="off">彩色</button><button type="button" data-v="on">去色 · 黑白</button>');
    seg.style.cssText = 'flex:0 0 66%';
    st.appendChild(seg); el.appendChild(st);
    seg.querySelectorAll('button').forEach(b => b.onclick = () => {
      P.desat = b.dataset.v; const f = fieldOf('去色（开场状态）'); if (f) f.value = P.desat;
      syncSeg(); o.dirty(); o.render(); drawLanes();
      hint(P.desat === 'on' ? '开场是黑白的 —— 在「色彩」那一行打一个「恢复彩色」的点，颜色就从那一秒加回来' : '开场是彩色的');
    });
    const syncSeg = () => seg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === (P.desat === 'on' ? 'on' : 'off')));

    const rows = LANES.map(l => {
      const ln = mk('div', 'stc-ln');
      ln.innerHTML = `<div class="stc-lh"><span>${l.name}</span><small></small></div>`;
      const tr = mk('div', 'stc-tr'); ln.appendChild(tr);
      const two = mk('div', 'stc-two');
      [0, 1].forEach(v => {
        const b = mk('button', '', v ? l.v1 : l.v0); b.type = 'button';
        b.onclick = () => {
          const t = r2(nowT()), arr = K[l.k];
          const hit = arr.find(k => Math.abs(k.t - t) < 0.04);
          if (hit) hit.v = v; else arr.push({ t, v });
          save(); hint('已在 ' + t.toFixed(2) + ' 秒记下【' + l.name + '：' + l.word(v) + '】—— 从这一秒开始变过去');
        };
        two.appendChild(b);
      });
      ln.appendChild(two);
      el.appendChild(ln);
      // 轨道上的交互：空白处点一下 = 跳到那一秒；拖菱形 = 改时间；双击菱形 = 切换状态；右键菱形 = 删掉
      const tOf = e => { const r = tr.getBoundingClientRect(); return clamp((e.clientX - r.left) / Math.max(1, r.width), 0, 1) * total(); };
      let drag = null;
      tr.addEventListener('pointerdown', e => {
        if (e.button !== 0) return;
        const pt = e.target.closest && e.target.closest('.stc-pt');
        if (pt) {
          const k = K[l.k][+pt.dataset.i];
          drag = { k, x: e.clientX, moved: false };
          try { tr.setPointerCapture(e.pointerId); } catch (x) {}
        } else { drag = { scrub: true }; seek(tOf(e)); try { tr.setPointerCapture(e.pointerId); } catch (x) {} }
        e.preventDefault();
      });
      tr.addEventListener('pointermove', e => {
        if (!drag) return;
        if (drag.scrub) { seek(tOf(e)); return; }
        if (!drag.moved && Math.abs(e.clientX - drag.x) < 3) return;
        drag.moved = true; drag.k.t = r2(tOf(e));
        o.setK({ c: K.c.slice().sort((a, b) => a.t - b.t), h: K.h.slice().sort((a, b) => a.t - b.t) });
        o.render(); drawLanes();
        hint('移动【' + l.name + '：' + l.word(drag.k.v) + '】→ ' + drag.k.t.toFixed(2) + ' 秒');
      });
      const up = () => {
        if (!drag) return;
        const d = drag; drag = null;
        if (d.scrub) return;
        if (d.moved) save(); else seek(d.k.t);                // 没拖动 = 跳到这个点
      };
      tr.addEventListener('pointerup', up); tr.addEventListener('pointercancel', up);
      tr.addEventListener('dblclick', e => {
        const pt = e.target.closest && e.target.closest('.stc-pt'); if (!pt) return;
        const k = K[l.k][+pt.dataset.i]; k.v = k.v ? 0 : 1; save();
        hint('已把 ' + k.t.toFixed(2) + ' 秒那个点改成【' + l.name + '：' + l.word(k.v) + '】');
      });
      tr.addEventListener('contextmenu', e => {
        const pt = e.target.closest && e.target.closest('.stc-pt'); if (!pt) return;
        e.preventDefault();
        K[l.k].splice(+pt.dataset.i, 1); save(); hint('已删掉一个【' + l.name + '】关键帧');
      });
      return { l, tr, cnt: ln.querySelector('small') };
    });

    // 一键示范 / 清空
    const qk = mk('div', 'stc-qk');
    const quick = (txt, fn, tip) => { const b = mk('button', '', txt); b.type = 'button'; b.title = tip; b.onclick = fn; qk.appendChild(b); };
    quick('示范：黑白开场 → 恢复彩色', () => {
      const t = r2(Math.min(total() * 0.4, o.inDur() + 1));
      P.desat = 'on'; const f = fieldOf('去色（开场状态）'); if (f) f.value = 'on';
      K.c = [{ t, v: 1 }]; syncSeg(); save(); hint('开场黑白，' + t.toFixed(2) + ' 秒开始恢复彩色');
    }, '开场整张卡片是黑白的，过一会儿颜色加回来');
    quick('示范：中间高亮一下', () => {
      const a = r2(total() * 0.3), b = r2(total() * 0.65);
      K.h = [{ t: a, v: 1 }, { t: b, v: 0 }]; save(); hint(a.toFixed(2) + ' 秒高亮，' + b.toFixed(2) + ' 秒' + (o.hiBack || '回到黑底'));
    }, '中间一段切到高亮色，然后' + (o.hiBack || '回到黑底'));
    quick('清空', () => {
      K.c = []; K.h = []; save(); hint('颜色关键帧已清空');
    }, '两行的关键帧全部删掉');
    el.appendChild(qk);
    el.appendChild(mk('div', 'stc-note', '用法：进度条拖到某一秒 → 点上面的按钮，就在这一秒打一个点，'
      + '从这一秒开始用「颜色渐变秒数」变过去。<b>轨道上</b>：点空白处跳到那一秒，拖菱形改时间，双击菱形切换状态，右键菱形删除。'));

    function drawLanes() {
      const T = total(), fade = clamp(num(P.fadeK, 0.4), 0, 5);
      rows.forEach(({ l, tr, cnt }) => {
        const arr = K[l.k].slice().sort((a, b) => a.t - b.t);
        // 按 120 个采样点画出这一行每一秒的状态：一眼看出哪一段是黑白 / 高亮
        const N = 120, stops = [];
        for (let i = 0; i <= N; i++) { const v = laneAt(arr, l.b0(), fade, i / N * T); stops.push(l.col(v) + ' ' + (i / N * 100).toFixed(2) + '%'); }
        tr.style.background = `linear-gradient(90deg,${stops.join(',')})`;
        tr.innerHTML = K[l.k].map((k, i) => `<div class="stc-pt v${k.v}" data-i="${i}" style="left:${clamp(k.t / T * 100, 0, 100).toFixed(2)}%"`
          + ` title="${k.t.toFixed(2)} 秒：${l.word(k.v)}（拖动改时间 · 双击切换 · 右键删除）"></div>`).join('') + '<div class="stc-hd"></div>';
        cnt.textContent = K[l.k].length ? K[l.k].length + ' 个点' : (l.k === 'c' ? (P.desat === 'on' ? '一直黑白' : '一直彩色') : (o.hiNone || '一直黑底'));
      });
      head(nowT(), true);
    }
    let ht = -1;
    function head(t, force) {
      const q = Math.round(t * 100); if (!force && q === ht) return; ht = q;     // 只在百分之一秒变了时写
      const p = clamp(t / total() * 100, 0, 100).toFixed(2) + '%';
      rows.forEach(r => { const h = r.tr.querySelector('.stc-hd'); if (h) h.style.left = p; });
      nowEl.textContent = '当前 ' + t.toFixed(2) + ' 秒';
    }
    const refresh = () => { K = S.readKeys(P.colorKeys); syncSeg(); drawLanes(); };
    refresh();
    return { el, refresh, head: t => { if (el.isConnected) head(t); } };
  };

  // ================= 【区域S9 编辑器·配色】 =================
  // o = { pd, pw, P, field, apply: () => 改完重画, title, sub, keys:[{key, name, tip, field, def}] 一个或两个,
  //       presets:[{c:[色, 色], name}], ls: 本地存储名（两个颜色的默认 'fx-my-color-pairs'，所有效果共用） }
  S.colorBlock = o => {
    const pd = o.pd, pw = o.pw, P = o.P, mk = mkr(pd), fieldOf = o.field;
    const keys = o.keys, n = keys.length;
    const el = mk('div', o.bare ? '' : 'stc-b');
    el.innerHTML = `<div class="stc-t"><b>${o.title || '配色'}</b><span>${o.sub || ''}</span></div>`;
    const sw = mk('div', 'stc-sw'); el.appendChild(sw);
    const now = () => keys.map(k => norm(P[k.key]) || k.def);
    const same = (a, b) => a.every((x, i) => norm(x) === norm(b[i]));
    const bgOf = c => n === 1 ? c[0] : `linear-gradient(90deg,${c[0]} 0 50%,${c[1]} 50% 100%)`;
    const setAll = c => {
      keys.forEach((k, i) => { P[k.key] = c[i]; const f = fieldOf(k.field); if (f) f.value = c[i]; });
      o.apply();
    };
    // 「我的配色」存在工作台页面的本地存储里，所有效果共用一份（规则 24）
    const LS = o.ls || (n === 2 ? 'fx-my-color-pairs' : 'fx-my-colors-' + n);
    const myList = () => {
      try {
        const a = JSON.parse(pw.localStorage.getItem(LS) || '[]');
        return !Array.isArray(a) ? [] : a.filter(p => Array.isArray(p) && p.length >= n && p.slice(0, n).every(x => norm(x))).map(p => p.slice(0, n).map(norm)).slice(0, 24);
      } catch (e) { return []; }
    };
    const saveMy = a => { try { pw.localStorage.setItem(LS, JSON.stringify(a.slice(0, 24))); } catch (e) {} };
    const dot = (c, title, click, mine) => {
      const b = mk('button'); b.type = 'button'; b.title = title;
      b.style.background = bgOf(c);
      if (mine) b.classList.add('mine');
      if (same(c, now())) b.classList.add('on');
      b.onclick = click; sw.appendChild(b); return b;
    };
    const drawDots = () => {
      sw.innerHTML = '';
      o.presets.forEach(p => dot(p.c, p.name, () => setAll(p.c)));
      myList().forEach((c, i) => {
        const b = dot(c, '我的配色（右键删掉）', () => setAll(c), true);
        b.oncontextmenu = e => {
          e.preventDefault();
          let ok = true; try { ok = pw.confirm(n === 2 ? '删掉这一对保存的配色？' : '删掉这一个保存的配色？'); } catch (x) {}
          if (!ok) return;
          const a = myList(); a.splice(i, 1); saveMy(a); drawDots();
        };
      });
    };
    // 颜色按钮：整个按钮就是取色入口，点哪儿都弹系统取色盘
    const two = mk('div', 'stc-two'); el.appendChild(two);
    const btns = {};
    keys.forEach(k => {
      const b = mk('label', 'stc-cb'); b.title = (k.tip || k.name) + '（点开取色盘）';
      const chip = mk('i'), lab = mk('span', '', k.name), ci = mk('input'); ci.type = 'color';
      ci.oninput = () => { P[k.key] = ci.value; const f = fieldOf(k.field); if (f) f.value = ci.value; o.apply(); };
      b.append(chip, lab, ci); two.appendChild(b); btns[k.key] = { ci, chip };
    });
    const foot = mk('div', 'stc-f'); el.appendChild(foot);
    const tip = mk('div', 'stc-msg', '');
    const save = mk('button', 'stc-save', '★ 保存为我的配色'); save.type = 'button';
    save.title = (n === 2 ? '把现在这一对颜色存下来' : '把现在的颜色存下来') + '，所有效果里都能一键点回来；存下的是圆角方块，右键可以删';
    foot.append(tip, save);
    const HINT = o.hint || '点色块直接换色，点按钮弹出取色盘';
    let tt = 0;
    const say = (m, ok) => { tip.textContent = m; tip.classList.toggle('ok', !!ok); clearTimeout(tt); tt = setTimeout(() => { tip.textContent = HINT; tip.classList.remove('ok'); }, 2600); };
    tip.textContent = HINT;
    save.onclick = () => {
      const c = now();
      if (o.presets.some(p => same(p.c, c))) return say(n === 1 ? '这个颜色是内置的，不用存' : '这一对是内置的，不用存');
      const a = myList();
      if (a.some(p => same(p, c))) return say('已经存过了');
      a.push(c); saveMy(a); drawDots(); say('已存 · 右键方块可删', true);
    };
    const refresh = () => {
      const c = now();
      keys.forEach((k, i) => { btns[k.key].ci.value = c[i]; btns[k.key].chip.style.background = c[i]; });
      drawDots();
    };
    refresh();
    return { el, refresh };
  };
})();
