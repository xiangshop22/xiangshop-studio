/* ===========================================================================
   fx-explain.js —— 讲解版式公共件（工作台公共模块，2026-11-12 新增）
   ---------------------------------------------------------------------------
   做什么：讲解类版式（时间轴、流程图、关系图、大公式条、文档荧光笔……）共用的零件，
           这几张卡只管自己的排版，卡片皮肤、「讲到哪亮哪」、箭头、右侧编辑器都从这里拿，不各写一份（规则 28）。
   来源：画面语言参考开源仓库 howoneai/xiaolin-explainer-packaging（MIT），按工作台规则重写成纯 HTML。
   谁在用：时间轴 timeline-axis、流程步骤 flow-steps、关系图 relation-graph、大公式条 formula-bar、文档荧光笔 doc-highlight。
           别的效果都没引用它，所以加这个文件不影响任何老效果。

   区域地图（想改哪里，直接说「区域Ex 怎么改」）
   【区域E1 小工具】   缓动、插值、颜色换算、写样式前先比值（put）
   【区域E2 颜色】     卡片色 × 高亮色 → 常态字色 / 高亮字色（高亮色上面自动配深色字）
   【区域E3 讲到哪亮哪】每一项一个「亮起秒数」；模式 = 依次点亮（当前亮、其余压暗）/ 亮了就一直亮 / 全部常亮
   【区域E4 卡片】     一张讲解卡 = 底色层 + 高亮色层（只改透明度）+ 两份文字（常态 / 高亮，交叉淡入）
                      文字一律用文字转场模块画（FXTrans.draw 'static'，规则 39），所以 **重点** / *加粗* / ~划掉~ / | 换行 都认
                      卡片背景动效（规则 40）：自动标记，用户在右侧打开才画
   【区域E5 箭头 / 曲线】箭头三角、二次曲线（关系图、流程图用）
   【区域E6 编辑器】   右侧面板：一行一项的列表（＋ 加一项、↑ ↓ 调顺序、✕ 删掉），改完直接写 P（不派发 input，规则 6）
                      + 配色块（FXSkin.colorBlock，预设来自配色库 fx-palettes.js，规则 24）
   引入顺序：fx-cards.js → fx-skin.js → fx-transition.js → fx-palettes.js → fx-explain.js → 效果脚本 → fx-video.js → view-controls.js
   =========================================================================== */
(function () {
  const E = window.FXExplain = window.FXExplain || {};

  // ================= 【区域E1 小工具】 =================
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  E.clamp = clamp;
  E.lerp = (a, b, k) => a + (b - a) * k;
  E.prog = (t, a, d) => clamp((t - a) / Math.max(1e-6, d));
  E.eout = k => 1 - Math.pow(1 - clamp(k), 3);
  E.eio = k => { k = clamp(k); return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2; };
  E.back = k => { k = clamp(k); const c = 1.5; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); };
  E.num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };
  E.f = x => (Math.round(x * 100) / 100).toString();
  // 写样式前先比值：每帧只写 transform / opacity，而且只在变了的时候写（规则 16）
  E.put = (el, tf, op) => {
    if (!el) return;
    if (tf != null && el.__tf !== tf){ el.style.transform = tf; el.__tf = tf; }
    if (op != null){ const o = Math.round(op * 1000) / 1000; if (el.__op !== o){ el.style.opacity = o; el.__op = o; el.style.visibility = o <= 0.001 ? 'hidden' : ''; } }
  };
  E.esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  E.plain = s => String(s == null ? '' : s).replace(/\*\*|\*|~~|~|==|\[\[|\]\]|__/g, '').replace(/\|/g, ' ');
  // 读一个 JSON 数组参数：坏字符串、不是数组都退回示例（规则 12：坏数据不能白屏）
  E.list = (raw, demo) => {
    let v = raw;
    if (typeof v === 'string'){ try { v = JSON.parse(v); } catch (e) { v = null; } }
    if (v && !Array.isArray(v) && Array.isArray(v.list)) v = v.list;
    if (!Array.isArray(v)) v = demo;
    v = v.filter(x => x && typeof x === 'object');
    return v.length ? v : demo;
  };

  // ================= 【区域E2 颜色】 =================
  const hex = c => { c = String(c || '').trim(); if (/^#[0-9a-f]{3}$/i.test(c)) c = '#' + c.slice(1).split('').map(x => x + x).join(''); return /^#[0-9a-f]{6}$/i.test(c) ? c.toLowerCase() : null; };
  const rgb = c => { const n = parseInt(c.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const toHex = a => '#' + a.map(x => clamp(Math.round(x), 0, 255).toString(16).padStart(2, '0')).join('');
  E.hex = hex; E.rgb = c => rgb(hex(c) || '#000000');
  E.mix = (a, b, k) => { const A = rgb(hex(a) || '#000000'), B = rgb(hex(b) || '#000000'); return toHex(A.map((x, i) => x + (B[i] - x) * k)); };
  E.rgba = (c, a) => { const A = rgb(hex(c) || '#000000'); return `rgba(${A[0]},${A[1]},${A[2]},${a})`; };
  const lum = c => { const A = rgb(c); return (0.2126 * A[0] + 0.7152 * A[1] + 0.0722 * A[2]) / 255; };
  // 卡片色上放浅字、高亮色上放深字；卡片色太浅时字自动变深（反之亦然），保证看得清
  E.colors = (P, defCard, defHi) => {
    const card = hex(P.cCard) || defCard || '#2e2d33', hi = hex(P.cHi) || defHi || '#f28c0f';
    const ink = lum(card) > 0.6 ? E.mix(card, '#000000', 0.82) : E.mix(card, '#ffffff', 0.86);
    const hiInk = lum(hi) > 0.45 ? E.mix(hi, '#000000', 0.78) : E.mix(hi, '#ffffff', 0.92);
    return { card, hi, ink, hiInk, sub: E.rgba(ink, 0.62), hiSub: E.rgba(hiInk, 0.75) };
  };

  // ================= 【区域E3 讲到哪亮哪】 =================
  // at[i] = 第 i 项亮起的秒数（已经按「自动 / 手填」算好）；fade = 亮 / 暗之间渐变多少秒
  // mode: 'step' 依次点亮，下一项亮起时上一项压暗；'keep' 亮了就一直亮；'all' 出现就是亮的；'none' 都不亮
  E.lit = (at, i, t, mode, fade) => {
    fade = Math.max(0.05, fade || 0.35);
    if (mode === 'none') return 0;
    if (mode === 'all') return 1;
    const on = E.prog(t, at[i], fade);
    if (mode === 'keep') return E.eio(on);
    // 下一个亮起时间比它晚的那一项
    let nx = Infinity; at.forEach((a, j) => { if (j !== i && a > at[i] && a < nx) nx = a; });
    return E.eio(on) * (1 - E.eio(E.prog(t, nx, fade)));
  };
  // 每项的亮起时间：手填了就用手填的（秒，从素材开头算），否则 = 出现时间 + 自动偏移
  E.times = (items, base, step, delay) => items.map((it, i) => {
    const v = parseFloat(it.t); return isFinite(v) && it.t !== '' ? Math.max(0, v) : base + i * step + (delay || 0);
  });

  // ================= 【区域E4 卡片】 =================
  E.stageCss = `
.fxe-card{position:absolute;left:0;top:0;will-change:transform,opacity;contain:layout style}
.fxe-card .fxe-sk{position:absolute;inset:0;border-radius:var(--r,12px)}
.fxe-card .fxe-base{box-shadow:0 18px 40px rgba(0,0,0,.45),0 2px 3px rgba(0,0,0,.35),inset 0 2px 0 rgba(255,255,255,.12),inset 0 -3px 0 rgba(0,0,0,.22)}
.fxe-card .fxe-lit{opacity:0;box-shadow:inset 0 2px 0 rgba(255,255,255,.35),inset 0 -3px 0 rgba(0,0,0,.18)}
.fxe-card .fxe-tx{position:absolute;inset:0;border-radius:var(--r,12px)}
.fxe-card .fxe-tx.on{opacity:0}
.fxe-card .fxe-num{position:absolute;left:20px;top:12px;font:800 28px/1 "DIN Alternate","Bahnschrift","Arial Narrow",sans-serif;letter-spacing:.04em}
.fxe-card .fxe-t,.fxe-card .fxe-s{position:absolute;left:14px;right:14px}
.fxe-card .fxe-s{font-weight:600;letter-spacing:.06em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}
.fxe-pill{position:absolute;left:0;top:0;white-space:nowrap;font-weight:800;border-radius:.32em;padding:.2em .55em;line-height:1.15;box-shadow:0 6px 14px rgba(0,0,0,.25);will-change:transform,opacity}
`;
  E.FONT = "'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif";   // 单引号：文字转场模块把它写进 style="..." 里
  E.injectStage = () => { if (document.getElementById('fxe-stage-css')) return; const s = document.createElement('style'); s.id = 'fxe-stage-css'; s.textContent = E.stageCss; document.head.appendChild(s); };
  const drawText = (el, txt, o) => {
    if (window.FXTrans) FXTrans.draw(el, { id: 'static', b: txt, fs: o.fs, color: o.color, accent: o.accent, bold: true, font: E.FONT, lh: 1.12, ls: 0.03 });
    else el.textContent = E.plain(txt);
  };
  // o = { w, h, t: 标题, s: 小字, num: '01', fs, ss, C: E.colors(), round, index, seed, r }
  // 返回 { el, set(lit) }：lit 0~1 只改两层透明度（文字颜色不每帧改）
  E.card = o => {
    const w = o.w, h = o.h, C = o.C, r = o.round ? Math.min(w, h) / 2 : (o.r == null ? 12 : o.r);
    const el = document.createElement('div'); el.className = 'fxe-card';
    el.style.cssText = `width:${w}px;height:${h}px;--r:${r}px`;
    const base = document.createElement('div'); base.className = 'fxe-sk fxe-base'; base.style.background = `linear-gradient(180deg,${E.mix(C.card, '#ffffff', 0.06)},${E.mix(C.card, '#000000', 0.12)})`;
    const lit = document.createElement('div'); lit.className = 'fxe-sk fxe-lit'; lit.style.background = `linear-gradient(180deg,${E.mix(C.hi, '#ffffff', 0.12)},${C.hi})`;
    el.append(base, lit);
    const fs = o.fs || Math.round(h * 0.3), ss = o.ss || Math.round(fs * 0.48);
    const mkTx = (on) => {
      const tx = document.createElement('div'); tx.className = 'fxe-tx' + (on ? ' on' : '');
      const ink = on ? C.hiInk : C.ink, sub = on ? C.hiSub : C.sub;
      if (o.num){ const n = document.createElement('div'); n.className = 'fxe-num'; n.textContent = o.num; n.style.color = sub; tx.appendChild(n); }
      const hasS = !!(o.s && String(o.s).trim());
      const tt = document.createElement('div'); tt.className = 'fxe-t';
      const th = hasS ? h * 0.62 : h; tt.style.cssText = `top:${hasS ? h * 0.06 : 0}px;height:${th}px`;
      if (o.num && !hasS){ tt.style.top = h * 0.08 + 'px'; tt.style.height = h * 0.92 + 'px'; }
      drawText(tt, o.t, { fs, color: ink, accent: on ? E.mix(C.hiInk, '#ff2a00', 0.35) : C.hi });
      tx.appendChild(tt);
      if (hasS){ const s = document.createElement('div'); s.className = 'fxe-s'; s.style.cssText = `top:${h * 0.66}px;font-size:${ss}px;color:${sub};font-family:${E.FONT}`; s.textContent = E.plain(o.s); tx.appendChild(s); }
      return tx;
    };
    const t0 = mkTx(false), t1 = mkTx(true);
    el.append(t0, t1);
    // 卡片背景动效（规则 40）：只做标记，用户在右侧打开才画；画在底色上面、文字下面
    if (window.FXCardBg) try { FXCardBg.mark(el, { after: lit, index: o.index || 0, seed: o.seed || (o.index || 0) * 17 + 3, radius: r, w, h }); } catch (e) {}
    let last = -1;
    return {
      el, w, h,
      set(k){
        k = Math.round(clamp(k) * 200) / 200; if (k === last) return; last = k;
        lit.style.opacity = k; t1.style.opacity = k; t0.style.opacity = 1 - k;
      }
    };
  };
  // 胶囊标签（箭头上的说明、公式下的小注）
  E.pill = (txt, o) => {
    const el = document.createElement('div'); el.className = 'fxe-pill';
    el.style.cssText = `font-size:${o.fs || 30}px;background:${o.bg};color:${o.ink};font-family:${E.FONT}`;
    el.textContent = E.plain(txt); return el;
  };

  // ================= 【区域E5 箭头 / 曲线】 =================
  // 在 (x, y) 处、朝角度 a（弧度）的实心箭头，返回 SVG polygon 的 points
  E.head = (x, y, a, s = 22) => {
    const p = (r, da) => `${(x + r * Math.cos(a + da)).toFixed(1)},${(y + r * Math.sin(a + da)).toFixed(1)}`;
    return `${p(0, 0)} ${p(-s, 0.42)} ${p(-s * 0.72, 0)} ${p(-s, -0.42)}`;
  };
  // A → B 的二次曲线，bend = 往一侧弯多少（弦长的比例）；at(u) 取线上的点，ang(u) 取切线角度
  E.quad = (ax, ay, bx, by, bend = 0) => {
    const mx = (ax + bx) / 2, my = (ay + by) / 2, dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy) || 1;
    const cx = mx - (dy / L) * bend * L, cy = my + (dx / L) * bend * L;
    const at = u => [(1 - u) * (1 - u) * ax + 2 * (1 - u) * u * cx + u * u * bx, (1 - u) * (1 - u) * ay + 2 * (1 - u) * u * cy + u * u * by];
    const ang = u => Math.atan2(2 * (1 - u) * (cy - ay) + 2 * u * (by - cy), 2 * (1 - u) * (cx - ax) + 2 * u * (bx - cx));
    return { d: `M${ax.toFixed(1)} ${ay.toFixed(1)}Q${cx.toFixed(1)} ${cy.toFixed(1)} ${bx.toFixed(1)} ${by.toFixed(1)}`, at, ang, len: L };
  };
  // 舞台：1920×1080 居中缩放到窗口
  E.fit = stage => { const s = Math.min(innerWidth / 1920, innerHeight / 1080); stage.style.transform = `translate(-50%,-50%) scale(${s})`; };

  // ================= 【区域E6 编辑器】 =================
  const EDCSS = `
html body #params .stc .fxe-row{display:block!important;margin:0 0 6px!important;padding:7px 8px!important;border:1px solid #262626!important;border-radius:8px!important;background:#161616!important}
html body #params .stc .fxe-h{display:flex!important;align-items:center!important;gap:5px!important;margin:0!important}
html body #params .stc .fxe-n{flex:none!important;font-size:10.5px!important;color:#888!important;border:1px solid #333!important;border-radius:4px!important;padding:1px 5px!important;line-height:1.4!important;min-width:14px!important;text-align:center!important}
html body #params .stc .fxe-g{display:flex!important;flex-wrap:wrap!important;gap:5px!important;margin:5px 0 0!important}
html body #params .stc .fxe-f{display:flex!important;flex-direction:column!important;gap:2px!important;flex:1 1 80px!important;min-width:0!important;margin:0!important}
html body #params .stc .fxe-f.w2{flex-basis:100%!important}
html body #params .stc .fxe-f.sm{flex:0 0 64px!important}
html body #params .stc .fxe-f.sm2{flex:0 0 96px!important}
html body #params .stc .fxe-nw{display:flex!important;gap:3px!important;align-items:center!important;min-width:0!important}
html body #params .stc .fxe-nw input.fxe-i{flex:1!important}
html body #params .stc .fxe-f>span{font-size:10.5px!important;color:#777!important;white-space:nowrap!important}
html body #params .stc input.fxe-i,html body #params .stc select.fxe-i{width:100%!important;min-width:0!important;height:26px!important;box-sizing:border-box!important;margin:0!important;padding:3px 7px!important;font-size:12.5px!important;background:#0e0e0e!important;color:#ddd!important;border:1px solid #2c2c2c!important;border-radius:5px!important;font-family:inherit!important}
html body #params .stc input.fxe-i:focus,html body #params .stc select.fxe-i:focus{border-color:#f28c0f!important;outline:none!important}
html body #params .stc .fxe-h input.fxe-i{flex:1!important}
html body #params .stc button.fxe-b{flex:none!important;width:auto!important;height:24px!important;min-width:24px!important;margin:0!important;padding:0 6px!important;font-size:12px!important;border-radius:5px!important;cursor:pointer!important;font-family:inherit!important;border:1px solid #333!important;background:#1d1d1d!important;color:#aaa!important;line-height:1!important}
html body #params .stc button.fxe-b:hover{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc button.fxe-b:disabled{opacity:.35!important;cursor:default!important}
html body #params .stc button.fxe-add{display:block!important;width:100%!important;height:28px!important;margin:4px 0 0!important;border:1px dashed #444!important;background:transparent!important;color:#aaa!important;border-radius:6px!important;cursor:pointer!important;font-size:12px!important;font-family:inherit!important}
html body #params .stc button.fxe-add:hover{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc .fxe-note{font-size:11px!important;color:#777!important;line-height:1.6!important;margin:6px 0 0!important}
html body #params .stc .fxe-note b{color:#bbb!important;font-weight:600!important}
html body #params .stc .fxe-seg{display:flex!important;flex-wrap:wrap!important;gap:4px!important;margin:0 0 8px!important}
html body #params .stc .fxe-seg button{flex:1 1 auto!important;width:auto!important;height:26px!important;margin:0!important;padding:0 8px!important;font-size:12px!important;border-radius:5px!important;cursor:pointer!important;font-family:inherit!important;white-space:nowrap!important;border-width:1px!important;border-style:solid!important}
html body #params .stc .fxe-seg button:not(.on){background:#1d1d1d!important;color:#aaa!important;border-color:#333!important}
html body #params .stc .fxe-seg button.on{border-color:#f28c0f!important;color:#f28c0f!important;background:#24190b!important}
`;
  const injectEd = pd => { if (pd.getElementById('fxe-ed-style')) return; const s = pd.createElement('style'); s.id = 'fxe-ed-style'; s.textContent = EDCSS; pd.head.appendChild(s); };

  /* E.mount(o)：把编辑器装进工作台右侧面板
     o = { tag: 效果简称（class 名用）, P, hide: [要藏掉的原始参数名开头], anchor: 插在哪一行参数前面（参数名开头）,
           blocks: (ctx) => [元素, ...]   ctx = { pd, pw, mk, fieldOf, dirty, save(key, value) } }
     已经装过（面板没重建）就只调 o.refresh */
  E.mount = o => {
    let pd, pw;
    try { if (window.parent === window) return null; pw = window.parent; pd = pw.document; } catch (e) { return null; }
    const box = pd.getElementById('params'); if (!box) return null;
    // 已经装过：只刷新；正在里面打字时不刷新（否则光标会跳走）
    if (o.ed.mounted && box.contains(o.ed.mounted)){ if (!o.ed.mounted.contains(pd.activeElement)) o.ed.refresh && o.ed.refresh(); return o.ed.mounted; }
    box.querySelectorAll('.stc.fxe-' + o.tag).forEach(x => x.remove());
    const labelOf = el => (el.firstChild && el.firstChild.nodeType === 3 ? el.firstChild.textContent : el.textContent || '').trim();
    const kids = [...box.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);
    const row = name => kids.find(el => el.tagName === 'LABEL' && labelOf(el) === name) || kids.find(el => el.tagName === 'LABEL' && labelOf(el).startsWith(name));
    const anchor = row(o.anchor); if (!anchor) return null;
    // 按参数名整个对上才藏（写成「xx·」结尾的按开头对：自定义·卡片色、自定义·高亮色）；别按开头对，免得把「循环线上的字」也藏了
    const hit = (lb, h) => h.endsWith('·') ? lb.startsWith(h) : lb === h;
    (o.hide || []).forEach(h => kids.filter(el => el.tagName === 'LABEL' && hit(labelOf(el), h)).forEach(el => el.style.display = 'none'));
    const fieldOf = name => { const r = row(name); return r && r.querySelector('input,select,textarea'); };
    if (window.FXSkin) FXSkin.injectStyle(pd);
    injectEd(pd);
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const dirty = () => { try { pw.markDirty && pw.markDirty(); } catch (e) {} try { pw.histSoon && pw.histSoon(); } catch (e) {} };
    const ctx = { pd, pw, mk, fieldOf, dirty };
    // 改一个参数：写 P + 同步隐藏的原始输入框（导出 / 撤销读的都是 P），不派发 input（规则 6）
    ctx.save = (key, label, value) => { o.P[key] = value; const f = fieldOf(label); if (f) f.value = value; dirty(); };
    const wrap = mk('div', 'stc fxe-' + o.tag); wrap.dataset.fxContent = '1';
    (o.blocks(ctx) || []).forEach(b => b && wrap.appendChild(b));
    // 放在「持续时间」正下方的 .fxtop（规则 37）；老工作台没有就插在原来那一行前面
    const top = box.querySelector(':scope > .fxtop');
    if (top) top.appendChild(wrap); else anchor.parentNode.insertBefore(wrap, anchor);
    o.ed.mounted = wrap;
    return wrap;
  };

  /* 一块「选择」按钮条（排版、点亮方式这种 select 参数），点了直接写 P 并重画
     o = { ctx, P, key, label: 参数名, opts: [[值, 名字, 鼠标提示]], apply } */
  E.seg = o => {
    const { ctx, P } = o, el = ctx.mk('div', 'fxe-seg');
    const draw = () => {
      el.innerHTML = '';
      o.opts.forEach(([v, name, tip]) => {
        const b = ctx.mk('button', P[o.key] === v ? 'on' : '', E.esc(name)); b.type = 'button'; if (tip) b.title = tip;
        b.onclick = () => { ctx.save(o.key, o.label, v); draw(); o.apply(); };
        el.appendChild(b);
      });
    };
    draw(); el.refresh = draw; return el;
  };

  /* 一行一项的列表编辑器
     o = { ctx, P, key: 参数 key, label: 参数名（隐藏的那一行）, demo, title, sub, note, max, min,
           fields: [{ k, name, ph, type: 'text'|'num'|'sel', opts:[[值,名字]], cls: 'w2'|'sm', head: true（放在标题行） }],
           blank: () => 新的一项, apply: () => 重排重画, rowName: i => '01' }
     返回 { el, refresh } */
  E.listBlock = o => {
    const { ctx, P } = o, mk = ctx.mk;
    const el = mk('div', 'stc-b');
    el.innerHTML = `<div class="stc-t"><b>${o.title}</b><span>${o.sub || ''}</span></div>`;
    const box = mk('div'); el.appendChild(box);
    const add = mk('button', 'fxe-add', '＋ 加一项'); add.type = 'button'; el.appendChild(add);
    if (o.note) el.appendChild(mk('div', 'fxe-note', o.note));
    let L = [];
    const read = () => { L = E.list(P[o.key], o.demo).map(x => Object.assign({}, x)); };
    const save = () => { ctx.save(o.key, o.label, JSON.stringify(L)); o.apply(); };
    const input = (f, it) => {
      let inp;
      if (f.type === 'sel'){
        inp = mk('select', 'fxe-i');
        const opts = typeof f.opts === 'function' ? f.opts() : f.opts;   // 可以是函数：选项跟着别的内容变（如关系图的节点名）
        opts.forEach(([v, n]) => { const op = mk('option', '', E.esc(n)); op.value = v; inp.appendChild(op); });
        inp.value = it[f.k] == null || !opts.some(x => String(x[0]) === String(it[f.k])) ? opts[0][0] : String(it[f.k]);
        inp.onchange = () => { it[f.k] = inp.value; save(); };
      } else {
        inp = mk('input', 'fxe-i'); inp.type = f.type === 'num' ? 'number' : 'text';
        if (f.type === 'num'){ inp.step = f.step || '0.1'; inp.min = '0'; }
        inp.placeholder = f.ph || ''; inp.value = it[f.k] == null ? '' : it[f.k];
        let tt = 0;
        inp.oninput = () => { it[f.k] = inp.value; clearTimeout(tt); tt = setTimeout(save, 220); };
        inp.onchange = () => { clearTimeout(tt); it[f.k] = inp.value; save(); };
      }
      if (f.tip) inp.title = f.tip;
      // f.now（可选，2026-11-12）：输入框旁边多一个「◆」按钮，点一下 = 填进进度条现在这一秒（像打关键帧那样）
      if (f.now && f.type === 'num'){
        const wrap = mk('div', 'fxe-nw'); wrap.appendChild(inp);
        const b = mk('button', 'fxe-b', '◆'); b.type = 'button'; b.title = f.nowTip || '填进进度条现在这一秒';
        b.onclick = () => { const v = Math.round(Math.max(0, +f.now() || 0) * 100) / 100; it[f.k] = String(v); inp.value = it[f.k]; save(); };
        wrap.appendChild(b);
        return wrap;
      }
      return inp;
    };
    const draw = () => {
      box.innerHTML = '';
      L.forEach((it, i) => {
        const r = mk('div', 'fxe-row'), h = mk('div', 'fxe-h');
        h.appendChild(mk('span', 'fxe-n', o.rowName ? o.rowName(i) : String(i + 1)));
        o.fields.filter(f => f.head).forEach(f => h.appendChild(input(f, it)));
        const btn = (txt, tip, fn, off) => { const b = mk('button', 'fxe-b', txt); b.type = 'button'; b.title = tip; b.disabled = !!off; b.onclick = fn; h.appendChild(b); };
        btn('↑', '往前挪', () => { [L[i - 1], L[i]] = [L[i], L[i - 1]]; save(); draw(); }, i === 0);
        btn('↓', '往后挪', () => { [L[i + 1], L[i]] = [L[i], L[i + 1]]; save(); draw(); }, i === L.length - 1);
        btn('✕', '删掉这一项', () => { L.splice(i, 1); save(); draw(); }, L.length <= (o.min || 1));
        r.appendChild(h);
        const rest = o.fields.filter(f => !f.head);
        if (rest.length){
          const g = mk('div', 'fxe-g');
          rest.forEach(f => { const w = mk('label', 'fxe-f' + (f.cls ? ' ' + f.cls : '')); w.appendChild(mk('span', '', f.name)); w.appendChild(input(f, it)); g.appendChild(w); });
          r.appendChild(g);
        }
        box.appendChild(r);
      });
      add.disabled = L.length >= (o.max || 12);
      add.textContent = L.length >= (o.max || 12) ? `最多 ${o.max || 12} 项` : '＋ 加一项';
    };
    add.onclick = () => { if (L.length >= (o.max || 12)) return; L.push(o.blank(L.length)); save(); draw(); };
    const refresh = () => { read(); draw(); };
    refresh();
    return { el, refresh };
  };

  // 配色块：卡片色 × 高亮色（规则 24：只给色块，不让敲数值）
  // names（可选）= { a: 左边颜色的名字, b: 右边的名字, sub, own: 自带预设 [{c,name}], noLib: 不要配色库 }
  E.colorBlock = (ctx, P, apply, defs, names) => {
    if (!window.FXSkin) return null;
    const N = names || {};
    const lib = (!N.noLib && window.FXPalettes && Array.isArray(FXPalettes.pairs)) ? FXPalettes.pairs : [];
    const own = (N.own || [{ c: [defs[0], defs[1]], name: '默认（深卡 × 橙）' }]).concat(lib);
    let cb = null;
    const wrap = ctx.mk('div', 'stc-b');
    cb = FXSkin.colorBlock({
      pd: ctx.pd, pw: ctx.pw, P, field: ctx.fieldOf, bare: true, title: '配色', sub: N.sub || '左半 卡片色 · 右半 高亮色',
      keys: [{ key: 'cCard', name: N.a || '卡片色', tip: N.at || '常态时卡片的颜色', field: '自定义·卡片色', def: defs[0] },
             { key: 'cHi', name: N.b || '高亮色', tip: N.bt || '讲到这一项时卡片变成的颜色', field: '自定义·高亮色', def: defs[1] }],
      presets: own,
      apply: () => { ctx.dirty(); apply(); cb && cb.refresh(); }
    });
    wrap.appendChild(cb.el);
    wrap.refresh = () => cb.refresh();
    return wrap;
  };
})();
