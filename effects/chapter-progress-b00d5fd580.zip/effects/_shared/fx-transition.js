/* ===========================================================================
   fx-transition.js —— 文字转场（工作台公共模块，v11.0 新增）
   ---------------------------------------------------------------------------
   做什么：两段文字之间的过渡（A → B）。18 种转场 + 一个「点开就弹出 16 个动态预览、点哪个用哪个」的选择窗口。
   谁在用：文字转场（effects/text-transition）、焦点格卡片（effects/focus-slot-card）。以后任何文字类效果想要「换一句话时带个转场」都可以直接用。

   区域地图（想改哪里，直接说「区域Tx 怎么改」）
   【区域T1 清单】     18 种转场的 id、中文名、一句话说明（选择窗口里显示的就是这些）
   【区域T2 小工具】   缓动曲线、固定随机数（同一帧永远算出同一个画面，导出逐帧确定）
   【区域T3 文字解析】 **重点**（强调色加粗）、*加粗*、~划掉~、| 换行
   【区域T4 公共骨架】 两段文字叠在同一个格子里，居中；转场只改这两层的 transform / opacity
   【区域T5 18 种转场】一种一个函数，p = 0（还是 A）→ 1（已经是 B）
   【区域T6 粒子】     把字拆成小方块飞散再聚合成新字（canvas 画，按字的真实位置取样）
   【区域T7 绘制入口】 FXTrans.draw(el, o)
   【区域T8 选择窗口】 FXTrans.pick(o)：弹在工作台页面上，15 个格子各自循环播放预览
   【区域T9 分段时间轴】FXTrans.readSegs / timeline / drawAt：一段段文字 + 中间的转场排成时间轴（v11.1 抽出）
   【区域T10 编辑面板】FXTrans.editor(o)：每段一个输入框 + 中间橙色转场按钮（v11.1 抽出，卡片里的文字也用它）
   【区域T12 嵌入 / 压印】（v33.5）字沉进背景变成压印的淡字：转场「嵌入」embed，停留时 draw 的 emboss: 0~1
   【区域T11 渐隐文字】（v30.5）一头实、一头透明的文字（像「股权」那种上实下透）：
                      转场 id 写成 'fadegrad:方向:入场'，方向 b/t/l/r = 哪一头透明，入场 up/down/fade = 从下往上长 / 从上往下长 / 淡入。
                      用这个转场进来的那段字，停留时也保持渐隐；下一个转场时渐隐再慢慢退掉（FXTrans.timeline 自动带上 grad）。
                      别的效果单独要一段渐隐的字：FXTrans.draw(el, { id: 'static', b: '文字', grad: { dir: 'b' }, ... })

   其他效果怎么接（三步）：
   ① 页面里引入：<script src="../_shared/fx-transition.js"></script>（放在效果脚本之前）
   ② 画面：FXTrans.draw(容器, { id, a: '旧文字', b: '新文字', p: 0~1, fs: 字号, color, accent, bold: true/false })
      容器要有固定宽高（position:absolute/relative），文字在里面自动居中。
      停留不动的时候：FXTrans.draw(容器, { id: 'static', b: '文字', ... })
   ③ 选转场：FXTrans.pick({ pd: parent.document, a, b, current: 'fade', onPick: id => {...} })
      可选：allowNone: true（多一个「无」，开场 / 结尾用）、allowAll: true（底部「这一种用到全部转场」勾选）
   =========================================================================== */
(function () {
  const FX = window.FXTrans = window.FXTrans || {};

  // ================= 【区域T1 清单】 =================
  FX.LIST = [
    { id: 'fade',     name: '淡入淡出', tip: '旧字慢慢变淡，新字慢慢浮现' },
    { id: 'blur',     name: '模糊溶解', tip: '旧字糊掉散开，新字从模糊里变清楚' },
    { id: 'push',     name: '上推',     tip: '旧字往上推走，新字从下面顶上来' },
    { id: 'slide',    name: '左滑',     tip: '旧字往左滑出，新字从右边滑进' },
    { id: 'zoom',     name: '缩放冲出', tip: '旧字放大冲向镜头散开，新字缩着弹出来' },
    { id: 'drop',     name: '逐字掉落', tip: '旧字一个个掉下去，新字一个个弹进来' },
    { id: 'type',     name: '打字机',   tip: '光标把旧字一个个删掉，再一个个打出新字' },
    { id: 'scramble', name: '乱码解码', tip: '字乱跳一阵，再从左到右定格成新字' },
    { id: 'flap',     name: '翻牌',     tip: '像机场翻页牌，每个字依次翻过去' },
    { id: 'cube',     name: '3D 翻转',  tip: '整行像方块一样往上滚一面' },
    { id: 'particle', name: '粒子聚散', tip: '字碎成小颗粒飞散，再聚成新字' },
    { id: 'sweep',    name: '扫光擦除', tip: '一道光扫过去，扫过的地方换成新字' },
    { id: 'mask',     name: '遮罩切换', tip: '一条色块扫过盖住旧字，退开时已经换成新字' },
    { id: 'squash',   name: '拉伸挤压', tip: '旧字压扁消失，新字弹性拉伸着冒出来' },
    { id: 'glitch',   name: '故障闪烁', tip: '画面抽风、错位、红蓝分离，一闪换字' },
    { id: 'roll',     name: '数字翻滚', tip: '每一位数字像计数器一样在 0~9 之间滚动，按数值大小从旧数滚到新数（v13.1）' },
    { id: 'fadegrad', name: '渐隐生长', tip: '一头实、一头透明的字（默认上实下透），从下往上长出来；可以改哪一头透明、怎么长（v30.5）', opts: true },
    { id: 'embed',    name: '嵌入',     tip: '旧字沉进背景、变成压印的淡字后隐去，新字从背景里浮出来（v33.5）' }
  ];
  FX.NONE = { id: 'none', name: '无', tip: '不要转场，直接出现 / 直接消失' };
  // 带选项的转场：id 写成 'fadegrad:b:up'，冒号前面是哪一种
  const baseId = id => String(id == null ? '' : id).split(':')[0];
  FX.base = baseId;
  // 【区域T11】渐隐生长的选项：dir = 哪一头透明（b 下 / t 上 / l 左 / r 右），grow = 入场（up 从下往上 / down 从上往下 / fade 淡入）
  const GDIR = { b: '下透明', t: '上透明', l: '左透明', r: '右透明' }, GROW = { up: '从下往上长', down: '从上往下长', fade: '淡入' };
  FX.gradOpt = id => { const q = String(id || '').split(':'); return { dir: GDIR[q[1]] ? q[1] : 'b', grow: GROW[q[2]] ? q[2] : 'up' }; };
  FX.gradId = o => 'fadegrad:' + o.dir + ':' + o.grow;
  FX.name = id => {
    const b = baseId(id);
    if (b === 'fadegrad') { const g = FX.gradOpt(id); return '渐隐生长 · ' + GDIR[g.dir] + ' · ' + GROW[g.grow]; }
    return (FX.LIST.find(x => x.id === b) || (id === 'none' ? FX.NONE : null) || { name: '淡入淡出' }).name;
  };
  FX.has = id => FX.LIST.some(x => x.id === baseId(id));

  // ================= 【区域T2 小工具】 =================
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const prog = (p, a, b) => clamp((p - a) / (b - a), 0, 1);
  const oc = x => 1 - Math.pow(1 - x, 3);                                   // 先快后慢
  const ic = x => x * x * x;                                                 // 先慢后快
  const ioc = x => x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; // 两头慢
  const back = (x, s) => { s = s == null ? 1.7 : s; const c = s + 1; return 1 + c * Math.pow(x - 1, 3) + s * Math.pow(x - 1, 2); }; // 冲过头再回来
  const elastic = x => x <= 0 ? 0 : x >= 1 ? 1 : 1 - Math.exp(-6 * x) * Math.cos(11 * x);      // 弹簧
  const bounce = x => {                                                      // 落地弹两下
    const n = 7.5625, d = 2.75;
    if (x < 1 / d) return n * x * x;
    if (x < 2 / d) return n * (x -= 1.5 / d) * x + 0.75;
    if (x < 2.5 / d) return n * (x -= 2.25 / d) * x + 0.9375;
    return n * (x -= 2.625 / d) * x + 0.984375;
  };
  const hash = (a, b) => { const h = Math.sin(a * 127.1 + b * 311.7 + 74.7) * 43758.5453; return h - Math.floor(h); }; // 固定随机数
  const f2 = x => (+x).toFixed(2), f3 = x => (+x).toFixed(3);
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  FX.ease = { prog, oc, ic, ioc, back, elastic, bounce, hash };

  // ================= 【区域T3 文字解析】 =================
  // m：0 普通 / 1 划掉 / 2 重点（强调色 + 加粗）/ 3 只加粗
  const PCACHE = new Map();
  FX.parse = str => {
    str = String(str == null ? '' : str);
    if (PCACHE.has(str)) return PCACHE.get(str);
    const s = str.replace(/\*\*([\s\S]+?)\*\*/g, '\u0001$1\u0001');
    const lines = s.split(/\||\n/).map(l => l.trim()).filter(l => l.replace(/[\u0001*~]/g, '').trim()).map(l =>
      l.split(/(\u0001[^\u0001]+\u0001|\*[^*]+\*|~~[^~]+~~|~[^~]+~)/).filter(Boolean).flatMap(seg => {
        let m = 0, body = seg;
        if (seg[0] === '\u0001' && seg.length > 2) { m = 2; body = seg.slice(1, -1); }
        else if (seg[0] === '*' && seg.length > 2 && seg.endsWith('*')) { m = 3; body = seg.slice(1, -1); }
        else if (seg.startsWith('~~') && seg.length > 4 && seg.endsWith('~~')) { m = 1; body = seg.slice(2, -2); }
        else if (seg[0] === '~' && seg.length > 2 && seg.endsWith('~')) { m = 1; body = seg.slice(1, -1); }
        return Array.from(body.replace(/\u0001/g, '')).map(c => ({ c, m }));
      }));
    const T = { lines, n: lines.reduce((n, l) => n + l.length, 0), src: str };
    if (PCACHE.size > 400) PCACHE.clear();
    PCACHE.set(str, T);
    return T;
  };
  // 估算一行有多宽（单位 = 字号），预览窗口用来自动选字号
  FX.emWidth = str => {
    const T = FX.parse(str);
    return Math.max(0, ...T.lines.map(l => l.reduce((w, ch) => {
      const k = ch.c.codePointAt(0) || 0;
      return w + (k >= 0x2e80 ? 1 : ch.c === ' ' ? 0.3 : /[A-Z0-9]/.test(ch.c) ? 0.68 : /[a-z]/.test(ch.c) ? 0.56 : 0.45);
    }, 0)));
  };

  // ================= 【区域T4 公共骨架】 =================
  // 一个字 = 一个 inline-block 的 <span>，逐字转场直接给它写 transform / opacity。
  function chSpan(ch, o, st, rep, i) {
    let s = 'display:inline-block;white-space:pre;';
    if (ch.m === 2) s += `color:${o.accent};font-weight:${o.wStrong};`;
    else if (ch.m === 3) s += `font-weight:${o.wStrong};`;
    if (ch.m === 1) s += `text-decoration:line-through;text-decoration-color:${o.accent};text-decoration-thickness:${f2(Math.max(2, o.fs * 0.07))}px;`;
    return `<span data-i="${i}" style="${s}${st || ''}">${esc(rep != null ? rep : ch.c)}</span>`;
  }
  // 一层文字。fn(ch, 第几个字, 总字数) 返回 { st: 额外样式, rep: 换成别的字 }，或者返回字符串（= st）
  function layer(T, o, layerStyle, fn, extra) {
    let i = 0;
    const html = T.lines.map(line => '<div style="white-space:nowrap">' + line.map(ch => {
      const k = i++;
      let r = fn ? fn(ch, k, T.n) : null;
      if (typeof r === 'string') r = { st: r };
      return chSpan(ch, o, r && r.st, r && r.rep, k) + (r && r.after ? r.after : '');
    }).join('') + '</div>').join('');
    return `<div class="fxt-l" style="grid-area:1/1;position:relative;text-align:center;${layerStyle || ''}">${html}${extra || ''}</div>`;
  }
  // 打字机光标（宽度为 0，不挤开文字）
  const caret = (o, on) => `<span style="display:inline-block;position:relative;width:0;height:1em;vertical-align:baseline"><i style="position:absolute;left:${f2(o.fs * 0.04)}px;top:${f2(-o.fs * 0.02)}px;height:${f2(o.fs * 1.05)}px;width:${f2(Math.max(2, o.fs * 0.06))}px;border-radius:${f2(o.fs * 0.03)}px;background:${o.accent};opacity:${on ? 1 : 0}"></i></span>`;

  // ================= 【区域T5 18 种转场】 =================
  // 每个函数收到 c = { A, B, p, o }，返回两层（或更多层）的 HTML。p = 0 时必须和 A 一模一样，p = 1 时和 B 一模一样。
  const TR = {
    // 【区域T11】渐隐生长：B 按选好的方向「长」出来（一层遮罩从一头扫到另一头，边缘是软的）；A 反着收回去。
    // 字本身的渐隐（一头实一头透）由外层统一加（见 wrapHtml 的 grad），这里只管长出来 / 收回去。
    fadegrad: c => {
      const g = FX.gradOpt(c.id), a = prog(c.p, 0, 0.45), b = ioc(prog(c.p, c.A.n ? 0.3 : 0, 1));
      const wipe = (k, dir) => {                                            // k = 0 全藏 → 1 全露；dir = 从哪边往哪边长
        const e = (k * 1.35 - 0.2) * 100, s = e + 22;                       // 软边 22%
        return `-webkit-mask-image:linear-gradient(${dir},#000 ${f2(e)}%,transparent ${f2(s)}%);mask-image:linear-gradient(${dir},#000 ${f2(e)}%,transparent ${f2(s)}%)`;
      };
      const st = (k, inn) => g.grow === 'fade' ? `opacity:${f3(k)}` : k >= 1 ? '' : wipe(k, inn ? (g.grow === 'down' ? 'to bottom' : 'to top') : (g.grow === 'down' ? 'to top' : 'to bottom'));
      return layer(c.A, c.o, st(1 - a, false)) + layer(c.B, c.o, st(b, true));
    },

    fade: c => layer(c.A, c.o, `opacity:${f3(1 - ioc(c.p))}`) + layer(c.B, c.o, `opacity:${f3(ioc(c.p))}`),

    blur: c => {
      const a = prog(c.p, 0, 0.65), b = prog(c.p, 0.35, 1), fs = c.o.fs;
      return layer(c.A, c.o, `opacity:${f3(1 - ioc(a))};filter:blur(${f2(ic(a) * fs * 0.22)}px);transform:scale(${f3(1 + 0.06 * oc(a))})`)
        + layer(c.B, c.o, `opacity:${f3(ioc(b))};filter:blur(${f2((1 - oc(b)) * fs * 0.22)}px);transform:scale(${f3(1.06 - 0.06 * oc(b))})`);
    },

    push: c => {
      const fs = c.o.fs, d = fs * 1.15, a = ic(prog(c.p, 0, 0.6)), b = prog(c.p, 0.25, 1);
      return layer(c.A, c.o, `opacity:${f3(1 - a)};transform:translateY(${f2(-a * d)}px)`)
        + layer(c.B, c.o, `opacity:${f3(oc(prog(b, 0, 0.5)))};transform:translateY(${f2((1 - back(b, 1.2)) * d)}px)`);
    },

    slide: c => {
      const fs = c.o.fs, d = fs * 3, a = ic(prog(c.p, 0, 0.6)), b = oc(prog(c.p, 0.3, 1));
      return layer(c.A, c.o, `opacity:${f3(1 - a)};transform:translateX(${f2(-a * d)}px);filter:blur(${f2(a * fs * 0.05)}px)`)
        + layer(c.B, c.o, `opacity:${f3(b)};transform:translateX(${f2((1 - b) * d)}px);filter:blur(${f2((1 - b) * fs * 0.05)}px)`);
    },

    zoom: c => {
      const fs = c.o.fs, a = prog(c.p, 0, 0.55), b = prog(c.p, 0.35, 1);
      return layer(c.A, c.o, `opacity:${f3(1 - oc(a))};transform:scale(${f3(1 + 1.8 * ic(a))});filter:blur(${f2(ic(a) * fs * 0.12)}px)`)
        + layer(c.B, c.o, `opacity:${f3(oc(prog(b, 0, 0.4)))};transform:scale(${f3(0.55 + 0.45 * back(b, 1.6))})`);
    },

    drop: c => {
      const fs = c.o.fs;
      return layer(c.A, c.o, '', (ch, i, n) => {
        const d = n > 1 ? i / (n - 1) * 0.3 : 0, k = ic(prog(c.p, d, d + 0.3));
        return `opacity:${f3(1 - k * k)};transform:translateY(${f2(k * fs * 1.6)}px) rotate(${f2((hash(i, 1) - 0.5) * 70 * k)}deg)`;
      }) + layer(c.B, c.o, '', (ch, i, n) => {
        const d = 0.38 + (n > 1 ? i / (n - 1) * 0.3 : 0), k = prog(c.p, d, Math.min(1, d + 0.32));
        return `opacity:${f3(prog(k, 0, 0.25))};transform:translateY(${f2(-(1 - bounce(k)) * fs * 1.4)}px)`;
      });
    },

    type: c => {
      const p = c.p, o = c.o, nA = c.A.n, nB = c.B.n;
      // 光标闪：动作当中一直亮，前后停顿时闪
      const typing = (p > 0.02 && p < 0.42) || (p > 0.55 && p < 0.98);
      const on = typing || Math.floor(p * 9) % 2 === 0;
      if (p < 0.5 && nA) {
        const v = Math.round(nA * (1 - prog(p, 0.02, 0.42)));
        return layer(c.A, o, '', (ch, i) => ({ st: i < v ? '' : 'visibility:hidden', after: i === v - 1 ? caret(o, on) : '' }))
          .replace(v === 0 ? '<span data-i="0"' : '\u0000', caret(o, on) + '<span data-i="0"') + layer(c.B, o, 'visibility:hidden');
      }
      if (!nB) return layer(c.A, o, 'visibility:hidden');
      const v = Math.round(nB * prog(p, 0.55, 0.98));
      const html = layer(c.B, o, '', (ch, i) => ({ st: i < v ? '' : 'visibility:hidden', after: i === v - 1 && p < 1 ? caret(o, on) : '' }));
      return layer(c.A, o, 'visibility:hidden') + (v === 0 ? html.replace('<span data-i="0"', caret(o, on) + '<span data-i="0"') : html);
    },

    scramble: c => {
      const p = c.p, q = Math.floor(p * 40);
      const g = (ch, i, salt) => {
        const cjk = (ch.c.codePointAt(0) || 0) >= 0x2e80, set = cjk ? GLYPH_CJK : GLYPH_LAT;
        return ch.c === ' ' ? ' ' : set[Math.floor(hash(i * 7 + salt, q) * set.length)];
      };
      return layer(c.A, c.o, '', (ch, i, n) => {
        const s = 0.04 + (n > 1 ? i / (n - 1) : 0) * 0.28;
        if (p < s) return null;
        if (p < s + 0.16) return { st: 'opacity:.75', rep: g(ch, i, 1) };
        return { st: 'visibility:hidden' };
      }) + layer(c.B, c.o, '', (ch, i, n) => {
        const r = 0.5 + (n > 1 ? i / (n - 1) : 0) * 0.46;
        if (p < 0.34) return { st: 'visibility:hidden' };
        if (p < r) return { st: 'opacity:.75', rep: g(ch, i, 2) };
        return null;
      });
    },

    flap: c => {
      const fs = c.o.fs, ps = fs * 5;
      return layer(c.A, c.o, '', (ch, i, n) => {
        const d = n > 1 ? i / (n - 1) * 0.3 : 0, k = ic(prog(c.p, d, d + 0.22));
        return `opacity:${f3(k >= 1 ? 0 : 1 - 0.5 * k)};transform:perspective(${f2(ps)}px) rotateX(${f2(-90 * k)}deg)`;
      }) + layer(c.B, c.o, '', (ch, i, n) => {
        const d = 0.4 + (n > 1 ? i / (n - 1) * 0.3 : 0), k = prog(c.p, d, Math.min(1, d + 0.3));
        return `opacity:${f3(k <= 0 ? 0 : 0.5 + 0.5 * k)};transform:perspective(${f2(ps)}px) rotateX(${f2(90 * (1 - back(k, 2.2)))}deg)`;
      });
    },

    cube: c => {
      const fs = c.o.fs, lines = Math.max(1, c.A.lines.length, c.B.lines.length), h = fs * (c.o.lh || 1.3) * lines / 2, e = ioc(c.p), ps = fs * 9;
      return layer(c.A, c.o, `opacity:${f3(1 - 0.75 * e)};transform:perspective(${f2(ps)}px) translateZ(${f2(-h)}px) rotateX(${f2(90 * e)}deg) translateZ(${f2(h)}px);backface-visibility:hidden`)
        + layer(c.B, c.o, `opacity:${f3(0.25 + 0.75 * e)};transform:perspective(${f2(ps)}px) translateZ(${f2(-h)}px) rotateX(${f2(-90 * (1 - e))}deg) translateZ(${f2(h)}px);backface-visibility:hidden`);
    },

    sweep: c => {
      const fs = c.o.fs, X = (-25 + 150 * ioc(c.p)), S = 14, show = Math.sin(Math.PI * clamp(c.p, 0, 1));
      const band = `<div style="position:absolute;top:-25%;height:150%;left:${f2(X)}%;width:${f2(fs * 0.9)}px;transform:translateX(-50%) skewX(-14deg);`
        + `background:linear-gradient(90deg,transparent,color-mix(in srgb,${c.o.accent} 55%,transparent) 30%,rgba(255,255,255,.95) 50%,color-mix(in srgb,${c.o.accent} 55%,transparent) 70%,transparent);`
        + `filter:blur(${f2(fs * 0.04)}px);opacity:${f3(show)};pointer-events:none"></div>`;
      return layer(c.A, c.o, `clip-path:polygon(${f2(X + S / 2)}% -50%,200% -50%,200% 150%,${f2(X - S / 2)}% 150%)`)
        + layer(c.B, c.o, `clip-path:polygon(-100% -50%,${f2(X + S / 2)}% -50%,${f2(X - S / 2)}% 150%,-100% 150%)`) + band;
    },

    mask: c => {
      const a = ioc(prog(c.p, 0, 0.48)), b = ioc(prog(c.p, 0.52, 1)), first = c.p < 0.5;
      const blk = `<div style="position:absolute;left:-5%;right:-5%;top:-6%;bottom:-6%;border-radius:${f2(c.o.fs * 0.06)}px;background:${c.o.accent};`
        + `transform-origin:${first ? '0' : '100%'} 50%;transform:scaleX(${f3(first ? a : 1 - b)});pointer-events:none"></div>`;
      return layer(c.A, c.o, `opacity:${first ? 1 : 0}`) + layer(c.B, c.o, `opacity:${first ? 0 : 1}`) + blk;
    },

    squash: c => {
      const a = prog(c.p, 0, 0.42), b = prog(c.p, 0.38, 1), ka = ic(a), sy = elastic(b), sx = 1 + (1 - sy) * 0.55;
      return layer(c.A, c.o, `opacity:${f3(1 - Math.pow(a, 4))};transform:scale(${f3(1 + 0.6 * ka)},${f3(Math.max(0.001, 1 - ka))})`)
        + layer(c.B, c.o, `opacity:${f3(prog(b, 0, 0.12))};transform:scale(${f3(b <= 0 ? 1.55 : sx)},${f3(Math.max(0.001, sy))})`);
    },

    glitch: c => {
      const p = c.p, fs = c.o.fs, env = Math.pow(Math.sin(Math.PI * clamp(p, 0, 1)), 0.7), q = Math.floor(p * 28);
      const r = k => hash(q, k);
      let showB = p >= 0.5;
      if (env > 0.35 && r(1) < 0.3) showB = !showB;              // 中间来回闪几下
      const sh = fs * 0.07 * env * (0.4 + r(3)), dx = (r(2) - 0.5) * fs * 0.3 * env;
      const ts = env > 0.01 ? `text-shadow:${f2(-sh)}px 0 rgba(255,40,90,.85),${f2(sh)}px 0 rgba(0,225,255,.85);` : '';
      const fl = env > 0.2 && r(5) < 0.12 ? 0.35 : 1;
      const T = showB ? c.B : c.A;
      let html = layer(T, c.o, `${ts}opacity:${fl};transform:translateX(${f2(dx)}px)`) + layer(showB ? c.A : c.B, c.o, 'visibility:hidden');
      for (let k = 0; k < 3; k++) {                              // 横着错位的几条切片
        if (r(10 + k) > env * 0.9) continue;
        const top = r(20 + k) * 85, h = 4 + r(30 + k) * 18, sx = (r(40 + k) - 0.5) * fs * 0.8 * env;
        html += layer(T, c.o, `${ts}clip-path:inset(${f2(top)}% -20% ${f2(Math.max(0, 100 - top - h))}% -20%);transform:translateX(${f2(sx)}px)`);
      }
      return html;
    },

    // 【区域T12】嵌入：A 慢慢沉进背景（变淡、压印）后隐去；B 从压印的状态浮出来变清楚。p = 0 和 A 一样，p = 1 和 B 一样。
    embed: c => {
      const a = ioc(prog(c.p, 0, 0.6)), ao = 1 - prog(c.p, 0.4, 0.75);
      const b = 1 - ioc(prog(c.p, 0.35, 1)), bo = c.p <= 0.35 ? 0 : ioc(prog(c.p, 0.35, 0.7));
      return layer(c.A, c.o, embossCss(a, c.o, ao)) + layer(c.B, c.o, c.p >= 1 ? '' : embossCss(b, c.o, bo));
    },

    // 数字翻滚（v13.1）：把 B 里的那个数拆成一位一位，每一位是一条 0~9 的竖条，像计数器一样滚到目标数。
    // 滚多少由数值大小决定：从 A 的数（A 不是数，比如「?」，就从 0）按「先快后慢」数到 B 的数，
    // 最右边一位连续滚，左边各位只在低一位从 9 进到 0 时进一格（真的计数器那样）；还没数到的高位先藏着。
    // B 里不是数字的字（小数点、%、单位、汉字）原地淡入；B 里没有数字就退回淡入淡出。
    // 每一位用「看不见的目标数字」撑出宽度，滚动的竖条叠在上面，所以 p = 1 时和 B 一模一样，接停留时不会跳。
    roll: c => {
      const o = c.o, lh = o.lh || 1.3, p = clamp(c.p, 0, 1);
      const chars = c.B.lines.flat();
      // 找 B 里第一段数：可带负号，数字之间可以有小数点、千分位逗号
      let a0 = -1, a1 = -1;
      for (let i = 0; i < chars.length; i++) {
        if (/[0-9]/.test(chars[i].c)) { a0 = i; break; }
      }
      if (a0 < 0) return TR.fade(c);
      a1 = a0;
      while (a1 + 1 < chars.length && /[0-9.,]/.test(chars[a1 + 1].c)) a1++;
      while (a1 > a0 && !/[0-9]/.test(chars[a1].c)) a1--;
      const run = chars.slice(a0, a1 + 1).map(x => x.c).join('');
      const neg = a0 > 0 && chars[a0 - 1].c === '-';
      const vB = (neg ? -1 : 1) * parseFloat(run.replace(/,/g, ''));
      const numA = (() => { const t = c.A.lines.flat().map(x => x.c).join('').replace(/,/g, ''); const m = t.match(/-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : null; })();
      const vA = numA == null ? 0 : numA;
      const e = 1 - Math.pow(1 - p, 3);                       // 先快后慢
      const v = Math.abs(vA + (vB - vA) * e);
      // 每一位数字的位数（个位 = 0，十位 = 1，小数第一位 = -1……）
      const dot = run.indexOf('.');
      const intEnd = dot < 0 ? run.length : dot;
      const expOf = {};
      let k = 0;
      for (let j = intEnd - 1; j >= 0; j--) if (/[0-9]/.test(run[j])) expOf[a0 + j] = k++;
      k = -1;
      if (dot >= 0) for (let j = dot + 1; j < run.length; j++) if (/[0-9]/.test(run[j])) expOf[a0 + j] = k--;
      const emin = Math.min(...Object.values(expOf));
      const cells = Array.from({ length: 11 }, (_, d) => `<span style="display:block;height:${lh}em;line-height:${lh}">${d % 10}</span>`).join('');
      const vis = A => `opacity:${f3(A)};`;
      const fadeIn = ioc(prog(p, 0, numA == null ? 0.3 : 0.12));
      let i = 0;
      const html = c.B.lines.map(line => '<div style="white-space:nowrap">' + line.map(ch => {
        const idx = i++, ex = expOf[idx];
        if (ex == null) return chSpan(ch, o, vis(fadeIn), null, idx);           // 不是数字：原地淡入
        const x = v / Math.pow(10, ex) + 1e-9;
        let pos;
        if (ex === emin) pos = x - 10 * Math.floor(x / 10);                      // 最右边一位：连续滚
        else { const fl = Math.floor(x), fr = x - fl; pos = (fl % 10) + clamp(fr * 10 - 9, 0, 1); }   // 低一位进位时才动
        const show = ex > 0 ? clamp((x - 0.9) * 10, 0, 1) : 1;                   // 还没数到的高位先藏着
        let st = `display:inline-block;position:relative;white-space:pre;${vis(show * Math.min(1, fadeIn + 0.6))}`;
        if (ch.m === 2) st += `color:${o.accent};font-weight:${o.wStrong};`;
        else if (ch.m === 3) st += `font-weight:${o.wStrong};`;
        return `<span data-i="${idx}" style="${st}"><span style="visibility:hidden">${esc(ch.c)}</span>`
          + `<span style="position:absolute;left:-50%;right:-50%;top:0;height:${lh}em;text-align:center;clip-path:inset(0 0 0 0);overflow:hidden">`
          + `<span style="display:block;transform:translateY(${f3(-pos * lh)}em)">${cells}</span></span></span>`;
      }).join('') + '</div>').join('');
      const layB = `<div class="fxt-l" style="grid-area:1/1;position:relative;text-align:center">${html}</div>`;
      const outA = 1 - ioc(prog(p, 0, numA == null ? 0.25 : 0.1));
      return layer(c.A, o, vis(outA)) + layB;
    }
  };
  const GLYPH_LAT = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789#$%&@*+=?<>/';
  const GLYPH_CJK = '的一是不了人在有这中大来上个到说们为和你地出道也时年得就那要下以生会自着去之过家学对可里后小心多天能好都然没日于起还发成事只作当想看文无开手用主行方又如前所本见经头面公同已老从动两长知样现分将外但身些与高意进把法此实回理美点月明其种声全己话者向情部正名定问力机给等几很业最间新什打便位因重被走电第门相次东海口使教西再平真听世气信北少关并内加化由却代产入先山太水万市眼体别处总才场师书比住员笑性通目华报立马命张活难神数件安表原车白应路期叫死常提感金何更反合放做系计或司利受光王果亲界及今京务制解各任至清物台象记边共风战干接它许特觉望直服毛林题建南度统色字请交爱让认算论百吃义科怎元社术结功指思非流每青管夫连远资队跟带花快条院变联言权往展该';

  // ================= 【区域T6 粒子】 =================
  // 按两层文字里每个字的真实位置，在离屏 canvas 上把字画出来、隔几个像素取一个点。
  // 结果按「文字 + 字号 + 容器大小」缓存，只有第一次（或改了文字）才取样。
  const PTS = new Map();
  function sample(doc, wrap, o) {
    const key = [o.a, o.b, o.fs, o.weight, o.wStrong, o.font, o.lh, wrap.clientWidth, wrap.clientHeight, o.color || '', o.accent].join('\u0002');
    if (PTS.has(key)) return PTS.get(key);
    if (!wrap.clientWidth || !wrap.clientHeight) return { A: [], B: [], step: 2, W: 1, H: 1 };   // 还没排版（不在页面上）：不缓存，下一帧再取
    const W = Math.max(1, wrap.clientWidth), H = Math.max(1, wrap.clientHeight);
    const base = o.color || getComputedStyle(wrap.querySelector('.fxt-g')).color || '#fff';
    const step = Math.max(2, Math.round(o.fs / 24));
    const cv = doc.createElement('canvas'); cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    const grab = (sel, T) => {
      const out = [], lay = wrap.querySelector(sel); if (!lay) return out;
      lay.querySelectorAll('span[data-i]').forEach(sp => {
        const ch = T.chars[+sp.dataset.i]; if (!ch || !ch.c.trim()) return;
        // 位置：span → 这一层 → 格子 → 外框（都是没缩放过的排版坐标）
        let x = sp.offsetLeft, y = sp.offsetTop, el = sp.offsetParent;
        while (el && el !== wrap) { x += el.offsetLeft; y += el.offsetTop; el = el.offsetParent; }
        const w = sp.offsetWidth, h = sp.offsetHeight; if (!w || !h) return;
        const strong = ch.m === 2 || ch.m === 3;
        ctx.font = `${strong ? o.wStrong : o.weight} ${o.fs}px ${o.font}`;
        ctx.textBaseline = 'middle'; ctx.textAlign = 'center'; ctx.fillStyle = '#000';
        const x0 = Math.max(0, Math.floor(x - 4)), y0 = Math.max(0, Math.floor(y - 4)), x1 = Math.min(W, Math.ceil(x + w + 4)), y1 = Math.min(H, Math.ceil(y + h + 4));
        if (x1 <= x0 || y1 <= y0) return;
        ctx.clearRect(x0, y0, x1 - x0, y1 - y0);
        ctx.fillText(ch.c, x + w / 2, y + h / 2);
        const d = ctx.getImageData(x0, y0, x1 - x0, y1 - y0).data, rw = x1 - x0;
        const col = ch.m === 2 ? o.accent : base;
        for (let yy = 0; yy < y1 - y0; yy += step) for (let xx = 0; xx < rw; xx += step) {
          if (d[(yy * rw + xx) * 4 + 3] > 110) out.push({ x: x0 + xx, y: y0 + yy, col });
        }
        ctx.clearRect(x0, y0, x1 - x0, y1 - y0);
      });
      // 点太多就均匀抽掉一些（保证每帧画得动）
      const MAX = 2600;
      if (out.length > MAX) { const k = out.length / MAX; return Array.from({ length: MAX }, (_, i) => out[Math.floor(i * k)]); }
      return out;
    };
    const A = FX.parse(o.a), B = FX.parse(o.b);
    A.chars = A.chars || A.lines.flat(); B.chars = B.chars || B.lines.flat();
    const r = { A: grab('.fxt-a', A), B: grab('.fxt-b', B), step, W, H };
    if (PTS.size > 60) PTS.clear();
    PTS.set(key, r);
    return r;
  }
  function particle(el, o, A, B) {
    const doc = el.ownerDocument, p = o.p;
    let st = el.__fxt;
    const key = [o.a, o.b, o.fs, o.weight, o.font, o.color || '', o.accent].join('\u0002');
    if (!st || st.mode !== 'particle' || st.key !== key || !el.contains(st.cv)) {
      el.innerHTML = wrapHtml(o, layer(A, o, '', null).replace('class="fxt-l"', 'class="fxt-l fxt-a"') + layer(B, o, '', null).replace('class="fxt-l"', 'class="fxt-l fxt-b"'));
      const wrap = el.firstChild;
      const cv = doc.createElement('canvas');
      cv.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none';
      wrap.appendChild(cv);
      st = el.__fxt = { mode: 'particle', key, cv, wrap, la: wrap.querySelector('.fxt-a'), lb: wrap.querySelector('.fxt-b') };
    }
    const S = sample(doc, st.wrap, o);
    if (st.cv.width !== S.W || st.cv.height !== S.H) { st.cv.width = S.W; st.cv.height = S.H; }
    // 两头是真的文字（和停留时一模一样），中间才换成粒子
    st.la.style.opacity = f3(1 - prog(p, 0, 0.07));
    st.lb.style.opacity = f3(prog(p, 0.93, 1));
    const ctx = st.cv.getContext('2d');
    ctx.clearRect(0, 0, S.W, S.H);
    const fade = prog(p, 0, 0.05) * (1 - prog(p, 0.95, 1));
    if (fade <= 0) return;
    const PA = S.A, PB = S.B, nA = PA.length, nB = PB.length, N = Math.max(nA, nB);
    if (!N) return;
    const ax = PA.reduce((m, q) => [Math.min(m[0], q.x), Math.max(m[1], q.x)], [1e9, -1e9]);
    const bx = PB.reduce((m, q) => [Math.min(m[0], q.x), Math.max(m[1], q.x)], [1e9, -1e9]);
    const sz = S.step * 0.95 * (+o.dot || 1), fs = o.fs;   // o.dot：颗粒放大倍数（预览小格子里用 1.8，不然看不清）
    let last = '';
    for (let k = 0; k < N; k++) {
      const a = nA ? PA[k % nA] : null, b = nB ? PB[k % nB] : null;
      const ref = a || b;
      const ang = hash(k, 3) * Math.PI * 2, rad = (0.25 + hash(k, 4)) * fs * 1.6;
      const sx = ref.x + Math.cos(ang) * rad + (a && b ? (b.x - a.x) * 0.5 : 0), sy = ref.y + Math.sin(ang) * rad * 0.8 + (a && b ? (b.y - a.y) * 0.5 : 0);
      const dA = a ? (a.x - ax[0]) / Math.max(1, ax[1] - ax[0]) * 0.12 : 0;
      const dB = b ? (b.x - bx[0]) / Math.max(1, bx[1] - bx[0]) * 0.1 : 0;
      const p1 = oc(prog(p, 0.02 + dA, 0.42 + dA)), p2 = ioc(prog(p, 0.45 + dB, 0.88 + dB));
      let x, y, al = 1;
      if (p2 <= 0) { x = a ? a.x + (sx - a.x) * p1 : sx; y = a ? a.y + (sy - a.y) * p1 : sy; }
      else { x = sx + ((b ? b.x : sx) - sx) * p2; y = sy + ((b ? b.y : sy) - sy) * p2; }
      if (!a) al = prog(p, 0.3, 0.6);
      if (!b) al = 1 - prog(p, 0.35, 0.75);
      // 飞的时候颗粒稍微大一点、亮一点
      const sw = 1 + 0.7 * Math.sin(Math.PI * clamp(p, 0, 1)) * hash(k, 5);
      const col = (p2 > 0.5 ? (b || a) : (a || b)).col;
      if (col !== last) { ctx.fillStyle = col; last = col; }
      ctx.globalAlpha = al * fade;
      ctx.fillRect(x - sz * sw / 2, y - sz * sw / 2, sz * sw, sz * sw);
    }
    ctx.globalAlpha = 1;
  }

  // ================= 【区域T7 绘制入口】 =================
  // o = { id, a, b, p, fs, color, accent, bold, font, lh, ls, shadow }
  //   color 不给 = 跟着容器的文字颜色走（选择窗口里用，浅色界面会自动翻转）
  const FONT = "'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif";
  function norm(o) {
    const fs = Math.max(4, +o.fs || 100), bold = o.bold !== false;
    return Object.assign({}, o, {
      fs, a: o.a == null ? '' : String(o.a), b: o.b == null ? '' : String(o.b), p: clamp(+o.p || 0, 0, 1),
      accent: o.accent || '#f28c0f', font: o.font || FONT, lh: +o.lh || 1.3, ls: o.ls == null ? 0.04 : +o.ls,
      weight: o.weight || (bold ? 700 : 400), wStrong: o.wStrong || (bold ? 900 : 700)
    });
  }
  // 【区域T11】一头实一头透：给整块字加一层线性遮罩。e = 透明那一头还剩多少（0 = 全透明，1 = 没有渐隐）
  const GTO = { b: 'to bottom', t: 'to top', l: 'to left', r: 'to right' };   // 从实的一头指向透明的一头
  function gradMask(dir, e) {
    if (!(e < 0.999)) return '';
    const g = `linear-gradient(${GTO[dir] || 'to bottom'},#000 0%,#000 30%,rgba(0,0,0,${f3(0.12 + 0.88 * e)}) 72%,rgba(0,0,0,${f3(e)}) 100%)`;
    return `-webkit-mask-image:${g};mask-image:${g};`;
  }
  function gradOf(o) {                                                     // 这一帧整块字的渐隐（停留 = grad；转场 = gradA → gradB 慢慢变）
    const ga = o.gradA !== undefined ? o.gradA : o.grad, gb = o.gradB !== undefined ? o.gradB : o.grad;
    if (!ga && !gb) return '';
    const k = o.id === 'static' || o.id === 'none' || !o.id ? 1 : ioc(o.p);
    const e = (ga ? 0 : 1) + ((gb ? 0 : 1) - (ga ? 0 : 1)) * k;
    return gradMask((gb || ga).dir, e);
  }
  // 【区域T12 嵌入 / 压印】（v33.5）k = 0 正常 → 1 完全嵌进背景：变淡 + 上暗下亮的压印阴影（像刻在背景里的字）。
  //   停留时用 FXTrans.draw(el, { id: 'static', b, emboss: 0~1 })；不传 emboss 时一个字都不多写（老效果画面不变）。
  //   只用 opacity + text-shadow，不用 filter（规则 16）。
  function embossCss(k, o, op) {
    k = clamp(+k || 0, 0, 1); op = op == null ? 1 : op;
    const d = Math.max(1, o.fs * 0.018) * k;
    return `opacity:${f3(op * (1 - 0.74 * k))};` + (k > 0.001 ? `text-shadow:0 ${f2(-d)}px ${f2(d * 0.6)}px rgba(0,0,0,${f3(0.7 * k)}),0 ${f2(d)}px 0 rgba(255,255,255,${f3(0.16 * k)});` : '');
  }
  FX.embossCss = (k, o) => embossCss(k, norm(o || {}));
  function wrapHtml(o, inner) {
    return `<div style="position:absolute;left:0;top:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center">`
      + `<div class="fxt-g" style="position:relative;display:grid;font-family:${o.font};font-size:${f2(o.fs)}px;line-height:${o.lh};letter-spacing:${o.ls}em;`
      + `font-weight:${o.weight};${o.color ? 'color:' + o.color + ';' : ''}${o.shadow ? 'text-shadow:' + o.shadow + ';' : ''}${gradOf(o)}">${inner}</div></div>`;
  }
  FX.draw = (el, o) => {
    if (!el) return;
    o = norm(o || {});
    const A = FX.parse(o.a), B = FX.parse(o.b);
    let id = o.id;
    if (id === 'static' || id === 'none' || !id) {
      // 停留：只画一段（none 转场 = 前一半是 A，后一半直接换成 B）
      const T = id === 'none' ? (o.p < 0.5 ? A : B) : B;
      el.__fxt = null; el.innerHTML = wrapHtml(o, layer(T, o, o.emboss > 0 ? embossCss(o.emboss, o) : ''));
      return;
    }
    const full = id; id = baseId(id);
    if (!TR[id] && id !== 'particle') id = 'fade';
    if (id === 'particle') { A.chars = A.chars || A.lines.flat(); B.chars = B.chars || B.lines.flat(); return particle(el, o, A, B); }
    // 渐隐生长自己进来的那段字：没人告诉它 gradB 时，按自己的方向带上渐隐
    if (id === 'fadegrad' && o.gradB === undefined && o.grad === undefined) o = Object.assign({}, o, { gradB: o.b ? { dir: FX.gradOpt(full).dir } : null, gradA: o.gradA === undefined ? null : o.gradA });
    el.__fxt = null;
    el.innerHTML = wrapHtml(o, TR[id]({ A, B, p: o.p, o, id: full }));
  };

  // ================= 【区域T8 选择窗口】 =================
  // 弹在工作台页面（父页面）上。15 个格子，每格循环播放「A → B」；点一个就选它。
  // o = { pd, a, b, current, title, allowNone, allowAll, bold, accent, onPick(id, toAll) }
  function css(pd) {
    if (pd.getElementById('fxt-style')) return;
    const st = pd.createElement('style'); st.id = 'fxt-style';
    // 注意（规则 6）：颜色都写在样式表里，浅色界面会自动翻转；主题色橙写在具体的类上，不写在通用规则里
    st.textContent = `
.fxt-ov{position:fixed;inset:0;z-index:99990;background:rgba(0,0,0,.62);display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box}
.fxt-dlg{width:min(1180px,96vw);max-height:92vh;display:flex;flex-direction:column;background:#171717;border:1px solid #333;border-radius:12px;box-shadow:0 30px 80px rgba(0,0,0,.5);color:#ddd;font-size:13px;overflow:hidden}
.fxt-hd{display:flex;align-items:center;gap:12px;padding:14px 18px;border-bottom:1px solid #2a2a2a}
.fxt-hd b{font-size:15px;color:#eee}
.fxt-hd small{color:#888;font-size:12px;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fxt-x{width:30px;height:30px;border:0;border-radius:50%;background:#262626;color:#bbb;font-size:16px;cursor:pointer;flex:none}
.fxt-x:hover{background:#333;color:#fff}
.fxt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;padding:16px 18px;overflow:auto}
.fxt-t{position:relative;display:flex;flex-direction:column;gap:6px;padding:8px;background:#101010;border:1px solid #2c2c2c;border-radius:10px;cursor:pointer;text-align:left;font-family:inherit;color:inherit}
.fxt-t:hover{border-color:#666;transform:translateY(-1px)}
.fxt-t *{pointer-events:none}
.fxt-t.on{box-shadow:0 0 0 2px #f28c0f}
.fxt-pv{position:relative;width:100%;aspect-ratio:16/9;border-radius:6px;overflow:hidden;background:#050505;color:#f4f4f4}
.fxt-pvi{position:absolute;left:0;top:0;width:480px;height:270px;transform-origin:0 0}
.fxt-nm{display:flex;align-items:center;gap:6px;font-size:13px;color:#eee;font-weight:600}
.fxt-nm i{font-style:normal;color:#777;font-weight:400;font-size:11px;margin-left:auto}
.fxt-tp{font-size:11px;color:#888;line-height:1.5;min-height:2.9em}
.fxt-cur{position:absolute;right:12px;top:12px;padding:1px 7px;border-radius:9px;font-size:11px;font-weight:700}
.fxt-t.on .fxt-cur{background:#f28c0f;color:#000}
.fxt-t:not(.on) .fxt-cur{display:none}
.fxt-ft{display:flex;align-items:center;gap:12px;padding:12px 18px;border-top:1px solid #2a2a2a;color:#999;font-size:12px}
.fxt-ft label{display:flex;align-items:center;gap:6px;cursor:pointer;color:#ccc}
.fxt-ft input{accent-color:#f28c0f;width:15px;height:15px;margin:0}
.fxt-ft span{margin-left:auto}
.fxt-op{display:flex;flex-wrap:wrap;gap:4px}
.fxt-t .fxt-op button{pointer-events:auto;padding:2px 7px;border-radius:9px;border:1px solid #333;background:#1a1a1a;color:#aaa;font-size:11px;cursor:pointer;font-family:inherit}
.fxt-t .fxt-op button:hover{border-color:#666;color:#eee}
.fxt-t .fxt-op button.on{border-color:#f28c0f;color:#f28c0f}`;
    pd.head.appendChild(st);
  }
  FX.pick = o => {
    const pd = o.pd || document, pw = pd.defaultView || window;
    css(pd);
    const old = pd.querySelector('.fxt-ov'); if (old && old.__close) old.__close();
    const items = (o.allowNone ? [FX.NONE] : []).concat(FX.LIST);
    const a = o.a == null ? '' : String(o.a), b = o.b == null ? '' : String(o.b);
    // 预览字号：按两段里最长的一行自动选，保证小格子里放得下
    const em = Math.max(1, FX.emWidth(a), FX.emWidth(b));
    const nl = Math.max(1, FX.parse(a).lines.length, FX.parse(b).lines.length);
    const fs = Math.max(14, Math.min(84, 400 / em, 190 / (nl * 1.3)));
    const label = s => { const t = FX.parse(s).lines.map(l => l.map(x => x.c).join('')).join(' / '); return t ? '「' + (t.length > 18 ? t.slice(0, 18) + '…' : t) + '」' : '（空）'; };

    const ov = pd.createElement('div'); ov.className = 'fxt-ov';
    ov.innerHTML = `<div class="fxt-dlg" role="dialog"><div class="fxt-hd"><b>${esc(o.title || '选择转场')}</b><small>${esc(label(a))} → ${esc(label(b))}　·　每格都在循环播放，点一个就用它</small><button class="fxt-x" type="button" title="关闭（Esc）">✕</button></div>`
      + `<div class="fxt-grid"></div>`
      + `<div class="fxt-ft">${o.allowAll ? '<label><input type="checkbox" class="fxt-all">选的这一种同时用到所有转场</label>' : ''}<span>Esc 或点空白处关闭</span></div></div>`;
    const grid = ov.querySelector('.fxt-grid'), tiles = [];
    items.forEach((it, i) => {
      const t = pd.createElement('div'); t.setAttribute('role', 'button'); t.tabIndex = 0;   // 里面有选项小按钮，外层不能再是 <button>
      t.className = 'fxt-t' + (baseId(o.current) === it.id ? ' on' : '');
      t.title = it.tip;
      t.innerHTML = `<div class="fxt-pv"><div class="fxt-pvi"></div></div><div class="fxt-nm">${esc(it.name)}<i>${it.id === 'none' ? '' : (o.allowNone ? i : i + 1)}</i></div><div class="fxt-tp">${esc(it.tip)}</div><em class="fxt-cur">当前</em>`;
      const tile = { it, pv: t.querySelector('.fxt-pv'), el: t.querySelector('.fxt-pvi'), id: it.id };
      // 【区域T11】带选项的转场：格子下面一排小按钮（哪一头透明 / 怎么长），点了预览马上跟着变，再点格子就用这个组合
      if (it.opts) {
        let g = baseId(o.current) === it.id ? FX.gradOpt(o.current) : FX.gradOpt('');
        const op = pd.createElement('div'); op.className = 'fxt-op';
        const draw = () => {
          tile.id = FX.gradId(g);
          op.innerHTML = Object.keys(GDIR).map(k => `<button type="button" data-d="${k}" class="${g.dir === k ? 'on' : ''}">${GDIR[k]}</button>`).join('')
            + Object.keys(GROW).map(k => `<button type="button" data-g="${k}" class="${g.grow === k ? 'on' : ''}">${GROW[k]}</button>`).join('');
          op.querySelectorAll('button').forEach(b => b.onclick = e => { e.stopPropagation(); if (b.dataset.d) g.dir = b.dataset.d; else g.grow = b.dataset.g; draw(); });
        };
        draw(); t.appendChild(op);
      }
      // v13.1：预览格每一帧都在重画（innerHTML），以前点在预览画面上时，按下和松开落在了不同的节点上，浏览器就不认这一下「点击」，
      // 只有点下面的文字才有用。现在格子里的东西都不接鼠标（CSS .fxt-t * { pointer-events:none }），整个格子哪儿都能点。
      const pick = () => { const all = !!(ov.querySelector('.fxt-all') || {}).checked; close(); o.onPick && o.onPick(tile.id, all); };
      t.onclick = pick; t.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } };
      grid.appendChild(t);
      tiles.push(tile);
    });
    pd.body.appendChild(ov);
    const fit = () => tiles.forEach(x => { const w = x.pv.clientWidth; if (w) x.el.style.transform = `scale(${w / 480})`; });
    fit();
    // 循环：停 0.5 秒 → 转场 1.2 秒 → 停 0.8 秒
    const t0 = pw.performance.now();
    let raf = 0;
    const tick = () => {
      const t = ((pw.performance.now() - t0) / 1000) % 2.5;
      const p = t < 0.5 ? 0 : t < 1.7 ? (t - 0.5) / 1.2 : 1;
      tiles.forEach(x => {
        try {
          if (x.it.id === 'none') FX.draw(x.el, { id: 'none', a, b, p, fs, accent: o.accent, bold: o.bold });
          else FX.draw(x.el, { id: x.id, a, b, p, fs, accent: o.accent, bold: o.bold, dot: 1.8 });
        } catch (e) { }
      });
      raf = pw.requestAnimationFrame(tick);
    };
    tick();
    const onKey = e => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); } };
    const onRs = () => fit();
    function close() {
      pw.cancelAnimationFrame(raf);
      pd.removeEventListener('keydown', onKey, true); pw.removeEventListener('resize', onRs);
      ov.remove();
    }
    ov.__close = close;
    ov.addEventListener('pointerdown', e => { if (e.target === ov) close(); });
    ov.querySelector('.fxt-x').onclick = close;
    pd.addEventListener('keydown', onKey, true); pw.addEventListener('resize', onRs);
    return { close };
  };
  // ================= 【区域T9 分段时间轴】（v11.1 从 text-transition 抽出来，所有「一段段换字」的效果共用） =================
  // 数据（存在效果自己的参数里，JSON 字符串）：{ list:[{text}], trans:[两段之间的转场 id], intro, outro }
  // FXTrans.readSegs(原始值, 示例)：坏数据一律兜住，退回示例
  FX.readSegs = (raw, demo) => {
    let v = raw;
    try { v = typeof v === 'string' ? JSON.parse(v) : v; } catch (e) { v = null; }
    if (!v || typeof v !== 'object') v = JSON.parse(JSON.stringify(demo || { list: [{ text: '' }] }));
    let list = Array.isArray(v.list) ? v.list.filter(x => x && typeof x === 'object').map(x => ({ text: String(x.text == null ? '' : x.text) })) : [];
    if (!list.length) list = [{ text: '' }];
    const trans = list.slice(1).map((_, i) => {
      const id = Array.isArray(v.trans) ? v.trans[i] : null;
      return FX.has(id) ? id : 'fade';
    });
    const io = id => id === 'none' || FX.has(id) ? id : 'none';
    return { list, trans, intro: io(v.intro), outro: io(v.outro) };
  };
  // FXTrans.timeline(D, { hold: 每段停留, tdur: 转场时长, end: 最后一段多停 })
  // 拆成一节一节：{ t0, t1, kind:'hold'|'trans', ... }；开场 → 第 1 段停留 → 转场 → … → 最后一段多停 → 结尾
  FX.timeline = (D, o) => {
    o = o || {};
    const hold = o.hold, td = o.tdur, end = o.end;
    const out = []; let t = 0;
    const push = (len, x) => { if (len <= 0) return; out.push(Object.assign({ t0: t, t1: t + len }, x)); t += len; };
    if (D.intro !== 'none') push(td, { kind: 'trans', id: D.intro, a: '', b: D.list[0].text });
    D.list.forEach((s, i) => {
      push(hold + (i === D.list.length - 1 ? end : 0), { kind: 'hold', b: s.text });
      if (i < D.list.length - 1) push(td, { kind: 'trans', id: D.trans[i], a: s.text, b: D.list[i + 1].text });
    });
    if (D.outro !== 'none') push(td, { kind: 'trans', id: D.outro, a: D.list[D.list.length - 1].text, b: '' });
    // 【区域T11】哪几段字是「渐隐生长」进来的：停留时保持渐隐，下一个转场时慢慢退掉（只有用了这个转场才会带上，别的不变）
    const into = i => (i === 0 ? D.intro : D.trans[i - 1]);
    const look = D.list.map((_, i) => baseId(into(i)) === 'fadegrad' ? { dir: FX.gradOpt(into(i)).dir } : null);
    if (look.some(Boolean)) {
      let hi = -1;
      out.forEach(sg => {
        if (sg.kind === 'hold') { hi++; if (look[hi]) sg.grad = look[hi]; return; }
        const ai = sg.a === '' ? -1 : hi, bi = sg.b === '' ? -1 : hi + 1;
        sg.gradA = ai >= 0 ? look[ai] : null;
        sg.gradB = bi >= 0 ? look[bi] : (baseId(sg.id) === 'fadegrad' && ai >= 0 ? look[ai] : null);
        if (!sg.gradA && !sg.gradB) { delete sg.gradA; delete sg.gradB; }
      });
    }
    return { segs: out, total: Math.max(0.5, t), D };
  };
  // FXTrans.drawAt(容器, 时间轴, 这一秒, 文字样式)：画时间轴上这一秒（停留 = 静止的字；转场 = A→B 的某一帧）
  FX.drawAt = (el, TL, t, S) => {
    const seg = TL.segs.find(x => t < x.t1) || TL.segs[TL.segs.length - 1];
    if (!seg) { el.innerHTML = ''; return; }
    if (seg.kind === 'hold') FX.draw(el, Object.assign({ id: 'static', b: seg.b }, S, seg.grad ? { grad: seg.grad } : {}));
    else FX.draw(el, Object.assign({ id: seg.id, a: seg.a, b: seg.b, p: (t - seg.t0) / (seg.t1 - seg.t0) }, S,
      'gradA' in seg ? { gradA: seg.gradA, gradB: seg.gradB } : {}));
  };

  // ================= 【区域T10 编辑面板】（v11.1 从 text-transition 抽出来） =================
  // 「每段一个输入框 + 两段之间一个橙色转场按钮 + 开场 / 结尾」。别的效果（比如卡片里的文字）直接调用，不另做一套。
  // FXTrans.editor({ pd, get: () => 原始值, save: json字符串 => {...}, look: () => ({accent, bold}), demo, title, note })
  // 返回 { el, refresh }：el 自己插到面板里；工作台撤销 / 恢复默认后调 refresh() 重新读。
  function edCss(pd) {
    if (pd.getElementById('ttx-style')) return;
    const st = pd.createElement('style'); st.id = 'ttx-style';
    // 颜色都写在样式表里（浅色界面自动翻转）；橙色写在具体类上，不写在通用规则里（规则 6 的坑）
    st.textContent = `
.ttx{display:block;font-size:12px;color:#999;margin-bottom:14px}
.ttx-h{font-size:13px;color:#ddd;font-weight:600;margin:4px 0 8px}
.ttx-note{font-size:12px;color:#777;line-height:1.6;margin:6px 0}
.ttx-seg{display:flex;align-items:center;gap:8px;background:#101010;border:1px solid #2c2c2c;border-radius:8px;padding:8px}
.ttx-no{min-width:20px;height:20px;padding:0 5px;border-radius:10px;background:#f28c0f;color:#000;font-size:12px;line-height:20px;text-align:center;font-weight:700;flex:none}
.ttx input.ttx-txt{display:block!important;flex:1;min-width:0;width:auto!important;box-sizing:border-box;margin:0!important;padding:8px 10px!important;font-size:14px;background:#0b0b0b;color:#eee;border:1px solid #333;border-radius:6px;font-family:inherit}
.ttx input.ttx-txt:focus{outline:none;border-color:#f28c0f}
.ttx-ic{width:22px;height:22px;padding:0;border:0;border-radius:50%;background:#262626;color:#bbb;cursor:pointer;font-size:12px;line-height:22px;flex:none;font-family:inherit}
.ttx-ic:hover{background:#333;color:#fff}
.ttx-ic.del:hover{background:#5a1f1f}
.ttx-ic:disabled{opacity:.25;cursor:default}
.ttx-tr{position:relative;display:flex;align-items:center;justify-content:center;margin:4px 0;height:34px}
.ttx-tr:before{content:'';position:absolute;left:50%;top:0;bottom:0;border-left:1px dashed #444}
.ttx-pill{position:relative;display:flex;align-items:center;gap:6px;padding:5px 12px;border-radius:16px;border:1px solid #f28c0f;background:#1c1206;color:#f2a33d;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap}
.ttx-pill:hover{background:#2a1a08}
.ttx-pill em{font-style:normal;color:#9a7a50}
.ttx-pill b{color:#ffc27a;font-weight:600}
.ttx-pill.none{border-style:dashed;border-color:#555;background:#151515}
.ttx-pill.none b{color:#aaa}
.ttx-add{display:block;width:100%;margin-top:10px;padding:9px;font-size:13px;background:#262626;color:#eee;border:0;border-radius:6px;cursor:pointer;font-family:inherit}
.ttx-add:hover{background:#2f2f2f}
.ttx-sum{margin-top:8px;font-size:12px;color:#888}`;
    pd.head.appendChild(st);
  }
  FX.editor = o => {
    const pd = o.pd;
    edCss(pd);
    const wrap = pd.createElement('div'); wrap.className = 'ttx';
    const read = () => FX.readSegs(o.get(), o.demo);
    let D = read();
    const save = () => o.save(JSON.stringify({ list: D.list, trans: D.trans, intro: D.intro, outro: D.outro }));
    const look = () => (o.look ? o.look() : {});
    const open = (which, i) => {
      const L = D.list, cur = which === 'intro' ? D.intro : which === 'outro' ? D.outro : D.trans[i];
      const a = which === 'intro' ? '' : which === 'outro' ? L[L.length - 1].text : L[i].text;
      const b = which === 'intro' ? L[0].text : which === 'outro' ? '' : L[i + 1].text;
      FX.pick(Object.assign({
        pd, a, b, current: cur,
        title: which === 'intro' ? '开场：第 1 段怎么出现' : which === 'outro' ? '结尾：最后一段怎么消失' : `第 ${i + 1} 段 → 第 ${i + 2} 段的转场`,
        allowNone: which !== 'gap', allowAll: which === 'gap' && D.trans.length > 1,
        onPick: (id, all) => {
          if (which === 'intro') D.intro = id; else if (which === 'outro') D.outro = id;
          else if (all) D.trans = D.trans.map(() => id); else D.trans[i] = id;
          save(); build();
        }
      }, look()));
    };
    const pill = (which, i, lead) => {
      const r = pd.createElement('div'); r.className = 'ttx-tr';
      const id = which === 'intro' ? D.intro : which === 'outro' ? D.outro : D.trans[i];
      const b = pd.createElement('button'); b.type = 'button';
      b.className = 'ttx-pill' + (id === 'none' ? ' none' : '');
      b.title = '点开弹出 18 种转场的预览，点哪个用哪个';
      b.innerHTML = `<em>${lead}</em><b>${FX.name(id)}</b><span>▾</span>`;
      b.onclick = () => open(which, i);
      r.appendChild(b); return r;
    };
    function build() {
      wrap.innerHTML = (o.title === '' ? '' : `<div class="ttx-h">${o.title || '文字和转场'}</div>`)
        + '<div class="ttx-note">每段文字之间都能选一种转场：点中间的橙色按钮，会弹出 18 种效果的预览，点哪个用哪个。</div>';
      wrap.appendChild(pill('intro', 0, '开场'));
      D.list.forEach((s, i) => {
        const row = pd.createElement('div'); row.className = 'ttx-seg';
        row.innerHTML = `<span class="ttx-no">${i + 1}</span><input class="ttx-txt" type="text" placeholder="第 ${i + 1} 段文字"><button type="button" class="ttx-ic" title="往上挪">↑</button><button type="button" class="ttx-ic" title="往下挪">↓</button><button type="button" class="ttx-ic del" title="删掉这一段">✕</button>`;
        const inp = row.querySelector('input'), [up, dn, del] = row.querySelectorAll('button');
        inp.value = s.text;
        let comp = false;
        inp.addEventListener('compositionstart', () => { comp = true; });
        const put = () => { if (D.list[i]) { D.list[i].text = inp.value; save(); } };
        inp.addEventListener('compositionend', () => { comp = false; put(); });
        inp.addEventListener('input', e => { if (comp || e.isComposing) return; put(); });
        up.disabled = i === 0; dn.disabled = i === D.list.length - 1; del.disabled = D.list.length < 2;
        const swap = (x, y) => { [D.list[x], D.list[y]] = [D.list[y], D.list[x]]; save(); build(); };
        up.onclick = () => swap(i, i - 1); dn.onclick = () => swap(i, i + 1);
        del.onclick = () => {
          D.list.splice(i, 1);
          D.trans.splice(Math.min(i, D.trans.length - 1), 1);   // 删掉这一段后面那个转场（最后一段就删前面那个）
          save(); build();
        };
        wrap.appendChild(row);
        if (i < D.list.length - 1) wrap.appendChild(pill('gap', i, '转场'));
      });
      wrap.appendChild(pill('outro', 0, '结尾'));
      const add = pd.createElement('button'); add.type = 'button'; add.className = 'ttx-add'; add.textContent = '＋ 加一段文字';
      add.onclick = () => {
        D.list.push({ text: '新的一段' });
        D.trans.push(D.trans.length ? D.trans[D.trans.length - 1] : 'fade');   // 新转场默认沿用上一个
        save(); build();
        const ins = wrap.querySelectorAll('input.ttx-txt'); const last = ins[ins.length - 1];
        if (last) { last.focus(); last.select(); }
      };
      wrap.appendChild(add);
      const sum = pd.createElement('div'); sum.className = 'ttx-note';
      sum.innerHTML = '写法：<b>**两个星号**</b> 包住的字变成强调色；<b>|</b> 换行；<b>~波浪线~</b> 包住的字划掉。<br>'
        + (o.note == null ? '每段停多久、转场多快，在下面「持续时间 → 分段时间」里调。' : o.note);
      wrap.appendChild(sum);
    }
    // 工作台撤销 / 恢复默认会改 params：重新读一遍再画（正在输入时不重建，免得打断输入法）
    const refresh = () => {
      const nd = read();
      if (JSON.stringify(nd) === JSON.stringify(D)) return;
      const a = pd.activeElement; if (a && wrap.contains(a) && a.tagName === 'INPUT') { D = nd; return; }
      D = nd; build();
    };
    build();
    return { el: wrap, refresh };
  };
})();
