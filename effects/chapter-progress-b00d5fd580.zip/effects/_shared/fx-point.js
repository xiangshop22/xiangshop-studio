/* ===========================================================================
   fx-point.js —— 指向逻辑（工作台公共模块，2026-11-13 新增，从关系图 relation-graph 抽出来）
   ---------------------------------------------------------------------------
   做什么：「从卡 A 指向卡 B」的那一套，以后所有箭头 / 连线都用这一份（规则 28）：
     · 线从 A 的边上出发、到 B 的边上停（圆卡按圆、方卡按矩形），中间留一点空，不压住卡片；
     · 默认按「弯曲」往一侧弯；在预览里按住线中间的那个点（标签 / 菱形点）约 0.3 秒再拖 = 线弯过去穿过拖到的那一点（存成中点偏移 mx / my），
       双击那个点 = 回到默认弯度，点一下（不拖）= 右侧跳到这条线的设置；
     · 箭头头（三角）。
   谁在用：关系图（relation-graph，连线 + 标签拖弯 + 节点拖动）、丝带连接卡（ribbon-link-cards，「箭头」样式的丝带）。
   以后想做新的箭头，几何用 FXPoint.curve，预览里的鼠标用 FXPoint.preview，别再自己写一套。

   区域地图（想改哪里，直接说「区域Px 怎么改」）
   【区域P1 几何】   exit：从卡片中心朝某个方向走到边外一点要走多少；curve：A → B 的二次曲线（默认弯度 / 拖过中点两种）
   【区域P2 箭头头】 head：箭头三角的 4 个点（和 FXExplain.head 一模一样）
   【区域P3 预览里的鼠标】preview：比 view-controls.js 先挂到工作台页面的捕获阶段；按中「要长按的点」= 0.3 秒后才能拖，
                    按中「直接拖的东西」（关系图的节点）= 马上拖；点一下 = 跳到设置；双击 = 回到默认；没按中 = 放行（拖空白处照旧整张图一起动），
                    tap 回调：没按中任何东西时点了一下（丝带连接卡用来「点卡片跳到设置」，不拦事件）
   =========================================================================== */
(function () {
  const P = window.FXPoint = window.FXPoint || {};

  // ================= 【区域P1 几何】 =================
  // g = { x, y 中心, w, h, round }；从中心朝 (dx, dy) 方向走到边外 gap 像素，需要走 (dx, dy) 的多少倍
  P.exit = (g, dx, dy, gap = 12) => {
    const Ln = Math.hypot(dx, dy) || 1;
    if (g.round) return (g.w / 2 + gap) / Ln;
    return Math.min((g.w / 2 + gap) / Math.max(1e-6, Math.abs(dx)), (g.h / 2 + gap) / Math.max(1e-6, Math.abs(dy)));
  };
  // 给了控制点的二次曲线：返回 { d 路径, at(u) 线上的点, ang(u) 切线角度, len 弦长, a 起点, c 控制点, b 终点 }
  P.quadC = (ax, ay, cx, cy, bx, by) => {
    const at = u => [(1 - u) * (1 - u) * ax + 2 * (1 - u) * u * cx + u * u * bx, (1 - u) * (1 - u) * ay + 2 * (1 - u) * u * cy + u * u * by];
    const ang = u => Math.atan2(2 * (1 - u) * (cy - ay) + 2 * u * (by - cy), 2 * (1 - u) * (cx - ax) + 2 * u * (bx - cx));
    return { d: `M${ax.toFixed(1)} ${ay.toFixed(1)}Q${cx.toFixed(1)} ${cy.toFixed(1)} ${bx.toFixed(1)} ${by.toFixed(1)}`, at, ang, len: Math.hypot(bx - ax, by - ay),
             a: [ax, ay], c: [cx, cy], b: [bx, by] };
  };
  // A → B，bend = 往一侧弯多少（弦长的比例），算法和 FXExplain.quad 一样
  P.quad = (ax, ay, bx, by, bend = 0) => {
    const mx = (ax + bx) / 2, my = (ay + by) / 2, dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy) || 1;
    const cx = mx - (dy / L) * bend * L, cy = my + (dx / L) * bend * L;
    const q = P.quadC(ax, ay, cx, cy, bx, by); q.len = L; return q;
  };
  // 从卡 A 指向卡 B 的线：o = { bend 默认弯度, mx / my 拖过的中点偏移, gap 离卡片边多远, gapA / gapB 两头单独的空隙 }
  //   没拖过（mx / my 都是 0）：两头沿 A→B 的连线方向离开卡片，按 bend 弯；
  //   拖过：二次曲线中点 = (起点 + 2 × 控制点 + 终点) / 4，所以中点挪 (mx, my) = 控制点挪 2 倍；线从朝着弯的方向的那条边出去
  P.curve = (A, B, o = {}) => {
    const bend = o.bend || 0, mx = +o.mx || 0, my = +o.my || 0;
    const gA = o.gapA != null ? o.gapA : (o.gap != null ? o.gap : 12), gB = o.gapB != null ? o.gapB : (o.gap != null ? o.gap : 12);
    const dx = B.x - A.x, dy = B.y - A.y;
    if (!mx && !my){ const sa = P.exit(A, dx, dy, gA), sb = P.exit(B, dx, dy, gB); return P.quad(A.x + dx * sa, A.y + dy * sa, B.x - dx * sb, B.y - dy * sb, bend); }
    const cx = (A.x + B.x) / 2 - dy * bend + 2 * mx, cy = (A.y + B.y) / 2 + dx * bend + 2 * my;
    const sa = P.exit(A, cx - A.x, cy - A.y, gA), sb = P.exit(B, cx - B.x, cy - B.y, gB);
    return P.quadC(A.x + (cx - A.x) * sa, A.y + (cy - A.y) * sa, cx, cy, B.x + (cx - B.x) * sb, B.y + (cy - B.y) * sb);
  };

  // ================= 【区域P2 箭头头】 =================
  P.head = (x, y, a, s = 22) => {
    const p = (r, da) => `${(x + r * Math.cos(a + da)).toFixed(1)},${(y + r * Math.sin(a + da)).toFixed(1)}`;
    return `${p(0, 0)} ${p(-s, 0.42)} ${p(-s * 0.72, 0)} ${p(-s, -0.42)}`;
  };

  // ================= 【区域P3 预览里的鼠标】 =================
  // c = {
  //   tag      防重复挂的名字（工作台页面上 __<tag>DragDispose）
  //   hit(p, e)  p = 效果页面里的坐标 { x, y, sx }；按中了返回 { hold: 要不要长按, ... 随便带 }，没按中返回 null
  //   begin(h, p, e)  按下时：返回这一下要记的东西（比如原来的偏移、1 屏幕像素 = 画布多少）
  //   drag(h, s, dx, dy)  拖动（dx / dy = 屏幕像素）；end(h, s, moved)  松手；click(h, s)  点了一下（没拖）；dbl(h)  双击
  //   cursor(h)  鼠标移上去的样子（没按中 = 'grab'）；armHint(h) 长按到时间的提示；earlyHint(h) 没长按就拖的提示
  //   tap(e, p)  没按中任何东西时点了一下（≤ 5 像素、≤ 450 毫秒）；不拦事件，view-controls 照常
  // }
  P.HOLD = 300;
  P.preview = c => {
    let pw, pd;
    try { if (window.parent === window) return null; pw = window.parent; pd = pw.document; } catch (e) { return null; }
    const tag = '__' + (c.tag || 'fxp') + 'DragDispose';
    const frameEl = () => { const f = pd.getElementById('frame'); return f && f.contentWindow === window ? f : null; };   // 叠加层（ghost）里不管
    const local = e => { const f = frameEl(); if (!f) return null; const r = f.getBoundingClientRect(); if (!r.width || !innerWidth) return null; const sx = r.width / innerWidth, sy = r.height / innerHeight; return { x: (e.clientX - r.left) / sx, y: (e.clientY - r.top) / sy, sx }; };
    const hint = s => { const h = pd.getElementById('hint'); if (h && s) h.textContent = s; };
    const box = () => pd.getElementById('box');
    const flag = '__' + (c.tag || 'fxp') + 'On';
    const cursor = cs => { const b = box(); if (b){ b.style.cursor = cs; b[flag] = cs !== 'grab'; } };
    const hit = e => {
      if (e.altKey || e.shiftKey || e.ctrlKey || e.metaKey) return null;
      const p = local(e); if (!p) return null;
      return c.hit(p, e) || null;
    };
    let D = null, raf = 0, holdT = 0, tp = null;
    const onDown = e => {
      if (e.button !== 0) return;
      const h = hit(e);
      if (!h){ const p = local(e); tp = p && !(e.altKey || e.shiftKey || e.ctrlKey || e.metaKey) ? { x: e.clientX, y: e.clientY, t: performance.now() } : null; return; }
      e.preventDefault(); e.stopImmediatePropagation();     // 不让 view-controls 把整张图拖走
      const p = local(e);
      D = { h, s: c.begin ? c.begin(h, p, e) : {}, x: e.clientX, y: e.clientY, moved: false, armed: !h.hold };
      clearTimeout(holdT);
      if (h.hold) holdT = setTimeout(() => { if (!D) return; D.armed = true; cursor('grabbing'); hint(c.armHint && c.armHint(D.h)); }, P.HOLD);
    };
    const onMove = e => {
      if (!D){
        if (e.buttons || !frameEl()) return;
        const h = hit(e), cs = !h ? 'grab' : (c.cursor ? c.cursor(h) : 'pointer');
        const b = box(); if (b && b.style.cursor !== cs && (h || b[flag])) cursor(cs);
        return;
      }
      e.stopImmediatePropagation();
      const ddx = e.clientX - D.x, ddy = e.clientY - D.y;
      if (!D.armed){                                        // 还没长按到点就拖：不动，提示怎么拖
        if (Math.hypot(ddx, ddy) > 10){ clearTimeout(holdT); hint(c.earlyHint && c.earlyHint(D.h)); D = null; }
        return;
      }
      D.moved = D.moved || Math.abs(ddx) + Math.abs(ddy) > 2;
      c.drag && c.drag(D.h, D.s, ddx, ddy);
      if (!raf) raf = requestAnimationFrame(() => { raf = 0; c.redraw && c.redraw(); });
    };
    const onUp = e => {
      if (!D){
        const q = tp; tp = null;
        if (q && e.button === 0 && Math.hypot(e.clientX - q.x, e.clientY - q.y) <= 5 && performance.now() - q.t <= 450 && c.tap){ const p = local(e); if (p) c.tap(e, p); }
        return;
      }
      e.stopImmediatePropagation(); clearTimeout(holdT);
      const d = D; D = null;
      if (raf){ cancelAnimationFrame(raf); raf = 0; }
      if (d.moved){ c.redraw && c.redraw(); c.end && c.end(d.h, d.s, true); }   // 松手时一定按最后的位置画一次（窗口在后台时 requestAnimationFrame 不跑）
      else if (Math.hypot(e.clientX - d.x, e.clientY - d.y) <= 4) c.click && c.click(d.h, d.s);   // 没拖 = 点了一下
      if (d.h.hold) cursor(c.cursor ? c.cursor(d.h) : 'pointer');
    };
    const onDbl = e => {
      const h = hit(e); if (!h) return;
      e.preventDefault(); e.stopImmediatePropagation();     // 不让 view-controls 把整张图还原
      c.dbl && c.dbl(h);
    };
    try { if (pw[tag]) pw[tag](); } catch (e) {}
    pd.addEventListener('mousedown', onDown, true);
    pd.addEventListener('mousemove', onMove, true);
    pd.addEventListener('mouseup', onUp, true);
    pd.addEventListener('dblclick', onDbl, true);
    const extra = [];
    const dispose = () => {
      clearTimeout(holdT);
      pd.removeEventListener('mousedown', onDown, true); pd.removeEventListener('mousemove', onMove, true);
      pd.removeEventListener('mouseup', onUp, true); pd.removeEventListener('dblclick', onDbl, true);
      extra.forEach(f => { try { f(); } catch (e) {} });
      const b = box(); if (b && b[flag]){ b[flag] = false; b.style.cursor = ''; }
      if (pw[tag] === dispose) pw[tag] = null;
    };
    pw[tag] = dispose;
    addEventListener('pagehide', dispose); addEventListener('unload', dispose);
    return { pw, pd, local, hint, cursor, dispose, onDispose: f => extra.push(f), busy: () => !!D };
  };
})();
