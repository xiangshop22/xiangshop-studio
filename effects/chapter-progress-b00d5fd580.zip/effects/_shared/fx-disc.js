/* =====================================================================
 * 效果工坊 · 圆卡公共模块 FXDisc（v33.5，2026-11-13 从「圆形闪光换色卡」round-flash-card 抽出来）
 * ---------------------------------------------------------------------
 * 管什么：画一张圆形名牌卡（一层）——
 *   【D1 样式表】   圆卡用到的 class（.ly .disc .rim .tx …），加载时自动装进页面
 *   【D2 版式库】   SPEC：文字 / 图标 / 人物在圆里怎么摆（坐标都是占直径的比例）
 *   【D3 示例素材】 DEMO_ICON / DEMO_PERSON（没上传时用）
 *   【D4 小工具】   花纹 ORN、环形文字 ringSvg、按字宽缩字号 fitFs
 *   【D5 画一层】   FXDisc.layer(o)：圆底（玻璃）+ 金属描边 + 外发光 + 文字 + 图标 + 人物 + 高亮层 + （可选）闪光层 + 编号小圆
 * 谁在用：圆形闪光换色卡 round-flash-card、竞价柱状图 bid-bar-chart
 * 引入顺序：fx-cards.js → fx-skin.js → fx-transition.js → fx-disc.js → 效果脚本
 * 规则 28：这里的代码是从圆形闪光换色卡原样搬过来的，原效果改成调用它，画面逐像素一致。
 * ===================================================================== */
(function () {
  if (window.FXDisc) return;
  const D_ = window.FXDisc = {};
  const F = () => window.FXCards, SK = () => window.FXSkin, TX = () => window.FXTrans;

  // ================= 【D1 样式表】 =================
  D_.CSS = `
.ly{position:absolute;will-change:filter,opacity}
.disc{position:absolute;inset:0;border-radius:50%;overflow:hidden}
.disc .fill{position:absolute;inset:0}
.disc .gl{position:absolute;inset:0;border-radius:50%;pointer-events:none}
.badge{position:absolute;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:"Montserrat","Segoe UI","Arial",sans-serif!important;font-weight:700;color:#eef0f5;z-index:5}
.rim{position:absolute;border-radius:50%;pointer-events:none;z-index:2;will-change:transform}
.hl{position:absolute;inset:0;border-radius:50%;pointer-events:none;opacity:0}
.flash,.sweep,.shade{position:absolute;pointer-events:none;opacity:0;will-change:opacity}
.disc .gl{will-change:opacity}
.tx{position:absolute;white-space:nowrap;text-align:center;line-height:1.1}
.tx em.hi{font-style:normal}
.tcn{font-weight:900;letter-spacing:.12em}
.ten{font-family:"Montserrat","Segoe UI","Arial",sans-serif!important;font-weight:700;letter-spacing:.14em}
.tsc{font-family:"Playfair Display",Georgia,"Times New Roman",serif!important;font-style:italic;font-weight:600;letter-spacing:.01em}
.dots{position:absolute;height:0}
.orn,.ring{position:absolute;overflow:visible}
.band{position:absolute;left:0;right:0}
.bign{position:absolute;display:flex;justify-content:space-between;align-items:center;white-space:nowrap}
.ic,.pp{position:absolute;overflow:visible}
.ic>*,.pp>*{position:absolute;inset:0;width:100%;height:100%;display:block}
.ic img{object-fit:contain}
.ic .tint{-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;-webkit-mask-size:contain;mask-size:contain}
.pp img,.pp video{object-fit:contain;object-position:50% 100%}`;
  D_.injectCss = doc => {
    doc = doc || document;
    if (doc.getElementById('fxdisc-css')) return;
    const s = doc.createElement('style'); s.id = 'fxdisc-css'; s.textContent = D_.CSS;
    (doc.head || doc.documentElement).appendChild(s);
  };
  D_.injectCss();

  // ================= 【D2 版式库】坐标都是「占圆直径的比例」，x 是文字中线 =================
  // 每个版式：ornT / ornB 上下花纹，icon {x,y,w,h}（中心点 + 宽高），script / en / cn {x,y,fs,mw}（y = 文字中线），
  // dots {x,y,w}，person {x,y,w,h}（左上角 + 宽高，人物贴着框底），band 底部压暗条 {y}，ring 环形英文，bigName 人名背景，top 人物盖在文字上面
  const STD = { ornT: 0.065, ornB: 0.93, icon: { x: 0.5, y: 0.25, w: 0.21, h: 0.17 }, script: { x: 0.5, y: 0.395, fs: 0.07, mw: 0.6 },
    dots: { x: 0.5, y: 0.462, w: 0.52 }, cn: { x: 0.5, y: 0.585, fs: 0.19, mw: 0.78 }, en: { x: 0.5, y: 0.735, fs: 0.042, mw: 0.6 } };
  D_.SPEC = {
    std: STD,                                                     // 文字名牌：图标 + 花体 + 点线 + 大字 + 英文（圆形闪光换色卡的开场版式）
    personTop: { ornT: 0.065, cn: { x: 0.5, y: 0.17, fs: 0.13, mw: 0.6 }, en: { x: 0.5, y: 0.255, fs: 0.036, mw: 0.5 },
      person: { x: 0.13, y: 0.29, w: 0.74, h: 0.73 }, top: true },   // 人物居中、名字在头顶
    ref: { ornT: 0.065, en: { x: 0.42, y: 0.17, fs: 0.042, mw: 0.5 }, cn: { x: 0.42, y: 0.29, fs: 0.165, mw: 0.62 },
      dots: { x: 0.42, y: 0.4, w: 0.48 }, icon: { x: 0.42, y: 0.545, w: 0.2, h: 0.16 }, script: { x: 0.42, y: 0.69, fs: 0.07, mw: 0.5 },
      person: { x: 0.44, y: 0.27, w: 0.64, h: 0.75 }, top: true },   // 参考图：文字在左、人物在右
    left: { ornT: 0.065, en: { x: 0.6, y: 0.17, fs: 0.042, mw: 0.5 }, cn: { x: 0.6, y: 0.29, fs: 0.165, mw: 0.62 },
      dots: { x: 0.6, y: 0.4, w: 0.48 }, icon: { x: 0.6, y: 0.545, w: 0.2, h: 0.16 }, script: { x: 0.6, y: 0.69, fs: 0.07, mw: 0.5 },
      person: { x: -0.08, y: 0.27, w: 0.64, h: 0.75 }, top: true },  // 人物在左
    bigA: { ornT: 0.08, ornB: 0.915, cn: { x: 0.5, y: 0.46, fs: 0.23, mw: 0.8 }, en: { x: 0.5, y: 0.625, fs: 0.046, mw: 0.62 }, dots: { x: 0.5, y: 0.7, w: 0.3 } },   // 极简大字
    bigB: { person: { x: 0.08, y: 0.12, w: 0.84, h: 0.9 }, band: { y: 0.6 }, cn: { x: 0.5, y: 0.79, fs: 0.13, mw: 0.62 }, en: { x: 0.5, y: 0.885, fs: 0.034, mw: 0.44 } },
    ringA: { ring: true, icon: { x: 0.5, y: 0.31, w: 0.2, h: 0.16 }, cn: { x: 0.5, y: 0.54, fs: 0.17, mw: 0.66 }, dots: { x: 0.5, y: 0.65, w: 0.34 }, script: { x: 0.5, y: 0.735, fs: 0.06, mw: 0.5 } },
    ringB: { ring: true, person: { x: 0.17, y: 0.2, w: 0.66, h: 0.82 }, band: { y: 0.62 }, cn: { x: 0.5, y: 0.8, fs: 0.12, mw: 0.56 } },
    portrait: { en: { x: 0.5, y: 0.15, fs: 0.055, mw: 0.62 }, bigName: { y: 0.47, fs: 0.3, w: 0.84 },
      person: { x: 0.14, y: 0.2, w: 0.72, h: 0.82 }, top: true },
    mergeA: { ornT: 0.07, ornB: 0.925, icon: { x: 0.5, y: 0.25, w: 0.24, h: 0.19 }, dots: { x: 0.5, y: 0.4, w: 0.56 },
      cn: { x: 0.5, y: 0.555, fs: 0.2, mw: 0.8 }, en: { x: 0.5, y: 0.72, fs: 0.05, mw: 0.66 } }
  };

  // ================= 【D3 示例素材】（没上传时用；都是通用图形） =================
  const svgUrl = s => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s);
  D_.DEMO_ICON = svgUrl('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 100"><g fill="#fff"><circle cx="60" cy="50" r="40" fill="none" stroke="#fff" stroke-width="5"/><path d="M60 16 L68 42 L94 50 L68 58 L60 84 L52 58 L26 50 L52 42Z"/></g></svg>');
  D_.DEMO_PERSON = svgUrl('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e4def0"/><stop offset="1" stop-color="#9a91b3"/></linearGradient><linearGradient id="s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3b3352"/><stop offset="1" stop-color="#1c1828"/></linearGradient></defs><ellipse cx="150" cy="105" rx="62" ry="74" fill="url(#g)"/><path d="M118 165h64v30h-64z" fill="#b9b1c9"/><path d="M10 340C20 230 70 196 150 192C230 196 280 230 290 340Z" fill="url(#s)"/><path d="M130 194L150 250L170 194Z" fill="#cfc6e4"/><text x="150" y="300" font-family="sans-serif" font-size="18" fill="#fff" fill-opacity=".5" text-anchor="middle">示例人物 · 上传替换</text></svg>');

  // ================= 【D4 小工具】 =================
  const TXT = s => String(s == null ? '' : s).trim();
  const em = s => Math.max(0.6, TX() && TX().emWidth ? TX().emWidth(F().plain(s)) : F().plain(s).length * 0.9);
  const nChars = s => Math.max(1, Array.from(F().plain(s)).length);
  const fitFs = D_.fitFs = (txt, fs, maxW, ls) => Math.min(fs, maxW / Math.max(0.6, em(txt) + nChars(txt) * ls));
  D_.em = em;
  // 图标 / 人物素材读法（坏数据兜住）
  const jsonOf = (v, def) => { let o = v; if (typeof o === 'string'){ try { o = JSON.parse(o); } catch (e) { o = null; } } return o && typeof o === 'object' && !Array.isArray(o) ? o : JSON.parse(JSON.stringify(def)); };
  D_.readIcon = raw => { const m = jsonOf(raw, { type: 'demo', tint: true }); if (!['demo', 'image', 'none'].includes(m.type)) m.type = 'demo'; m.tint = m.tint !== false; return m; };
  D_.readPerson = raw => { const m = jsonOf(raw, { type: 'image', img: '' }); if (!['image', 'video', 'none'].includes(m.type)) m.type = 'image'; return m; };
  // 上下花纹
  const ORN = D_.ORN = `<g fill="none" stroke="#fff" stroke-width="1.2" stroke-linecap="round"><path d="M4 12H60M90 12H146"/><path d="M60 12C66 4 70 4 75 10C80 4 84 4 90 12"/><path d="M68 12C70 16 73 16 75 13C77 16 80 16 82 12"/></g><path d="M75 3l3 4-3 4-3-4z" fill="#fff"/>`;
  // 环形文字
  const ringSvg = D_.ringSvg = (D, txt, col) => {
    const r = D * 0.44, fs = D * 0.04, circ = 2 * Math.PI * r;
    const unit = (TXT(txt) || 'TEXT').toUpperCase() + '  ·  ';
    const unitW = (em(unit) + unit.length * 0.3) * fs;
    const rep = Math.max(1, Math.floor(circ / Math.max(20, unitW)));
    const f = v => v.toFixed(1);
    return `<svg width="${f(D)}" height="${f(D)}" viewBox="0 0 ${f(D)} ${f(D)}"><defs><path id="rgp${Math.round(D)}" d="M${f(D / 2)} ${f(D / 2 - r)}a${f(r)} ${f(r)} 0 1 1 -0.01 0"/></defs>`
      + `<circle cx="${f(D / 2)}" cy="${f(D / 2)}" r="${f(r + fs * 0.95)}" fill="none" stroke="${col}" stroke-opacity=".35" stroke-width="${f(Math.max(1, D * 0.002))}"/>`
      + `<circle cx="${f(D / 2)}" cy="${f(D / 2)}" r="${f(r - fs * 0.6)}" fill="none" stroke="${col}" stroke-opacity=".25" stroke-width="${f(Math.max(1, D * 0.002))}"/>`
      + `<text font-family="Montserrat,Segoe UI,Arial,sans-serif" font-weight="700" font-size="${f(fs)}" fill="${col}" fill-opacity=".7" textLength="${f(circ - 2)}" lengthAdjust="spacing"><textPath href="#rgp${Math.round(D)}">${F().esc(unit.repeat(rep))}</textPath></text></svg>`;
  };

  /* ================= 【D5 画一层】 =================
     o = {
       D: 直径（px）, off: 这一层在外框里的左上偏移（px，默认 0）, base: 卡片底色 [r,g,b],
       C: { tx: 文字色 [r,g,b], hi: 高亮色 [r,g,b] }, spec: 版式（D2 里的一个，或自己写）,
       txt: { cn, en, sc }, icon: 图标素材（readIcon 的结果）, person: 人物素材（readPerson 的结果）,
       P: 读样式的参数对象（stroke / strokeW / strokeShine / cRim / ornament / titleFs / personSize / iconSize / showScript / flashRange，没写用默认）,
       flash: true = 加闪光层（明暗蒙版 + 边缘闪光 + 扫光）, num: 顶上编号（空 = 没有）,
       mark: true = 标记给卡片背景动效（fx-cardbg.js，规则 40）, loads: 数组，图片 / 视频的加载 Promise 往里推
     }
     返回 r = { ly: 这一层的元素, hi: [高亮层…], glow, rim, ring, person, dark, light, flash, sweep, disc } */
  D_.layer = o => {
    const Fc = F(), S = SK(), Tx = TX();
    const num = Fc.num, clamp = Fc.clamp, css = S.css, mix = S.mix, W3 = S.W3, K3 = S.K3, rgbOf = S.rgbOf, norm = S.norm;
    const P = o.P || {}, D = o.D, C = o.C, spec = o.spec, base = o.base, loads = o.loads || [];
    const ly = document.createElement('div'); ly.className = 'ly';
    const off = o.off || 0;
    ly.style.cssText += `;left:${off.toFixed(1)}px;top:${off.toFixed(1)}px;width:${D.toFixed(1)}px;height:${D.toFixed(1)}px`;
    const r = { ly, hi: [] };
    // 【区域C】圆底：中心亮、边缘暗 + 亮边 + 外发光
    const disc = document.createElement('div'); disc.className = 'disc';
    const rim = Math.max(2, D * 0.0065);
    const strokeOn = P.stroke !== 'off';
    disc.style.boxShadow = (strokeOn ? '' : `0 0 0 ${rim.toFixed(1)}px ${css(mix(base, W3, 0.55))}, 0 0 0 ${(rim * 2.2).toFixed(1)}px ${css(base, 0.35)}, `) + `0 ${(D * 0.03).toFixed(0)}px ${(D * 0.09).toFixed(0)}px rgba(0,0,0,.45)`;
    disc.innerHTML = `<div class="fill" style="background:radial-gradient(circle at 50% 42%,${css(mix(base, W3, 0.22))} 0%,${css(base)} 48%,${css(mix(base, K3, 0.45))} 100%)"></div>`;
    ly.appendChild(disc); r.disc = disc;
    if (o.mark) window.FXCardBg && FXCardBg.mark(disc, Object.assign({ after: disc.firstElementChild, seed: 101, index: 0 }, o.markOpt || {}));   // 卡片背景动效（_shared/fx-cardbg.js，规则 40）
    // 【区域M】金属描边：先在一张 canvas 上把圆环画好（暗底 + 几处亮斑），之后转动只转这张图（纯 transform，不重画）
    if (strokeOn){
      const k = D / 460, sw = clamp(num(P.strokeW, 7), 1, 30) * k, shine = clamp(num(P.strokeShine, 100), 0, 200) / 100;
      const mc = rgbOf(norm(P.cRim) || '#cfe6ff');
      const dark = mix(mix(mc, base, 0.5), K3, 0.45), light = mix(mc, W3, 0.7);
      const spots = [[315, 1], [272, 0.75], [218, 0.9], [145, 1], [72, 0.85], [20, 0.35]];   // 亮斑的位置（0° = 正上方，顺时针）
      const size = D + sw, Q = 1.5, cv = document.createElement('canvas');
      cv.width = cv.height = Math.ceil(size * Q);
      const g = cv.getContext('2d'), c0 = size * Q / 2, ro = (D / 2 + sw / 2) * Q, ri = (D / 2 - sw / 2) * Q;
      for (let a = 0; a < 360; a += 2){                                    // 每 2° 一小段扇环，颜色按亮斑高斯混合
        let b = 0.12;
        spots.forEach(([c, w]) => { let d = Math.abs(a + 1 - c); d = Math.min(d, 360 - d); b = Math.max(b, w * Math.exp(-(d * d) / (2 * 11 * 11))); });
        const a0 = (a - 90.6) * Math.PI / 180, a1 = (a + 2 - 89.4) * Math.PI / 180;
        g.beginPath(); g.arc(c0, c0, ro, a0, a1); g.arc(c0, c0, ri, a1, a0, true); g.closePath();
        g.fillStyle = css(mix(dark, light, clamp(b * shine, 0, 1))); g.fill();
      }
      const rm = document.createElement('div'); rm.className = 'rim';
      rm.style.cssText += `;inset:${(-sw * 0.5).toFixed(1)}px`;
      cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%';
      rm.appendChild(cv);
      ly.appendChild(rm); r.rim = rm;
    }
    // 外发光（闪的时候加强）
    const glow = document.createElement('div'); glow.className = 'gl';
    glow.style.boxShadow = `0 0 ${(D * 0.06).toFixed(0)}px ${css(mix(base, W3, 0.3), 0.55)}, inset 0 0 ${(D * 0.08).toFixed(0)}px ${css(mix(base, W3, 0.5), 0.45)}`;
    ly.appendChild(glow); r.glow = glow;
    // 玻璃反光
    const gls = document.createElement('div'); gls.className = 'gl';
    gls.style.background = 'linear-gradient(160deg,rgba(255,255,255,.16),rgba(255,255,255,0) 38%,rgba(255,255,255,0) 70%,rgba(255,255,255,.05))';
    ly.appendChild(gls);

    const txC = css(C.tx), enC = css(C.tx, 0.62), lineC = css(C.tx, 0.36), scC = css(mix(base, W3, 0.72)), hiC = css(C.hi);
    const ornOn = P.ornament !== 'off';
    const put = (el, front) => { disc.appendChild(el); if (front) el.style.zIndex = 3; return el; };
    const textBox = (sp, cls, html, color, extra = '') => {
      if (!sp || !html) return null;
      const d = document.createElement('div'); d.className = 'tx ' + cls;
      const fs = sp.fsPx;
      d.style.cssText += `;left:${(sp.x * D - D).toFixed(1)}px;width:${(D * 2).toFixed(1)}px;top:${(sp.y * D - fs * 0.55).toFixed(1)}px;font-size:${fs.toFixed(1)}px;color:${color};${extra}`;
      d.innerHTML = html.replace(/<em class="hi">/g, `<em class="hi" style="color:${hiC}">`);
      return d;
    };
    const txt = o.txt || { cn: '', en: '', sc: '' };
    const fsOf = (sp, s, ls) => { if (!sp) return; sp.fsPx = fitFs(s, sp.fs * D * clamp(num(P.titleFs, 100), 40, 180) / 100, sp.mw * D, ls); };
    const S2 = JSON.parse(JSON.stringify(spec));
    fsOf(S2.cn, txt.cn, 0.12); fsOf(S2.en, txt.en, 0.14); fsOf(S2.script, txt.sc, 0.01);

    // 人物：盖在文字上面（top）或下面
    let person = null;
    const pm = o.person || { type: 'none' };
    if (S2.person && pm.type !== 'none'){
      const pb = S2.person, w = pb.w * D, h = pb.h * D * clamp(num(P.personSize, 100), 30, 200) / 100;
      person = document.createElement('div'); person.className = 'pp';
      const hw = pb.w * D * clamp(num(P.personSize, 100), 30, 200) / 100;
      person.style.cssText += `;left:${(pb.x * D + (w - hw) / 2).toFixed(1)}px;top:${(pb.y * D + pb.h * D - h).toFixed(1)}px;width:${hw.toFixed(1)}px;height:${h.toFixed(1)}px`;
      person.style.filter = `drop-shadow(${(-D * 0.012).toFixed(1)}px 0 ${(D * 0.03).toFixed(1)}px rgba(0,0,0,.35))`;
      if (pm.type === 'video' && pm.video && window.FXVideo){
        loads.push(FXVideo.mount(person, pm, 'contain'));
        Fc.place(person.lastElementChild, pm, hw, h);
      } else {
        const im = new Image(); im.alt = ''; im.src = pm.type === 'image' && pm.img ? pm.img : D_.DEMO_PERSON;
        loads.push(im.decode ? im.decode().catch(() => {}) : Promise.resolve());
        person.appendChild(im);
        if (pm.img) Fc.place(im, pm, hw, h);
      }
    }
    if (person && !S2.top) put(person);
    // 人名背景：每个字一个格子，左右撑开（人物挡住中间），从上到下渐变变淡
    if (S2.bigName && txt.cn){
      const chars = Array.from(Fc.plain(txt.cn)), n = chars.length, bw = S2.bigName.w * D;
      const fs = Math.min(S2.bigName.fs * D * clamp(num(P.titleFs, 100), 40, 180) / 100, bw / Math.max(1, n) * (n <= 2 ? 0.62 : 0.95));
      const bn = document.createElement('div'); bn.className = 'bign';
      bn.style.cssText += `;left:${((D - bw) / 2).toFixed(1)}px;width:${bw.toFixed(1)}px;top:${(S2.bigName.y * D - fs * 0.6).toFixed(1)}px;height:${(fs * 1.2).toFixed(1)}px;`
        + `filter:drop-shadow(0 0 ${(D * 0.02).toFixed(1)}px ${css(mix(base, W3, 0.5), 0.55)})`;
      // 渐隐的字直接调公共模块 fx-transition.js【区域T11】（上实下透）（规则 39）
      const col = css(mix(C.tx, mix(base, W3, 0.72), 0.25));
      chars.forEach(ch => {
        const cell = document.createElement('span');
        cell.style.cssText = `position:relative;display:block;width:${(fs * 1.05).toFixed(1)}px;height:${(fs * 1.2).toFixed(1)}px`;
        Tx.draw(cell, { id: 'static', b: ch, fs, color: col, bold: true, weight: 900, lh: 1.2, ls: 0, grad: { dir: 'b' } });
        bn.appendChild(cell);
      });
      put(bn);
    }
    if (S2.band){
      const b = document.createElement('div'); b.className = 'band';
      b.style.cssText += `;top:${(S2.band.y * D).toFixed(1)}px;bottom:0;background:linear-gradient(180deg,${css(mix(base, K3, 0.35), 0)} 0%,${css(mix(base, K3, 0.35), 0.82)} 45%,${css(mix(base, K3, 0.45), 0.95)} 100%)`;
      put(b);
    }
    if (S2.ring){ const rg = document.createElement('div'); rg.className = 'ring'; rg.style.cssText += `;left:0;top:0;width:${D.toFixed(1)}px;height:${D.toFixed(1)}px`; rg.innerHTML = ringSvg(D, txt.en || txt.sc, txC); put(rg); r.ring = rg; }
    const orn = (y, flip) => { if (y == null || !ornOn) return; const w = D * 0.33, h = w * 18 / 150, e = document.createElement('div'); e.className = 'orn';
      e.style.cssText += `;left:${((D - w) / 2).toFixed(1)}px;top:${(y * D - h / 2).toFixed(1)}px;width:${w.toFixed(1)}px;height:${h.toFixed(1)}px;opacity:.72${flip ? ';transform:scaleY(-1)' : ''}`;
      e.innerHTML = `<svg viewBox="0 0 150 18" width="100%" height="100%">${ORN}</svg>`; put(e); };
    orn(S2.ornT); orn(S2.ornB, true);
    // 图标
    const icm = o.icon || { type: 'none' };
    if (S2.icon && icm.type !== 'none'){
      const ib = S2.icon, iw = ib.w * D * clamp(num(P.iconSize, 100), 30, 250) / 100, ih = ib.h * D * clamp(num(P.iconSize, 100), 30, 250) / 100;
      const ic = document.createElement('div'); ic.className = 'ic';
      ic.style.cssText += `;left:${(ib.x * D - iw / 2).toFixed(1)}px;top:${(ib.y * D - ih / 2).toFixed(1)}px;width:${iw.toFixed(1)}px;height:${ih.toFixed(1)}px`;
      const src = icm.type === 'image' && icm.img ? icm.img : D_.DEMO_ICON;
      if (icm.tint){
        const t = document.createElement('div'); t.className = 'tint';
        t.style.background = css(mix(base, W3, 0.7));
        t.style.webkitMaskImage = t.style.maskImage = `url("${src}")`;
        if (icm.type === 'image' && icm.img && Fc.place(t, icm, iw, ih)){ t.style.webkitMaskSize = t.style.maskSize = '100% 100%'; }
        ic.appendChild(t);
        if (icm.type === 'image' && icm.img){ const pre = new Image(); pre.src = src; loads.push(pre.decode ? pre.decode().catch(() => {}) : Promise.resolve()); }
      } else {
        const im = new Image(); im.alt = ''; im.src = src; ic.appendChild(im);
        loads.push(im.decode ? im.decode().catch(() => {}) : Promise.resolve());
        if (icm.type === 'image' && icm.img) Fc.place(im, icm, iw, ih);
      }
      put(ic);
    }
    // 文字
    const sh = `text-shadow:0 ${(D * 0.004).toFixed(1)}px ${(D * 0.02).toFixed(1)}px rgba(0,0,0,.3)`;
    [[S2.script, 'tsc', txt.sc, scC], [S2.en, 'ten', txt.en, enC], [S2.cn, 'tcn', txt.cn, txC]].forEach(([sp, cls, s, col]) => {
      if (cls === 'tsc' && P.showScript === 'off') return;
      const d = textBox(sp, cls, Fc.mark(s), col, sh); if (d) put(d);
    });
    if (S2.dots){ const dd = document.createElement('div'); dd.className = 'dots'; const w = S2.dots.w * D;
      dd.style.cssText += `;left:${(S2.dots.x * D - w / 2).toFixed(1)}px;top:${(S2.dots.y * D).toFixed(1)}px;width:${w.toFixed(1)}px;border-top:${Math.max(1.5, D * 0.0035).toFixed(1)}px dotted ${lineC}`; put(dd); }
    if (person && S2.top) put(person, true);
    r.person = person;

    // 【区域I】高亮层：卡片里泛起高亮色的光 + 外圈一圈高亮色（透明度 = 高亮程度 0~1，用 FXSkin.applyColor 或自己写）
    const h1 = document.createElement('div'); h1.className = 'hl';
    h1.style.cssText += `;background:radial-gradient(circle at 50% 45%,${css(C.hi, 0.42)} 0%,${css(C.hi, 0.14)} 55%,${css(C.hi, 0)} 75%);z-index:4`;
    disc.appendChild(h1);
    const h2 = document.createElement('div'); h2.className = 'hl';
    h2.style.boxShadow = `0 0 0 ${(rim * 1.2).toFixed(1)}px ${css(C.hi)}, 0 0 ${(D * 0.09).toFixed(0)}px ${(D * 0.01).toFixed(0)}px ${css(C.hi, 0.75)}`;
    ly.appendChild(h2);
    r.hi.push(h1, h2);

    // 闪光层（可选）；明暗用两层蒙版做（比每帧改 brightness 滤镜省很多，规则 16）
    if (o.flash){
      const dk = document.createElement('div'); dk.className = 'shade'; dk.style.cssText += ';inset:0;z-index:5;background:#000';
      const lt = document.createElement('div'); lt.className = 'shade'; lt.style.cssText += `;inset:0;z-index:5;background:radial-gradient(circle at 50% 42%,${css(mix(base, W3, 0.75))} 0%,${css(mix(base, W3, 0.4))} 70%)`;
      disc.append(dk, lt); r.dark = dk; r.light = lt;
      // 闪光：从圆的边缘往里渐变，越靠近中心越透明；「闪光范围」= 从边缘往里亮多深（占半径的百分比）
      const rg = clamp(num(P.flashRange, 45), 5, 100), edgeC = css(mix(base, W3, 0.75), 0.7);
      const fl = document.createElement('div'); fl.className = 'flash';
      fl.style.cssText += `;inset:0;border-radius:50%;z-index:6;background:radial-gradient(circle closest-side at 50% 50%,rgba(255,255,255,0) ${(100 - rg).toFixed(1)}%,${edgeC} ${(100 - rg * 0.35).toFixed(1)}%,rgba(255,255,255,.95) 100%)`;
      disc.appendChild(fl); r.flash = fl;
      const sw = document.createElement('div'); sw.className = 'sweep'; sw.style.cssText += ';inset:-20%;z-index:6;background:linear-gradient(115deg,rgba(255,255,255,0) 40%,rgba(255,255,255,.75) 50%,rgba(255,255,255,0) 60%)';
      disc.appendChild(sw); r.sweep = sw;
    }
    // 编号小圆（压在上边框，跟着这一层一起糊 / 一起换色）
    const nm = TXT(o.num);
    if (nm){
      const bd = D * 0.1, b = document.createElement('div'); b.className = 'badge';
      b.style.cssText += `;left:${((D - bd) / 2).toFixed(1)}px;top:${(-bd * 0.62).toFixed(1)}px;width:${bd.toFixed(1)}px;height:${bd.toFixed(1)}px;font-size:${(bd * 0.48).toFixed(1)}px;`
        + `background:radial-gradient(circle at 50% 35%,#3a4152,#171b25);box-shadow:0 0 0 ${Math.max(1.5, bd * 0.035).toFixed(1)}px ${css(mix(base, W3, 0.6))},0 0 ${(bd * 0.3).toFixed(1)}px ${css(base, 0.8)}`;
      b.textContent = nm; ly.appendChild(b);
    }
    return r;
  };
})();
