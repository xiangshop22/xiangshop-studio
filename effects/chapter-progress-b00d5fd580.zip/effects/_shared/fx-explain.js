/* ===========================================================================
   fx-explain.js —— 讲解版式公共件（工作台公共模块，2026-11-12 新增）
   ---------------------------------------------------------------------------
   做什么：讲解类版式（时间轴、流程图、关系图、大公式条、文档荧光笔……）共用的零件，
           这几张卡只管自己的排版，卡片皮肤、「讲到哪亮哪」、箭头、右侧编辑器都从这里拿，不各写一份（规则 28）。
   来源：画面语言参考开源仓库 howoneai/xiaolin-explainer-packaging（MIT），按工作台规则重写成纯 HTML。
   谁在用：时间轴 timeline-axis、流程步骤 flow-steps、关系图 relation-graph、大公式条 formula-bar、文档荧光笔 doc-highlight、要点展开卡 point-expand-cards（v33.1）。
           别的效果都没引用它，所以加这个文件不影响任何老效果。

   区域地图（想改哪里，直接说「区域Ex 怎么改」）
   【区域E1 小工具】   缓动、插值、颜色换算、写样式前先比值（put）
   【区域E2 颜色】     卡片色 × 高亮色 → 常态字色 / 高亮字色（高亮色上面自动配深色字）
   【区域E3 讲到哪亮哪】每一项一个「亮起秒数」；模式 = 依次点亮（当前亮、其余压暗）/ 亮了就一直亮 / 全部常亮
   【区域E4 卡片】     一张讲解卡 = 底色层 + 高亮色层（只改透明度）+ 两份文字（常态 / 高亮，交叉淡入）
                      文字一律用文字转场模块画（FXTrans.draw 'static'，规则 39），所以 **重点** / *加粗* / ~划掉~ / | 换行 都认
                      卡片背景动效（规则 40）：自动标记，用户在右侧打开才画
   【区域E5 箭头 / 曲线】箭头三角、二次曲线（关系图、流程图用）
   【区域E6 编辑器】   右侧面板：一行一项的列表（＋ 加一项、↑ ↓ 调顺序、✕ 删掉），改完直接写 P（不派发 input，规则 6）
                      + 配色块（FXSkin.colorBlock，预设来自配色库 fx-palettes.js，规则 24）
   【区域E7 说明框】   v33.1：几个矩形合起来的外轮廓（框 + 包住当前卡片的舌头），虚线从卡片开始描出来，半透明底，可以挖一个镂空窗口
   【区域E8 说明框内容库】v33.1：圆头像 / 方图 / 文字要点 / 大数字 / 镂空，E.addBoxKind 往里加新样式
   【区域E9 要点卡】   v33.1：灰色空壳 → 颜色从左往右擦满 → 高亮 / 变灰
   【区域E10 版式库】  v33.1：卡片和说明框怎么摆（一列 / 一排 / 左列右框……），E.addPointLayout 往里加新版式，缩略图自动画
   【区域E11 样式 · 版式选择块】v33.1：要点卡 / 说明框的样式表、编辑器里按类型分组的版式缩略图
   引入顺序：fx-cards.js → fx-skin.js → fx-transition.js → fx-palettes.js → fx-explain.js → 效果脚本 → fx-video.js → view-controls.js
   =========================================================================== */
(function () {
  const E = window.FXExplain = window.FXExplain || {};

  // ================= 【区域E1 小工具】 =================
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  E.clamp = clamp;
  E.lerp = (a, b, k) => a + (b - a) * k;
  E.prog = (t, a, d) => clamp((t - a) / Math.max(1e-6, d));
  E.eout = k => 1 - Math.pow(1 - clamp(k), 3);
  E.eio = k => { k = clamp(k); return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2; };
  E.back = k => { k = clamp(k); const c = 1.5; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); };
  E.num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };
  E.f = x => (Math.round(x * 100) / 100).toString();
  // 写样式前先比值：每帧只写 transform / opacity，而且只在变了的时候写（规则 16）
  E.put = (el, tf, op) => {
    if (!el) return;
    if (tf != null && el.__tf !== tf){ el.style.transform = tf; el.__tf = tf; }
    if (op != null){ const o = Math.round(op * 1000) / 1000; if (el.__op !== o){ el.style.opacity = o; el.__op = o; el.style.visibility = o <= 0.001 ? 'hidden' : ''; } }
  };
  E.esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  E.plain = s => String(s == null ? '' : s).replace(/\*\*|\*|~~|~|==|\[\[|\]\]|__/g, '').replace(/\|/g, ' ');
  // 读一个 JSON 数组参数：坏字符串、不是数组都退回示例（规则 12：坏数据不能白屏）
  E.list = (raw, demo) => {
    let v = raw;
    if (typeof v === 'string'){ try { v = JSON.parse(v); } catch (e) { v = null; } }
    if (v && !Array.isArray(v) && Array.isArray(v.list)) v = v.list;
    if (!Array.isArray(v)) v = demo;
    v = v.filter(x => x && typeof x === 'object');
    return v.length ? v : demo;
  };

  // ================= 【区域E2 颜色】 =================
  const hex = c => { c = String(c || '').trim(); if (/^#[0-9a-f]{3}$/i.test(c)) c = '#' + c.slice(1).split('').map(x => x + x).join(''); return /^#[0-9a-f]{6}$/i.test(c) ? c.toLowerCase() : null; };
  const rgb = c => { const n = parseInt(c.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const toHex = a => '#' + a.map(x => clamp(Math.round(x), 0, 255).toString(16).padStart(2, '0')).join('');
  E.hex = hex; E.rgb = c => rgb(hex(c) || '#000000');
  E.mix = (a, b, k) => { const A = rgb(hex(a) || '#000000'), B = rgb(hex(b) || '#000000'); return toHex(A.map((x, i) => x + (B[i] - x) * k)); };
  E.rgba = (c, a) => { const A = rgb(hex(c) || '#000000'); return `rgba(${A[0]},${A[1]},${A[2]},${a})`; };
  const lum = c => { const A = rgb(c); return (0.2126 * A[0] + 0.7152 * A[1] + 0.0722 * A[2]) / 255; };
  // 卡片色上放浅字、高亮色上放深字；卡片色太浅时字自动变深（反之亦然），保证看得清
  E.colors = (P, defCard, defHi) => {
    const card = hex(P.cCard) || defCard || '#2e2d33', hi = hex(P.cHi) || defHi || '#f28c0f';
    const ink = lum(card) > 0.6 ? E.mix(card, '#000000', 0.82) : E.mix(card, '#ffffff', 0.86);
    const hiInk = lum(hi) > 0.45 ? E.mix(hi, '#000000', 0.78) : E.mix(hi, '#ffffff', 0.92);
    return { card, hi, ink, hiInk, sub: E.rgba(ink, 0.62), hiSub: E.rgba(hiInk, 0.75) };
  };

  // ================= 【区域E3 讲到哪亮哪】 =================
  // at[i] = 第 i 项亮起的秒数（已经按「自动 / 手填」算好）；fade = 亮 / 暗之间渐变多少秒
  // mode: 'step' 依次点亮，下一项亮起时上一项压暗；'keep' 亮了就一直亮；'all' 出现就是亮的；'none' 都不亮
  E.lit = (at, i, t, mode, fade) => {
    fade = Math.max(0.05, fade || 0.35);
    if (mode === 'none') return 0;
    if (mode === 'all') return 1;
    const on = E.prog(t, at[i], fade);
    if (mode === 'keep') return E.eio(on);
    // 下一个亮起时间比它晚的那一项
    let nx = Infinity; at.forEach((a, j) => { if (j !== i && a > at[i] && a < nx) nx = a; });
    return E.eio(on) * (1 - E.eio(E.prog(t, nx, fade)));
  };
  // 每项的亮起时间：手填了就用手填的（秒，从素材开头算），否则 = 出现时间 + 自动偏移
  E.times = (items, base, step, delay) => items.map((it, i) => {
    const v = parseFloat(it.t); return isFinite(v) && it.t !== '' ? Math.max(0, v) : base + i * step + (delay || 0);
  });

  // ================= 【区域E4 卡片】 =================
  E.stageCss = `
.fxe-card{position:absolute;left:0;top:0;will-change:transform,opacity;contain:layout style}
.fxe-card .fxe-sk{position:absolute;inset:0;border-radius:var(--r,12px)}
.fxe-card .fxe-base{box-shadow:0 18px 40px rgba(0,0,0,.45),0 2px 3px rgba(0,0,0,.35),inset 0 2px 0 rgba(255,255,255,.12),inset 0 -3px 0 rgba(0,0,0,.22)}
.fxe-card .fxe-lit{opacity:0;box-shadow:inset 0 2px 0 rgba(255,255,255,.35),inset 0 -3px 0 rgba(0,0,0,.18)}
.fxe-card .fxe-tx{position:absolute;inset:0;border-radius:var(--r,12px)}
.fxe-card .fxe-tx.on{opacity:0}
.fxe-card .fxe-num{position:absolute;left:20px;top:12px;font:800 28px/1 "DIN Alternate","Bahnschrift","Arial Narrow",sans-serif;letter-spacing:.04em}
.fxe-card .fxe-t,.fxe-card .fxe-s{position:absolute;left:14px;right:14px}
.fxe-card .fxe-s{font-weight:600;letter-spacing:.06em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}
.fxe-pill{position:absolute;left:0;top:0;white-space:nowrap;font-weight:800;border-radius:.32em;padding:.2em .55em;line-height:1.15;box-shadow:0 6px 14px rgba(0,0,0,.25);will-change:transform,opacity}
`;
  E.FONT = "'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif";   // 单引号：文字转场模块把它写进 style="..." 里
  E.injectStage = () => { if (document.getElementById('fxe-stage-css')) return; const s = document.createElement('style'); s.id = 'fxe-stage-css'; s.textContent = E.stageCss; document.head.appendChild(s); };
  const drawText = (el, txt, o) => {
    if (window.FXTrans) FXTrans.draw(el, { id: 'static', b: txt, fs: o.fs, color: o.color, accent: o.accent, bold: true, font: E.FONT, lh: 1.12, ls: 0.03 });
    else el.textContent = E.plain(txt);
  };
  // o = { w, h, t: 标题, s: 小字, num: '01', fs, ss, C: E.colors(), round, index, seed, r }
  // 返回 { el, set(lit) }：lit 0~1 只改两层透明度（文字颜色不每帧改）
  E.card = o => {
    const w = o.w, h = o.h, C = o.C, r = o.round ? Math.min(w, h) / 2 : (o.r == null ? 12 : o.r);
    const el = document.createElement('div'); el.className = 'fxe-card';
    el.style.cssText = `width:${w}px;height:${h}px;--r:${r}px`;
    const base = document.createElement('div'); base.className = 'fxe-sk fxe-base'; base.style.background = `linear-gradient(180deg,${E.mix(C.card, '#ffffff', 0.06)},${E.mix(C.card, '#000000', 0.12)})`;
    const lit = document.createElement('div'); lit.className = 'fxe-sk fxe-lit'; lit.style.background = `linear-gradient(180deg,${E.mix(C.hi, '#ffffff', 0.12)},${C.hi})`;
    el.append(base, lit);
    const fs = o.fs || Math.round(h * 0.3), ss = o.ss || Math.round(fs * 0.48);
    const mkTx = (on) => {
      const tx = document.createElement('div'); tx.className = 'fxe-tx' + (on ? ' on' : '');
      const ink = on ? C.hiInk : C.ink, sub = on ? C.hiSub : C.sub;
      if (o.num){ const n = document.createElement('div'); n.className = 'fxe-num'; n.textContent = o.num; n.style.color = sub; tx.appendChild(n); }
      const hasS = !!(o.s && String(o.s).trim());
      const tt = document.createElement('div'); tt.className = 'fxe-t';
      const th = hasS ? h * 0.62 : h; tt.style.cssText = `top:${hasS ? h * 0.06 : 0}px;height:${th}px`;
      if (o.num && !hasS){ tt.style.top = h * 0.08 + 'px'; tt.style.height = h * 0.92 + 'px'; }
      drawText(tt, o.t, { fs, color: ink, accent: on ? E.mix(C.hiInk, '#ff2a00', 0.35) : C.hi });
      tx.appendChild(tt);
      if (hasS){ const s = document.createElement('div'); s.className = 'fxe-s'; s.style.cssText = `top:${h * 0.66}px;font-size:${ss}px;color:${sub};font-family:${E.FONT}`; s.textContent = E.plain(o.s); tx.appendChild(s); }
      return tx;
    };
    const t0 = mkTx(false), t1 = mkTx(true);
    el.append(t0, t1);
    // 卡片背景动效（规则 40）：只做标记，用户在右侧打开才画；画在底色上面、文字下面
    if (window.FXCardBg) try { FXCardBg.mark(el, { after: lit, index: o.index || 0, seed: o.seed || (o.index || 0) * 17 + 3, radius: r, w, h }); } catch (e) {}
    let last = -1;
    return {
      el, w, h,
      set(k){
        k = Math.round(clamp(k) * 200) / 200; if (k === last) return; last = k;
        lit.style.opacity = k; t1.style.opacity = k; t0.style.opacity = 1 - k;
      }
    };
  };
  // 胶囊标签（箭头上的说明、公式下的小注）
  E.pill = (txt, o) => {
    const el = document.createElement('div'); el.className = 'fxe-pill';
    el.style.cssText = `font-size:${o.fs || 30}px;background:${o.bg};color:${o.ink};font-family:${E.FONT}`;
    el.textContent = E.plain(txt); return el;
  };

  // ================= 【区域E5 箭头 / 曲线】 =================
  // 在 (x, y) 处、朝角度 a（弧度）的实心箭头，返回 SVG polygon 的 points
  E.head = (x, y, a, s = 22) => {
    const p = (r, da) => `${(x + r * Math.cos(a + da)).toFixed(1)},${(y + r * Math.sin(a + da)).toFixed(1)}`;
    return `${p(0, 0)} ${p(-s, 0.42)} ${p(-s * 0.72, 0)} ${p(-s, -0.42)}`;
  };
  // A → B 的二次曲线，bend = 往一侧弯多少（弦长的比例）；at(u) 取线上的点，ang(u) 取切线角度
  E.quad = (ax, ay, bx, by, bend = 0) => {
    const mx = (ax + bx) / 2, my = (ay + by) / 2, dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy) || 1;
    const cx = mx - (dy / L) * bend * L, cy = my + (dx / L) * bend * L;
    const at = u => [(1 - u) * (1 - u) * ax + 2 * (1 - u) * u * cx + u * u * bx, (1 - u) * (1 - u) * ay + 2 * (1 - u) * u * cy + u * u * by];
    const ang = u => Math.atan2(2 * (1 - u) * (cy - ay) + 2 * u * (by - cy), 2 * (1 - u) * (cx - ax) + 2 * u * (bx - cx));
    return { d: `M${ax.toFixed(1)} ${ay.toFixed(1)}Q${cx.toFixed(1)} ${cy.toFixed(1)} ${bx.toFixed(1)} ${by.toFixed(1)}`, at, ang, len: L };
  };
  // 舞台：1920×1080 居中缩放到窗口
  E.fit = stage => { const s = Math.min(innerWidth / 1920, innerHeight / 1080); stage.style.transform = `translate(-50%,-50%) scale(${s})`; };

  // ================= 【区域E6 编辑器】 =================
  const EDCSS = `
html body #params .stc .fxe-row{display:block!important;margin:0 0 6px!important;padding:7px 8px!important;border:1px solid #262626!important;border-radius:8px!important;background:#161616!important}
html body #params .stc .fxe-h{display:flex!important;align-items:center!important;gap:5px!important;margin:0!important}
html body #params .stc .fxe-n{flex:none!important;font-size:10.5px!important;color:#888!important;border:1px solid #333!important;border-radius:4px!important;padding:1px 5px!important;line-height:1.4!important;min-width:14px!important;text-align:center!important}
html body #params .stc .fxe-g{display:flex!important;flex-wrap:wrap!important;gap:5px!important;margin:5px 0 0!important}
html body #params .stc .fxe-f{display:flex!important;flex-direction:column!important;gap:2px!important;flex:1 1 80px!important;min-width:0!important;margin:0!important}
html body #params .stc .fxe-f.w2{flex-basis:100%!important}
html body #params .stc .fxe-f.sm{flex:0 0 64px!important}
html body #params .stc .fxe-f.sm2{flex:0 0 96px!important}
html body #params .stc .fxe-nw{display:flex!important;gap:3px!important;align-items:center!important;min-width:0!important}
html body #params .stc .fxe-nw input.fxe-i{flex:1!important}
html body #params .stc .fxe-f>span{font-size:10.5px!important;color:#777!important;white-space:nowrap!important}
html body #params .stc input.fxe-i,html body #params .stc select.fxe-i{width:100%!important;min-width:0!important;height:26px!important;box-sizing:border-box!important;margin:0!important;padding:3px 7px!important;font-size:12.5px!important;background:#0e0e0e!important;color:#ddd!important;border:1px solid #2c2c2c!important;border-radius:5px!important;font-family:inherit!important}
html body #params .stc input.fxe-i:focus,html body #params .stc select.fxe-i:focus{border-color:#f28c0f!important;outline:none!important}
html body #params .stc .fxe-h input.fxe-i{flex:1!important}
html body #params .stc button.fxe-b{flex:none!important;width:auto!important;height:24px!important;min-width:24px!important;margin:0!important;padding:0 6px!important;font-size:12px!important;border-radius:5px!important;cursor:pointer!important;font-family:inherit!important;border:1px solid #333!important;background:#1d1d1d!important;color:#aaa!important;line-height:1!important}
html body #params .stc button.fxe-b:hover{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc button.fxe-b:disabled{opacity:.35!important;cursor:default!important}
html body #params .stc button.fxe-add{display:block!important;width:100%!important;height:28px!important;margin:4px 0 0!important;border:1px dashed #444!important;background:transparent!important;color:#aaa!important;border-radius:6px!important;cursor:pointer!important;font-size:12px!important;font-family:inherit!important}
html body #params .stc button.fxe-add:hover{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc .fxe-note{font-size:11px!important;color:#777!important;line-height:1.6!important;margin:6px 0 0!important}
html body #params .stc .fxe-note b{color:#bbb!important;font-weight:600!important}
html body #params .stc .fxe-seg{display:flex!important;flex-wrap:wrap!important;gap:4px!important;margin:0 0 8px!important}
html body #params .stc .fxe-seg button{flex:1 1 auto!important;width:auto!important;height:26px!important;margin:0!important;padding:0 8px!important;font-size:12px!important;border-radius:5px!important;cursor:pointer!important;font-family:inherit!important;white-space:nowrap!important;border-width:1px!important;border-style:solid!important}
html body #params .stc .fxe-seg button:not(.on){background:#1d1d1d!important;color:#aaa!important;border-color:#333!important}
html body #params .stc .fxe-seg button.on{border-color:#f28c0f!important;color:#f28c0f!important;background:#24190b!important}
`;
  const injectEd = pd => { if (pd.getElementById('fxe-ed-style')) return; const s = pd.createElement('style'); s.id = 'fxe-ed-style'; s.textContent = EDCSS; pd.head.appendChild(s); };

  /* E.mount(o)：把编辑器装进工作台右侧面板
     o = { tag: 效果简称（class 名用）, P, hide: [要藏掉的原始参数名开头], anchor: 插在哪一行参数前面（参数名开头）,
           blocks: (ctx) => [元素, ...]   ctx = { pd, pw, mk, fieldOf, dirty, save(key, value) } }
     已经装过（面板没重建）就只调 o.refresh */
  E.mount = o => {
    let pd, pw;
    try { if (window.parent === window) return null; pw = window.parent; pd = pw.document; } catch (e) { return null; }
    const box = pd.getElementById('params'); if (!box) return null;
    // 已经装过：只刷新；正在里面打字时不刷新（否则光标会跳走）
    if (o.ed.mounted && box.contains(o.ed.mounted)){ if (!o.ed.mounted.contains(pd.activeElement)) o.ed.refresh && o.ed.refresh(); return o.ed.mounted; }
    box.querySelectorAll('.stc.fxe-' + o.tag).forEach(x => x.remove());
    const labelOf = el => (el.firstChild && el.firstChild.nodeType === 3 ? el.firstChild.textContent : el.textContent || '').trim();
    const kids = [...box.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);
    const row = name => kids.find(el => el.tagName === 'LABEL' && labelOf(el) === name) || kids.find(el => el.tagName === 'LABEL' && labelOf(el).startsWith(name));
    const anchor = row(o.anchor); if (!anchor) return null;
    // 按参数名整个对上才藏（写成「xx·」结尾的按开头对：自定义·卡片色、自定义·高亮色）；别按开头对，免得把「循环线上的字」也藏了
    const hit = (lb, h) => h.endsWith('·') ? lb.startsWith(h) : lb === h;
    (o.hide || []).forEach(h => kids.filter(el => el.tagName === 'LABEL' && hit(labelOf(el), h)).forEach(el => el.style.display = 'none'));
    const fieldOf = name => { const r = row(name); return r && r.querySelector('input,select,textarea'); };
    if (window.FXSkin) FXSkin.injectStyle(pd);
    injectEd(pd);
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const dirty = () => { try { pw.markDirty && pw.markDirty(); } catch (e) {} try { pw.histSoon && pw.histSoon(); } catch (e) {} };
    const ctx = { pd, pw, mk, fieldOf, dirty };
    // 改一个参数：写 P + 同步隐藏的原始输入框（导出 / 撤销读的都是 P），不派发 input（规则 6）
    ctx.save = (key, label, value) => { o.P[key] = value; const f = fieldOf(label); if (f) f.value = value; dirty(); };
    const wrap = mk('div', 'stc fxe-' + o.tag); wrap.dataset.fxContent = '1';
    (o.blocks(ctx) || []).forEach(b => b && wrap.appendChild(b));
    // 放在「持续时间」正下方的 .fxtop（规则 37）；老工作台没有就插在原来那一行前面
    const top = box.querySelector(':scope > .fxtop');
    if (top) top.appendChild(wrap); else anchor.parentNode.insertBefore(wrap, anchor);
    o.ed.mounted = wrap;
    return wrap;
  };

  /* 一块「选择」按钮条（排版、点亮方式这种 select 参数），点了直接写 P 并重画
     o = { ctx, P, key, label: 参数名, opts: [[值, 名字, 鼠标提示]], apply } */
  E.seg = o => {
    const { ctx, P } = o, el = ctx.mk('div', 'fxe-seg');
    const draw = () => {
      el.innerHTML = '';
      o.opts.forEach(([v, name, tip]) => {
        const b = ctx.mk('button', P[o.key] === v ? 'on' : '', E.esc(name)); b.type = 'button'; if (tip) b.title = tip;
        b.onclick = () => { ctx.save(o.key, o.label, v); draw(); o.apply(); };
        el.appendChild(b);
      });
    };
    draw(); el.refresh = draw; return el;
  };

  /* 一行一项的列表编辑器
     o = { ctx, P, key: 参数 key, label: 参数名（隐藏的那一行）, demo, title, sub, note, max, min,
           fields: [{ k, name, ph, type: 'text'|'num'|'sel', opts:[[值,名字]], cls: 'w2'|'sm', head: true（放在标题行） }],
           blank: () => 新的一项, apply: () => 重排重画, rowName: i => '01' }
     返回 { el, refresh } */
  E.listBlock = o => {
    const { ctx, P } = o, mk = ctx.mk;
    const el = mk('div', 'stc-b');
    el.innerHTML = `<div class="stc-t"><b>${o.title}</b><span>${o.sub || ''}</span></div>`;
    const box = mk('div'); el.appendChild(box);
    const add = mk('button', 'fxe-add', '＋ 加一项'); add.type = 'button'; el.appendChild(add);
    if (o.note) el.appendChild(mk('div', 'fxe-note', o.note));
    let L = [];
    const read = () => { L = E.list(P[o.key], o.demo).map(x => Object.assign({}, x)); };
    const save = () => { ctx.save(o.key, o.label, JSON.stringify(L)); o.apply(); };
    const input = (f, it) => {
      let inp;
      if (f.type === 'sel'){
        inp = mk('select', 'fxe-i');
        const opts = typeof f.opts === 'function' ? f.opts() : f.opts;   // 可以是函数：选项跟着别的内容变（如关系图的节点名）
        opts.forEach(([v, n]) => { const op = mk('option', '', E.esc(n)); op.value = v; inp.appendChild(op); });
        inp.value = it[f.k] == null || !opts.some(x => String(x[0]) === String(it[f.k])) ? opts[0][0] : String(it[f.k]);
        inp.onchange = () => { it[f.k] = inp.value; save(); };
      } else {
        inp = mk('input', 'fxe-i'); inp.type = f.type === 'num' ? 'number' : 'text';
        if (f.type === 'num'){ inp.step = f.step || '0.1'; inp.min = '0'; }
        inp.placeholder = f.ph || ''; inp.value = it[f.k] == null ? '' : it[f.k];
        let tt = 0;
        inp.oninput = () => { it[f.k] = inp.value; clearTimeout(tt); tt = setTimeout(save, 220); };
        inp.onchange = () => { clearTimeout(tt); it[f.k] = inp.value; save(); };
      }
      if (f.tip) inp.title = f.tip;
      // f.now（可选，2026-11-12）：输入框旁边多一个「◆」按钮，点一下 = 填进进度条现在这一秒（像打关键帧那样）
      if (f.now && f.type === 'num'){
        const wrap = mk('div', 'fxe-nw'); wrap.appendChild(inp);
        const b = mk('button', 'fxe-b', '◆'); b.type = 'button'; b.title = f.nowTip || '填进进度条现在这一秒';
        b.onclick = () => { const v = Math.round(Math.max(0, +f.now() || 0) * 100) / 100; it[f.k] = String(v); inp.value = it[f.k]; save(); };
        wrap.appendChild(b);
        return wrap;
      }
      return inp;
    };
    const draw = () => {
      box.innerHTML = '';
      L.forEach((it, i) => {
        const r = mk('div', 'fxe-row'), h = mk('div', 'fxe-h');
        h.appendChild(mk('span', 'fxe-n', o.rowName ? o.rowName(i) : String(i + 1)));
        o.fields.filter(f => f.head).forEach(f => h.appendChild(input(f, it)));
        const btn = (txt, tip, fn, off) => { const b = mk('button', 'fxe-b', txt); b.type = 'button'; b.title = tip; b.disabled = !!off; b.onclick = fn; h.appendChild(b); };
        btn('↑', '往前挪', () => { [L[i - 1], L[i]] = [L[i], L[i - 1]]; save(); draw(); }, i === 0);
        btn('↓', '往后挪', () => { [L[i + 1], L[i]] = [L[i], L[i + 1]]; save(); draw(); }, i === L.length - 1);
        btn('✕', '删掉这一项', () => { L.splice(i, 1); save(); draw(); }, L.length <= (o.min || 1));
        r.appendChild(h);
        const rest = o.fields.filter(f => !f.head);
        if (rest.length){
          const g = mk('div', 'fxe-g');
          rest.forEach(f => { const w = mk('label', 'fxe-f' + (f.cls ? ' ' + f.cls : '')); w.appendChild(mk('span', '', f.name)); w.appendChild(input(f, it)); g.appendChild(w); });
          r.appendChild(g);
        }
        box.appendChild(r);
      });
      add.disabled = L.length >= (o.max || 12);
      add.textContent = L.length >= (o.max || 12) ? `最多 ${o.max || 12} 项` : '＋ 加一项';
    };
    add.onclick = () => { if (L.length >= (o.max || 12)) return; L.push(o.blank(L.length)); save(); draw(); };
    const refresh = () => { read(); draw(); };
    refresh();
    return { el, refresh };
  };

  // 配色块：卡片色 × 高亮色（规则 24：只给色块，不让敲数值）
  // names（可选）= { a: 左边颜色的名字, b: 右边的名字, sub, own: 自带预设 [{c,name}], noLib: 不要配色库 }
  E.colorBlock = (ctx, P, apply, defs, names) => {
    if (!window.FXSkin) return null;
    const N = names || {};
    const lib = (!N.noLib && window.FXPalettes && Array.isArray(FXPalettes.pairs)) ? FXPalettes.pairs : [];
    const own = (N.own || [{ c: [defs[0], defs[1]], name: '默认（深卡 × 橙）' }]).concat(lib);
    let cb = null;
    const wrap = ctx.mk('div', 'stc-b');
    cb = FXSkin.colorBlock({
      pd: ctx.pd, pw: ctx.pw, P, field: ctx.fieldOf, bare: true, title: '配色', sub: N.sub || '左半 卡片色 · 右半 高亮色',
      keys: [{ key: 'cCard', name: N.a || '卡片色', tip: N.at || '常态时卡片的颜色', field: '自定义·卡片色', def: defs[0] },
             { key: 'cHi', name: N.b || '高亮色', tip: N.bt || '讲到这一项时卡片变成的颜色', field: '自定义·高亮色', def: defs[1] }],
      presets: own,
      apply: () => { ctx.dirty(); apply(); cb && cb.refresh(); }
    });
    wrap.appendChild(cb.el);
    wrap.refresh = () => cb.refresh();
    return wrap;
  };
  /* ===========================================================================
     以下 E7 ~ E11 是 2026-11-13 为「要点展开卡 point-expand-cards」新加的（v33.1）。
     只新增函数，上面 E1 ~ E6 一个字没改，所以原来用 FXExplain 的 5 个效果画面不变。
     这几块做成公共的，是为了以后别的讲解卡（流程步骤、层级结构图……）也能直接用「说明框」和「版式库」：
       · 看到好的排版 → 往 E.POINT_LAYOUTS 里加一项（E.addPointLayout）
       · 想到新的说明框内容 → 往 E.BOX_KINDS 里加一项（E.addBoxKind）
     不用再重新设计卡片。
     =========================================================================== */

  // ================= 【区域E7 说明框（虚线框）】 =================
  // 几个矩形合起来的外轮廓（只有横竖边的多边形）。格子法：所有矩形的边把平面切成格子，
  // 格子中心在任一矩形里 = 里面；里外交界的边按顺时针串起来就是轮廓。返回 [[x, y], ...]
  E.unionOutline = rects => {
    const r1 = v => Math.round(v * 10) / 10;
    const xs = [...new Set(rects.flatMap(r => [r1(r.x), r1(r.x + r.w)]))].sort((a, b) => a - b);
    const ys = [...new Set(rects.flatMap(r => [r1(r.y), r1(r.y + r.h)]))].sort((a, b) => a - b);
    const nx = xs.length - 1, ny = ys.length - 1;
    const IN = (i, j) => {
      if (i < 0 || j < 0 || i >= nx || j >= ny) return false;
      const cx = (xs[i] + xs[i + 1]) / 2, cy = (ys[j] + ys[j + 1]) / 2;
      return rects.some(r => cx > r.x && cx < r.x + r.w && cy > r.y && cy < r.y + r.h);
    };
    const nxt = new Map(), key = (i, j) => i + ',' + j;
    const add = (a, b) => nxt.set(key(a[0], a[1]), b);
    for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) {
      if (!IN(i, j)) continue;
      if (!IN(i, j - 1)) add([i, j], [i + 1, j]);             // 上边：左 → 右
      if (!IN(i + 1, j)) add([i + 1, j], [i + 1, j + 1]);     // 右边：上 → 下
      if (!IN(i, j + 1)) add([i + 1, j + 1], [i, j + 1]);     // 下边：右 → 左
      if (!IN(i - 1, j)) add([i, j + 1], [i, j]);             // 左边：下 → 上
    }
    if (!nxt.size) return [];
    // 从最左上的点出发串一圈
    let start = [...nxt.keys()].map(k => k.split(',').map(Number)).sort((a, b) => a[1] - b[1] || a[0] - b[0])[0];
    const loop = []; let cur = start, guard = 0;
    do { loop.push(cur); cur = nxt.get(key(cur[0], cur[1])); guard++; } while (cur && (cur[0] !== start[0] || cur[1] !== start[1]) && guard < 400);
    // 去掉一条直线上的中间点
    const pts = loop.map(([i, j]) => [xs[i], ys[j]]);
    const out = pts.filter((p, k) => {
      const a = pts[(k - 1 + pts.length) % pts.length], b = pts[(k + 1) % pts.length];
      return !((a[0] === p[0] && p[0] === b[0]) || (a[1] === p[1] && p[1] === b[1]));
    });
    return out;
  };
  // 多边形 → 圆角路径（凸角、凹角都用二次曲线倒圆）。返回 { d, len }，len 是大约的周长（给描边动画用）
  E.roundPath = (pts, r, startNear) => {
    const n = pts.length; if (n < 3) return { d: '', len: 0 };
    let s = 0;
    if (startNear){ let best = Infinity; pts.forEach((p, i) => { const d = Math.hypot(p[0] - startNear.x, p[1] - startNear.y); if (d < best){ best = d; s = i; } }); }
    const P2 = pts.slice(s).concat(pts.slice(0, s));
    const A = [], B = []; let len = 0;
    P2.forEach((p, i) => {
      const a = P2[(i - 1 + n) % n], b = P2[(i + 1) % n];
      const d1 = Math.hypot(a[0] - p[0], a[1] - p[1]), d2 = Math.hypot(b[0] - p[0], b[1] - p[1]);
      const rr = Math.min(r, d1 / 2, d2 / 2);
      A.push([p[0] + (a[0] - p[0]) / d1 * rr, p[1] + (a[1] - p[1]) / d1 * rr]);
      B.push([p[0] + (b[0] - p[0]) / d2 * rr, p[1] + (b[1] - p[1]) / d2 * rr]);
      len += d2 - 2 * rr + rr * 1.58;
    });
    const f = v => E.f(v);
    let d = `M${f(A[0][0])} ${f(A[0][1])}`;
    P2.forEach((p, i) => { d += `Q${f(p[0])} ${f(p[1])} ${f(B[i][0])} ${f(B[i][1])}`; const nx = A[(i + 1) % n]; if (i < n - 1) d += `L${f(nx[0])} ${f(nx[1])}`; });
    return { d: d + 'Z', len: Math.max(1, len) };
  };
  const SVGNS = 'http://www.w3.org/2000/svg';
  /* E.detailBox(o)：一个说明框 = 外轮廓（框 + 包住当前卡片的「舌头」合在一起）+ 半透明底 + 放内容的格子
     o = { rects: [框, 舌头...], from: {x, y} 从哪儿开始描（卡片中心）, area: {x, y, w, h} 内容区,
           k: 大小倍数, line: 线色, style: 'dash' | 'solid', fill: 底色（rgba）, hole: {x, y, w, h} 镂空（底色在这里挖掉）, r: 圆角 }
     返回 { el, host, set(open 0~1, close 0~1) }：open = 描边进度，close = 收起进度（只改透明度和描边） */
  E.detailBox = o => {
    const k = o.k || 1, el = document.createElement('div'); el.className = 'fxp-box'; el.style.opacity = 0; el.style.visibility = 'hidden';
    const svg = document.createElementNS(SVGNS, 'svg'); svg.setAttribute('class', 'fxp-bsvg'); svg.setAttribute('width', 1920); svg.setAttribute('height', 1080);
    const RP = E.roundPath(E.unionOutline(o.rects), (o.r == null ? 22 : o.r) * k, o.from);
    const fill = document.createElementNS(SVGNS, 'path');
    let fd = RP.d;
    if (o.hole){ const h = o.hole; fd += `M${E.f(h.x)} ${E.f(h.y)}h${E.f(h.w)}v${E.f(h.h)}h${E.f(-h.w)}Z`; fill.setAttribute('fill-rule', 'evenodd'); }
    fill.setAttribute('d', fd); fill.setAttribute('fill', o.fill || 'rgba(8,10,16,.3)'); fill.style.opacity = 0;
    const line = document.createElementNS(SVGNS, 'path');
    line.setAttribute('d', RP.d); line.setAttribute('fill', 'none'); line.setAttribute('stroke', o.line || 'rgba(255,255,255,.78)');
    line.setAttribute('stroke-width', E.f(3.2 * k)); line.setAttribute('stroke-linecap', 'round'); line.setAttribute('stroke-linejoin', 'round');
    line.setAttribute('pathLength', E.f(RP.len));
    svg.append(fill, line);
    const host = document.createElement('div'); host.className = 'fxp-host';
    const A = o.area || { x: 0, y: 0, w: 0, h: 0 };
    host.style.cssText = `left:${E.f(A.x)}px;top:${E.f(A.y)}px;width:${E.f(A.w)}px;height:${E.f(A.h)}px`;
    el.append(svg, host);
    const L = RP.len, dash = o.style === 'solid' ? 0 : 13 * k, gap = 10 * k;
    // 描到 p：虚线时把「已经描出来的那一段」拼成一串 dash / gap，后面整段留空（每 1/160 才重算一次）
    const dashAt = p => {
      if (p >= 1) return dash ? `${E.f(dash)} ${E.f(gap)}` : 'none';
      const rev = p * L;
      if (!dash) return `${E.f(rev)} ${E.f(L * 2)}`;
      const n = Math.floor(rev / (dash + gap)), rem = rev - n * (dash + gap);
      return (`${E.f(dash)} ${E.f(gap)} `).repeat(n) + `${E.f(Math.min(rem, dash))} ${E.f(L * 2)}`;
    };
    let lastP = -1, lastO = -1;
    return {
      el, host, len: L,
      set(open, close){
        const p = Math.round(E.clamp(open) * 160) / 160;
        if (p !== lastP){ lastP = p; line.setAttribute('stroke-dasharray', p <= 0 ? `0 ${E.f(L * 2)}` : dashAt(p)); }
        const op = p <= 0 ? 0 : 1 - E.clamp(close);
        E.put(el, null, op);
        const fo = Math.round(E.eio(E.prog(open, 0.25, 0.75)) * 100) / 100;
        if (fo !== lastO){ lastO = fo; fill.style.opacity = fo; }
      }
    };
  };

  // ================= 【区域E8 说明框内容库】 =================
  /* 每一种内容 = { name, tip, max, fields: 编辑器里每一项要填的格子, build(host, items, o) → { play(秒) } }
     o = { w, h, k, C: { hi, hiInk, ink, sub, tint }, opt: 这个框的其他设置（如 lead） }
     play(s)：s = 框打开后过了几秒（< 0 = 还没打开），每帧调；每帧只写 transform / opacity。
     以后要加新的内容样式：E.addBoxKind('id', { ... })，要点展开卡的编辑器会自动多一个按钮。 */
  E.BOX_KINDS = {};
  E.BOX_ORDER = [];
  E.addBoxKind = (id, def) => { if (!E.BOX_KINDS[id]) E.BOX_ORDER.push(id); E.BOX_KINDS[id] = Object.assign({ id }, def); };
  const drawTx = (el, txt, fs, color, accent, o) => {
    o = o || {};
    const ls = o.ls == null ? 0.03 : o.ls;
    // 一行放不下就把字缩小（不换行、不溢出框外）：按格子宽度和文字转场模块的字宽估算
    const W = parseFloat(el.style.width);
    if (W > 0 && window.FXTrans && FXTrans.emWidth){ const em = FXTrans.emWidth(txt) + ls * E.plain(txt).length; if (em > 0) fs = Math.min(fs, W * 0.97 / em); }
    if (window.FXTrans) FXTrans.draw(el, { id: 'static', b: txt, fs, color, accent, bold: o.bold !== false, font: E.FONT, lh: o.lh || 1.12, ls });
    else el.textContent = E.plain(txt);
    // 靠左：文字转场模块默认居中，这里只把外面那层的对齐改成靠左（不改公共模块）
    if (o.align === 'left' && el.firstElementChild){ el.firstElementChild.style.justifyContent = 'flex-start'; const l = el.querySelector('.fxt-l'); if (l) l.style.textAlign = 'left'; }
  };
  E.drawTx = drawTx;
  const pop = (el, x, y, s0, k, op) => E.put(el, `translate(${E.f(x)}px,${E.f(y)}px) scale(${(s0 + (1 - s0) * E.back(k)).toFixed(3)})`, op == null ? E.clamp(k * 2) : op);
  const mkd = (cls, css) => { const d = document.createElement('div'); d.className = cls; if (css) d.style.cssText = css; return d; };
  // 照片：调过大小位置就按 FXCards.place 摆，没调过就铺满
  const putImg = (box, it, W, H) => {
    const im = document.createElement('img'); im.src = it.img; im.alt = ''; im.draggable = false;
    im.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;object-fit:cover';
    box.appendChild(im);
    if (window.FXCards && FXCards.place) try { FXCards.place(im, it, W, H); } catch (e) {}
  };
  // 半身人像（圆头像里的示例插画）
  E.bustSvg = (col, skin) => `<svg viewBox="0 0 100 100" width="100%" height="100%" style="position:absolute;inset:0"><circle cx="50" cy="40" r="17" fill="${skin || '#f1c9a5'}"/><path d="M50 22c-12 0-19 7-19 16 6-5 13-7 19-7s13 2 19 7c0-9-7-16-19-16z" fill="#2b2420"/><path d="M14 104c0-22 16-36 36-36s36 14 36 36z" fill="${col}"/><path d="M42 68l8 14 8-14z" fill="#fff" opacity=".9"/></svg>`;
  const SKINS = ['#f1c9a5', '#e2b48f', '#c98f66', '#f5d3b5', '#a8754f', '#eac09a'];
  const SHIRTS = ['#f2b233', '#e6463c', '#3fa7e0', '#5fc28a', '#9b6be0', '#ef7f3a'];

  // ① 圆头像格：圆形照片 + 一行大字 + 一行小字（第一项可以单独占一行当「领头」）
  E.addBoxKind('avatar', {
    name: '圆头像', tip: '一格一个人：圆形照片 + 名字 + 小字（像 CEO / COO / CFO）', max: 10,
    fields: [{ k: 'l', name: '大字', ph: 'CEO' }, { k: 's', name: '小字', ph: '首席执行官' }], img: 1,
    build(host, items, o){
      const k = o.k, C = o.C, lead = o.opt.lead !== 'off' && items.length > 2;
      const rest = items.slice(lead ? 1 : 0), n = rest.length;
      const cols = n <= 3 ? n : n === 4 ? 2 : n <= 9 ? 3 : 4;
      const rows = (lead ? 1 : 0) + Math.ceil(n / cols);
      const cw = o.w / Math.max(1, cols), ch = Math.min(o.h / rows, 230 * k * (o.tk || 1));
      const D = Math.min(ch * 0.78, cw * 0.4, 150 * k * (o.tk || 1));
      const y0 = (o.h - ch * rows) / 2;
      const cells = items.map((it, idx) => {
        const isLead = lead && idx === 0, j = lead ? idx - 1 : idx;
        const col = isLead ? 0 : j % cols, row = isLead ? 0 : (lead ? 1 : 0) + Math.floor(j / cols);
        const x = col * cw + cw * 0.04, y = y0 + row * ch + (ch - D) / 2;
        const cell = mkd('fxp-cell'); cell.style.transformOrigin = `${E.f(D / 2)}px ${E.f(D / 2)}px`;
        const dots = /^(\.{2,}|…+|。。。)$/.test(String(it.l || '').trim());
        if (dots){
          cell.innerHTML = `<div class="fxp-dots" style="width:${E.f(D)}px;height:${E.f(D)}px">${'<i></i>'.repeat(3)}</div>`;
        } else {
          const av = mkd('fxp-av', `width:${E.f(D)}px;height:${E.f(D)}px;background:${isLead ? C.hi : E.mix(C.tint, '#ffffff', 0.12)};box-shadow:0 0 0 ${E.f(D * 0.045)}px ${E.rgba('#000000', 0.25)},0 ${E.f(D * 0.06)}px ${E.f(D * 0.16)}px rgba(0,0,0,.35)`);
          if (it.img) putImg(av, it, D, D); else av.innerHTML = E.bustSvg(SHIRTS[idx % SHIRTS.length], SKINS[idx % SKINS.length]);
          cell.appendChild(av);
          const fs = D * (isLead ? 0.46 : 0.38), tw = cw - D * 1.25 - cw * 0.06;
          const t1 = mkd('fxp-tl', `left:${E.f(D * 1.2)}px;top:${E.f(D / 2 - fs * 0.95)}px;width:${E.f(Math.max(40, tw))}px;height:${E.f(fs * 1.15)}px`);
          drawTx(t1, it.l || '', fs, isLead ? C.hi : C.ink, C.hi, { align: 'left', ls: 0.02 });
          cell.appendChild(t1);
          if (it.s && String(it.s).trim()){
            const ss = fs * 0.46, t2 = mkd('fxp-ts', `left:${E.f(D * 1.2)}px;top:${E.f(D / 2 + fs * 0.32)}px;width:${E.f(Math.max(40, tw))}px;font-size:${E.f(ss)}px;color:${C.sub};font-family:${E.FONT}`);
            t2.textContent = E.plain(it.s); cell.appendChild(t2);
          }
        }
        host.appendChild(cell);
        return { cell, x, y, a: 0.3 + idx * 0.09 };
      });
      return { play(s){ cells.forEach(c => pop(c.cell, c.x, c.y, 0.4, E.prog(s, c.a, 0.42))); } };
    }
  });

  // ② 方图卡：方形照片 + 下面一行字
  E.addBoxKind('tiles', {
    name: '方图', tip: '一排方形照片，每张下面一行字（产品、地点、作品）', max: 8,
    fields: [{ k: 'l', name: '大字', ph: '名字' }, { k: 's', name: '小字', ph: '可空' }], img: 1,
    build(host, items, o){
      const k = o.k, C = o.C, n = items.length, cols = n <= 4 ? n : Math.ceil(n / 2), rows = Math.ceil(n / cols);
      const cw = o.w / cols, rh = o.h / rows;
      const S = Math.min(cw * 0.86, rh * 0.72, 380 * k * (o.tk || 1)), fs = S * 0.13;
      const y0 = (o.h - rows * rh) / 2;
      const cells = items.map((it, i) => {
        const col = i % cols, row = Math.floor(i / cols);
        const x = col * cw + (cw - S) / 2, y = y0 + row * rh + (rh - S - fs * 2.6) / 2;
        const cell = mkd('fxp-cell'); cell.style.transformOrigin = `${E.f(S / 2)}px ${E.f(S / 2)}px`;
        const tl = mkd('fxp-tile', `width:${E.f(S)}px;height:${E.f(S)}px;border-radius:${E.f(S * 0.08)}px;background:linear-gradient(150deg,${E.mix(E.hueShift(C.tint, i * 22), '#ffffff', 0.18)},${E.mix(E.hueShift(C.tint, i * 22), '#000000', 0.35)})`);
        if (it.img) putImg(tl, it, S, S);
        else { const big = mkd('fxp-tbig', `font-size:${E.f(S * 0.42)}px;font-family:${E.FONT}`); big.textContent = E.plain(it.l || '').slice(0, 1); tl.appendChild(big); }
        cell.appendChild(tl);
        const t1 = mkd('fxp-tl', `left:${E.f(-S * 0.1)}px;top:${E.f(S + fs * 0.45)}px;width:${E.f(S * 1.2)}px;height:${E.f(fs * 1.2)}px`);
        drawTx(t1, it.l || '', fs, C.ink, C.hi); cell.appendChild(t1);
        if (it.s && String(it.s).trim()){ const t2 = mkd('fxp-ts', `left:${E.f(-S * 0.1)}px;top:${E.f(S + fs * 1.75)}px;width:${E.f(S * 1.2)}px;text-align:center;font-size:${E.f(fs * 0.62)}px;color:${C.sub};font-family:${E.FONT}`); t2.textContent = E.plain(it.s); cell.appendChild(t2); }
        host.appendChild(cell);
        return { cell, x, y, a: 0.3 + i * 0.1 };
      });
      return { play(s){ cells.forEach(c => pop(c.cell, c.x, c.y, 0.6, E.prog(s, c.a, 0.45))); } };
    }
  });

  // ③ 文字要点：一行一条，前面一个编号圆点
  E.addBoxKind('list', {
    name: '文字要点', tip: '一行一条要点，前面带编号；**重点** 用高亮色', max: 6,
    fields: [{ k: 'l', name: '要点', ph: '一句话，**重点**' }, { k: 's', name: '小字', ph: '可空' }],
    build(host, items, o){
      const k = o.k * (o.tk || 1), C = o.C, n = items.length;
      const rh = Math.min(o.h / n, 170 * k), fs = Math.min(rh * 0.36, 60 * k), y0 = (o.h - rh * n) / 2;
      const cells = items.map((it, i) => {
        const hasS = !!(it.s && String(it.s).trim());
        const y = y0 + i * rh, B = fs * 1.25;
        const cell = mkd('fxp-cell');
        cell.innerHTML = `<div class="fxp-badge" style="width:${E.f(B)}px;height:${E.f(B)}px;top:${E.f((rh - B) / 2 - (hasS ? fs * 0.3 : 0))}px;background:${C.hi};color:${C.hiInk};font-size:${E.f(B * 0.46)}px">${String(i + 1).padStart(2, '0')}</div>`;
        const t1 = mkd('fxp-tl', `left:${E.f(B * 1.45)}px;top:${E.f((rh - fs * 1.2) / 2 - (hasS ? fs * 0.3 : 0))}px;width:${E.f(o.w - B * 1.6)}px;height:${E.f(fs * 1.2)}px`);
        drawTx(t1, it.l || '', fs, C.ink, C.hi, { align: 'left' }); cell.appendChild(t1);
        if (hasS){ const t2 = mkd('fxp-ts', `left:${E.f(B * 1.45)}px;top:${E.f(rh / 2 + fs * 0.42)}px;width:${E.f(o.w - B * 1.6)}px;font-size:${E.f(fs * 0.5)}px;color:${C.sub};font-family:${E.FONT}`); t2.textContent = E.plain(it.s); cell.appendChild(t2); }
        host.appendChild(cell);
        return { cell, y, a: 0.3 + i * 0.16 };
      });
      return { play(s){ cells.forEach(c => { const q = E.eout(E.prog(s, c.a, 0.45)); E.put(c.cell, `translate(${E.f((1 - q) * -40 * k)}px,${E.f(c.y)}px)`, q); }); } };
    }
  });

  // ④ 大数字：一到四个大数字并排，数字翻滚出来（文字转场的「数字翻滚」，规则 39）
  E.addBoxKind('stat', {
    name: '大数字', tip: '一到四个大数字并排，数字翻滚出来，下面一行说明', max: 4,
    fields: [{ k: 'l', name: '数字', ph: '3.2', cls: 'sm2' }, { k: 'u', name: '单位', ph: '%', cls: 'sm' }, { k: 's', name: '说明', ph: '一句话' }],
    build(host, items, o){
      const k = o.k * (o.tk || 1), C = o.C, n = items.length, cw = o.w / n;
      const fs = Math.min(cw * 0.3, o.h * 0.34, 170 * k);
      const cells = items.map((it, i) => {
        const x = i * cw, cell = mkd('fxp-cell');
        const num = mkd('fxp-tl', `left:0;top:${E.f(o.h / 2 - fs * 0.95)}px;width:${E.f(cw)}px;height:${E.f(fs * 1.15)}px`);
        cell.appendChild(num);
        const b = String(it.l == null ? '' : it.l) + (it.u ? String(it.u) : '');
        if (it.s && String(it.s).trim()){ const t2 = mkd('fxp-ts', `left:${E.f(cw * 0.06)}px;top:${E.f(o.h / 2 + fs * 0.35)}px;width:${E.f(cw * 0.88)}px;text-align:center;font-size:${E.f(fs * 0.24)}px;color:${C.sub};font-family:${E.FONT}`); t2.textContent = E.plain(it.s); cell.appendChild(t2); }
        if (i){ const sep = mkd('fxp-sep', `left:0;top:${E.f(o.h * 0.25)}px;height:${E.f(o.h * 0.5)}px;background:${E.rgba(C.ink, 0.2)}`); cell.appendChild(sep); }
        host.appendChild(cell);
        return { cell, num, x, b, a: 0.3 + i * 0.15, last: -2 };
      });
      const zero = b => b.replace(/[0-9]/g, '0');
      return { play(s){ cells.forEach(c => {
        const q = E.prog(s, c.a, 0.3); E.put(c.cell, `translate(${E.f(c.x)}px,0px)`, E.clamp(q * 2));
        const p = Math.round(E.clamp(E.prog(s, c.a, 0.9)) * 60) / 60;
        if (p === c.last) return; c.last = p;
        if (!window.FXTrans){ c.num.textContent = c.b; return; }
        if (p >= 1) FXTrans.draw(c.num, { id: 'static', b: c.b, fs, color: C.hi, bold: true, font: E.FONT, lh: 1.1, ls: 0.02 });
        else FXTrans.draw(c.num, { id: 'roll', a: zero(c.b), b: c.b, p, fs, color: C.hi, bold: true, font: E.FONT, lh: 1.1, ls: 0.02 });
      }); } };
    }
  });

  // ⑤ 镂空窗口：框里挖一个透明的窗口（导出时这里 alpha = 0），剪辑时把自己的视频垫在下面
  E.addBoxKind('hole', {
    name: '镂空', tip: '框里一个透明窗口：剪辑时把自己的视频放在下面一轨，从窗口里透出来', max: 1,
    fields: [{ k: 'l', name: '窗口下面的字', ph: '可空' }],
    // 窗口在内容区里的位置（16:9，尽量大）；说明框的底色会在这里挖掉
    hole(area, items){
      const cap = items[0] && String(items[0].l || '').trim() ? 0.14 : 0;
      const hMax = area.h * (1 - cap), w = Math.min(area.w, hMax * 16 / 9), h = w * 9 / 16;
      return { x: area.x + (area.w - w) / 2, y: area.y + (area.h * (1 - cap) - h) / 2, w, h };
    },
    build(host, items, o){
      const C = o.C, H = this.hole({ x: 0, y: 0, w: o.w, h: o.h }, items);
      const fr = mkd('fxp-hole', `left:${E.f(H.x)}px;top:${E.f(H.y)}px;width:${E.f(H.w)}px;height:${E.f(H.h)}px;border:${E.f(3 * o.k)}px solid ${E.rgba(C.ink, 0.9)};box-shadow:0 0 ${E.f(24 * o.k)}px rgba(0,0,0,.45)`);
      host.appendChild(fr);
      let cap = null;
      if (items[0] && String(items[0].l || '').trim()){
        const fs = Math.min(o.h * 0.07, 48 * o.k);
        cap = mkd('fxp-tl', `left:0;top:${E.f(H.y + H.h + fs * 0.5)}px;width:${E.f(o.w)}px;height:${E.f(fs * 1.2)}px`);
        drawTx(cap, items[0].l, fs, C.ink, C.hi); host.appendChild(cap);
      }
      return { play(s){ const q = E.eout(E.prog(s, 0.25, 0.4)); E.put(fr, `scale(${(0.94 + 0.06 * q).toFixed(3)})`, q); if (cap) E.put(cap, null, E.prog(s, 0.5, 0.35)); } };
    }
  });

  // ================= 【区域E9 要点卡：空壳 → 填充 → 高亮 / 变灰】 =================
  /* o = { w, h, t: 名字, s: 英文小字, icon: 'man'|'woman'|'group'|'num'|'image'|'none', img: 照片素材, num: '01',
           color: 卡片色, C: { hi, hiInk }, k, index }
     四层底色（空壳灰 / 填充彩色 / 变灰 / 高亮）各配一份文字，只改透明度；填充 = 从左往右擦出来（两层反向平移，只写 transform）
     返回 { el, set(fill 0~1, dim 0~1, lit 0~1) } */
  E.ICONS = {
    man: '<path d="M30 3.5c6.4 0 11 5.1 11 11.6S36.4 27 30 27s-11-5.5-11-11.9S23.6 3.5 30 3.5z"/><path d="M13 33.5c5-2.6 10.6-3.6 17-3.6s12 1 17 3.6c4 2 6 5.6 6.4 10l1.7 39.5c.1 2.2-1.3 3.6-3.4 3.6-1.9 0-3.1-1.2-3.3-3.2l-2.3-33.2-1.5 42.3-2.6 46c-.1 2.2-1.6 3.6-3.7 3.6-2.2 0-3.6-1.5-3.8-3.8l-3.3-46.5h-1.2l-3.3 46.5c-.2 2.3-1.6 3.8-3.8 3.8-2.1 0-3.6-1.4-3.7-3.6l-2.6-46-1.5-42.3-2.3 33.2c-.2 2-1.4 3.2-3.3 3.2-2.1 0-3.5-1.4-3.4-3.6L6.6 43.5c.4-4.4 2.4-8 6.4-10z"/>',
    woman: '<path d="M30 3c7.5 0 12.5 5.6 12.5 13.4 0 5.4 1.3 9 4.2 11.8-4.2 1.6-8.6 1-11.5-.6A10.6 10.6 0 0 1 30 29a10.6 10.6 0 0 1-5.2-1.4c-2.9 1.6-7.3 2.2-11.5.6 2.9-2.8 4.2-6.4 4.2-11.8C17.5 8.6 22.5 3 30 3z"/><path d="M15.5 34c4.3-2.4 9-3.4 14.5-3.4S40.2 31.6 44.5 34c3.6 2 5.4 5.4 5.8 9.6l4.7 33.6c.3 2.2-1 3.7-3.1 3.7-1.8 0-3-1.1-3.3-3l-3.6-24 7.2 41.4H40.6l-1.8 39.4c-.1 2.1-1.5 3.4-3.5 3.4-2.1 0-3.4-1.3-3.6-3.4L29 95.3l-2.7 39.4c-.2 2.1-1.5 3.4-3.6 3.4-2 0-3.4-1.3-3.5-3.4l-1.8-39.4H5.8L13 53.9l-3.6 24c-.3 1.9-1.5 3-3.3 3-2.1 0-3.4-1.5-3.1-3.7l4.7-33.6c.4-4.2 2.2-7.6 5.8-9.6z"/>',
    group: '<g transform="translate(-14 26) scale(.72)"><path d="M30 3.5c6.4 0 11 5.1 11 11.6S36.4 27 30 27s-11-5.5-11-11.9S23.6 3.5 30 3.5z"/><path d="M13 33.5c5-2.6 10.6-3.6 17-3.6s12 1 17 3.6c4 2 6 5.6 6.4 10l1.7 39.5c.1 2.2-1.3 3.6-3.4 3.6l-3-36-1.5 42.3-2.6 46h-7.5l-3.3-46.5h-1.2l-3.3 46.5h-7.5l-2.6-46-1.5-42.3-3 36c-2.1 0-3.5-1.4-3.4-3.6L6.6 43.5c.4-4.4 2.4-8 6.4-10z"/></g><g transform="translate(31 26) scale(.72)"><path d="M30 3.5c6.4 0 11 5.1 11 11.6S36.4 27 30 27s-11-5.5-11-11.9S23.6 3.5 30 3.5z"/><path d="M13 33.5c5-2.6 10.6-3.6 17-3.6s12 1 17 3.6c4 2 6 5.6 6.4 10l1.7 39.5c.1 2.2-1.3 3.6-3.4 3.6l-3-36-1.5 42.3-2.6 46h-7.5l-3.3-46.5h-1.2l-3.3 46.5h-7.5l-2.6-46-1.5-42.3-3 36c-2.1 0-3.5-1.4-3.4-3.6L6.6 43.5c.4-4.4 2.4-8 6.4-10z"/></g><g transform="translate(5 10) scale(.84)"><path d="M30 3.5c6.4 0 11 5.1 11 11.6S36.4 27 30 27s-11-5.5-11-11.9S23.6 3.5 30 3.5z"/><path d="M13 33.5c5-2.6 10.6-3.6 17-3.6s12 1 17 3.6c4 2 6 5.6 6.4 10l1.7 39.5c.1 2.2-1.3 3.6-3.4 3.6l-3-36-1.5 42.3-2.6 46h-7.5l-3.3-46.5h-1.2l-3.3 46.5h-7.5l-2.6-46-1.5-42.3-3 36c-2.1 0-3.5-1.4-3.4-3.6L6.6 43.5c.4-4.4 2.4-8 6.4-10z"/></g>'
  };
  // 卡片色 → 两头的渐变色（色相往蓝紫那边转 38°，像参考图里的粉 → 紫、蓝 → 靛、青 → 蓝）
  E.hueOf = c => { const [r, g, b] = E.rgb(c).map(v => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; if (!d) return 0; let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; return (h * 60 + 360) % 360; };
  E.hueShift = (c, deg) => {
    const [r, g, b] = E.rgb(c).map(v => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    let h = 0, s = 0;
    if (d){ s = d / (1 - Math.abs(2 * l - 1)); h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; }
    h = ((h + deg) % 360 + 360) % 360;
    const C2 = (1 - Math.abs(2 * l - 1)) * s, X = C2 * (1 - Math.abs((h / 60) % 2 - 1)), m = l - C2 / 2;
    const [a1, b1, c1] = h < 60 ? [C2, X, 0] : h < 120 ? [X, C2, 0] : h < 180 ? [0, C2, X] : h < 240 ? [0, X, C2] : h < 300 ? [X, 0, C2] : [C2, 0, X];
    return '#' + [a1, b1, c1].map(v => Math.round((v + m) * 255).toString(16).padStart(2, '0')).join('');
  };
  E.POINT_COLORS = ['#d24f9c', '#2f43d6', '#16a38c', '#e2731c', '#7b3fd4', '#1d8fd1'];
  E.pointCard = o => {
    const w = o.w, h = o.h, k = o.k || 1, r = Math.round(Math.min(w, h) * 0.12), C = o.C;
    const col = E.hex(o.color) || E.POINT_COLORS[(o.index || 0) % E.POINT_COLORS.length];
    const el = mkd('fxp-card', `width:${E.f(w)}px;height:${E.f(h)}px`);
    const glow = mkd('fxp-glow', `border-radius:${r}px;box-shadow:0 0 ${E.f(26 * k)}px ${E.f(6 * k)}px ${E.rgba(C.hi, 0.75)},0 0 ${E.f(70 * k)}px ${E.rgba(C.hi, 0.35)}`);
    const clip = mkd('fxp-clip', `border-radius:${r}px`);
    el.append(glow, clip);
    // 四套颜色：空壳 / 填充 / 变灰 / 高亮
    const ST = {
      sh: { bg: 'linear-gradient(180deg,#717171,#3f3f42)', icon: '#2c2c2e', t: 'rgba(255,255,255,0)', s: 'rgba(255,255,255,0)' },
      fill: { bg: `linear-gradient(100deg,${E.mix(col, '#ffffff', 0.08)},${E.hueShift(col, (E.hueOf(col) > 250 || E.hueOf(col) < 60) ? -38 : 38)})`, icon: '#0c0c10', t: '#ffffff', s: 'rgba(255,255,255,.72)' },
      dim: { bg: 'linear-gradient(180deg,#7e7e80,#505053)', icon: '#2e2e30', t: '#d2d2d4', s: 'rgba(225,225,228,.62)' },
      lit: { bg: `linear-gradient(180deg,${E.mix(C.hi, '#ffffff', 0.32)},${C.hi})`, icon: '#0c0c10', t: E.mix(C.hi, '#000000', 0.86), s: E.rgba(E.mix(C.hi, '#000000', 0.86), 0.7) }
    };
    const iw = h * 0.52, ih = h * 0.84, ix = h * 0.2, tx = ix + iw + h * 0.16, tw = w - tx - h * 0.16;
    const wipe = () => { const a = mkd('fxp-wipe'), b = mkd('fxp-wi'); a.appendChild(b); return [a, b]; };
    const bgL = {}, ctL = {};
    ['sh', 'fill', 'dim', 'lit'].forEach(key => { bgL[key] = mkd('fxp-bg ' + key, `background:${ST[key].bg}`); });
    const [bw1, bw2] = wipe(); bw2.appendChild(bgL.fill);
    clip.append(bgL.sh, bw1, bgL.dim, bgL.lit);
    // 内容：图标 + 名字 + 英文小字（空壳 = 灰色占位条）
    const icon = key => {
      const box = mkd('fxp-ic', `left:${E.f(ix)}px;top:${E.f((h - ih) / 2)}px;width:${E.f(iw)}px;height:${E.f(ih)}px`);
      if (o.icon === 'none') return box;
      if (o.icon === 'image' && o.img && o.img.img){
        const m = mkd('fxp-icimg', `border-radius:${E.f(h * 0.08)}px`); putImg(m, o.img, iw, ih); box.appendChild(m);
        if (key === 'sh' || key === 'dim') m.style.filter = 'grayscale(1) brightness(' + (key === 'sh' ? 0.45 : 0.75) + ')';
        return box;
      }
      if (o.icon === 'num'){
        const n = mkd('fxp-icnum', `font-size:${E.f(h * 0.36)}px;color:${key === 'fill' ? 'rgba(255,255,255,.9)' : ST[key].icon}`); n.textContent = o.num || ''; box.appendChild(n); return box;
      }
      box.innerHTML = `<svg viewBox="0 0 60 140" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" fill="${ST[key].icon}">${E.ICONS[o.icon] || E.ICONS.man}</svg>`;
      return box;
    };
    const fs = Math.min(h * 0.34, tw / Math.max(2, E.plain(o.t).length) / 1.25), ss = h * 0.12;
    const hasS = !!(o.s && String(o.s).trim());
    ['sh', 'fill', 'dim', 'lit'].forEach(key => {
      const ct = mkd('fxp-ct'); ct.appendChild(icon(key));
      if (key === 'sh'){
        ct.appendChild(mkd('fxp-bar', `left:${E.f(tx)}px;top:${E.f(h * 0.24)}px;width:${E.f(tw * 0.92)}px;height:${E.f(h * 0.3)}px;border-radius:${E.f(h * 0.05)}px`));
        ct.appendChild(mkd('fxp-bar', `left:${E.f(tx)}px;top:${E.f(h * 0.64)}px;width:${E.f(tw * 0.92)}px;height:${E.f(h * 0.1)}px;border-radius:${E.f(h * 0.03)}px;opacity:.7`));
      } else {
        const t1 = mkd('fxp-tl', `left:${E.f(tx)}px;top:${E.f(hasS ? h * 0.13 : (h - fs * 1.2) / 2)}px;width:${E.f(tw)}px;height:${E.f(fs * 1.2)}px`);
        drawTx(t1, o.t || '', fs, ST[key].t, key === 'lit' ? E.mix(C.hi, '#000000', 0.6) : C.hi, { align: 'left', ls: 0.22 });
        ct.appendChild(t1);
        if (hasS){ const t2 = mkd('fxp-ts', `left:${E.f(tx + fs * 0.05)}px;top:${E.f(h * 0.13 + fs * 1.25)}px;width:${E.f(tw)}px;font-size:${E.f(ss)}px;color:${ST[key].s};font-family:'Bahnschrift','DIN Alternate','Arial Narrow',${E.FONT};letter-spacing:.06em`); t2.textContent = E.plain(o.s); ct.appendChild(t2); }
      }
      ctL[key] = ct;
    });
    const [cw1, cw2] = wipe(); cw2.appendChild(ctL.fill);
    const edge = mkd('fxp-edge', `width:${E.f(h * 0.22)}px`);
    clip.append(ctL.sh, cw1, ctL.dim, ctL.lit, edge);
    // 卡片背景动效（规则 40）：画在底色上面、内容下面
    if (window.FXCardBg) try { FXCardBg.mark(clip, { after: bgL.lit, index: o.index || 0, seed: (o.index || 0) * 17 + 5, radius: r, w, h }); } catch (e) {}
    const last = {};
    const op = (el2, v, name) => { v = Math.round(E.clamp(v) * 200) / 200; if (last[name] === v) return; last[name] = v; el2.style.opacity = v; el2.style.visibility = v <= 0 ? 'hidden' : ''; };
    return {
      el, clip, w, h,
      set(fill, dim, lit){
        const p = Math.round(E.clamp(fill) * 400) / 400;
        if (last.p !== p){
          last.p = p;
          const dx = E.f(-(1 - p) * w), bx = E.f((1 - p) * w);
          [bw1, cw1].forEach(x => x.style.transform = `translateX(${dx}px)`);
          [bw2, cw2].forEach(x => x.style.transform = `translateX(${bx}px)`);
          bw1.style.visibility = cw1.style.visibility = p <= 0 ? 'hidden' : '';
          edge.style.transform = `translateX(${E.f(p * w - h * 0.11)}px)`;
          edge.style.opacity = p > 0 && p < 1 ? Math.sin(p * Math.PI).toFixed(3) : 0;
        }
        const d = E.clamp(dim) * (p >= 1 ? 1 : p);
        op(bgL.dim, d, 'd1'); op(ctL.dim, d, 'd2');
        op(bgL.lit, lit, 'l1'); op(ctL.lit, lit, 'l2'); op(glow, lit, 'l3');
        // 空壳的文字层在填充完以后就看不见了，藏掉省绘制
        op(ctL.sh, p >= 1 ? 0 : 1, 's1');
      }
    };
  };

  // ================= 【区域E10 版式库】 =================
  /* 每个版式 = { id, name, group: 'basic'（只亮卡片，没有说明框）| 'box'（带说明框）, tip,
                 place(n, k) → { cards: [{x, y, w, h}], box: {x, y, w, h} | null, pad: 舌头离卡片多远, side: 'right'|'left'|'below'|'above' } }
     坐标都在 1920 × 1080 的画布里。缩略图（编辑器里那一排小图）用 place(3) 自动画，不用另外画。
     以后看到好的排版：E.addPointLayout({ id, name, group, tip, place }) 就行。 */
  E.POINT_LAYOUTS = [];
  E.addPointLayout = def => { const i = E.POINT_LAYOUTS.findIndex(x => x.id === def.id); if (i >= 0) E.POINT_LAYOUTS[i] = def; else E.POINT_LAYOUTS.push(def); };
  E.pointLayout = id => E.POINT_LAYOUTS.find(x => x.id === id) || E.POINT_LAYOUTS[0];
  // 一列卡片：x0 = 左边，返回卡片和整列的高
  const colCards = (n, k, x0, cy, maxH) => {
    let cw = 430 * k, ch = 150 * k, gap = 58 * k;
    const H0 = n * ch + (n - 1) * gap, f = Math.min(1, (maxH || 900) / H0);
    ch *= f; gap *= f; cw *= Math.max(0.8, f);
    const H = n * ch + (n - 1) * gap, y0 = cy - H / 2;
    return { cards: Array.from({ length: n }, (_, i) => ({ x: x0, y: y0 + i * (ch + gap), w: cw, h: ch })), cw, ch, H, y0 };
  };
  const rowCards = (n, k, y0, maxW) => {
    let cw = 400 * k, ch = 140 * k, gap = 48 * k;
    const W0 = n * cw + (n - 1) * gap, f = Math.min(1, (maxW || 1640) / W0);
    cw *= f; gap *= f; ch *= Math.max(0.7, f);
    const W = n * cw + (n - 1) * gap, x0 = (1920 - W) / 2;
    return { cards: Array.from({ length: n }, (_, i) => ({ x: x0 + i * (cw + gap), y: y0, w: cw, h: ch })), cw, ch, W, x0 };
  };
  const mirX = R => ({ ...R, cards: R.cards.map(c => ({ ...c, x: 1920 - c.x - c.w })), box: R.box && { ...R.box, x: 1920 - R.box.x - R.box.w }, side: R.side === 'right' ? 'left' : R.side });
  const mirY = R => ({ ...R, cards: R.cards.map(c => ({ ...c, y: 1080 - c.y - c.h })), box: R.box && { ...R.box, y: 1080 - R.box.y - R.box.h }, side: R.side === 'below' ? 'above' : R.side });
  const colRight = (n, k) => {
    const C = colCards(n, k, 150, 540, 860), pad = 18 * k, bx = 150 + C.cw + 60 * k;
    const bh = Math.min(980, Math.max(C.H + 2 * pad, 620 * k)), by = 540 - bh / 2;
    return { cards: C.cards, box: { x: bx, y: by, w: 1920 - 130 - bx, h: bh }, pad, side: 'right' };
  };
  const rowBelow = (n, k) => {
    const C = rowCards(n, k, 110), pad = 16 * k, by = 110 + C.ch + 56 * k;
    return { cards: C.cards, box: { x: 130, y: by, w: 1660, h: 1080 - 90 - by }, pad, side: 'below' };
  };
  E.addPointLayout({ id: 'col', name: '一列', group: 'basic', tip: '卡片竖着一列放在画面中间，讲到哪张亮哪张', place: (n, k) => { const C = colCards(n, k * 1.1, 0, 540, 900); C.cards.forEach(c => c.x = (1920 - C.cw) / 2); return { cards: C.cards, box: null }; } });
  E.addPointLayout({ id: 'row', name: '一排', group: 'basic', tip: '卡片横着一排放在画面中间', place: (n, k) => { const C = rowCards(n, k * 1.05, 0); C.cards.forEach(c => c.y = (1080 - C.ch) / 2); return { cards: C.cards, box: null }; } });
  E.addPointLayout({ id: 'colR', name: '左列右框', group: 'box', tip: '卡片在左边一列，说明框在右边（参考图的样子）', place: colRight });
  E.addPointLayout({ id: 'colL', name: '右列左框', group: 'box', tip: '卡片在右边一列，说明框在左边', place: (n, k) => mirX(colRight(n, k)) });
  E.addPointLayout({ id: 'rowB', name: '上排下框', group: 'box', tip: '卡片在上面一排，说明框在下面', place: rowBelow });
  E.addPointLayout({ id: 'rowA', name: '下排上框', group: 'box', tip: '卡片在下面一排，说明框在上面', place: (n, k) => mirY(rowBelow(n, k)) });
  // 舌头：把当前卡片包进来、一直伸到框边上的那一块
  E.tabRect = (c, R) => {
    const p = R.pad || 16, b = R.box;
    if (R.side === 'right') return { x: c.x - p, y: c.y - p, w: b.x - (c.x - p), h: c.h + 2 * p };
    if (R.side === 'left') return { x: b.x + b.w, y: c.y - p, w: c.x + c.w + p - (b.x + b.w), h: c.h + 2 * p };
    if (R.side === 'below') return { x: c.x - p, y: c.y - p, w: c.w + 2 * p, h: b.y - (c.y - p) };
    return { x: c.x - p, y: b.y + b.h, w: c.w + 2 * p, h: c.y + c.h + p - (b.y + b.h) };
  };
  // 缩略图：用 place(3) 直接画（卡片 = 实心小块，第 1 张是高亮色；框 = 虚线）
  E.layoutThumb = def => {
    const R = def.place(3, 1);
    let s = '<svg viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid meet">';
    s += '<rect x="20" y="20" width="1880" height="1040" rx="60" fill="none" stroke="currentColor" stroke-opacity=".25" stroke-width="16"/>';
    if (R.box){
      const c = R.cards[R.side === 'right' || R.side === 'left' ? 2 : 1];
      const pr = E.roundPath(E.unionOutline([R.box, E.tabRect(c, R)]), 40);
      s += `<path d="${pr.d}" fill="none" stroke="currentColor" stroke-width="22" stroke-dasharray="60 40"/>`;
    }
    R.cards.forEach((c, i) => { s += `<rect x="${E.f(c.x)}" y="${E.f(c.y)}" width="${E.f(c.w)}" height="${E.f(c.h)}" rx="26" fill="currentColor" fill-opacity="${R.box && i === (R.side === 'right' || R.side === 'left' ? 2 : 1) ? 1 : 0.45}"/>`; });
    return s + '</svg>';
  };

  // ================= 【区域E11 样式 · 版式选择块】 =================
  E.pointCss = `
.fxp-card{position:absolute;left:0;top:0;will-change:transform,opacity}
.fxp-glow{position:absolute;inset:0}
.fxp-clip{position:absolute;inset:0;overflow:hidden;box-shadow:0 0 0 2px rgba(0,0,0,.35),0 16px 34px rgba(0,0,0,.42),inset 0 2px 0 rgba(255,255,255,.2)}
.fxp-bg,.fxp-ct{position:absolute;inset:0}
.fxp-bg.lit,.fxp-bg.dim{opacity:0}
.fxp-wipe{position:absolute;inset:0;overflow:hidden;will-change:transform}
.fxp-wi{position:absolute;inset:0;will-change:transform}
.fxp-edge{position:absolute;left:0;top:0;bottom:0;opacity:0;background:linear-gradient(90deg,rgba(255,255,255,0),rgba(255,255,255,.75),rgba(255,255,255,0));will-change:transform,opacity}
.fxp-ic{position:absolute}
.fxp-icimg{position:absolute;inset:0;overflow:hidden}
.fxp-icnum{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:800;font-family:'DIN Alternate','Bahnschrift','Arial Narrow',sans-serif}
.fxp-bar{position:absolute;background:linear-gradient(180deg,rgba(255,255,255,.34),rgba(255,255,255,.22))}
.fxp-tl,.fxp-ts{position:absolute}
.fxp-ts{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600;line-height:1.2}
.fxp-box{position:absolute;left:0;top:0;width:1920px;height:1080px;pointer-events:none}
.fxp-bsvg{position:absolute;left:0;top:0;overflow:visible}
.fxp-host{position:absolute}
.fxp-cell{position:absolute;left:0;top:0;will-change:transform,opacity}
.fxp-av{position:absolute;left:0;top:0;border-radius:50%;overflow:hidden}
.fxp-dots{position:absolute;left:0;top:0;display:flex;align-items:center;justify-content:center;gap:14%}
.fxp-dots i{display:block;width:16%;height:16%;border-radius:50%;background:rgba(255,255,255,.6)}
.fxp-tile{position:absolute;left:0;top:0;overflow:hidden;box-shadow:0 10px 26px rgba(0,0,0,.4)}
.fxp-tbig{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.85);font-weight:800}
.fxp-badge{position:absolute;left:0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-family:'DIN Alternate','Bahnschrift','Arial Narrow',sans-serif}
.fxp-sep{position:absolute;width:2px}
.fxp-hole{position:absolute;box-sizing:border-box;border-radius:6px;will-change:transform,opacity}
`;
  E.injectPoint = () => { if (document.getElementById('fxp-css')) return; const s = document.createElement('style'); s.id = 'fxp-css'; s.textContent = E.pointCss; document.head.appendChild(s); };
  // 编辑器：版式按类型分组（规则 37：基础组在前、虚线框 + 「基础」角标）
  const LAYCSS = `
html body #params .stc .fxp-gh{display:flex!important;align-items:baseline!important;gap:8px!important;margin:8px 0 6px!important}
html body #params .stc .fxp-gh b{font-size:12px!important;color:#ddd!important;font-weight:600!important}
html body #params .stc .fxp-gh span{font-size:11px!important;color:#777!important}
html body #params .stc .fxp-lay{display:grid!important;grid-template-columns:repeat(4,1fr)!important;gap:6px!important;margin:0!important}
html body #params .stc .fxp-lay button{position:relative!important;display:flex!important;flex-direction:column!important;align-items:center!important;gap:4px!important;width:auto!important;height:auto!important;min-width:0!important;margin:0!important;padding:6px 3px 5px!important;background:#1a1a1a!important;border-width:1px!important;border-style:solid!important;border-radius:7px!important;font-size:11px!important;cursor:pointer!important;font-family:inherit!important;white-space:nowrap!important}
html body #params .stc .fxp-lay button:not(.on){border-color:#2a2a2a!important;color:#999!important}
html body #params .stc .fxp-lay button.basic:not(.on){border-style:dashed!important;border-color:#3a3a3a!important}
html body #params .stc .fxp-lay button:not(.on):hover{border-color:#555!important;color:#eee!important}
html body #params .stc .fxp-lay button.on{border-color:#f28c0f!important;color:#f28c0f!important}
html body #params .stc .fxp-lay svg{display:block!important;width:100%!important;height:34px!important}
html body #params .stc .fxp-lay i{position:absolute!important;right:2px!important;top:2px!important;font-style:normal!important;font-size:9px!important;line-height:1.3!important;padding:0 3px!important;border-radius:3px!important}
html body #params .stc .fxp-lay button:not(.on) i{background:#2a2a2a!important;color:#999!important}
html body #params .stc .fxp-lay button.on i{background:#f28c0f!important;color:#000!important}
`;
  /* o = { ctx, P, key, label, apply, groups: [['basic', '基础', '一句话'], ['box', '展开说明框', '一句话']] } */
  E.layoutBlock = o => {
    const { ctx, P } = o, pd = ctx.pd;
    if (!pd.getElementById('fxp-lay-style')){ const s = pd.createElement('style'); s.id = 'fxp-lay-style'; s.textContent = LAYCSS; pd.head.appendChild(s); }
    const el = ctx.mk('div', 'stc-b');
    const note = ctx.mk('div', 'stc-note');
    const draw = () => {
      el.innerHTML = `<div class="stc-t"><b>版式</b><span>${E.POINT_LAYOUTS.length} 种 · 版式库可以一直加</span></div>`;
      const cur = E.pointLayout(P[o.key]).id;
      (o.groups || []).forEach(([g, name, sub]) => {
        const list = E.POINT_LAYOUTS.filter(x => x.group === g); if (!list.length) return;
        el.appendChild(ctx.mk('div', 'fxp-gh', `<b>${name}</b><span>${sub}</span>`));
        const grid = ctx.mk('div', 'fxp-lay');
        list.forEach(def => {
          const b = ctx.mk('button', (def.id === cur ? 'on ' : '') + (g === 'basic' ? 'basic' : ''), E.layoutThumb(def) + `<span>${E.esc(def.name)}</span>` + (g === 'basic' ? '<i>基础</i>' : ''));
          b.type = 'button'; b.title = def.tip || '';
          b.onclick = () => { ctx.save(o.key, o.label, def.id); draw(); o.apply(); };
          grid.appendChild(b);
        });
        el.appendChild(grid);
      });
      const d = E.pointLayout(P[o.key]); note.textContent = d.tip || ''; el.appendChild(note);
    };
    draw(); el.refresh = draw; return el;
  };
})();
