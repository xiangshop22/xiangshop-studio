/* ===========================================================================
   fx-palettes.js —— 配色库（工作台公共模块，2026-11-10 新增）
   ---------------------------------------------------------------------------
   做什么：只放配色，不放任何功能代码。所有效果要「一排预设色块」时都从这里取，
           加 / 改 / 删一组配色只改这一个文件，用到它的效果全部跟着变。
   谁在用：丝带连接卡（money 钞票色、arrow 箭头色，2026-11-13）；层级结构图（pairs 原样用）；缝线标题卡、焦点格卡片（forText / forBg，排在它们自己原有的配色后面）；
           所有效果通用的「去色 · 高亮」里的高亮色（forGlow，view-controls.js 按需加载这个文件）。
   怎么用：effect.html 里在效果脚本之前引入
             <script src="../_shared/fx-palettes.js"></script>
           然后 FXSkin.colorBlock({ presets: FXPalettes.pairs, ... })。
   数据格式：pairs = [{ c: [卡片色（常态）, 高亮色], name: '鼠标提示里显示的名字' }, ...]
           · 卡片色上面放白字，要够深；高亮色上面放深色字（自动取高亮色的深色版），要够浅。
           · 前 8 组是层级结构图第一版自带的；后 8 组（2026-11-10）是新加的。
           · 「我的配色」（用户自己存的）不在这里，在工作台浏览器的 localStorage（fx-my-color-pairs），所有效果共用。
   =========================================================================== */
(function () {
  const pairs = [
    // ---- 第一版（8 组）----
    { c: ['#f28c0f', '#eef3a6'], name: '橙 × 嫩黄（默认）' },
    { c: ['#5b46c9', '#e6f19a'], name: '靛紫 × 嫩黄（参考图）' },
    { c: ['#1d8f97', '#eef3a6'], name: '青 × 嫩黄' },
    { c: ['#4c6fff', '#bfe0ff'], name: '蓝 × 天蓝' },
    { c: ['#a5272d', '#ffe17a'], name: '红 × 暖黄' },
    { c: ['#7b2fc2', '#f5c6ff'], name: '紫 × 粉紫' },
    { c: ['#2e8b57', '#d8f5c4'], name: '绿 × 薄荷' },
    { c: ['#3a3a3f', '#ffffff'], name: '石墨 × 白' },
    // ---- 新加（8 组，2026-11-10）----
    { c: ['#1f3c88', '#9ff0ff'], name: '午夜蓝 × 冰青（科技、数据）' },
    { c: ['#7a1f3d', '#f7e6c4'], name: '酒红 × 香槟（高级、品牌）' },
    { c: ['#17473a', '#f3d36b'], name: '墨绿 × 金（财经、稳重）' },
    { c: ['#0e5b6b', '#ffb8a6'], name: '深海青 × 珊瑚（清新、生活）' },
    { c: ['#3f2a8c', '#f6f58a'], name: '葡萄紫 × 柠檬（年轻、活泼）' },
    { c: ['#9a4a22', '#ffeccf'], name: '赭石 × 奶油（人文、复古）' },
    { c: ['#36485c', '#bff3dc'], name: '钢蓝灰 × 薄荷（理性、冷静）' },
    { c: ['#b3195a', '#ffe0ee'], name: '玫红 × 樱粉（时尚、美妆）' }
  ];

  // ---------- 同一组配色，换成别的效果要的「角色」 ----------
  // 各效果对两个颜色的用法不一样：层级结构图 = 卡片色（放白字）× 高亮色；
  // 缝线标题卡 / 焦点格卡片 = 文字色（放在深色卡上）× 高亮色，焦点格卡片另有一个单独的底色；
  // 通用「去色 · 高亮」= 一个高亮光的颜色。直接搬过去会出现「深蓝字放在黑卡上」看不清，所以在这里换算一下：
  //   forText()  [卡片色提亮成能放在深色底上的字色, 高亮色]   —— 缝线标题卡、焦点格卡片的「文字色 × 高亮色」
  //   forBg()    [卡片色压深成底色]                          —— 焦点格卡片的「底色」
  //   forGlow()  [卡片色提亮成鲜艳的光色]                    —— 所有效果通用的「高亮色」（画面外面那圈光）
  const hex2hsl = h => {
    const n = parseInt(h.slice(1), 16), r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    let hh = 0, ss = 0;
    if (d){ ss = d / (1 - Math.abs(2 * l - 1)); hh = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh *= 60; if (hh < 0) hh += 360; }
    return [hh, ss, l];
  };
  const hsl2hex = (hh, ss, l) => {
    const f = k0 => { const k = (k0 + hh / 30) % 12, a = ss * Math.min(l, 1 - l); return Math.round((l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1))) * 255); };
    return '#' + [f(0), f(8), f(4)].map(x => x.toString(16).padStart(2, '0')).join('');
  };
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const bright = (h, L) => { const [hh, ss, l] = hex2hsl(h); return ss < 0.08 ? hsl2hex(hh, ss, 0.9) : hsl2hex(hh, cl(Math.max(ss, 0.6), 0, 0.95), Math.max(l, L)); };
  const deep = h => { const [hh, ss, l] = hex2hsl(h); return hsl2hex(hh, cl(ss, 0, 0.75), cl(l * 0.6, 0.1, 0.24)); };
  const short = s => s.replace(/（.*?）/g, '');
  // 钞票色（2026-11-13，丝带连接卡的「钞票流」用）：[钞票底色, 图案 / 边框色]，参考各国纸币不同面值的主色
  const money = [
    { c: ['#c9e7b8', '#2e6b3f'], name: '美元 · 绿（默认）' },
    { c: ['#f4c7c3', '#b3262e'], name: '人民币 100 元 · 红' },
    { c: ['#c8e6d6', '#1f6b4e'], name: '人民币 50 元 · 墨绿' },
    { c: ['#ecd6bd', '#8a5a2b'], name: '人民币 20 元 · 棕' },
    { c: ['#c9dcf2', '#24589e'], name: '人民币 10 元 · 蓝' },
    { c: ['#e0d0ef', '#6b3f96'], name: '人民币 5 元 · 紫' },
    { c: ['#e2e6c0', '#6f7a2c'], name: '人民币 1 元 · 橄榄绿' },
    { c: ['#dcdfe2', '#5f666d'], name: '欧元 5 · 灰' },
    { c: ['#f7d9b5', '#c96a1b'], name: '欧元 50 · 橙' },
    { c: ['#f3e3a8', '#a07a12'], name: '欧元 200 · 黄' },
    { c: ['#e3d0ea', '#7a3f86'], name: '欧元 500 · 紫' }
  ];
  // 箭头色（2026-11-13，丝带的「箭头」样式用）：[箭头色, 外面的光]
  const arrow = [
    { c: ['#a24fe0', '#e9c6ff'], name: '紫（默认，参考图）' },
    { c: ['#e0a92f', '#ffe9a8'], name: '金' },
    { c: ['#3f7fe0', '#bcd8ff'], name: '蓝' },
    { c: ['#d9443f', '#ffc2b8'], name: '红' },
    { c: ['#2fae6a', '#bff2d4'], name: '绿' },
    { c: ['#d8d8e4', '#ffffff'], name: '白' }
  ];
  window.FXPalettes = {
    pairs: pairs,
    money: money,
    arrow: arrow,
    forText: () => pairs.map(p => ({ c: [bright(p.c[0], 0.68), p.c[1]], name: short(p.name) })),
    forBg:   () => pairs.map(p => ({ c: [deep(p.c[0])], name: short(p.name).split(' × ')[0] + '（深）' })),
    forGlow: () => pairs.map(p => ({ c: [bright(p.c[0], 0.6)], name: short(p.name).split(' × ')[0] }))
  };
})();
