/* ===========================================================================
   fx-ribbon.js —— 丝带样式库（工作台公共模块，2026-11-13 新增）
   ---------------------------------------------------------------------------
   做什么：两张卡之间那条「丝带」怎么画。丝带的形状（起点一小段 → 终点一小段，两条二次曲线做边）由效果自己算，
           这里只管「画成什么样」。每条丝带自己选一种样式，没选到的样式一点开销都没有。
   谁在用：丝带连接卡（effects/ribbon-link-cards）。别的效果都没引用它，加这个文件不影响任何老效果。
   以后加新样式：R.add('名字', { name, tip, make(o) }) 就行，效果里的「丝带样式」按钮会自动多一个（规则 28）。

   区域地图（想改哪里，直接说「区域Rx 怎么改」）
   【区域R1 小工具】   插值、二次曲线取点 / 切开、按弧长取点的查表
   【区域R2 样式表】   R.STYLES（按钮上显示的名字和说明）、R.add、R.make
   【区域R3 半透明带子】原来丝带连接卡的样子：半透明渐变的带子 + 两条亮边（SVG）。从 effect.html 原样搬过来，画面逐像素不变
   【区域R4 钞票流】   丝带里排着几排小钞票，一直顺着丝带流；一排亮一排暗（暗的那排像在后面、带一点虚）；靠近两头的卡时渐渐变透明（fade0 / fade1）。
                      每条丝带一块画布，钞票先画成一张小图，每帧只是贴图（不是一张钞票一个节点），几百张也不卡
   【区域R5 箭头】     一根粗箭头（参考图里的紫色大箭头）：从起点长出去，到终点前留一点空隙；渐变 + 外面一圈淡淡的光（不用 CSS 滤镜，省性能）

   画的时候效果每帧传：g = { p1, p2, q1, q2, c1, c2, cA, cB }（两条边：p1→q1、p2→q2，控制点 c1 / c2；cA / cB 两头中点）
                       s = { u 生长 0~1, vis 整体透明度, t 秒, base 带子颜色, k 浓淡, cs 彩色程度 0~1, hs 高亮程度 0~1, ribOp, res 画布分辨率, opt 这条丝带的设置 }
   颜色预设在配色库 fx-palettes.js（FXPalettes.money 钞票色、FXPalettes.arrow 箭头色）。
   =========================================================================== */
(function () {
  const R = window.FXRibbon = window.FXRibbon || {};
  const NS = 'http://www.w3.org/2000/svg';

  // ================= 【区域R1 小工具】 =================
  const f1 = v => (+v).toFixed(1);
  const P2 = p => f1(p[0]) + ' ' + f1(p[1]);
  const lerp = (a, b, k) => a + (b - a) * k;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };
  const mixP = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k)];
  const qpt = (p, c, q, u) => { const a = 1 - u; return [a * a * p[0] + 2 * a * u * c[0] + u * u * q[0], a * a * p[1] + 2 * a * u * c[1] + u * u * q[1]]; };
  const qtan = (p, c, q, u) => [2 * (1 - u) * (c[0] - p[0]) + 2 * u * (q[0] - c[0]), 2 * (1 - u) * (c[1] - p[1]) + 2 * u * (q[1] - c[1])];
  // 二次曲线从 p 出发、走到 u 的那一段：返回 [新控制点, 终点]（de Casteljau 切开，生长时形状不变形）
  R.sub = (p, c, q, u) => {
    const a = [lerp(p[0], c[0], u), lerp(p[1], c[1], u)], b = [lerp(c[0], q[0], u), lerp(c[1], q[1], u)];
    return [a, [lerp(a[0], b[0], u), lerp(a[1], b[1], u)]];
  };
  // 弧长查表：arc(0~1 的弧长比例) → 曲线参数；len = 总长
  const arcLut = (p, c, q) => {
    const n = 32, acc = [0]; let prev = p, L = 0;
    for (let i = 1; i <= n; i++){ const pt = qpt(p, c, q, i / n); L += Math.hypot(pt[0] - prev[0], pt[1] - prev[1]); acc.push(L); prev = pt; }
    return { len: L, at: a => { const s = clamp(a, 0, 1) * L; let i = 1; while (i < n && acc[i] < s) i++; const s0 = acc[i - 1], s1 = acc[i]; return (i - 1 + (s1 > s0 ? (s - s0) / (s1 - s0) : 0)) / n; } };
  };
  const SK = () => window.FXSkin;
  const rgb = c => { const s = SK(); return s && s.rgbOf ? s.rgbOf(c) : [128, 128, 128]; };
  const css = (c, a) => SK().css(c, a);
  const mix = (a, b, k) => SK().mix(a, b, k);
  const GRAY = [128, 128, 128], WHITE = [255, 255, 255];

  // ================= 【区域R2 样式表】 =================
  const STY = {};
  R.STYLES = [];
  R.add = (id, def) => { if (!STY[id]) R.STYLES.push({ id, name: def.name, tip: def.tip || '' }); STY[id] = def; };
  R.has = id => !!STY[id];
  // o = { id: 这条丝带的编号（SVG 渐变 id 用）}
  R.make = (style, o) => { const def = STY[style] || STY.band; const it = def.make(o || {}); it.style = STY[style] ? style : 'band'; return it; };

  // ================= 【区域R3 半透明带子】（原样搬自丝带连接卡 v29.1，画面不变） =================
  R.add('band', { name: '半透明', tip: '半透明渐变的带子 + 两条亮边（卡片之间的光带）',
    make(o){
      const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('class', 'rib');
      svg.setAttribute('viewBox', '0 0 1920 1080');
      const id = 'rg' + (o.id == null ? 0 : o.id);
      svg.innerHTML = `<defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse"><stop offset="0"/><stop offset="0.55"/><stop offset="1"/></linearGradient></defs>`
        + `<path class="fill" fill="url(#${id})"/><path class="edge" fill="none" stroke-width="2"/>`;
      const rb = { el: svg, grad: svg.querySelector('linearGradient'), stops: svg.querySelectorAll('stop'), fill: svg.querySelector('.fill'), edge: svg.querySelector('.edge') };
      rb.draw = (g, s) => {
        const u = s.u, vis = s.vis, base = s.base, k = s.k;
        let d = '', e = '';
        if (u > 0.001 && vis > 0.001){
          const [c1, e1] = R.sub(g.p1, g.c1, g.q1, u), [c2, e2] = R.sub(g.p2, g.c2, g.q2, u);
          d = `M${P2(g.p1)}Q${P2(c1)} ${P2(e1)}L${P2(e2)}Q${P2(c2)} ${P2(g.p2)}Z`;
          e = `M${P2(g.p1)}Q${P2(c1)} ${P2(e1)}M${P2(g.p2)}Q${P2(c2)} ${P2(e2)}`;
        }
        if (rb.d !== d){ rb.d = d; rb.fill.setAttribute('d', d); rb.edge.setAttribute('d', e); }
        const ge = `${f1(g.cA[0])},${f1(g.cA[1])},${f1(lerp(g.cA[0], g.cB[0], u))},${f1(lerp(g.cA[1], g.cB[1], u))}`;
        if (rb.ge !== ge){ rb.ge = ge; const q = ge.split(','); ['x1', 'y1', 'x2', 'y2'].forEach((n, j) => rb.grad.setAttribute(n, q[j])); }
        const cstr = `${css(base, clamp(0.12 * k, 0, 1))}|${css(base, clamp(0.38 * k, 0, 1))}|${css(base, clamp(0.6 * k, 0, 1))}|${css(mix(base, WHITE, 0.5), clamp(0.45 * k, 0, 1))}`;
        if (rb.cs !== cstr){ rb.cs = cstr; const q = cstr.split('|'); rb.stops.forEach((st, j) => st.setAttribute('stop-color', q[j])); rb.edge.setAttribute('stroke', q[3]); }
        const op = vis.toFixed(3);
        if (rb.o !== op){ rb.o = op; rb.el.style.opacity = op; }
      };
      return rb;
    } });

  // ================= 【区域R4 钞票流】 =================
  // 一张小钞票：浅色底、深色边、里面一圈细框、中间一个椭圆章（里面一个「0」），章两边各一个小圆点 —— 简化版的钞票
  const billCache = new Map();
  const toGray = c => { const l = Math.round(c[0] * 0.3 + c[1] * 0.59 + c[2] * 0.11); return [l, l, l]; };
  function billSprite(paper, ink, Wp, Hp, kind){
    const key = paper + '|' + ink + '|' + Wp + '|' + Hp + '|' + kind;
    let c = billCache.get(key); if (c) return c;
    if (billCache.size > 200) billCache.clear();
    let pa = rgb(paper), ik = rgb(ink);
    if (kind === 'gray'){ pa = toGray(pa); ik = toGray(ik); }
    if (kind === 'dim'){ pa = mix(pa, [22, 20, 30], 0.62); ik = mix(ik, [22, 20, 30], 0.5); }
    const pad = Math.ceil(Hp * 0.25) + 2;
    c = document.createElement('canvas'); c.width = Wp + pad * 2; c.height = Hp + pad * 2;
    const x = c.getContext('2d');
    const draw = ctx => {
      const W = Wp, H = Hp, rr = (a, b, w, h, r) => { ctx.beginPath(); ctx.moveTo(a + r, b); ctx.arcTo(a + w, b, a + w, b + h, r); ctx.arcTo(a + w, b + h, a, b + h, r); ctx.arcTo(a, b + h, a, b, r); ctx.arcTo(a, b, a + w, b, r); ctx.closePath(); };
      ctx.save(); ctx.translate(pad, pad);
      rr(0, 0, W, H, H * 0.12); ctx.fillStyle = css(pa); ctx.fill();
      ctx.lineWidth = Math.max(1, H * 0.09); ctx.strokeStyle = css(ik); ctx.stroke();
      rr(H * 0.17, H * 0.17, W - H * 0.34, H - H * 0.34, H * 0.05); ctx.lineWidth = Math.max(0.6, H * 0.045); ctx.strokeStyle = css(ik, 0.7); ctx.stroke();
      ctx.beginPath(); ctx.ellipse(W / 2, H / 2, W * 0.15, H * 0.3, 0, 0, Math.PI * 2); ctx.fillStyle = css(pa); ctx.fill();
      ctx.lineWidth = Math.max(0.8, H * 0.07); ctx.strokeStyle = css(ik); ctx.stroke();
      ctx.beginPath(); ctx.ellipse(W / 2, H / 2, W * 0.05, H * 0.15, 0, 0, Math.PI * 2); ctx.lineWidth = Math.max(0.8, H * 0.07); ctx.stroke();
      ctx.fillStyle = css(ik);
      [-1, 1].forEach(sd => { ctx.beginPath(); ctx.arc(W / 2 + sd * W * 0.26, H / 2, H * 0.085, 0, Math.PI * 2); ctx.fill(); });
      ctx.restore();
    };
    if (kind === 'dim' && 'filter' in x){
      const t = document.createElement('canvas'); t.width = c.width; t.height = c.height; draw(t.getContext('2d'));
      x.filter = `blur(${Math.max(0.6, Hp * 0.06).toFixed(1)}px)`; x.drawImage(t, 0, 0); x.filter = 'none';
    } else draw(x);
    c.__pad = pad;
    billCache.set(key, c);
    return c;
  }
  R.add('money', { name: '钞票流', tip: '丝带里排着几排小钞票，一直顺着丝带流动（讲资金流向）',
    make(){
      const cv = document.createElement('canvas'); cv.className = 'rib rib-money';
      cv.style.position = 'absolute'; cv.style.left = '0px'; cv.style.top = '0px'; cv.style.pointerEvents = 'none';
      const ctx = cv.getContext('2d');
      const it = { el: cv, gk: '', blank: true };
      it.draw = (g, s) => {
        const o = s.opt || {}, res = clamp(num(s.res, 1.5), 0.5, 3);
        const n = Math.round(clamp(num(o.lanes, 5), 1, 12)), sz = clamp(num(o.msz, 100), 20, 300) / 100;
        const vis = s.vis, u = s.u;
        const op = vis.toFixed(3);
        if (it.o !== op){ it.o = op; cv.style.opacity = op; }
        if (u <= 0.001 || vis <= 0.001){ if (!it.blank){ ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height); it.blank = true; } return; }
        // ---- 形状变了才重算：每排的曲线、弧长表、钞票大小、画布范围 ----
        const gk = [g.p1, g.p2, g.q1, g.q2, g.c1, g.c2].map(P2).join('|') + '|' + n + '|' + sz + '|' + res;
        if (it.gk !== gk){
          it.gk = gk;
          const wA = Math.hypot(g.p2[0] - g.p1[0], g.p2[1] - g.p1[1]), wB = Math.hypot(g.q2[0] - g.q1[0], g.q2[1] - g.q1[1]);
          const h = clamp((wA + wB) / 2 / n * 0.62, 4, 30) * sz, w = h * 2.15;   // 钞票默认最高 30 像素（参考图里是一小张一小张的），再乘「钞票大小」
          it.h = h; it.w = w;
          it.lanes = [];
          for (let j = 0; j < n; j++){
            const k = (j + 0.5) / n, p = mixP(g.p1, g.p2, k), c = mixP(g.c1, g.c2, k), q = mixP(g.q1, g.q2, k);
            it.lanes.push({ p, c, q, lut: arcLut(p, c, q) });
          }
          const pts = [g.p1, g.p2, g.q1, g.q2, g.c1, g.c2];
          const m = w * 0.7;
          const bx = Math.floor(Math.min(...pts.map(v => v[0])) - m), by = Math.floor(Math.min(...pts.map(v => v[1])) - m);
          const bw = Math.ceil(Math.max(...pts.map(v => v[0])) + m) - bx, bh = Math.ceil(Math.max(...pts.map(v => v[1])) + m) - by;
          let r = res; const big = Math.max(bw, bh) * r; if (big > 3200) r *= 3200 / big;
          it.bx = bx; it.by = by; it.r = r;
          const W = Math.max(1, Math.round(bw * r)), H = Math.max(1, Math.round(bh * r));
          if (cv.width !== W || cv.height !== H){ cv.width = W; cv.height = H; }
          cv.style.left = bx + 'px'; cv.style.top = by + 'px'; cv.style.width = bw + 'px'; cv.style.height = bh + 'px';
        }
        const r = it.r, w = it.w, h = it.h;
        const col = Array.isArray(o.mcol) && o.mcol.length >= 2 ? o.mcol : ['#c9e7b8', '#2e6b3f'];
        const Wp = Math.max(4, Math.round(w * r)), Hp = Math.max(2, Math.round(h * r));
        const cs = clamp(num(s.cs, 1), 0, 1), hs = clamp(num(s.hs, 0), 0, 1);
        const kk = clamp(num(s.ribOp, 1), 0, 2) * lerp(0.55, 1, cs) * (1 + 0.25 * hs);
        const alt = o.alt !== false, back = o.mdir === 'back';
        const spd = clamp(num(o.mspd, 70), 0, 2000);
        ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height); it.blank = false;
        const gap = w * 1.4;
        // 靠近两头的卡时慢慢变透明（参考图：钞票快到圆卡边上就淡掉）：fade0 / fade1 = 起点 / 终点这一头淡出的那一段占丝带长度的百分比
        const f0 = clamp(num(o.fade0, 30), 0, 60) / 100, f1 = clamp(num(o.fade1, 15), 0, 60) / 100;
        const ss = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
        it.lanes.forEach((ln, j) => {
          const dim = alt && j % 2 === 1;
          const spr = billSprite(col[0], col[1], Wp, Hp, dim ? 'dim' : 'c');
          const gspr = cs < 0.999 ? billSprite(col[0], col[1], Wp, Hp, dim ? 'dim' : 'gray') : null;
          const L = ln.lut.len, N = Math.max(1, Math.floor(L / gap)), ph = s.t * spd * (dim ? 0.6 : 1) / (L / N) + (dim ? 0.5 : 0) + j * 0.37;
          const a0 = dim ? 0.55 : 0.96;
          const pad = spr.__pad / r;
          for (let i = 0; i < N; i++){
            let a = (((i + ph) % N) + N) % N / N;
            if (back) a = 1 - a;
            const v = ln.lut.at(a);
            if (v > u) continue;
            const edge = (f0 > 0 ? ss(a / f0) : 1) * (f1 > 0 ? ss((1 - a) / f1) : 1) * Math.min(1, a / 0.02, (1 - a) / 0.02), front = clamp((u - v) / 0.05, 0, 1);
            const al = clamp(a0 * edge * front * kk, 0, 1);
            if (al <= 0.01) continue;
            const pt = qpt(ln.p, ln.c, ln.q, v), tg = qtan(ln.p, ln.c, ln.q, v);
            const an = Math.atan2(tg[1], tg[0]), co = Math.cos(an) * r, si = Math.sin(an) * r;
            ctx.setTransform(co, si, -si, co, (pt[0] - it.bx) * r, (pt[1] - it.by) * r);
            const dx = -w / 2 - pad, dy = -h / 2 - pad, dw = w + pad * 2, dh = h + pad * 2;
            if (gspr){ ctx.globalAlpha = al * (1 - cs); ctx.drawImage(gspr, dx, dy, dw, dh); ctx.globalAlpha = al * cs; }
            else ctx.globalAlpha = al;
            ctx.drawImage(spr, dx, dy, dw, dh);
          }
        });
        ctx.globalAlpha = 1;
      };
      return it;
    } });

  // ================= 【区域R5 箭头】 =================
  R.add('arrow', { name: '箭头', tip: '一根粗箭头从起点长到终点（参考图：人物 → 公司的紫色大箭头）',
    make(o){
      const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('class', 'rib rib-arrow');
      svg.setAttribute('viewBox', '0 0 1920 1080');
      const id = 'ra' + (o.id == null ? 0 : o.id);
      svg.innerHTML = `<defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse"><stop offset="0"/><stop offset="0.6"/><stop offset="1"/></linearGradient></defs>`
        + `<path class="glow" fill="none" stroke-linejoin="round"/><path class="fill" fill="url(#${id})"/>`;
      const it = { el: svg, grad: svg.querySelector('linearGradient'), stops: svg.querySelectorAll('stop'), fill: svg.querySelector('.fill'), glow: svg.querySelector('.glow') };
      it.draw = (g, s) => {
        const op0 = s.opt || {}, u = s.u, vis = s.vis;
        const aw = clamp(num(op0.aw, 64), 6, 400), gapE = clamp(num(op0.agap, 16), -200, 400);
        const m0 = mixP(g.p1, g.p2, 0.5), mc = mixP(g.c1, g.c2, 0.5), m1 = mixP(g.q1, g.q2, 0.5);
        const gk = [m0, mc, m1].map(P2).join('|');
        if (it.gk !== gk){ it.gk = gk; it.lut = arcLut(m0, mc, m1); }
        const Ltot = Math.max(1, it.lut.len - gapE), tipL = Ltot * clamp(u, 0, 1);
        let d = '', gs = '';
        if (u > 0.001 && vis > 0.001 && tipL > 1){
          const hl = Math.min(aw * 1.15, tipL * 0.6), hw = aw * 2.1 * (hl / (aw * 1.15)), sw = aw * Math.min(1, hl / (aw * 0.6));
          const at = L => it.lut.at(L / it.lut.len);
          const nrm = v => { const t = qtan(m0, mc, m1, v), l = Math.hypot(t[0], t[1]) || 1; return [-t[1] / l, t[0] / l]; };
          const sEnd = Math.max(0, tipL - hl), nS = 14, L1 = [], L2 = [];
          for (let i = 0; i <= nS; i++){
            const v = at(sEnd * i / nS), p = qpt(m0, mc, m1, v), nm = nrm(v);
            L1.push([p[0] + nm[0] * sw / 2, p[1] + nm[1] * sw / 2]); L2.push([p[0] - nm[0] * sw / 2, p[1] - nm[1] * sw / 2]);
          }
          const vb = at(sEnd), pb = qpt(m0, mc, m1, vb), nb = nrm(vb), vt = at(tipL), pt = qpt(m0, mc, m1, vt);
          const pts = L1.concat([[pb[0] + nb[0] * hw / 2, pb[1] + nb[1] * hw / 2], pt, [pb[0] - nb[0] * hw / 2, pb[1] - nb[1] * hw / 2]], L2.reverse());
          d = 'M' + pts.map(P2).join('L') + 'Z';
          gs = `${f1(m0[0])},${f1(m0[1])},${f1(pt[0])},${f1(pt[1])}`;
        }
        if (it.d !== d){ it.d = d; it.fill.setAttribute('d', d); it.glow.setAttribute('d', d); it.glow.setAttribute('stroke-width', f1(aw * 0.45)); }
        if (gs && it.gs !== gs){ it.gs = gs; const q = gs.split(','); ['x1', 'y1', 'x2', 'y2'].forEach((n, j) => it.grad.setAttribute(n, q[j])); }
        const col = Array.isArray(op0.acol) && op0.acol.length >= 2 ? op0.acol : ['#a24fe0', '#e9c6ff'];
        const cs = clamp(num(s.cs, 1), 0, 1), hs = clamp(num(s.hs, 0), 0, 1);
        let main = rgb(col[0]), gl = rgb(col[1]);
        main = mix(mix(GRAY, main, 0.25), main, cs); gl = mix(mix(GRAY, gl, 0.25), gl, cs);
        main = mix(main, WHITE, 0.15 * hs);
        const k = clamp(num(s.ribOp, 1), 0, 2) * lerp(0.5, 1, cs) * (1 + 0.25 * hs);
        const cstr = `${css(main, clamp(0.18 * k, 0, 1))}|${css(main, clamp(0.78 * k, 0, 1))}|${css(mix(main, gl, 0.35), clamp(0.98 * k, 0, 1))}|${css(gl, clamp(0.22 * k, 0, 1))}`;
        if (it.cs !== cstr){ it.cs = cstr; const q = cstr.split('|'); it.stops.forEach((st, j) => st.setAttribute('stop-color', q[j])); it.glow.setAttribute('stroke', q[3]); }
        const op = vis.toFixed(3);
        if (it.o !== op){ it.o = op; svg.style.opacity = op; }
      };
      return it;
    } });
})();
