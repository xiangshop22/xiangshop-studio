/* 效果工坊 · 通用预览操作（所有效果共用）
 * 在工作台预览区：
 *   - 鼠标滚轮：缩放大小（写入参数 scale）
 *   - 按住鼠标左键拖动：移动位置（写入参数 offsetX / offsetY，单位是 1920×1080 画布上的像素）
 *   - 双击：还原大小和位置
 * 改的是工作台里同一份参数，所以导出的视频和预览一致。
 * 导出时页面单独打开（没有工作台），这个脚本什么都不做。
 * 放在 effects/_shared 里：没有 effect.json，工作台不会把它当成一个效果。
 */
(function () {
  let pw, pd;
  try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
  if (typeof window.init !== 'function' || typeof window.renderAt !== 'function') return;

  const CFG = window.VIEW_CONTROLS || {};          // { live: true } = renderAt 每帧都读参数，不用重新 init
  let lastP = null, lastT = 0;
  const origInit = window.init, origRender = window.renderAt;
  window.init = function (p) { lastP = p; const r = origInit.apply(this, arguments); setTimeout(() => { hideSize(); enhancePanel(); groupPanel(); }, 0); return r; };
  window.renderAt = function (t) { lastT = +t || 0; return origRender.apply(this, arguments); };

  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const box = () => pd.getElementById('box');
  const labelOf = el => {
    const f = el.firstChild; if (!f) return '';
    if (f.nodeType === 3) return f.textContent.trim();
    if (f.classList && f.classList.contains('fxr-row')) return (f.firstChild.textContent || '').trim();
    return '';
  };
  // 面板里的每一项（分组折叠后它们在分组里面，也要找得到）
  const panelItems = () => {
    const b = pd.getElementById('params'); if (!b) return [];
    return [...b.children].flatMap(el => el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : el.classList.contains('fxg-bar') ? [] : [el]);
  };
  const panelLabel = prefix => panelItems().find(el => labelOf(el).startsWith(prefix));
  // 右侧面板精简：大小、水平偏移、垂直偏移都用鼠标在预览区直接调（滚轮 / 拖动 / 双击还原），面板里不再显示
  function hideSize() { ['卡片大小', '水平偏移', '垂直偏移'].forEach(k => { const l = panelLabel(k); if (l) l.style.display = 'none'; }); }
  function syncInputs() {
    [['水平偏移', 'offsetX'], ['垂直偏移', 'offsetY']].forEach(([lab, key]) => {
      const l = panelLabel(lab), i = l && l.querySelector('input');
      if (i && lastP) { i.value = Math.round(num(lastP[key], 0)); if (i.__fxRange) i.__fxRange.value = i.value; }
    });
  }

  // ---------- 规则：所有数字参数 = 文字后面一个数字框 + 下面一条滑块 ----------
  let defs = null;
  fetch(new URL('effect.json', location.href)).then(r => r.json()).then(j => { defs = j.params || []; hideSize(); enhancePanel(); groupPanel(); }).catch(() => {});
  function rangeOf(def, input) {
    const key = def && def.key, d = num(def && def.default, num(input.value, 0));
    let min = def && def.min != null ? +def.min : null, max = def && def.max != null ? +def.max : null;
    if (key === 'offsetX') { if (min == null) min = -960; if (max == null) max = 960; }
    if (key === 'offsetY') { if (min == null) min = -540; if (max == null) max = 540; }
    if (min == null) min = d < 0 ? d * 4 : 0;
    if (max == null) max = d > 0 ? Math.max(10, Math.ceil(d * 4)) : 100;
    if (max <= min) max = min + 1;
    let step = def && def.step != null && def.step !== 'any' ? +def.step : null;
    if (!step || !(step > 0)) { const raw = (max - min) / 200, p10 = Math.pow(10, Math.floor(Math.log10(raw))); step = [1, 2, 5, 10].map(m => m * p10).find(x => x >= raw) || raw; }
    return { min, max, step };
  }
  function enhancePanel() {
    const box = pd.getElementById('params'); if (!box || !defs) return;
    if (!pd.getElementById('fxr-style')) {
      const st = pd.createElement('style'); st.id = 'fxr-style';
      st.textContent = `
.fxr-row{display:flex;align-items:center;justify-content:space-between;gap:10px}
.fxr-row>span{flex:1;min-width:0}
.fxr-row input[type=number]{width:96px!important;flex:none;margin:0!important;display:inline-block!important;text-align:right;padding:6px 8px!important}
input.fxr-range{display:block!important;width:100%!important;margin:8px 0 2px!important;padding:0!important;border:0!important;background:none!important;height:18px;accent-color:#f28c0f;cursor:pointer}`;
      pd.head.appendChild(st);
    }
    panelItems().forEach(lab => {
      if (lab.tagName !== 'LABEL' || lab.dataset.fxr) return;
      const input = [...lab.children].find(x => x.tagName === 'INPUT' && x.type === 'number');
      if (!input) return;
      const text = labelOf(lab);
      const def = defs.find(q => q.type === 'number' && q.label === text) || defs.find(q => q.type === 'number' && text && q.label && text.startsWith(q.label));
      const { min, max, step } = rangeOf(def, input);
      lab.dataset.fxr = '1';
      const row = pd.createElement('div'); row.className = 'fxr-row';
      const span = pd.createElement('span'); span.textContent = text;
      lab.firstChild.remove();
      row.append(span, input);
      const rng = pd.createElement('input'); rng.type = 'range'; rng.className = 'fxr-range';
      rng.min = min; rng.max = max; rng.step = step; rng.value = input.value;
      input.__fxRange = rng;
      rng.addEventListener('input', () => {
        input.value = rng.value;
        input.dispatchEvent(new pw.Event('input', { bubbles: true }));
      });
      input.addEventListener('input', () => { if (input.value !== '') rng.value = input.value; });
      lab.prepend(row); lab.appendChild(rng);
    });
  }
  // ---------- 右侧参数分组折叠：内容 / 样式 / 数值调节 ----------
  const effId = (location.pathname.match(/effects\/([^/]+)\//) || [])[1] || 'fx';
  const store = {
    get(k) { try { return pw.localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { pw.localStorage.setItem(k, v); } catch (e) {} },
  };
  function groupPanel() {
    const box = pd.getElementById('params'); if (!box || !defs) return;
    if (box.querySelector(':scope > .fxg')) return;
    const kids = [...box.children]; if (!kids.length) return;
    if (!pd.getElementById('fxg-style')) {
      const st = pd.createElement('style'); st.id = 'fxg-style';
      st.textContent = `
.fxg-bar{display:flex;justify-content:flex-end;gap:6px;margin:-4px 0 8px}
.fxg-bar button{background:#1d1d1d;color:#aaa;border:1px solid #2c2c2c;border-radius:6px;padding:3px 10px;font-size:12px;cursor:pointer;font-family:inherit}
.fxg-bar button:hover{color:#f28c0f;border-color:#f28c0f}
.fxg{margin:0 0 10px;border:1px solid #262626;border-radius:8px;background:#121212}
.fxg-h{display:flex;align-items:center;gap:8px;width:100%;padding:10px 12px;background:none;border:0;color:#ddd;font-size:13px;font-weight:600;cursor:pointer;text-align:left;font-family:inherit}
.fxg-h:hover{color:#f28c0f}
.fxg-h i{font-style:normal;color:#f28c0f;display:inline-block;transition:transform .15s}
.fxg.off .fxg-h i{transform:rotate(-90deg)}
.fxg-h small{margin-left:auto;color:#666;font-weight:400;font-size:12px}
.fxg-b{padding:4px 12px 2px}
.fxg.off .fxg-b{display:none}`;
      pd.head.appendChild(st);
    }
    const kindOf = el => {
      if (el.classList.contains('cdx') || (el.dataset && el.dataset.fxContent)) return 'content';
      const t = labelOf(el);
      const d = defs.find(q => q.label && t && (t === q.label || t.startsWith(q.label)));
      if (!d) return 'look';
      if (d.type === 'text' || d.type === 'textarea' || d.type === 'images' || d.type === 'cards') return 'content';
      if (d.type === 'number') return 'num';
      return 'look';
    };
    const G = [['content', '内容'], ['look', '样式'], ['num', '数值调节']];
    const groups = [];
    G.forEach(([k, name]) => {
      const mine = kids.filter(el => kindOf(el) === k); if (!mine.length) return;
      const g = pd.createElement('div'); g.className = 'fxg'; g.dataset.k = k;
      const h = pd.createElement('button'); h.type = 'button'; h.className = 'fxg-h';
      const shown = mine.filter(el => el.style.display !== 'none').length;
      h.innerHTML = '<i>▾</i>' + name + '<small>' + (k === 'content' ? '' : shown + ' 项') + '</small>';
      const body = pd.createElement('div'); body.className = 'fxg-b';
      body.append(...mine); g.append(h, body);
      if (!shown) g.style.display = 'none';
      const key = 'fxg:' + effId + ':' + k;
      if (store.get(key) === '0') g.classList.add('off');
      h.onclick = () => { g.classList.toggle('off'); store.set(key, g.classList.contains('off') ? '0' : '1'); };
      groups.push(g);
    });
    const bar = pd.createElement('div'); bar.className = 'fxg-bar';
    bar.innerHTML = '<button type="button" data-f="0">全部折叠</button><button type="button" data-f="1">全部展开</button>';
    bar.querySelectorAll('button').forEach(b => b.onclick = () => groups.forEach(g => {
      g.classList.toggle('off', b.dataset.f === '0'); store.set('fxg:' + effId + ':' + g.dataset.k, b.dataset.f);
    }));
    box.innerHTML = '';
    box.append(bar, ...groups);
  }
  function hint(msg) { const h = pd.getElementById('hint'); if (h) h.textContent = msg; }
  function apply() {
    if (!lastP) return;
    const t = lastT;                                  // init 内部会 renderAt(0)，先记住当前时间
    if (CFG.live) window.renderAt(t);
    else { window.init(lastP); window.renderAt(t); }
    syncInputs();
  }
  // 预览区里 1 个屏幕像素 = 多少个 1920×1080 画布像素
  function stagePerScreen() {
    const b = box(); if (!b) return 1;
    const fitS = Math.min(innerWidth / 1920, innerHeight / 1080) || 1;
    return (innerWidth / (b.getBoundingClientRect().width || innerWidth)) / fitS;
  }
  const inBox = e => { const b = box(); return b && e.target instanceof pw.Node && b.contains(e.target); };

  function onWheel(e) {
    if (!inBox(e) || !lastP) return;
    e.preventDefault(); e.stopPropagation();          // 拦下工作台自带的滚轮处理，避免缩放两次
    begin();                                          // 从画面当前这一帧的大小开始缩放
    let s = num(lastP.scale, 1) * (e.deltaY < 0 ? 1.06 : 1 / 1.06);
    s = Math.min(5, Math.max(0.2, Math.round(s * 100) / 100));
    lastP.scale = s; apply();
    hint('大小 ' + Math.round(s * 100) + '%　·　按住左键拖动位置　·　双击还原');
    changed('scale');                                 // 让关键帧那一层在这一秒记下大小
  }
  // 手动操作开始 / 结束：交给关键帧层（对齐当前帧 + 操作期间暂停曲线）
  const begin = () => { try { if (window.__fxViewBegin) window.__fxViewBegin(); } catch (e) { } };
  const end = () => { try { if (window.__fxViewEnd) window.__fxViewEnd(); } catch (e) { } };
  // 缩放 / 位置改完通知关键帧层（它在本文件末尾那个 IIFE 里，会按当前秒自动打点）
  let chT = 0;
  function changed(kind) {
    clearTimeout(chT);
    chT = setTimeout(() => { try { if (window.__fxViewChanged) window.__fxViewChanged(kind); } catch (e) { } }, 220);
  }
  let drag = null;
  function onDown(e) {
    if (!inBox(e) || e.button !== 0 || !lastP) return;
    e.preventDefault();
    begin();                                          // 从画面当前这一帧的位置开始拖
    drag = { x: e.clientX, y: e.clientY, ox: num(lastP.offsetX, 0), oy: num(lastP.offsetY, 0), k: stagePerScreen() };
    const b = box(); if (b) b.style.cursor = 'grabbing';
  }
  let raf = 0;
  function onMove(e) {
    if (!drag) return;
    lastP.offsetX = Math.round(drag.ox + (e.clientX - drag.x) * drag.k);
    lastP.offsetY = Math.round(drag.oy + (e.clientY - drag.y) * drag.k);
    if (!raf) raf = pw.requestAnimationFrame(() => { raf = 0; apply(); });
    hint('位置 X ' + lastP.offsetX + '　Y ' + lastP.offsetY + '　·　双击还原');
  }
  function onUp() {
    if (!drag) return;
    const moved = drag.ox !== num(lastP.offsetX, 0) || drag.oy !== num(lastP.offsetY, 0);
    drag = null; const b = box(); if (b) b.style.cursor = 'grab';
    if (moved) changed('pos');                        // 松手就在这一秒记下位置
    else end();
  }
  function onDbl(e) {
    if (!inBox(e) || !lastP) return;
    e.preventDefault(); e.stopPropagation();
    lastP.scale = 1; lastP.offsetX = 0; lastP.offsetY = 0; apply();
    hint('已还原：大小 100%，位置居中');
  }

  // 上一个效果留下的监听先撤掉，再挂这个效果的
  try { if (pw.__fxViewDispose) pw.__fxViewDispose(); } catch (e) {}
  pd.addEventListener('wheel', onWheel, { capture: true, passive: false });
  pd.addEventListener('mousedown', onDown, true);
  pd.addEventListener('mousemove', onMove, true);
  pd.addEventListener('mouseup', onUp, true);
  pd.addEventListener('dblclick', onDbl, true);
  const dispose = () => {
    pd.removeEventListener('wheel', onWheel, { capture: true });
    pd.removeEventListener('mousedown', onDown, true);
    pd.removeEventListener('mousemove', onMove, true);
    pd.removeEventListener('mouseup', onUp, true);
    pd.removeEventListener('dblclick', onDbl, true);
    if (pw.__fxViewDispose === dispose) pw.__fxViewDispose = null;
  };
  pw.__fxViewDispose = dispose;
  window.addEventListener('pagehide', dispose);
  window.addEventListener('unload', dispose);
  const b = box(); if (b) { b.style.cursor = 'grab'; const f = pd.getElementById('frame'); if (f) f.style.pointerEvents = 'none'; }
  hint('滚轮缩放大小　·　按住左键拖动位置　·　双击还原');
})();

/* =====================================================================
 * 效果工坊 · 公共关键帧（FXKeys）—— 所有效果通用，v6.9 起
 *
 * 为什么放在 view-controls.js 里：**每一个效果都会加载这个文件**，所以关键帧成了
 * 全局能力 —— 以前做的、以后做的，都自动有，效果本身一行都不用改。
 *
 * 怎么做到不改效果：在 #stage 里插一层 <div id="fx-rot">，把原来 stage 下的内容
 * 整体搬进去，旋转 / 缩放都加在这一层上；透视加在 #stage 上（它是 fx-rot 的父节点）。
 * 效果自己的 DOM 结构、定位、裁剪都不受影响（fx-rot 和 stage 等大、同位置）。
 * 效果如果在 init 里清空过 #stage，init 之后会自动重新搬一次。
 *
 * 每个关键帧记的是【角度 x/y/z + 大小 s + 位置 ox/oy】三件事：
 *   右键拖转角度、滚轮缩放、左键拖位置，松手都会在当前这一秒自动打点。
 *   大小按「比例」、位置按「像素差」叠加到效果自己的 scale / offsetX / offsetY 上，不会打架。
 *   老数据里没有 ox/oy 的记录按默认值算，等于那一项没动过。
 *
 * 【核心语义】关键帧只管中间那一段：
 *   第一个关键帧之前、最后一个之后，角度 / 大小 / 位置回到参数里的默认值，
 *   所以每个效果自带的开场和结尾原样保留，不会被关键帧按住；
 *   两端用「首尾衔接（秒）」平滑过渡。想保持首尾角度就把「关键帧之外」改成「保持首尾」。
 *
 * 效果要做的事：只在 effect.json 里加 rotX / rotY / rotZ / persp / keys 五个参数。
 * 想自己接管（比如 ring-carousel 把关键帧接到它自己的 tilt / roll / startAngle 上）：
 *   window.VIEW_CONTROLS = { live:true, keys:{ apply:false, drag:false,
 *       map:{x:'tilt',y:'startAngle',z:'roll'}, labels:{...} } };
 *   然后自己在 renderAt 里调 FXKeys.at(P, t, 总时长)，在松手处调 FXKeys.recordNow()。
 * ===================================================================== */
(function () {
  const CFG0 = (window.VIEW_CONTROLS || {}).keys;
  if (CFG0 === false) return;                       // 明确关掉关键帧的效果
  const O = (CFG0 && typeof CFG0 === 'object') ? CFG0 : {};
  const MAP = O.map || { x: 'rotX', y: 'rotY', z: 'rotZ' };
  const APPLY = O.apply !== false;                  // false = 效果自己在 renderAt 里应用
  const DRAG = O.drag !== false;                    // false = 效果自己已经接管了右键
  const LB = O.labels || { y: 'Y 轴旋转', x: 'X 轴俯仰', z: 'Z 轴倾斜' };

  const origInit = window.init, origRender = window.renderAt;
  if (typeof origInit !== 'function' || typeof origRender !== 'function') return;

  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const prog = (t, a, b) => (b <= a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a), 0, 1));
  const lerp = (a, b, k) => a + (b - a) * k;
  const smooth = x => x * x * (3 - 2 * x);
  const r1 = x => Math.round(x * 10) / 10;
  const r2 = x => Math.round(x * 100) / 100;

  let P = {}, lastT = 0, wrap = null;
  const K = { dragging: false, map: MAP };
  window.FXKeys = K;

  // ---------- 数据 ----------
  const KDEF = () => ({ on: true, auto: true, scale: true, pos: true, ease: 'smooth', edge: 'blend', fade: 0.6, list: [] });
  let _raw = null, _K = null;
  // 一条关键帧记录：角度 x/y/z、大小 s、位置 ox/oy。
  // 老数据没有 ox/oy（甚至没有 s）→ 存 null，求值时按「参数里的默认值」算，等于没动过。
  const fin = v => (Number.isFinite(+v) ? +v : null);
  const norm = k => ({
    t: Math.max(0, r2(+k.t)), x: r1(+k.x || 0), y: r1(+k.y || 0), z: r1(+k.z || 0),
    s: fin(k.s) == null ? null : r2(+k.s),
    ox: fin(k.ox) == null ? null : Math.round(+k.ox),
    oy: fin(k.oy) == null ? null : Math.round(+k.oy)
  });
  K.norm = norm;
  K.read = p => {
    p = p || P;
    const raw = typeof p.keys === 'string' ? p.keys : JSON.stringify(p.keys || null);
    if (_raw === raw && _K) return _K;
    let v; try { v = typeof p.keys === 'string' ? JSON.parse(p.keys) : p.keys; } catch (e) { v = null; }
    const o = KDEF();
    if (v && typeof v === 'object') {
      o.on = v.on !== false; o.auto = v.auto !== false;
      o.scale = v.scale !== false; o.pos = v.pos !== false;
      o.ease = v.ease === 'linear' ? 'linear' : 'smooth';
      o.edge = v.edge === 'hold' ? 'hold' : 'blend';
      o.fade = Math.max(0, num(v.fade, 0.6));
      if (Array.isArray(v.list)) o.list = v.list;
    }
    o.list = o.list.filter(k => k && Number.isFinite(+k.t)).map(norm).sort((a, b) => a.t - b.t);
    _raw = raw; _K = o;
    return o;
  };

  // ---------- 求值 ----------
  K.at = (p, t, total) => {
    p = p || P;
    const def = { x: num(p[MAP.x], 0), y: num(p[MAP.y], 0), z: num(p[MAP.z], 0),
      s: clamp(num(p.scale, 1), 0.1, 5), ox: num(p.offsetX, 0), oy: num(p.offsetY, 0) };
    const out = { x: def.x, y: def.y, z: def.z, s: def.s, ox: def.ox, oy: def.oy,
      persp: clamp(num(p.persp, 2400), 400, 20000), on: false };
    const o = K.read(p);
    if (!o.on || !o.list.length || K.dragging) return out;   // 拖动时先不走曲线，画面才跟手
    const L = o.list, first = L[0], last = L[L.length - 1];
    const ease = u => (o.ease === 'linear' ? u : smooth(u));
    // 取某一条记录的某个字段；null（老数据没记）就退回参数里的默认值
    const g = (k, f) => (k[f] == null ? def[f] : k[f]);
    const mix = (a, b, u) => ({ x: lerp(g(a, 'x'), g(b, 'x'), u), y: lerp(g(a, 'y'), g(b, 'y'), u), z: lerp(g(a, 'z'), g(b, 'z'), u),
      s: lerp(g(a, 's'), g(b, 's'), u), ox: lerp(g(a, 'ox'), g(b, 'ox'), u), oy: lerp(g(a, 'oy'), g(b, 'oy'), u) });
    let v;
    const full = k => mix(k, k, 0);
    if (t <= first.t) {
      if (o.edge === 'hold') v = full(first);
      else if (o.fade <= 0) v = (t < first.t ? def : full(first));
      else v = mix(def, first, ease(prog(t, first.t - o.fade, first.t)));   // 开场：从默认角度过渡进来
    } else if (t >= last.t) {
      if (o.edge === 'hold') v = full(last);
      else if (o.fade <= 0) v = (t > last.t ? def : full(last));
      else v = mix(last, def, ease(prog(t, last.t, last.t + o.fade)));      // 结尾：平滑回到默认
    } else {
      let i = 0; while (i < L.length - 1 && L[i + 1].t <= t) i++;
      v = mix(L[i], L[i + 1], ease((t - L[i].t) / Math.max(1e-6, L[i + 1].t - L[i].t)));
    }
    out.x = v.x; out.y = v.y; out.z = v.z; out.on = true;
    if (o.scale) out.s = clamp(v.s, 0.1, 5);
    if (o.pos) { out.ox = Math.round(v.ox); out.oy = Math.round(v.oy); }
    return out;
  };

  // ---------- 【画面】在 #stage 里插一层，旋转加在这一层上 ----------
  // 有的老效果没有 #stage（直接往 body 里画），这时候就拿 body 当舞台
  function host() {
    return document.getElementById('stage')
      || (document.body && document.body.firstElementChild ? document.body : null);
  }
  function ensureWrap() {
    const st = host();
    if (!st) return null;
    if (st === document.body && getComputedStyle(st).position === 'static') st.style.position = 'relative';
    if (!wrap || wrap.parentNode !== st) {
      wrap = st.querySelector(':scope > #fx-rot');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.id = 'fx-rot';
        wrap.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;transform-origin:center center';
        st.appendChild(wrap);
      }
    }
    // 把 stage 下除 fx-rot 以外的节点搬进来（效果在 init 里清空过 stage 的话这里会重新搬）
    for (let n = st.firstChild; n;) { const next = n.nextSibling; if (n !== wrap) wrap.appendChild(n); n = next; }
    return wrap;
  }
  function applyRot(t) {
    const R = K.at(P, t, dur());
    const st = host();
    if (st) {
      // 效果自己已经乘过 P.scale / offsetX / offsetY 了，这里只补「关键帧带来的那一份」差值：
      // 大小是比例（没开就是 1），位置是像素差（没开就是 0），所以和效果自己的参数不会打架。
      const k = R.s / Math.max(0.01, num(P.scale, 1));
      const dx = R.ox - num(P.offsetX, 0), dy = R.oy - num(P.offsetY, 0);
      const move = (Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5 ? 'translate(' + Math.round(dx) + 'px,' + Math.round(dy) + 'px) ' : '')
        + (Math.abs(k - 1) > 1e-4 ? 'scale(' + k.toFixed(4) + ') ' : '');
      // 角度由效果自己应用时（apply:false，如 ring-carousel），大小和位置仍然由这一层补
      const tr = APPLY
        ? move + 'rotateX(' + R.x + 'deg) rotateY(' + R.y + 'deg) rotateZ(' + R.z + 'deg)'
        : move.trim();
      if (APPLY || tr || wrap) {        // tr 变空时也要写回去，把上一帧的位移 / 缩放清掉
        const w = ensureWrap();
        if (APPLY && st.__p !== R.persp) { st.__p = R.persp; st.style.perspective = R.persp + 'px'; }
        if (w && w.__tr !== tr) { w.__tr = tr; w.style.transform = tr; }
      }
    }
    if (K.live) K.live(t, R.x, R.y, R.z, R.s, R);
    return R;
  }
  const dur = () => { try { return +window.getDuration() || 0; } catch (e) { return 0; } };

  window.init = function (p) {
    P = p || {};
    const r = origInit.apply(this, arguments);
    setTimeout(() => { try { ensureWrap(); mount(); applyRot(lastT); } catch (e) { console.error(e); } }, 0);
    return r;
  };
  window.renderAt = function (t) {
    lastT = +t || 0;
    const r = origRender.apply(this, arguments);
    try { applyRot(lastT); } catch (e) { }
    return r;
  };

  // ================= 工作台里的交互（右键拖动 + 面板 + 轨道接口） =================
  let mounted = false, panelBox = null, redraw = () => { }, field = null;
  function mount() {
    let pw, pd;
    try { if (window.parent === window) return; pw = window.parent; pd = pw.document; } catch (e) { return; }
    const box = pd.getElementById('params'); if (!box) return;
    const boxOf = () => pd.getElementById('box');
    const inBox = e => { const b = boxOf(); return b && e.target instanceof pw.Node && b.contains(e.target); };
    const hint = s => { const h = pd.getElementById('hint'); if (h) h.textContent = s; };
    const slider = () => pd.getElementById('slider');
    const nowT = () => { const s = slider(); return s ? +s.value || 0 : 0; };
    const labelOf = el => { const f = el.firstChild; if (!f) return ''; return String(f.nodeType === 3 ? f.textContent : (f.firstChild && f.firstChild.textContent) || '').trim(); };
    const rowsOf = () => [...box.children].flatMap(el => el.classList && el.classList.contains('fxg') ? [...el.querySelector('.fxg-b').children] : [el]);

    // 存回参数：**不派发 input 事件**（工作台收到 input 会重新 init 并从 0 秒重播，关键帧就没法调了）。
    // P 就是工作台的 params（init 时按引用传进来的），直接写即可；导出照样读得到。
    const commit = () => {
      const o2 = K.read(P);
      const json = JSON.stringify({ on: o2.on, auto: o2.auto, scale: o2.scale, pos: o2.pos, ease: o2.ease, edge: o2.edge, fade: o2.fade, list: o2.list });
      P.keys = json; _raw = json;
      if (field) field.value = json;
      try { if (pw.markDirty) pw.markDirty(); } catch (e) { }
      try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }
    };
    function setKey(t, x, y, z) {
      const o2 = K.read(P);
      t = Math.max(0, r2(t));
      const hit = o2.list.find(k => Math.abs(k.t - t) < 0.04);
      // 打点时把当前这一帧的大小和位置一起记下来（所以滚轮缩放、左键拖位置都能形成关键帧）
      const rec = { t, x: r1(x), y: r1(y), z: r1(z), s: r2(clamp(num(P.scale, 1), 0.1, 5)),
        ox: Math.round(num(P.offsetX, 0)), oy: Math.round(num(P.offsetY, 0)) };
      if (hit) Object.assign(hit, rec); else o2.list.push(rec);
      o2.list.sort((a, b) => a.t - b.t);
      liveT = 0; commit(); redraw();
    }
    K.setAt = setKey;
    // 滚轮缩放 / 左键拖位置之后，由前面那一层调过来：在当前这一秒记一个关键帧
    // 任何手动操作（右键转 / 滚轮 / 左键拖）开始前：把角度、大小、位置都对齐到画面当前这一帧，
    // 并在操作期间暂停曲线（K.dragging），画面才跟手；松手打点后再恢复。
    window.__fxViewBegin = () => {
      if (K.dragging) return;
      const c = K.at(P, nowT(), dur());
      P[MAP.x] = c.x; P[MAP.y] = c.y; P[MAP.z] = c.z;
      P.scale = r2(c.s); P.offsetX = Math.round(c.ox); P.offsetY = Math.round(c.oy);
      K.dragging = true;
    };
    window.__fxViewEnd = () => { K.dragging = false; window.renderAt(nowT()); };
    window.__fxViewChanged = kind => {
      K.dragging = false;
      const o2 = K.read(P);
      if (!o2.on || !o2.auto) { window.renderAt(nowT()); return; }
      if ((kind === 'scale' && !o2.scale) || (kind === 'pos' && !o2.pos)) { window.renderAt(nowT()); return; }
      const t = nowT();
      setKey(t, num(P[MAP.x], 0), num(P[MAP.y], 0), num(P[MAP.z], 0));   // 角度就是当前帧的（begin 时已对齐）
      hint(kind === 'pos'
        ? '已在 ' + t.toFixed(2) + ' 秒记下位置关键帧：X ' + Math.round(num(P.offsetX, 0)) + '　Y ' + Math.round(num(P.offsetY, 0))
        : '已在 ' + t.toFixed(2) + ' 秒记下大小关键帧：' + Math.round(clamp(num(P.scale, 1), 0.1, 5) * 100) + '%');
      window.renderAt(t);
    };
    K.recordNow = () => {                 // 给自己接管右键的效果用（ring-carousel）
      const o2 = K.read(P); if (!o2.on || !o2.auto) return;
      const t = nowT();
      setKey(t, num(P[MAP.x], 0), num(P[MAP.y], 0), num(P[MAP.z], 0));
      hint('已在 ' + t.toFixed(2) + ' 秒记下关键帧：X ' + r1(num(P[MAP.x], 0)) + '°　Y ' + r1(num(P[MAP.y], 0)) + '°　Z ' + r1(num(P[MAP.z], 0)) + '°');
      window.renderAt(t);
    };
    // 给播放器下面那条轨道用的接口（挂在效果自己的 window 上，换效果时自动消失）
    window.__fxKeysApi = {
      get: () => K.read(P).list.map(k => ({ ...k })),
      set: list => { const o2 = K.read(P); o2.list = list.map(norm).sort((a, b) => a.t - b.t); commit(); redraw(); window.renderAt(nowT()); },
      addAt: t => { const c = K.at(P, nowT(), dur()); setKey(t, c.x, c.y, c.z); window.renderAt(nowT()); },
      enabled: () => K.read(P).on,
      total: () => dur()
    };

    // ---------- 右键拖动转 XYZ ----------
    const syncRot = () => {
      const rows = rowsOf();
      [[LB.y, MAP.y], [LB.x, MAP.x], [LB.z, MAP.z]].forEach(([lab, key]) => {
        const row = rows.find(el => labelOf(el).startsWith(lab));
        const inp = row && row.querySelector('input[type=number]');
        if (inp) { inp.value = r1(num(P[key], 0)); if (inp.__fxRange) inp.__fxRange.value = inp.value; }
      });
    };
    if (DRAG && !mounted) {
      let drag = null, raf = 0, lastRight = 0, lastXY = [0, 0];
      const zeroAll = why => {
        P[MAP.x] = 0; P[MAP.y] = 0; P[MAP.z] = 0;
        const o2 = K.read(P); if (o2.on && o2.list.length) setKey(nowT(), 0, 0, 0);
        window.renderAt(nowT()); syncRot(); hint(why);
      };
      const onCtx = e => { if (inBox(e)) e.preventDefault(); };
      const onDown = e => {
        if (!inBox(e) || e.button !== 2) return;
        e.preventDefault(); e.stopPropagation();
        const now = Date.now();
        // 浏览器的 dblclick 只对左键触发，右键没有这个事件 → 自己判断双击
        if (now - lastRight < 350 && Math.abs(e.clientX - lastXY[0]) < 6 && Math.abs(e.clientY - lastXY[1]) < 6) {
          lastRight = 0; drag = null; K.dragging = false;
          const b0 = boxOf(); if (b0) b0.style.cursor = '';
          zeroAll('三轴角度已归零'); return;
        }
        lastRight = now; lastXY = [e.clientX, e.clientY];
        window.__fxViewBegin();                    // 角度、大小、位置都从当前这一帧开始，画面不跳
        drag = { x: e.clientX, y: e.clientY, rx: num(P[MAP.x], 0), ry: num(P[MAP.y], 0), rz: num(P[MAP.z], 0), shift: e.shiftKey };
        const b = boxOf(); if (b) b.style.cursor = 'move';
      };
      const onMove = e => {
        if (!drag) return;
        e.preventDefault();
        const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (drag.shift || e.shiftKey) P[MAP.z] = r1(clamp(drag.rz + dx * 0.25, -180, 180));
        else { P[MAP.y] = r1(clamp(drag.ry + dx * 0.3, -180, 180)); P[MAP.x] = r1(clamp(drag.rx - dy * 0.3, -90, 90)); }
        if (!raf) raf = pw.requestAnimationFrame(() => { raf = 0; window.renderAt(nowT()); syncRot(); });
        hint('X 轴 ' + r1(num(P[MAP.x], 0)) + '°　Y 轴 ' + r1(num(P[MAP.y], 0)) + '°　Z 轴 ' + r1(num(P[MAP.z], 0))
          + '°　·　Shift + 右键转 Z 轴　·　右键双击归零');
      };
      const onUp = () => {
        if (!drag) return;
        drag = null; K.dragging = false;
        const b = boxOf(); if (b) b.style.cursor = '';
        const o2 = K.read(P);
        if (o2.on && o2.auto) {                    // 松手就在当前这一秒记一个关键帧
          const t = nowT();
          setKey(t, num(P[MAP.x], 0), num(P[MAP.y], 0), num(P[MAP.z], 0));
          hint('已在 ' + t.toFixed(2) + ' 秒记下关键帧：X ' + r1(num(P[MAP.x], 0)) + '°　Y ' + r1(num(P[MAP.y], 0)) + '°　Z ' + r1(num(P[MAP.z], 0)) + '°');
        }
        window.renderAt(nowT());
      };
      const onDbl = e => { if (inBox(e) && e.button === 0) setTimeout(() => zeroAll('已还原：大小、位置、角度'), 0); };
      try { if (pw.__fxRotDispose) pw.__fxRotDispose(); } catch (e) { }
      pd.addEventListener('contextmenu', onCtx, true);
      pd.addEventListener('mousedown', onDown, true);
      pd.addEventListener('mousemove', onMove, true);
      pd.addEventListener('mouseup', onUp, true);
      pd.addEventListener('dblclick', onDbl, true);
      pw.__fxRotDispose = () => {
        pd.removeEventListener('contextmenu', onCtx, true);
        pd.removeEventListener('mousedown', onDown, true);
        pd.removeEventListener('mousemove', onMove, true);
        pd.removeEventListener('mouseup', onUp, true);
        pd.removeEventListener('dblclick', onDbl, true);
        pw.__fxRotDispose = null;
      };
      mounted = true;
    }

    // ---------- 右侧面板里的「关键帧」一栏 ----------
    const jl = rowsOf().find(el => el.tagName === 'LABEL' && labelOf(el).startsWith('关键帧'));
    field = jl && jl.querySelector('input,textarea');
    if (!field) { redraw = () => { }; try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { } return; }
    if (panelBox && box.contains(panelBox)) { redraw(); try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { } return; }
    box.querySelectorAll('.kfx').forEach(x => x.remove());
    jl.style.display = 'none';

    if (!pd.getElementById('kfx-style')) {
      const st = pd.createElement('style'); st.id = 'kfx-style';
      st.textContent = '.kfx{display:block;font-size:12px;color:#999;margin-bottom:14px}'
        + '.kfx-b{margin-top:8px;padding:10px;background:#101010;border:1px solid #2c2c2c;border-radius:8px}'
        + '.kfx-top{display:flex;align-items:center;gap:8px;margin-bottom:8px}'
        + '.kfx-top>span{flex:1;color:#ccc;font-size:13px}'
        + '.kfx-seg{display:flex;background:#1d1d1d;border:1px solid #333;border-radius:6px;overflow:hidden}'
        + '.kfx-seg button{border:0;background:none;color:#aaa;padding:4px 11px;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap}'
        + '.kfx-seg button.on{background:#f28c0f;color:#000;font-weight:600}'
        + '.kfx-now{padding:7px 9px;background:#0b0b0b;border:1px solid #262626;border-radius:6px;font-size:12px;color:#bbb;line-height:1.7}'
        + '.kfx-now b{color:#f2a33d;font-weight:600}'
        + '.kfx-add{display:block;width:100%;margin-top:8px;padding:9px;font-size:13px;color:#111;border:0;border-radius:6px;cursor:pointer;font-family:inherit;font-weight:600;background:#f28c0f}'
        + '.kfx-add:hover{filter:brightness(1.08)}'
        + '.kfx-row{display:flex;align-items:center;gap:8px;margin-top:9px;color:#aaa}'
        + '.kfx-row>span{flex:1;min-width:0}'
        + '.kfx-clr{display:block;width:100%;margin-top:8px;padding:7px;font-size:12px;border-radius:6px;cursor:pointer;font-family:inherit;background:#262626;color:#bbb;border:1px solid #333}'
        + '.kfx-clr:hover{border-color:#5a1f1f;color:#fff}'
        + '.kfx-note{margin-top:7px;font-size:11.5px;color:#777;line-height:1.7}'
        + '.kfx-note b{color:#f2b56a;font-weight:500}';
      pd.head.appendChild(st);
    }
    const mk = (tag, cls, html) => { const e = pd.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
    const wrapEl = mk('div', 'kfx'); wrapEl.append('关键帧');
    const b = mk('div', 'kfx-b');
    const top = mk('div', 'kfx-top', '<span>关键帧动画</span>');
    const segOn = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    top.appendChild(segOn);
    const now = mk('div', 'kfx-now', '把进度条拖到某一秒，这里会显示那一帧的角度');
    const add = mk('button', 'kfx-add'); add.type = 'button';
    const rowAuto = mk('div', 'kfx-row', '<span>拖完自动打点</span>');
    const segAuto = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowAuto.appendChild(segAuto);
    const rowEase = mk('div', 'kfx-row', '<span>两点之间</span>');
    const segEase = mk('div', 'kfx-seg', '<button type="button" data-v="smooth">平滑</button><button type="button" data-v="linear">匀速</button>');
    rowEase.appendChild(segEase);
    const rowEdge = mk('div', 'kfx-row', '<span>关键帧之外</span>');
    const segEdge = mk('div', 'kfx-seg', '<button type="button" data-v="blend">回到默认</button><button type="button" data-v="hold">保持首尾</button>');
    rowEdge.appendChild(segEdge);
    const rowFade = mk('div', 'kfx-row', '<span>首尾衔接（秒）</span>');
    const fadeIn = mk('input'); fadeIn.type = 'number'; fadeIn.min = '0'; fadeIn.max = '10'; fadeIn.step = '0.1';
    fadeIn.style.cssText = 'width:72px;flex:none;margin:0;padding:5px 7px;text-align:right';
    rowFade.appendChild(fadeIn);
    const rowScale = mk('div', 'kfx-row', '<span>也记录大小（滚轮）</span>');
    const segScale = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowScale.appendChild(segScale);
    const rowPos = mk('div', 'kfx-row', '<span>也记录位置（左键拖）</span>');
    const segPos = mk('div', 'kfx-seg', '<button type="button" data-v="1">开</button><button type="button" data-v="0">关</button>');
    rowPos.appendChild(segPos);
    const clr = mk('button', 'kfx-clr'); clr.type = 'button'; clr.textContent = '清空全部关键帧';
    const note = mk('div', 'kfx-note');

    const applyNow = () => { liveT = 0; redraw(); commit(); window.renderAt(nowT()); };
    segOn.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).on = x.dataset.v === '1'; applyNow(); });
    segAuto.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).auto = x.dataset.v === '1'; applyNow(); });
    segEase.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).ease = x.dataset.v; applyNow(); });
    segEdge.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).edge = x.dataset.v; applyNow(); });
    segScale.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).scale = x.dataset.v === '1'; applyNow(); });
    segPos.querySelectorAll('button').forEach(x => x.onclick = () => { K.read(P).pos = x.dataset.v === '1'; applyNow(); });
    fadeIn.addEventListener('input', () => { K.read(P).fade = Math.max(0, num(fadeIn.value, 0.6)); liveT = 0; commit(); window.renderAt(nowT()); });
    add.onclick = () => { const c = K.at(P, nowT(), dur()); setKey(nowT(), c.x, c.y, c.z); window.renderAt(nowT()); };
    clr.onclick = () => { K.read(P).list = []; applyNow(); };

    redraw = function () {
      const o2 = K.read(P), t = nowT(), n = o2.list.length;
      segOn.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.on));
      segAuto.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.auto));
      segEase.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.v === o2.ease));
      segEdge.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.v === o2.edge));
      segScale.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.scale));
      segPos.querySelectorAll('button').forEach(x => x.classList.toggle('on', (x.dataset.v === '1') === !!o2.pos));
      if (pd.activeElement !== fadeIn) fadeIn.value = o2.fade;
      rowFade.style.display = o2.edge === 'blend' ? '' : 'none';
      add.textContent = '＋ 在 ' + t.toFixed(2) + ' 秒打一个关键帧';
      note.innerHTML = !o2.on
        ? '关键帧动画已关闭，现在用的是 X / Y / Z 三个固定角度。'
        : n === 0 ? '还没有关键帧。<b>把进度条拖到某一秒，在预览区按住右键转角度、滚轮缩放、或按住左键把素材拖到想要的位置，松手就自动记下这一帧</b>；播放器下面那条轨道上会出现一个点，可以框选、拖着前后移动。'
          : n + ' 个关键帧。每个点都记着<b>角度 + 大小 + 位置</b>：转一下（右键）、滚轮缩放、左键拖位置，松手都会在当前这一秒自动打点。<b>第一个点之前、最后一个点之后会回到默认值</b>，所以这个效果自带的开场和结尾原样保留；中间这一段才走你打的关键帧。点在播放器下面的轨道上，可以框选、拖动、按 Delete 删除。';
      try { if (pw.kfTrackDraw) pw.kfTrackDraw(); } catch (e) { }
    };
    let liveT = 0;
    K.live = (t, rx, ry, rz, s, R) => {
      const nn = Date.now(); if (nn - liveT < 80) return; liveT = nn;
      const o2 = K.read(P);
      now.innerHTML = '当前 <b>' + (+t).toFixed(2) + ' 秒</b>　X <b>' + r1(rx) + '°</b>　Y <b>' + r1(ry) + '°</b>　Z <b>' + r1(rz) + '°</b>'
        + (o2.scale ? '　大小 <b>' + Math.round(s * 100) + '%</b>' : '')
        + (o2.pos && R ? '　位置 <b>' + Math.round(R.ox) + ', ' + Math.round(R.oy) + '</b>' : '');
      add.textContent = '＋ 在 ' + (+t).toFixed(2) + ' 秒打一个关键帧';
    };
    b.append(top, now, add, rowAuto, rowEase, rowEdge, rowFade, rowScale, rowPos, clr, note);
    wrapEl.appendChild(b); jl.after(wrapEl);
    panelBox = wrapEl;
    redraw();
  }
})();
