/* ws-runtime.js —— 把 wallstreet-explainer skill 的场景接进效果工坊（效果名都以 ws- 开头）。
 *
 * 一个 ws- 效果 = skill 的「一镜」。effect.html 只写：
 *   WSFX.mount({
 *     demo: {...},                              // 没填参数时的示例（effect.json 的 default 也要同一套）
 *     shot: (P, T) => ({scene:'change', ...}),  // 参数 → skill 的一镜（kit/README.md 的写法）；时刻写 T(秒)，秒＝从这个片段开头算起
 *     end:  (P, n) => 秒,                       // 内容最后一个动作的时刻（不含停留）；n=数字工具
 *     marks:(P) => [{id,t,label}],               // 可选：素材时间线上的小旗子（拖旗子改那一项的「出现（秒）」）
 *     markSet:(P, id, v) => P,                   // 可选：拖完旗子写回参数
 *   });
 * 这一层负责：效果工坊接口（init / renderAt / getDuration / __fxFrameWait）、按秒生成一条小时间线（skill 只认 '@句id'）、
 *   背景开关（织物底 / 透明）、停留和退场、整体大小和偏移（offsetX / offsetY / scale，单位是 1920×1080 舞台的像素）。
 * 画面全部是 skill 原来的模板库（_shared/ws/lib），没有改写；字体和织物底图在 _shared/ws/fonts、_shared/ws/assets。
 * 页面用 <base href="../_shared/ws/">，所以这里的相对路径都从 _shared/ws/ 算起。
 */
window.WSFX = (() => {
  const num = (v, d = 0) => { const x = parseFloat(v); return Number.isFinite(x) ? x : d; };
  const list = (v, d) => { if (Array.isArray(v)) return v; try { const a = JSON.parse(v); return Array.isArray(a) ? a : d; } catch (e) { return d; } };
  const C = x => Math.max(0, Math.min(1, x));
  const eio = q => q < .5 ? 2 * q * q : 1 - Math.pow(-2 * q + 2, 2) / 2;
  const N = { num, list, C };

  function mount(def) {
    const stage = document.getElementById('stage'), world = document.getElementById('world'), frame = document.getElementById('ws-frame');
    const fit = () => { const s = Math.min(innerWidth / 1920, innerHeight / 1080); stage.style.transform = `translate(-50%,-50%) scale(${s})`;
      document.body.classList.toggle('ws-boxed', Math.abs(innerWidth / innerHeight - 16 / 9) > .02);
      const bs = document.body.style; bs.setProperty('--rx', (1152 * s).toFixed(1) + 'px'); bs.setProperty('--ry', (648 * s).toFixed(1) + 'px'); bs.setProperty('--tx', (1024 * s).toFixed(1) + 'px'); };
    addEventListener('resize', fit); fit();
    let P = {}, RAW = {}, D = 8, endT = 6, hold = 2, outDur = .5, exitOn = true, lastP = Promise.resolve(), gen = 0, ready = Promise.resolve(), built = false;

    async function build(p) {
      const my = ++gen;
      P = Object.assign({}, def.demo || {}, p || {});
      // 空着的参数就是空着（比如「打叉」空着＝不打叉），各效果自己决定空着时用什么
      document.body.classList.toggle('ws-clear', P.bg === 'clear'); document.body.classList.toggle('ws-fabric', P.bg !== 'clear');
      // 时刻：shot 里每用一次 T(秒) 就登记一句话（id k0、k1…），skill 用 '@k3' 取那一秒
      const ts = [];
      const T = s => { s = Math.max(0, num(s, 0)); let i = ts.indexOf(s); if (i < 0) { ts.push(s); i = ts.length - 1; } return '@k' + i; };
      const shot = def.shot(P, T, N);
      endT = Math.max(0.5, num(def.end ? def.end(P, N) : 4, 4));
      hold = Math.max(0, num(P.hold, 2)); outDur = Math.max(0, num(P.outDur, .5)); exitOn = P.exit !== 'off';
      D = endT + hold + (exitOn ? outDur : 0);
      const tl = { fps: 30, duration: +(D + 0.02).toFixed(3), pre: 0, title: '', inserts: [],
        beats: ts.map((s, i) => ({ id: 'k' + i, start: s, end: s + 0.01, text: '', chars: [] })) };
      if (!tl.beats.length) tl.beats.push({ id: 'k0', start: 0, end: 0.01, text: '', chars: [] });
      const url = URL.createObjectURL(new Blob([JSON.stringify(tl)], { type: 'application/json' }));
      const F = await FB.init({ timeline: url, stage: '#ws-frame', fonts: KIT.FONTS, assets: 'assets/' });
      URL.revokeObjectURL(url);
      if (my !== gen) return;
      const K = await KIT.use(F);
      if (my !== gen) return;
      await K.film([Object.assign({ says: def.says || 'ws' }, shot)]);
      await K.go();
      built = true;
    }

    function paint(t) {
      t = Math.max(0, +t || 0);
      const sc = Math.max(.1, num(P.scale, 1)), ox = num(P.offsetX, 0), oy = num(P.offsetY, 0);
      let o = 1, s = 1;
      if (exitOn && outDur > 0) { const q = eio(C((t - endT - hold) / outDur)); o = 1 - q; s = 1 - .03 * q; }
      world.style.transform = `translate(${ox}px,${oy}px) scale(${(sc * s).toFixed(4)})`;
      world.style.opacity = o.toFixed(3);
      if (!built || !window.seek) return Promise.resolve();
      return window.seek(Math.min(t, D));
    }

    window.init = p => { RAW = p || {}; ready = build(RAW).catch(e => console.error('[ws]', e)); lastP = ready.then(() => paint(0)); return lastP; };
    window.renderAt = t => { lastP = ready.then(() => paint(t)); return lastP; };
    window.__fxFrameWait = () => lastP;
    window.getDuration = () => D;
    if (def.marks) {
      window.__fxMarks = () => def.marks(P, N);
      window.__fxMarkSet = (id, v) => { const np = def.markSet(Object.assign({}, P), id, Math.round(Math.max(0, +v || 0) * 100) / 100, N);
        Object.assign(RAW, np); window.init(RAW); return num(v) + .3; };
    }
    // 不在工作台里（直接打开 effect.html 看效果）：用示例跑起来
    if (window.parent === window) window.init({});
  }
  return { mount, num, list };
})();
